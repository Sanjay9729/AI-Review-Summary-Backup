// app._index.jsx - Complete Full Code

import { useLoaderData, useFetcher } from "@remix-run/react";
import { useState, useEffect } from "react";
import {
  Page,
  Layout,
  Text,
  Card,
  BlockStack,
  DataTable,
  Badge,
  EmptyState,
  InlineStack,
  Link,
  Button,
  Collapsible,
  Spinner,
  Icon,
} from "@shopify/polaris";
import { ChevronDownIcon, ChevronUpIcon, StarFilledIcon } from "@shopify/polaris-icons";
import { TitleBar } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import {} from "./_index/aap.index.css"

// Review scraping service
async function scrapeProductReviews(productHandle) {
  const puppeteer = await import('puppeteer');
  const productUrl = `${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`;
  let reviews = [];
  let stats = {
    total: 0,
    average: 0,
    distribution: {},
    verified: 0,
    totalWithText: 0,
  };

  let browser;
  try {
    browser = await puppeteer.default.launch({ 
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();

    // Set user agent to avoid blocking
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');

    // Go to the product page
    await page.goto(productUrl, { waitUntil: 'networkidle2', timeout: 30000 });

    // Wait for Judge.me reviews to load
    try {
      await page.waitForSelector('.jdgm-rev, .jdgm-review-widget, [data-jdgm-review]', { timeout: 10000 });
    } catch (e) {
      console.log('No Judge.me reviews found on page');
    }

    // Scrape Judge.me reviews
    const scrapedReviews = await page.evaluate(() => {
      const reviewList = [];
      
      // Try different Judge.me selectors
      const reviewElements = document.querySelectorAll('.jdgm-rev, .jdgm-review-item, [data-review-id]');
      
      reviewElements.forEach((review) => {
        try {
          // Extract review data with multiple fallback selectors
          const authorEl = review.querySelector('.jdgm-rev__author, .jdgm-author, .review-author');
          const author = authorEl?.textContent?.trim() || 'Anonymous';
          
          // Extract rating (look for star elements or rating data)
          let rating = 0;
          const ratingEl = review.querySelector('.jdgm-rev__rating, .jdgm-rating, .rating, [data-rating]');
          if (ratingEl) {
            const ratingText = ratingEl.textContent || ratingEl.getAttribute('data-rating') || '';
            const ratingMatch = ratingText.match(/(\d+(?:\.\d+)?)/);
            rating = ratingMatch ? parseFloat(ratingMatch[1]) : 0;
            
            // If no numeric rating found, count star elements
            if (rating === 0) {
              const stars = ratingEl.querySelectorAll('.jdgm-star, .star-filled, .fa-star');
              rating = stars.length;
            }
          }
          
          // Extract review text
          const textEl = review.querySelector('.jdgm-rev__body, .jdgm-review-text, .review-text, .jdgm-rev__text');
          const text = textEl?.textContent?.trim() || '';
          
          // Check if verified
          const verifiedEl = review.querySelector('.jdgm-rev__verified, .jdgm-verified, .verified');
          const verified = !!verifiedEl;
          
          // Extract date
          const dateEl = review.querySelector('.jdgm-rev__timestamp, .jdgm-date, .review-date');
          const date = dateEl?.textContent?.trim() || '';
          
          // Extract title if available
          const titleEl = review.querySelector('.jdgm-rev__title, .review-title');
          const title = titleEl?.textContent?.trim() || '';
          
          if (author !== 'Anonymous' || text.length > 0) {
            reviewList.push({
              author,
              rating: Math.min(5, Math.max(0, rating)), // Ensure rating is between 0-5
              text,
              title,
              verified,
              date,
            });
          }
        } catch (err) {
          console.error('Error parsing individual review:', err);
        }
      });

      return reviewList;
    });

    // Calculate statistics
    if (scrapedReviews.length > 0) {
      const totalReviews = scrapedReviews.length;
      const averageRating = scrapedReviews.reduce((acc, review) => acc + review.rating, 0) / totalReviews;
      const distribution = scrapedReviews.reduce((acc, review) => {
        const starRating = Math.round(review.rating);
        acc[starRating] = (acc[starRating] || 0) + 1;
        return acc;
      }, {});

      const totalWithText = scrapedReviews.filter((review) => review.text.length > 0).length;
      const verifiedReviews = scrapedReviews.filter((review) => review.verified).length;

      stats = {
        total: totalReviews,
        average: Math.round(averageRating * 10) / 10,
        distribution,
        verified: verifiedReviews,
        totalWithText,
      };
    }

    reviews = scrapedReviews;
  } catch (error) {
    console.error('Error scraping reviews for', productHandle, ':', error);
  } finally {
    if (browser) await browser.close();
  }

  return {
    reviews,
    stats,
    success: reviews.length > 0,
    productHandle,
  };
}

// Loader function
export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);
  
  try {
    // Fetch all products using GraphQL
    const response = await admin.graphql(
      `#graphql
        query getProducts($first: Int!) {
          products(first: $first) {
            edges {
              node {
                id
                title
                handle
                status
                createdAt
                updatedAt
              }
            }
            pageInfo {
              hasNextPage
              endCursor
            }
          }
        }`,
      {
        variables: {
          first: 50, // Reduced from 100 for better performance with reviews
        },
      }
    );

    const responseJson = await response.json();
    
    if (responseJson.errors) {
      console.error('GraphQL Errors:', responseJson.errors);
      return {
        success: false,
        error: 'Failed to fetch products',
        products: [],
        pageInfo: {},
      };
    }

    const products = responseJson.data?.products?.edges || [];
    const pageInfo = responseJson.data?.products?.pageInfo || {};

    // Format product data
    const formattedProducts = products.map((productEdge, index) => {
      const product = productEdge.node;
      return {
        id: product.id,
        serialNumber: index + 1,
        title: product.title,
        handle: product.handle,
        status: product.status,
        createdAt: new Date(product.createdAt).toLocaleDateString('en-IN'),
        updatedAt: new Date(product.updatedAt).toLocaleDateString('en-IN'),
        shopifyAdminUrl: `shopify:admin/products/${product.id.replace("gid://shopify/Product/", "")}`,
        storeUrl: `${process.env.SHOPIFY_STORE_URL}/products/${product.handle}`,
      };
    });

    // Calculate stats
    const stats = {
      total: products.length,
      active: products.filter(p => p.node.status === 'ACTIVE').length,
      draft: products.filter(p => p.node.status === 'DRAFT').length,
      archived: products.filter(p => p.node.status === 'ARCHIVED').length,
    };

    return {
      success: true,
      products: formattedProducts,
      rawProducts: products,
      pageInfo,
      stats,
      totalCount: products.length,
    };
    
  } catch (error) {
    console.error('Error fetching products:', error);
    return {
      success: false,
      error: error.message,
      products: [],
      pageInfo: {},
      stats: { total: 0, active: 0, draft: 0, archived: 0 },
    };
  }
};

// Enhanced Reviews component with auto-refresh functionality
function ProductReviews({ productHandle }) {
  const [reviewsData, setReviewsData] = useState(null);
  const [loading, setLoading] = useState(false);
const [isOpen, setIsOpen] = useState(false);
  const [error, setError] = useState(null);
  const [debugInfo, setDebugInfo] = useState(null);
  const [aiSummary, setAiSummary] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState(null);
  const [isMobile, setIsMobile] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Detect window width on client-side
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(typeof window !== 'undefined' && window.innerWidth < 768);
    };

    handleResize();

    if (typeof window !== 'undefined') {
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }
  }, []);

  useEffect(() => {
    const fetchReviews = async () => {
      console.log(`Frontend: Fetching reviews for ${productHandle}`);
      
      try {
        setLoading(true);
        setError(null);
        
        const apiUrl = `/api/reviews/${productHandle}`;
        console.log(`Frontend: Making request to ${apiUrl}`);
        
        const response = await fetch(apiUrl);
        console.log(`Frontend: Response status: ${response.status}`);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log(`Frontend: Received data:`, {
          success: data.success,
          reviewCount: data.reviews?.length || 0,
          error: data.error,
          debugInfo: data.debugInfo
        });
        
        setReviewsData(data);
        setDebugInfo(data.debugInfo);
        setLastUpdated(data.scrapedAt || data.cachedAt);
        
        if (!data.success) {
          setError(data.error || 'Unknown error occurred');
        }

        // DISABLED: Auto-load existing AI summary to force fresh generation each time
        // if (data.success && data.reviews?.length > 0) {
        //   loadExistingAISummary();
        // }
        
      } catch (error) {
        console.error(`Frontend: Error fetching reviews for ${productHandle}:`, error);
        setError(`Network error: ${error.message}`);
        setReviewsData({ 
          reviews: [], 
          stats: { total: 0 }, 
          success: false,
          error: error.message 
        });
      } finally {
        setLoading(false);
      }
    };

    if (isOpen && !reviewsData) {
      fetchReviews();
    }
  }, [productHandle, isOpen, reviewsData]);

  // DISABLED: Load existing AI summary to force fresh generation
  const loadExistingAISummary = async () => {
    // TEMPORARILY DISABLED FOR TESTING
    console.log('Skipping existing AI summary load to ensure fresh generation');
    // try {
    //   const response = await fetch(`/api/ai-review-summary?productHandle=${productHandle}`);
    //   if (response.ok) {
    //     const data = await response.json();
    //     if (data.success) {
    //       setAiSummary(data.summary);
    //     }
    //   }
    // } catch (error) {
    //   console.log('No existing AI summary found');
    // }
  };

  // Force refresh reviews and AI summary
  const forceRefreshReviews = async () => {
    try {
      setRefreshing(true);
      setError(null);
      setAiError(null);
      
      console.log(`Force refreshing reviews for ${productHandle}`);
      
      // Call cache management API to force refresh
      const refreshResponse = await fetch('/api/cache-management', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'force-refresh',
          productHandle: productHandle
        })
      });

      if (!refreshResponse.ok) {
        throw new Error('Failed to refresh reviews');
      }

      const refreshData = await refreshResponse.json();
      
      if (refreshData.success && refreshData.data) {
        setReviewsData(refreshData.data);
        setLastUpdated(new Date().toISOString());
        
        // Auto-generate AI summary for fresh reviews
        if (refreshData.data.reviews?.length > 0) {
          console.log('Auto-generating AI summary for fresh reviews...');
          generateAISummary(true); // Force regenerate
        }
      } else {
        throw new Error(refreshData.error || 'Failed to refresh reviews');
      }
      
    } catch (error) {
      console.error(`Error refreshing reviews for ${productHandle}:`, error);
      setError(`Refresh failed: ${error.message}`);
    } finally {
      setRefreshing(false);
    }
  };

  // AI Summary Generator Function
  const generateAISummary = async (forceRegenerate = false) => {
    if (!reviewsData?.reviews || reviewsData.reviews.length === 0) {
      setAiError('No reviews available to summarize');
      return;
    }

    try {
      setAiLoading(true);
      setAiError(null);
      setAiSummary(null); // Clear existing summary first
      
      const actualReviewCount = reviewsData.reviews.length;
      const actualPlatform = reviewsData.reviewPlatform || 'Unknown';
      
      console.log(`🤖 Generating AI summary for ${productHandle}:`);
      console.log(`   - Platform: ${actualPlatform}`);
      console.log(`   - Review Count: ${actualReviewCount}`);
      console.log(`   - Force Regenerate: ${forceRegenerate}`);
      console.log(`   - Reviews:`, reviewsData.reviews.map(r => `${r.author}: ${r.rating}⭐`));
      
      const response = await fetch('/api/ai-review-summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reviews: reviewsData.reviews,
          stats: {
            ...reviewsData.stats,
            total: actualReviewCount // Ensure correct count
          },
          productHandle: productHandle,
          reviewPlatform: actualPlatform,
          forceRegenerate: true, // Always force regenerate to avoid cache conflicts
          actualReviewCount: actualReviewCount, // Pass actual count
          platformSpecific: true, // Flag for platform-specific generation
          timestamp: new Date().toISOString() // Add timestamp to prevent caching
        })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Response error:', errorText);
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const summaryData = await response.json();
      
      if (summaryData.success) {
        setAiSummary(summaryData.summary);
        console.log(`AI summary generated successfully (from cache: ${summaryData.metadata.fromCache})`);
      } else {
        throw new Error(summaryData.error || 'Failed to generate AI summary');
      }
      
    } catch (error) {
      console.error(`Error generating AI summary:`, error);
      setAiError(`Failed to generate AI summary: ${error.message}`);
    } finally {
      setAiLoading(false);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < 5; i++) {
      stars.push(
        <Icon
          key={i}
          source={StarFilledIcon}
          tone={i < fullStars || (i === fullStars && hasHalfStar) ? "warning" : "subdued"}
        />
      );
    }
    return stars;
  };

  const formatLastUpdated = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffMinutes = Math.floor((now - date) / (1000 * 60));
    
    if (diffMinutes < 1) return 'just now';
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  const hasReviews = reviewsData?.reviews?.length > 0;
  const stats = reviewsData?.stats || { total: 0, average: 0 };

  if (loading && isOpen) {
    return (
      <BlockStack gap="200">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          icon={isOpen ? ChevronUpIcon : ChevronDownIcon}
          variant="plain"
        >
          Reviews (Loading...)
        </Button>
        <Collapsible open={isOpen}>
          <Card>
            <BlockStack align="center" gap="300">
              <Spinner size="small" />
              <Text variant="bodyMd">Loading reviews for {productHandle}...</Text>
            </BlockStack>
          </Card>
        </Collapsible>
      </BlockStack>
    );
  }

  return (
    <BlockStack gap="200">
      <Button
        onClick={() => setIsOpen(!isOpen)}
        icon={isOpen ? ChevronUpIcon : ChevronDownIcon}
        variant="plain"
      >
        Reviews ({stats.total}) {stats.average > 0 && `⭐ ${stats.average}`}
      </Button>
      
      <Collapsible open={isOpen}>
        <div style={{ 
          width: '100%',
          maxWidth: '100%',
          overflow: 'hidden',
        }}>
          <Card>
            {hasReviews ? (
              <BlockStack gap="300">
                <div style={{ 
                  display: 'flex',
                  flexDirection: isMobile ? 'column' : 'row',
                  justifyContent: 'space-between',
                  alignItems: isMobile ? 'flex-start' : 'center',
                  gap: '12px',
                }}>
                  <BlockStack gap="100">
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      flexWrap: 'wrap'
                    }}>
                      <Text variant="headingMd">Customer Reviews</Text>
                      {lastUpdated && (
                        <Text variant="bodySm" tone="subdued">
                          Updated {formatLastUpdated(lastUpdated)}
                        </Text>
                      )}
                    </div>
                    <InlineStack gap="200" align="center" wrap={true}>
                      <InlineStack gap="100">
                        {renderStars(stats.average)}
                      </InlineStack>
                      <Text variant="bodyLg" fontWeight="bold">{stats.average}</Text>
                      <Text variant="bodyMd">({stats.total} reviews)</Text>
                      {/* Enhanced platform display */}
                      {reviewsData.reviewPlatforms && reviewsData.reviewPlatforms.length > 0 && (
                        <InlineStack gap="100">
                          {reviewsData.reviewPlatforms.map((platform, index) => (
                            <Badge key={index} tone="info" size="small">
                              {platform}
                            </Badge>
                          ))}
                          {reviewsData.platformInfo?.duplicatesRemoved > 0 && (
                            <Badge tone="warning" size="small">
                              {reviewsData.platformInfo.duplicatesRemoved} duplicates merged
                            </Badge>
                          )}
                        </InlineStack>
                      )}
                    </InlineStack>
                  </BlockStack>
                  <InlineStack gap="200">
                    <Badge tone={stats.verified > 0 ? "success" : "info"}>
                      {stats.verified} Verified
                    </Badge>
                    <Button
                      size="slim"
                      variant="secondary"
                      onClick={forceRefreshReviews}
                      loading={refreshing}
                      disabled={refreshing}
                    >
                      {refreshing ? 'Refreshing...' : 'Refresh'}
                    </Button>
                  </InlineStack>
                </div>

                {/* Show refresh success message */}
                {refreshing === false && lastUpdated && (
                  <div style={{ 
                    padding: '8px 12px',
                    backgroundColor: '#f0f9f0',
                    borderRadius: '6px',
                    border: '1px solid #d4edda'
                  }}>
                    <Text variant="bodySm" tone="success">
                      Reviews refreshed successfully! Latest data from website.
                    </Text>
                  </div>
                )}

                <BlockStack gap="300">
                  {reviewsData.reviews.slice(0, 3).map((review, index) => (
                    <Card key={index} background="bg-surface-secondary">
                      <BlockStack gap="200">
                        <div style={{ 
                          display: 'flex',
                          flexDirection: isMobile ? 'column' : 'row',
                          justifyContent: 'space-between',
                          alignItems: isMobile ? 'flex-start' : 'center',
                          gap: '8px',
                        }}>
                          <BlockStack gap="100">
                            <InlineStack gap="200" align="center" wrap={true}>
                              <Text 
                                variant="bodyMd" 
                                fontWeight="medium"
                                style={{ 
                                  wordBreak: 'break-word',
                                  maxWidth: isMobile ? '200px' : 'none',
                                }}
                              >
                                {review.author}
                              </Text>
                              {review.verified && (
                                <Badge size="small" tone="success">Verified</Badge>
                              )}
                              {review.platform && review.platform !== 'Unknown' && (
                                <Badge size="small" tone="info">{review.platform}</Badge>
                              )}
                            </InlineStack>
                            <InlineStack gap="100">
                              {renderStars(review.rating)}
                            </InlineStack>
                          </BlockStack>
                          <Text 
                            variant="bodyMd" 
                            tone="subdued"
                            style={{ 
                              whiteSpace: isMobile ? 'normal' : 'nowrap',
                              fontSize: isMobile ? '12px' : '14px',
                            }}
                          >
                            {review.date}
                          </Text>
                        </div>
                        
                        {review.title && (
                          <div style={{ 
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            hyphens: 'auto',
                            maxWidth: '100%',
                          }}>
                            <Text 
                              variant="bodyMd" 
                              fontWeight="medium"
                              as="div"
                            >
                              {review.title}
                            </Text>
                          </div>
                        )}
                        
                        {review.text && (
                          <div style={{ 
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            hyphens: 'auto',
                            lineHeight: '1.5',
                            maxWidth: '100%',
                            whiteSpace: 'pre-wrap',
                          }}>
                            <Text 
                              variant="bodyMd"
                              as="div"
                            >
                              {review.text}
                            </Text>
                          </div>
                        )}
                      </BlockStack>
                    </Card>
                  ))}
                  
                  {stats.total > 3 && (
                    <InlineStack align="center">
                      <Link url={`/products/${productHandle}`} external>
                        <Button variant="plain" size={isMobile ? "slim" : "medium"}>
                          View all {stats.total} reviews on store
                        </Button>
                      </Link>
                    </InlineStack>
                  )}
                </BlockStack>
                
                <BlockStack gap="300">
                  <InlineStack align="center" gap="200">
                    <Button 
                      variant="primary" 
                      onClick={() => generateAISummary(false)}
                      loading={aiLoading}
                      disabled={aiLoading || !hasReviews}
                      size={isMobile ? "slim" : "medium"}
                    >
                      {aiLoading ? 'Generating AI Summary...' : 'AI Review Generator'}
                    </Button>
                    {aiSummary && (
                      <Button 
                        variant="secondary" 
                        onClick={() => generateAISummary(true)}
                        loading={aiLoading}
                        disabled={aiLoading}
                        size={isMobile ? "slim" : "medium"}
                      >
                        Regenerate
                      </Button>
                    )}
                  </InlineStack>
                  
                  {aiSummary && (
                    <Card background="bg-surface-success">
                      <div style={{ 
                        maxWidth: '100%',
                        overflow: 'hidden',
                      }}>
                        <BlockStack gap="200">
                          <Text variant="headingMd" fontWeight="bold">
                            AI Generated Review Summary
                          </Text>
                          <div style={{ 
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            hyphens: 'auto',
                            lineHeight: '1.6',
                            maxWidth: '100%',
                            whiteSpace: 'pre-wrap',
                          }}>
                            <Text 
                              variant="bodyMd" 
                              tone="success"
                              as="div"
                            >
                              {aiSummary}
                            </Text>
                          </div>
                          <div style={{ 
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            fontSize: isMobile ? '11px' : '13px',
                            maxWidth: '100%',
                          }}>
                            <Text 
                              variant="bodySm" 
                              tone="subdued"
                              as="div"
                            >
                              Generated by AI s • Based on {reviewsData?.reviews?.length || stats.total} customer reviews • {reviewsData?.reviewPlatform || 'Unknown Platform'}
                              {reviewsData.reviewPlatforms && reviewsData.reviewPlatforms.length > 1 && (
                                ` • Multi-platform: ${reviewsData.reviewPlatforms.join(', ')}`
                              )}
                              {reviewsData.platformInfo?.duplicatesRemoved > 0 && (
                                ` • ${reviewsData.platformInfo.duplicatesRemoved} duplicates merged`
                              )}
                              • Auto-updates
                            </Text>
                          </div>
                        </BlockStack>
                      </div>
                    </Card>
                  )}
                  
                  {aiError && (
                    <Card background="bg-surface-critical">
                      <div style={{ 
                        maxWidth: '100%',
                        overflow: 'hidden',
                      }}>
                        <BlockStack gap="200">
                          <Text variant="headingMd" fontWeight="bold" tone="critical">
                            AI Summary Error
                          </Text>
                          <div style={{ 
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            maxWidth: '100%',
                            whiteSpace: 'pre-wrap',
                          }}>
                            <Text 
                              variant="bodyMd" 
                              tone="critical"
                              as="div"
                            >
                              {aiError}
                            </Text>
                          </div>
                          <InlineStack align="center">
                            <Button 
                              size="slim" 
                              variant="secondary"
                              onClick={() => {
                                setAiError(null);
                                setAiSummary(null);
                              }}
                            >
                              Clear Error
                            </Button>
                          </InlineStack>
                        </BlockStack>
                      </div>
                    </Card>
                  )}
                </BlockStack>
              </BlockStack>
            ) : (
              <BlockStack gap="300">
                <EmptyState
                  heading={error ? "Error loading reviews" : "No reviews yet"}
                  image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                >
                  {error ? (
                    <BlockStack gap="200">
                      <Text>Failed to load reviews for this product.</Text>
                      <Text 
                        variant="bodyMd" 
                        tone="subdued"
                        style={{ 
                          wordWrap: 'break-word',
                          overflowWrap: 'break-word',
                        }}
                      >
                        {error.includes('scrapeProductReviews') ? 
                          'Review scraping service is temporarily unavailable. Please try again later.' :
                          `Error: ${error}`
                        }
                      </Text>
                      <InlineStack align="center" gap="200">
                        <Button 
                          size="slim" 
                          variant="primary"
                          onClick={forceRefreshReviews}
                          loading={refreshing}
                        >
                          Try Again
                        </Button>
                        <Button 
                          size="slim" 
                          variant="secondary"
                          onClick={() => setError(null)}
                        >
                          Dismiss
                        </Button>
                      </InlineStack>
                    </BlockStack>
                  ) : (
                    <BlockStack gap="200">
                      <Text>This product hasn't received any reviews yet.</Text>
                      <Text variant="bodySm" tone="subdued">
                        Reviews will appear here once customers start leaving them on your store.
                      </Text>
                    </BlockStack>
                  )}
                </EmptyState>
              </BlockStack>
            )}
          </Card>
        </div>
      </Collapsible>
    </BlockStack>
  );
}

export default function ProductsIndex() {
  const { success, products, stats, totalCount, error } = useLoaderData();

  // Prepare data for DataTable - reviews show below product name
  const rows = products.map((product) => [
    <Text variant="bodyMd" fontWeight="medium">
      {product.serialNumber}
    </Text>,
    <div style={{ minWidth: '300px', maxWidth: '100%' }}>
      <BlockStack gap="200">
        <Link 
          url={product.shopifyAdminUrl}
          external
          removeUnderline
        >
          <Text 
            variant="bodyMd" 
            fontWeight="medium" 
            tone="magic"
            style={{ 
              wordWrap: 'break-word',
              overflowWrap: 'break-word',
              hyphens: 'auto',
            }}
          >
            {product.title}
          </Text>
        </Link>
        <ProductReviews productHandle={product.handle} />
      </BlockStack>
    </div>,
    <Badge tone={
      product.status === 'ACTIVE' ? 'success' : 
      product.status === 'DRAFT' ? 'attention' : 'critical'
    }>
      {product.status.toLowerCase()}
    </Badge>,
    <Text variant="bodyMd" style={{ whiteSpace: 'nowrap' }}>
      {product.createdAt}
    </Text>,
  ]);

  const headings = [
    '#',
    'Product Name & Reviews',
    'Status',
    'Created Date',
  ];

  if (!success) {
    return (
      <Page fullWidth>
        <div style={{ padding: '0 20px' }}>
          <TitleBar title="Products" />
          <Card>
            <EmptyState
              heading="Error loading products"
              image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
            >
              <p>{error || 'Something went wrong while fetching products.'}</p>
            </EmptyState>
          </Card>
        </div>
      </Page>
    );
  }

  return (
    <Page fullWidth>
      <div style={{ padding: '0 20px' }}>
        <TitleBar title="AI Reviews" />
        
        <BlockStack gap="500">
          <Layout>
            <Layout.Section>
              <Card>
                <BlockStack gap="500">
                  <div style={{ 
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                    gap: '16px',
                  }}>
                    <Text as="h2" variant="headingLg">
                      Products with Reviews ({totalCount})
                    </Text>
                    <InlineStack gap="200">
                      <Button onClick={() => window.location.reload()}>
                        Refresh
                      </Button>
                    </InlineStack>
                  </div>

                  {products.length === 0 ? (
                    <EmptyState
                      heading="No products found"
                      image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                    >
                      <p>No products available in your store.</p>
                    </EmptyState>
                  ) : (
                    <div style={{ 
                      overflowX: 'auto',
                      width: '100%',
                      WebkitOverflowScrolling: 'touch',
                    }}>
                      <div style={{ minWidth: '800px' }}>
                        <DataTable
                          columnContentTypes={[
                            'text',
                            'text',
                            'text',
                            'text',
                          ]}
                          headings={headings}
                          rows={rows}
                          footerContent={`Showing ${products.length} products with reviews`}
                        />
                      </div>
                    </div>
                  )}
                </BlockStack>
              </Card>
            </Layout.Section>
          </Layout>
        </BlockStack>
      </div>
    </Page>
  );
}