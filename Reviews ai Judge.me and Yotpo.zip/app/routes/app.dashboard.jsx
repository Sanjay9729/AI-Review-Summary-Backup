// // app/routes/app.dashboard.jsx
// import fs from "fs/promises";
// import path from "path";
// import { json } from "@remix-run/node";
// import { useLoaderData } from "@remix-run/react";
// import {
//   Page,
//   Layout,
//   Card,
//   IndexTable,
//   Text,
//   Badge,
//   Box,
//   InlineStack,
//   BlockStack,
// } from "@shopify/polaris";
// import ReviewCache from "../../services/reviewCache.server";
// import shopify from "../shopify.server"; // Shopify API setup

// // Cache folder path
// const CACHE_DIR = path.join(process.cwd(), "cache");

// // ---------------- Loader ----------------
// export const loader = async () => {
//   try {
//     const stats = await ReviewCache.getCacheStats();

//     const files = await fs.readdir(CACHE_DIR);
//     const aiFiles = files.filter((f) => f.startsWith("ai_summary_"));

//     const summaries = [];
//     for (const file of aiFiles) {
//       const content = await fs.readFile(path.join(CACHE_DIR, file), "utf8");
//       const data = JSON.parse(content);

//       // 👇 fallback handle from filename
//       const handleFromFile = file
//         .replace("ai_summary_", "")
//         .replace(".json", "");

//       let productTitle = handleFromFile; // default = handle string

//       try {
//         const handle = data.productHandle || handleFromFile;
//         if (handle) {
//           const admin = await shopify.admin();
//           const response = await admin.graphql(
//             `#graphql
//             query getProductTitle($handle: String!) {
//               productByHandle(handle: $handle) {
//                 title
//               }
//             }`,
//             { variables: { handle } }
//           );
//           const body = await response.json();
//           productTitle = body?.data?.productByHandle?.title || handle;
//         }
//       } catch (err) {
//         console.error("❌ Product title fetch error:", err);
//         productTitle = handleFromFile;
//       }

//       summaries.push({
//         product: productTitle,
//         summary: data.summary || "No summary",
//         updated: new Date(data.generatedAt).toLocaleDateString("en-IN", {
//           day: "numeric",
//           month: "short",
//           year: "numeric",
//         }),
//       });
//     }

//     summaries.sort((a, b) => new Date(b.updated) - new Date(a.updated));
//     const latestSummaries = summaries.slice(0, 5);

//     return json({
//       totalProducts: stats?.reviewsFiles || 0,
//       avgRating: 4.3, // TODO: calculate from reviews
//       summariesGenerated: stats?.aiFiles || 0,
//       latestSummaries,
//     });
//   } catch (err) {
//     console.error("Dashboard loader error:", err);
//     return json({
//       totalProducts: 0,
//       avgRating: 0,
//       summariesGenerated: 0,
//       latestSummaries: [],
//     });
//   }
// };

// // ---------------- Component ----------------
// export default function Dashboard() {
//   const { totalProducts, avgRating, summariesGenerated, latestSummaries } =
//     useLoaderData();

//   return (
//     <Page title="Dashboard" fullWidth>
//       <Box paddingInline="6">
//         <Layout>
//           {/* Overview Cards */}
//           <Layout.Section>
//             <InlineStack gap="400">
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">Total Products</Text>
//                   <Text variant="headingXl">{totalProducts}</Text>
//                 </BlockStack>
//               </Card>
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">Avg Rating</Text>
//                   <InlineStack gap="200" align="center">
//                     <Text variant="headingXl">{avgRating}</Text>
//                     <Badge tone="warning">★</Badge>
//                   </InlineStack>
//                 </BlockStack>
//               </Card>
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">AI Summaries</Text>
//                   <Text variant="headingXl">{summariesGenerated}</Text>
//                 </BlockStack>
//               </Card>
//             </InlineStack>
//           </Layout.Section>

//           {/* Latest Summaries Table */}
//           <Layout.Section>
//             <Card title="Latest AI Summaries">
//               {latestSummaries.length === 0 ? (
//                 <Text tone="subdued">No summaries available yet.</Text>
//               ) : (
//                 <IndexTable
//                   resourceName={{ singular: "summary", plural: "summaries" }}
//                   itemCount={latestSummaries.length}
//                   selectable={false}
//                   headings={[
//                     { title: "Product" },
//                     { title: "Summary" },
//                     { title: "Updated" },
//                   ]}
//                 >
//                   {latestSummaries.map((s, index) => (
//                     <IndexTable.Row
//                       id={index.toString()}
//                       key={index}
//                       position={index}
//                     >
//                       <IndexTable.Cell>
//                         <Text variant="bodyMd" fontWeight="bold" truncate>
//                           {s.product}
//                         </Text>
//                       </IndexTable.Cell>
//                       <IndexTable.Cell>
//                         {/* ✅ Wrap like Shopify Reviews */}
//                         <Box 
//                           as="p"
//                           overflowWrap="break-word"
//                           style={{ whiteSpace: "normal", margin: 0 }}
//                         >
//                           {s.summary}
//                         </Box>
//                       </IndexTable.Cell>
//                       <IndexTable.Cell>
//                         <Text variant="bodyMd">{s.updated}</Text>
//                       </IndexTable.Cell>
//                     </IndexTable.Row>
//                   ))}
//                 </IndexTable>
//               )}
//             </Card>
//           </Layout.Section>
//         </Layout>
//       </Box>
//     </Page>
//   );
// }


// app/routes/app.dashboard.jsx
import fs from "fs/promises";
import path from "path";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  IndexTable,
  Text,
  Badge,
  Box,
  InlineStack,
  BlockStack,
} from "@shopify/polaris";
import ReviewCache from "../../services/reviewCache.server";
import shopify from "../shopify.server"; // Shopify API setup

// Cache folder path
const CACHE_DIR = path.join(process.cwd(), "cache");

// ---------------- Loader ----------------
export const loader = async () => {
  try {
    const stats = await ReviewCache.getCacheStats();

    const files = await fs.readdir(CACHE_DIR);
    const aiFiles = files.filter((f) => f.startsWith("ai_summary_"));

    const summaries = [];
    for (const file of aiFiles) {
      const content = await fs.readFile(path.join(CACHE_DIR, file), "utf8");
      const data = JSON.parse(content);

      // 👇 fallback handle from filename
      const handleFromFile = file
        .replace("ai_summary_", "")
        .replace(".json", "");

      let productTitle = handleFromFile; // default = handle string

      try {
        const handle = data.productHandle || handleFromFile;
        if (handle) {
          const admin = await shopify.admin();
          const response = await admin.graphql(
            `#graphql
            query getProductTitle($handle: String!) {
              productByHandle(handle: $handle) {
                title
              }
            }`,
            { variables: { handle } }
          );
          const body = await response.json();
          productTitle = body?.data?.productByHandle?.title || handle;
        }
      } catch (err) {
        console.error("❌ Product title fetch error:", err);
        productTitle = handleFromFile;
      }

      summaries.push({
        product: productTitle,
        summary: data.summary || "No summary",
        updated: new Date(data.generatedAt).toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
        }),
      });
    }

    summaries.sort((a, b) => new Date(b.updated) - new Date(a.updated));
    const latestSummaries = summaries.slice(0, 5);

    return json({
      totalProducts: stats?.reviewsFiles || 0,
      avgRating: 4.3, // TODO: calculate from reviews
      summariesGenerated: stats?.aiFiles || 0,
      latestSummaries,
    });
  } catch (err) {
    console.error("Dashboard loader error:", err);
    return json({
      totalProducts: 0,
      avgRating: 0,
      summariesGenerated: 0,
      latestSummaries: [],
    });
  }
};

// ---------------- Component ----------------
export default function Dashboard() {
  const { totalProducts, avgRating, summariesGenerated, latestSummaries } =
    useLoaderData();

  return (
    <Page title="Dashboard" fullWidth>
      <Box paddingInline="6">
        <Layout>
          {/* Overview Cards */}
          <Layout.Section>
            <InlineStack gap="400">
              <Card>
                <BlockStack>
                  <Text variant="headingLg">Total Products</Text>
                  <Text variant="headingXl">{totalProducts}</Text>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack>
                  <Text variant="headingLg">Avg Rating</Text>
                  <InlineStack gap="200" align="center">
                    <Text variant="headingXl">{avgRating}</Text>
                    <Badge tone="warning">★</Badge>
                  </InlineStack>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack>
                  <Text variant="headingLg">AI Summaries</Text>
                  <Text variant="headingXl">{summariesGenerated}</Text>
                </BlockStack>
              </Card>
            </InlineStack>
          </Layout.Section>

          {/* Latest Summaries Table */}
          <Layout.Section>
            <Card title="Latest AI Summaries">
              {latestSummaries.length === 0 ? (
                <Text tone="subdued">No summaries available yet.</Text>
              ) : (
                <IndexTable
                  resourceName={{ singular: "summary", plural: "summaries" }}
                  itemCount={latestSummaries.length}
                  selectable={false}
                  headings={[
                    { title: "Product" },
                    { title: "Ai Summary Reviews" },
                    { title: "Updated" },
                  ]}
                >
                  {latestSummaries.map((s, index) => (
                    <IndexTable.Row
                      id={index.toString()}
                      key={index}
                      position={index}
                    >
                      {/* Product Column */}
                      <IndexTable.Cell>
                        <Box paddingInline="6">
                          <Text variant="bodyMd" fontWeight="bold" truncate >
                            {s.product}
                          </Text>
                        </Box>
                      </IndexTable.Cell>

                      {/* Summary Column */}
                      <IndexTable.Cell>
                        <Box
                          as="p"
                          paddingInline="6"
                          overflowWrap="break-word"
                          style={{ whiteSpace: "normal", margin: 0 }}
                        >
                          {s.summary}
                        </Box>
                      </IndexTable.Cell>

                      {/* Updated Column */}
                      <IndexTable.Cell>
                        <Box paddingInline="6">
                          <Text variant="bodyMd">{s.updated}</Text>
                        </Box>
                      </IndexTable.Cell>
                    </IndexTable.Row>
                  ))}
                </IndexTable>
              )}
            </Card>
          </Layout.Section>
        </Layout>
      </Box>
    </Page>
  );
}
