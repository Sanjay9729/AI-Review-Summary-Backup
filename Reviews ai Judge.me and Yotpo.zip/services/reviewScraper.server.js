// app/services/reviewScraper.server.js - Further Enhanced Version
import puppeteer from 'puppeteer';

const activeRequests = new Map();

async function scrapeProductReviews(productHandle) {
  console.log(`🤖 Starting review scraping for product: ${productHandle}`);

  if (activeRequests.has(productHandle)) {
    console.log(`Request for ${productHandle} already in progress, waiting...`);
    return await activeRequests.get(productHandle);
  }

  const productUrl = `https://${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`;
  console.log(`📍 Product URL: ${productUrl}`);

  let reviews = [];
  let stats = { total: 0, average: 0, distribution: {}, verified: 0, totalWithText: 0 };
  let browser = null;
  let page = null;

  const requestPromise = (async () => {
    try {
      console.log(`🚀 Launching Puppeteer browser for ${productHandle}...`);
      browser = await puppeteer.launch({
        headless: true,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-web-security",
          "--disable-features=VizDisplayCompositor",
          "--disable-background-networking",
          "--disable-background-timer-throttling",
          "--disable-renderer-backgrounding",
          "--disable-backgrounding-occluded-windows",
        ],
      });

      page = await browser.newPage();

      // Block unnecessary resources
      await page.setRequestInterception(true);
      page.on('request', (req) => {
        // Keep stylesheets so third‑party widgets (e.g., Yotpo) can render fully
        if (['image', 'font', 'media'].includes(req.resourceType())) {
          req.abort();
        } else {
          req.continue();
        }
      });

      await page.setUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      );

      console.log(`🌐 Navigating to: ${productUrl}`);
      await page.goto(productUrl, { waitUntil: "domcontentloaded", timeout: 30000 });

      console.log(`Current URL after navigation: ${page.url()}`);
      console.log(`Page title: ${await page.title()}`);

      // Check if password page
      const needsPassword = await page.evaluate(() => {
        return (
          window.location.pathname === "/password" ||
          document.querySelector('input[type="password"]') !== null
        );
      });

      if (needsPassword) {
        console.log(`🔒 Password page detected for ${productHandle}, attempting login...`);

        const passwordInput = await page.$('input[type="password"]');
        if (!passwordInput) throw new Error("Password input not found on page");

        const storePassword = process.env.SHOPIFY_STORE_PASSWORD;
        if (!storePassword) throw new Error("SHOPIFY_STORE_PASSWORD env var not set");

        await passwordInput.type(storePassword);
        await passwordInput.press("Enter");

        try {
          await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 10000 });
          console.log(`✅ Store unlocked for ${productHandle}`);
        } catch {
          console.log(`⏱️ Navigation timeout after password for ${productHandle}, continuing...`);
        }

        if (page.url().includes("/password")) {
          throw new Error("Password authentication failed - check SHOPIFY_STORE_PASSWORD");
        }

        // Re-navigate to product page after unlock
        await page.goto(productUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
      }

      console.log(`✅ Successfully reached product page: ${page.url()}`);

      // Debug: Check what's on the page first
      const pageDebug = await page.evaluate(() => {
        return {
          title: document.title,
          bodyClasses: document.body?.className || '',
          hasYotpo: !!document.querySelector('[class*="yotpo"], [id*="yotpo"]'),
          hasJudgeme: !!document.querySelector('[class*="jdgm"], [id*="jdgm"], #judgeme_product_reviews'),
          yotpoElements: document.querySelectorAll('[class*="yotpo"], [id*="yotpo"]').length,
          judgemeElements: document.querySelectorAll('[class*="jdgm"], [id*="jdgm"]').length,
          allReviewLike: document.querySelectorAll('[class*="review"], [id*="review"]').length
        };
      });
      console.log(`🔍 Page debug info:`, JSON.stringify(pageDebug, null, 2));

// Wait for review widgets to load (Judge.me or Yotpo)
      try {
        console.log(`⌛ Waiting for review widget containers...`);
        // Combined selector that targets both Judge.me and Yotpo widgets
        await page.waitForSelector('#judgeme_product_reviews, .jdgm-review-widget, .jdgm-widget, .yotpo-reviews-widget, .yotpo-review, .yotpo-reviews-container, .yotpo-text-container .yotpo-read-more-text p', { timeout: 30000 });
        console.log(`✅ Review widget container found`);

        console.log(`⌛ Additional wait for reviews to populate...`);
        await page.waitForTimeout(5000);

        // Wait for Yotpo network responses if present (helps with dynamic rendering)
        try {
          await page.waitForResponse(r => /yotpo|judgeme|review/i.test(r.url()), { timeout: 10000 });
          console.log(`✅ Found review-related network response`);
        } catch {
          console.log(`⏰ No review-related network responses detected`);
        }

        // Trigger lazy loading by scrolling through the page
        await page.evaluate(async () => {
          await new Promise((resolve) => {
            let totalHeight = 0;
            const distance = 500;
            const timer = setInterval(() => {
              const { scrollHeight } = document.documentElement;
              window.scrollBy(0, distance);
              totalHeight += distance;
              if (totalHeight >= scrollHeight - window.innerHeight) {
                clearInterval(timer);
                resolve();
              }
            }, 200);
          });
        });

        // Expand any "read more" links in common widgets prior to scraping
        const readMoreCount = await page.evaluate(() => {
          const selectors = [
            '.yotpo-read-more',
            '.yotpo-read-more-link',
            '.yotpo-read-more-text + a',
            'button[aria-expanded="false"][aria-controls*="read"]',
          ];
          let clicked = 0;
          selectors.forEach((sel) => {
            document.querySelectorAll(sel).forEach((btn) => {
              try { 
                (btn).dispatchEvent(new MouseEvent('click', { bubbles: true })); 
                clicked++;
              } catch {}
            });
          });
          return clicked;
        });
        console.log(`🔗 Clicked ${readMoreCount} read-more buttons`);

        // Small extra wait after interactions
        await page.waitForTimeout(1500);
        
        // Check which review platform is detected
        const reviewPlatform = await page.evaluate(() => {
          if (document.querySelector('.jdgm-widget, .jdgm-review-widget, #judgeme_product_reviews')) {
            return 'Judge.me';
          } else if (document.querySelector('.yotpo-reviews-widget, .yotpo-review, .yotpo-reviews-container')) {
            return 'Yotpo';
          } else {
            return 'Unknown';
          }
        });
        console.log(`🔍 Detected review platform: ${reviewPlatform}`);
      } catch (error) {
        console.log(`❌ Error waiting for review widgets: ${error.message}`);
      }

      // Log page content for debugging (truncated to avoid huge logs)
      const pageContent = await page.content();
      console.log(`📄 Page content snippet: ${pageContent.substring(0, 500)}...`);

      // Enhanced multi-platform review scraping with strategies for both Judge.me and Yotpo
      const scrapedReviews = await page.evaluate(() => {
        const reviewList = [];
        let detectedPlatforms = [];
        
        console.log('Starting to scrape reviews from all available platforms...');

        // Detect ALL available review platforms on the page
        const hasJudgeMe = document.querySelector('.jdgm-widget, .jdgm-review-widget, #judgeme_product_reviews');
        const hasYotpo = document.querySelector('.yotpo-reviews-widget, .yotpo-review, .yotpo-reviews-container');
        
        if (hasJudgeMe) detectedPlatforms.push('Judge.me');
        if (hasYotpo) detectedPlatforms.push('Yotpo');
        
        console.log(`Detected platforms: ${detectedPlatforms.join(', ')}`);
        
        // Function to extract reviews from a specific platform
        const extractReviewsFromPlatform = (platform) => {
          let reviewElements = [];
          let platformReviews = [];
          
          if (platform === 'Judge.me') {
            // Strategy 1: Standard Judge.me selectors
            reviewElements = document.querySelectorAll('.jdgm-rev, .jdgm-review, .jdgm-review-item, .jdgm-widget .review, [data-jdgm-review], .jdgm-review-widget .jdgm-rev, .jdgm-rev-widg .jdgm-rev, .jdgm-outside-widget .jdgm-rev');
            console.log(`Judge.me: Found ${reviewElements.length} reviews with standard selectors`);
          } else if (platform === 'Yotpo') {
            // Strategy 1: Yotpo specific selectors
            reviewElements = document.querySelectorAll('.yotpo-review, .yotpo-review-wrapper, [data-review-id], .yotpo-reviews-list .yotpo-review, .yotpo-text-container .yotpo-read-more-text p');
            console.log(`Yotpo: Found ${reviewElements.length} reviews with standard selectors`);
          }
          
          return { elements: reviewElements, platform };
        };
        
        // Extract reviews from all detected platforms
        let allPlatformData = [];
        detectedPlatforms.forEach(platform => {
          const platformData = extractReviewsFromPlatform(platform);
          if (platformData.elements.length > 0) {
            allPlatformData.push(platformData);
          }
        });
        
        // If no platform-specific reviews found, use fallback strategies
        if (allPlatformData.length === 0) {
          console.log('No platform-specific reviews found, using fallback strategies...');
          
          detectedPlatforms.forEach(platform => {
            let reviewElements = [];
            
            if (platform === 'Judge.me') {
              reviewElements = document.querySelectorAll('[class*="jdgm"][class*="review"], [id*="jdgm"][id*="review"], [data-review], .jdgm-rev__wrapper');
              console.log(`Judge.me Fallback: Found ${reviewElements.length} elements`);
            } else if (platform === 'Yotpo') {
              reviewElements = document.querySelectorAll('[class*="yotpo"][class*="review"], [id*="yotpo"][id*="review"], .yotpo-review-content, .yotpo-reviews-container .yotpo-review, .yotpo-text-container .yotpo-read-more-text p');
              console.log(`Yotpo Fallback: Found ${reviewElements.length} elements`);
            }
            
            if (reviewElements.length > 0) {
              allPlatformData.push({ elements: reviewElements, platform });
            }
          });
        }
        
        // Process reviews from each platform
        allPlatformData.forEach(({ elements: reviewElements, platform: reviewPlatform }) => {

          console.log(`Processing ${reviewElements.length} reviews from ${reviewPlatform}`);
          
          reviewElements.forEach((el, index) => {
          try {
            // If the element is a text paragraph inside Yotpo, use its closest review wrapper
            if (el.matches && el.matches('.yotpo-text-container .yotpo-read-more-text p')) {
              const container = el.closest('.yotpo-review, .yotpo-review-wrapper, .yotpo-text-container') || el.parentElement;
              if (container) el = container;
            }
            console.log(`Processing element ${index + 1}...`);

            // Extract author with platform-specific selectors
            let author = 'Anonymous';
            let authorSelectors = [
              // Generic selectors
              '.review-author',
              '.reviewer-name',
              '.author',
              '.customer-name',
              '[class*="author"]',
              '[class*="reviewer"]'
            ];
            
            // Add platform-specific selectors
            if (reviewPlatform === 'Judge.me') {
              authorSelectors = [
                '.jdgm-rev__author',
                '.jdgm-rev__author-wrapper',
                '.jdgm-author',
                ...authorSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              authorSelectors = [
                '.yotpo-user-name',
                '.yotpo-review-author',
                '.yotpo-user',
                '.yotpo-user-field',
                ...authorSelectors
              ];
            }

            for (const selector of authorSelectors) {
              const authorEl = el.querySelector(selector);
              if (authorEl && authorEl.textContent.trim()) {
                author = authorEl.textContent.trim();
                break;
              }
            }

            // If no author found in child, look in parent or ancestors
            if (author === 'Anonymous') {
              let currentEl = el.parentElement;
              for (let i = 0; i < 3 && currentEl; i++) { // Check up to 3 levels up
                for (const selector of authorSelectors) {
                  const authorEl = currentEl.querySelector(selector);
                  if (authorEl && authorEl.textContent.trim()) {
                    author = authorEl.textContent.trim();
                    break;
                  }
                }
                if (author !== 'Anonymous') break;
                currentEl = currentEl.parentElement;
              }
            }

            // Extract rating with multiple strategies
            let rating = 0;
            
            // Strategy 1: Look for platform-specific rating attributes
            let ratingSelectors = [
              // Generic selectors
              '[data-score]',
              '[data-rating]',
              '[data-stars]',
              '.rating',
              '.stars',
              '[aria-label*="out of 5 stars"]'
            ];
            
            // Add platform-specific selectors
            if (reviewPlatform === 'Judge.me') {
              ratingSelectors = [
                '.jdgm-rev__rating',
                '.jdgm-rev__rating-wrapper',
                ...ratingSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              ratingSelectors = [
                '.yotpo-review-stars',
                '.yotpo-stars',
                '.yotpo-stars-wrapper',
                '.yotpo-stars-wrapper [data-score]',
                '.yotpo-review-rating',
                ...ratingSelectors
              ];
            }

            for (const selector of ratingSelectors) {
              const ratingEl = el.querySelector(selector);
              if (ratingEl) {
                const dataScore = ratingEl.getAttribute('data-score');
                const dataRating = ratingEl.getAttribute('data-rating');
                const dataStars = ratingEl.getAttribute('data-stars');
                const ariaLabel = ratingEl.getAttribute('aria-label');
                
                if (dataScore) rating = parseFloat(dataScore);
                else if (dataRating) rating = parseFloat(dataRating);
                else if (dataStars) rating = parseFloat(dataStars);
                else if (ariaLabel) {
                  const match = ariaLabel.match(/(\d+(?:\.\d+)?) out of 5/);
                  if (match) rating = parseFloat(match[1]);
                }
                
                if (rating > 0) break;
              }
            }

            // Strategy 2: Count star elements
            if (rating === 0) {
              let starSelectors = [
                // Generic selectors
                '.star-filled',
                '.fa-star.filled',
                '.star.active',
                '[class*="star"][class*="filled"]',
                '[class*="star"][class*="active"]',
                '[class*="star"][class*="on"]'
              ];
              
              // Add platform-specific selectors
              if (reviewPlatform === 'Judge.me') {
                starSelectors = [
                  '.jdgm-star.jdgm--on',
                  '.jdgm-star.jdgm-star--on',
                  ...starSelectors
                ];
              } else if (reviewPlatform === 'Yotpo') {
                starSelectors = [
                  '.yotpo-icon-star',
                  '.yotpo-star-full',
                  '.yotpo-icon-full-star',
                  '.yotpo-icon-default-full-star',
                  '.yotpo-icon.yotpo-icon-star.pull-left',
                  ...starSelectors
                ];
              }

              for (const selector of starSelectors) {
                const stars = el.querySelectorAll(selector);
                if (stars.length > 0) {
                  rating = stars.length;
                  break;
                }
              }
            }

            // Strategy 3: Look for rating in text content
            if (rating === 0) {
              const text = el.textContent || '';
              const ratingMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/|\s)\s*5|5\s*(?:out of|\/|\s)\s*(\d+(?:\.\d+)?)/);
              if (ratingMatch) {
                rating = parseFloat(ratingMatch[1] || ratingMatch[2]);
              }
            }

            // Extract review text with platform-specific selectors
            let text = '';
            let textSelectors = [
              // Generic selectors
              '.review-text',
              '.review-content',
              '.comment',
              '[class*="review"][class*="text"]',
              '[class*="review"][class*="body"]',
              '[class*="review"][class*="content"]',
              '[class*="comment"]'
            ];
            
            // Add platform-specific selectors
            if (reviewPlatform === 'Judge.me') {
              textSelectors = [
                '.jdgm-rev__body',
                '.jdgm-rev__content',
                '.jdgm-rev__text',
                '.jdgm-rev__review-text',
                ...textSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              textSelectors = [
                // Most specific match from screenshot: paragraph inside read-more within text container
                '.yotpo-text-container .yotpo-read-more-text p',
                // Close fallbacks for robustness
                '.yotpo-read-more-text p',
                '.yotpo-text-container p',
                '.yotpo-review-content p',
                // Existing selectors
                '.yotpo-review-content',
                '.content-review',
                '.yotpo-review-text',
                '.yotpo-text-container',
                '.yotpo-read-more-text',
                '.yotpo-review-content',
                ...textSelectors
              ];
            }

            for (const selector of textSelectors) {
              const textEl = el.querySelector(selector);
              if (textEl && textEl.textContent.trim().length > 10) {
                text = textEl.textContent.trim();
                break;
              }
            }

            // If no specific text element, use element's own text (filtered)
            if (!text) {
              const elementText = el.textContent || '';
              if (elementText.length > 50 && elementText.length < 2000 && 
                  !elementText.toLowerCase().includes('write a review') &&
                  !elementText.toLowerCase().includes('load more')) {
                text = elementText.trim();
              }
            }

            // Extract title with platform-specific selectors
            let title = '';
            let titleSelectors = [
              // Generic selectors
              '.review-title',
              '.title',
              'h3', 'h4', 'h5'
            ];
            
            // Add platform-specific selectors
            if (reviewPlatform === 'Judge.me') {
              titleSelectors = [
                '.jdgm-rev__title',
                '.jdgm-review-title',
                ...titleSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              titleSelectors = [
                '.yotpo-review-title',
                '.content-title',
                '.yotpo-review-content .content-title',
                ...titleSelectors
              ];
            }

            for (const selector of titleSelectors) {
              const titleEl = el.querySelector(selector);
              if (titleEl && titleEl.textContent.trim()) {
                title = titleEl.textContent.trim();
                break;
              }
            }

            // Check if verified with platform-specific indicators
            let verifiedSelectors = [
              '.verified',
              '[class*="verified"]'
            ];
            
            if (reviewPlatform === 'Judge.me') {
              verifiedSelectors = [
                '.jdgm-rev__verified',
                '.jdgm-rev__buyer-badge',
                '.jdgm-verified',
                '.jdgm-verified-badge',
                ...verifiedSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              verifiedSelectors = [
                '.yotpo-verified-buyer',
                '.verified-buyer',
                '.yotpo-user-verified',
                ...verifiedSelectors
              ];
            }
            
            const verified = !!(
              verifiedSelectors.some(selector => el.querySelector(selector)) ||
              (el.textContent && el.textContent.includes('Verified'))
            );

            // Extract date with platform-specific selectors
            let date = '';
            let dateSelectors = [
              // Generic selectors
              '.review-date',
              '.date',
              '[class*="date"]',
              '[class*="time"]',
              '[data-date]'
            ];
            
            // Add platform-specific selectors
            if (reviewPlatform === 'Judge.me') {
              dateSelectors = [
                '.jdgm-rev__timestamp',
                '.jdgm-rev__published-date',
                ...dateSelectors
              ];
            } else if (reviewPlatform === 'Yotpo') {
              dateSelectors = [
                '.yotpo-review-date',
                '.yotpo-review-time',
                '.yotpo-header-element [data-type="date"]',
                ...dateSelectors
              ];
            }

            for (const selector of dateSelectors) {
              const dateEl = el.querySelector(selector);
              if (dateEl && dateEl.textContent.trim()) {
                date = dateEl.textContent.trim();
                break;
              }
            }

            console.log(`📝 Extracted data for review ${index + 1}: ${JSON.stringify({
              author: author.substring(0, 20),
              rating,
              textLength: text.length,
              title: title.substring(0, 20),
              verified,
              date
            })}`);

            // Only add if we have meaningful data
            if (text.length > 10 || rating > 0 || author !== 'Anonymous') {
              reviewList.push({
                id: `${reviewPlatform.toLowerCase()}_${index}`,
                author,
                rating: Math.min(5, Math.max(0, rating)),
                text,
                title,
                verified,
                date,
                platform: reviewPlatform,  // Add platform information to each review
                platformSpecificId: index,
                extractedFrom: reviewPlatform
              });
            }
          } catch (err) {
            console.error(`❌ Error parsing review ${index} from ${reviewPlatform}:`, err);
          }
          });  // End of reviewElements.forEach
        });  // End of allPlatformData.forEach

        // Deduplication logic for multi-platform reviews
        const deduplicatedReviews = [];
        const seenReviews = new Set();
        
        console.log(`Raw reviews extracted: ${reviewList.length}`);
        
        // Helper function to create a review signature for comparison
        const createReviewSignature = (review) => {
          // Normalize text for comparison (remove extra spaces, convert to lowercase)
          const normalizedText = (review.text || '').toLowerCase().replace(/\s+/g, ' ').trim();
          const normalizedAuthor = (review.author || '').toLowerCase().trim();
          
          // Create a signature based on author, rating, and partial text
          return `${normalizedAuthor}_${review.rating}_${normalizedText.substring(0, 100)}`;
        };
        
        // Group reviews by signature to identify potential duplicates
        const reviewGroups = new Map();
        
        reviewList.forEach(review => {
          const signature = createReviewSignature(review);
          
          if (!reviewGroups.has(signature)) {
            reviewGroups.set(signature, []);
          }
          reviewGroups.get(signature).push(review);
        });
        
        // Process each group - keep the most complete review from each group
        reviewGroups.forEach((reviews, signature) => {
          if (reviews.length === 1) {
            // Single review - no duplicates
            deduplicatedReviews.push(reviews[0]);
          } else {
            // Multiple reviews with same signature - select the best one
            console.log(`Found ${reviews.length} similar reviews from platforms: ${reviews.map(r => r.platform).join(', ')}`);
            
            // Priority: 1. Longest text, 2. Has title, 3. Is verified, 4. Judge.me over Yotpo
            const bestReview = reviews.reduce((best, current) => {
              const bestScore = (
                (best.text?.length || 0) * 2 +
                (best.title ? 10 : 0) +
                (best.verified ? 5 : 0) +
                (best.platform === 'Judge.me' ? 3 : 0)
              );
              
              const currentScore = (
                (current.text?.length || 0) * 2 +
                (current.title ? 10 : 0) +
                (current.verified ? 5 : 0) +
                (current.platform === 'Judge.me' ? 3 : 0)
              );
              
              return currentScore > bestScore ? current : best;
            });
            
            // Add platform information about duplicates
            bestReview.duplicateOnPlatforms = reviews.map(r => r.platform).filter((p, i, arr) => arr.indexOf(p) === i);
            bestReview.isDuplicate = true;
            
            deduplicatedReviews.push(bestReview);
          }
        });
        
        console.log(`After deduplication: ${deduplicatedReviews.length} unique reviews`);
        
        // Add platform summary information
        const platformSummary = {
          detectedPlatforms: detectedPlatforms,
          totalReviewsFound: reviewList.length,
          uniqueReviewsAfterDeduplication: deduplicatedReviews.length,
          duplicatesRemoved: reviewList.length - deduplicatedReviews.length
        };
        
        return {
          reviews: deduplicatedReviews,
          platformInfo: platformSummary,
          allPlatforms: detectedPlatforms
        };
      });

      // Handle the new return format from enhanced scraping
      const scrapingResult = scrapedReviews;
      reviews = scrapingResult.reviews || [];
      const platformInfo = scrapingResult.platformInfo || {};
      const allPlatforms = scrapingResult.allPlatforms || ['Unknown'];

      console.log(`📊 Platform Summary:`, JSON.stringify(platformInfo, null, 2));
      console.log(`📊 Extracted ${reviews.length} unique reviews for ${productHandle}`);

      // Calculate enhanced stats with multi-platform information
      if (reviews.length > 0) {
        const avg = reviews.reduce((acc, r) => acc + (r.rating || 0), 0) / reviews.length;
        const duplicateCount = reviews.filter((r) => r.isDuplicate).length;
        
        // Calculate platform distribution from reviews
        const platformCounts = reviews.reduce((acc, review) => {
          const platforms = review.duplicateOnPlatforms || [review.platform];
          platforms.forEach(platform => {
            if (platform) {
              acc[platform] = (acc[platform] || 0) + 1;
            }
          });
          return acc;
        }, {});

        stats = {
          total: reviews.length,
          average: Math.round(avg * 10) / 10,
          verified: reviews.filter((r) => r.verified).length,
          totalWithText: reviews.filter((r) => r.text && r.text.length > 0).length,
          distribution: reviews.reduce((acc, r) => {
            const star = Math.round(r.rating);
            acc[star] = (acc[star] || 0) + 1;
            return acc;
          }, {}),
          duplicatesFound: duplicateCount,
          platformCounts,
          rawReviewsScraped: platformInfo.totalReviewsFound || reviews.length,
          platformsDetected: allPlatforms
        };
      }

      // Determine primary platform for backward compatibility
      const primaryPlatform = allPlatforms.length > 0 ? allPlatforms[0] : 'Unknown';
      const allPlatformsDetected = allPlatforms.length > 1 ? allPlatforms : [primaryPlatform];
      
      const result = {
        success: reviews.length > 0,
        reviews,
        stats,
        productHandle,
        scrapedAt: new Date().toISOString(),
        reviewPlatform: primaryPlatform, // Backward compatibility
        reviewPlatforms: allPlatformsDetected, // New: all detected platforms
        platformInfo: platformInfo, // Detailed platform information
        debugInfo: { 
          productUrl, 
          reviewCount: reviews.length,
          reviewPlatform: primaryPlatform,
          allPlatformsDetected: allPlatformsDetected,
          rawReviewsScraped: platformInfo.totalReviewsFound || reviews.length,
          duplicatesRemoved: platformInfo.duplicatesRemoved || 0,
          scrapingStrategies: 4,
          finalStats: stats,
          multiPlatformMode: allPlatforms.length > 1
        },
      };

      return result;

    } catch (err) {
      console.error(`❌ Scraping error for ${productHandle}: ${err.message}`);
      return {
        success: false,
        reviews: [],
        stats,
        error: err.message,
        productHandle,
        scrapedAt: new Date().toISOString(),
      };
    } finally {
      if (page) await page.close().catch(() => {});
      if (browser) await browser.close().catch(() => {});
      activeRequests.delete(productHandle);
    }
  })();

  activeRequests.set(productHandle, requestPromise);

  return await requestPromise;
}

export default { scrapeProductReviews };