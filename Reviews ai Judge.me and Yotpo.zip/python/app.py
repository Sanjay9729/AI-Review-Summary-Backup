# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import sqlite3
# from datetime import datetime

# app = Flask(__name__)
# CORS(app)

# DB_FILE = "reviews.db"

# # -------------------------------
# # Init DB (reviews + summaries)
# # -------------------------------
# def init_db():
#     conn = sqlite3.connect(DB_FILE)
#     cur = conn.cursor()

#     # Reviews Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS reviews (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         author TEXT,
#         title TEXT,
#         body TEXT,   -- 👈 fixed: correct column name
#         rating REAL,
#         review_date TEXT,
#         verified INTEGER,
#         url TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     # AI Summaries Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS ai_summaries (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         summary TEXT,
#         model TEXT,
#         reviews_analyzed INTEGER,
#         total_reviews INTEGER,
#         average_rating REAL,
#         from_cache INTEGER,
#         generated_at TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     conn.commit()
#     conn.close()
#     print("✅ Tables ensured (reviews, ai_summaries)")


# # -------------------------------
# # POST: Save Reviews
# # -------------------------------
# @app.route("/save-reviews", methods=["POST"])
# def save_reviews():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         reviews = data.get("reviews", [])

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         for review in reviews:
#             # 👇 mapping added: use "text" from request and store into "body" column
#             body = review.get("text") or review.get("body")

#             cur.execute("""
#                 INSERT INTO reviews 
#                 (product_id, product_handle, author, title, body, rating, review_date, verified, url) 
#                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#             """, (
#                 product_id,
#                 product_handle,
#                 review.get("author"),
#                 review.get("title"),
#                 body,
#                 review.get("rating"),
#                 review.get("date"),
#                 int(review.get("verified", False)),
#                 review.get("url")
#             ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"Saved {len(reviews)} reviews for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # POST: Save AI Summary
# # -------------------------------
# @app.route("/save-summary", methods=["POST"])
# def save_summary():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         summary = data.get("summary")
#         model = data.get("model")
#         reviews_analyzed = data.get("reviewsAnalyzed")
#         total_reviews = data.get("totalReviews")
#         average_rating = data.get("averageRating")
#         from_cache = int(data.get("fromCache", False))
#         generated_at = data.get("generatedAt", datetime.utcnow().isoformat())

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         cur.execute("""
#             INSERT INTO ai_summaries 
#             (product_id, product_handle, summary, model, reviews_analyzed, total_reviews, average_rating, from_cache, generated_at)
#             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#         """, (
#             product_id,
#             product_handle,
#             summary,
#             model,
#             reviews_analyzed,
#             total_reviews,
#             average_rating,
#             from_cache,
#             generated_at
#         ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"AI summary saved for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # GET: Fetch All Reviews
# # -------------------------------
# @app.route("/reviews/all", methods=["GET"])
# def get_all_reviews():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM reviews ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         reviews = []
#         for row in rows:
#             reviews.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "author": row[3],
#                 "title": row[4],
#                 "body": row[5],   # 👈 changed to body
#                 "rating": row[6],
#                 "date": row[7],
#                 "verified": bool(row[8]),
#                 "url": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "reviews": reviews})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # GET: Fetch All Summaries
# # -------------------------------
# @app.route("/summaries/all", methods=["GET"])
# def get_all_summaries():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM ai_summaries ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         summaries = []
#         for row in rows:
#             summaries.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "summary": row[3],
#                 "model": row[4],
#                 "reviewsAnalyzed": row[5],
#                 "totalReviews": row[6],
#                 "averageRating": row[7],
#                 "fromCache": bool(row[8]),
#                 "generatedAt": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "summaries": summaries})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # Run App
# # -------------------------------
# if __name__ == "__main__":
#     init_db()
#     app.run(host="0.0.0.0", port=5001, debug=True)


# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import sqlite3
# from datetime import datetime

# app = Flask(__name__)
# CORS(app)

# DB_FILE = "reviews.db"

# # -------------------------------
# # Init DB (reviews + summaries)
# # -------------------------------
# def init_db():
#     conn = sqlite3.connect(DB_FILE)
#     cur = conn.cursor()

#     # Reviews Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS reviews (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         author TEXT,
#         title TEXT,
#         body TEXT,
#         rating REAL,
#         date TEXT,
#         verified INTEGER,
#         url TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     # AI Summaries Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS ai_summaries (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         summary TEXT,
#         model TEXT,
#         reviews_analyzed INTEGER,
#         total_reviews INTEGER,
#         average_rating REAL,
#         from_cache INTEGER,
#         generated_at TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     conn.commit()
#     conn.close()
#     print("✅ Tables ensured (reviews, ai_summaries)")


# # -------------------------------
# # POST: Save Reviews
# # -------------------------------
# @app.route("/save-reviews", methods=["POST"])
# def save_reviews():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         reviews = data.get("reviews", [])

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         for review in reviews:
#             body = review.get("body") or review.get("text")  # Map text → body if needed
#             cur.execute("""
#                 INSERT INTO reviews 
#                 (product_id, product_handle, author, title, body, rating, date, verified, url) 
#                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#             """, (
#                 product_id,
#                 product_handle,
#                 review.get("author"),
#                 review.get("title"),
#                 body,
#                 review.get("rating"),
#                 review.get("date"),
#                 int(review.get("verified", False)),
#                 review.get("url")
#             ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"Saved {len(reviews)} reviews for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # POST: Save AI Summary
# # -------------------------------
# @app.route("/save-summary", methods=["POST"])
# def save_summary():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         summary = data.get("summary")
#         model = data.get("model")
#         reviews_analyzed = data.get("reviewsAnalyzed")
#         total_reviews = data.get("totalReviews")
#         average_rating = data.get("averageRating")
#         from_cache = int(data.get("fromCache", False))
#         generated_at = data.get("generatedAt", datetime.utcnow().isoformat())

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         cur.execute("""
#             INSERT INTO ai_summaries 
#             (product_id, product_handle, summary, model, reviews_analyzed, total_reviews, average_rating, from_cache, generated_at)
#             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#         """, (
#             product_id,
#             product_handle,
#             summary,
#             model,
#             reviews_analyzed,
#             total_reviews,
#             average_rating,
#             from_cache,
#             generated_at
#         ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"AI summary saved for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # GET: Fetch All Reviews
# # -------------------------------
# @app.route("/reviews/all", methods=["GET"])
# def get_all_reviews():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM reviews ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         reviews = []
#         for row in rows:
#             reviews.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "author": row[3],
#                 "title": row[4],
#                 "body": row[5],
#                 "rating": row[6],
#                 "date": row[7],
#                 "verified": bool(row[8]),
#                 "url": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "reviews": reviews})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # GET: Fetch Latest 100 Reviews
# # -------------------------------
# @app.route("/reviews/latest", methods=["GET"])
# def get_latest_reviews():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM reviews ORDER BY created_at DESC LIMIT 100")
#         rows = cur.fetchall()
#         conn.close()

#         reviews = []
#         for row in rows:
#             reviews.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "author": row[3],
#                 "title": row[4],
#                 "body": row[5],
#                 "rating": row[6],
#                 "date": row[7],
#                 "verified": bool(row[8]),
#                 "url": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "reviews": reviews})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # GET: Fetch All Summaries
# # -------------------------------
# @app.route("/summaries/all", methods=["GET"])
# def get_all_summaries():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM ai_summaries ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         summaries = []
#         for row in rows:
#             summaries.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "summary": row[3],
#                 "model": row[4],
#                 "reviewsAnalyzed": row[5],
#                 "totalReviews": row[6],
#                 "averageRating": row[7],
#                 "fromCache": bool(row[8]),
#                 "generatedAt": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "summaries": summaries})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500


# # -------------------------------
# # Run App
# # -------------------------------
# if __name__ == "__main__":
#     init_db()
#     app.run(host="0.0.0.0", port=5001, debug=True)

# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import sqlite3
# from datetime import datetime
# from apscheduler.schedulers.background import BackgroundScheduler

# app = Flask(__name__)
# app.url_map.strict_slashes = False   # 👈 Add this line here
# CORS(app)
# # 👇 Slash issue fix
# app.url_map.strict_slashes = False

# DB_FILE = "reviews.db"

# # -------------------------------
# # Init DB (reviews + summaries)
# # -------------------------------
# def init_db():
#     conn = sqlite3.connect(DB_FILE)
#     cur = conn.cursor()

#     # Reviews Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS reviews (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         author TEXT,
#         title TEXT,
#         body TEXT,
#         rating REAL,
#         review_date TEXT,
#         verified INTEGER,
#         url TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     # AI Summaries Table
#     cur.execute("""
#     CREATE TABLE IF NOT EXISTS ai_summaries (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         product_id TEXT,
#         product_handle TEXT,
#         summary TEXT,
#         model TEXT,
#         reviews_analyzed INTEGER,
#         total_reviews INTEGER,
#         average_rating REAL,
#         from_cache INTEGER,
#         generated_at TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)

#     conn.commit()
#     conn.close()
#     print("✅ Tables ensured (reviews, ai_summaries)")

# # -------------------------------
# # POST: Save Reviews
# # -------------------------------
# @app.route("/save-reviews", methods=["POST"])
# def save_reviews():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         reviews = data.get("reviews", [])

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         for review in reviews:
#             body = review.get("body") or review.get("text")  # map text → body
#             cur.execute("""
#                 INSERT INTO reviews 
#                 (product_id, product_handle, author, title, body, rating, review_date, verified, url) 
#                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#             """, (
#                 product_id,
#                 product_handle,
#                 review.get("author"),
#                 review.get("title"),
#                 body,
#                 review.get("rating"),
#                 review.get("date"),
#                 int(review.get("verified", False)),
#                 review.get("url")
#             ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"Saved {len(reviews)} reviews for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # POST: Save AI Summary
# # -------------------------------
# @app.route("/save-summary", methods=["POST"])
# def save_summary():
#     try:
#         data = request.json
#         product_id = data.get("productId")
#         product_handle = data.get("productHandle")
#         summary = data.get("summary")
#         model = data.get("model")
#         reviews_analyzed = data.get("reviewsAnalyzed")
#         total_reviews = data.get("totalReviews")
#         average_rating = data.get("averageRating")
#         from_cache = int(data.get("fromCache", False))
#         generated_at = data.get("generatedAt", datetime.utcnow().isoformat())

#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()

#         cur.execute("""
#             INSERT INTO ai_summaries 
#             (product_id, product_handle, summary, model, reviews_analyzed, total_reviews, average_rating, from_cache, generated_at)
#             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#         """, (
#             product_id,
#             product_handle,
#             summary,
#             model,
#             reviews_analyzed,
#             total_reviews,
#             average_rating,
#             from_cache,
#             generated_at
#         ))

#         conn.commit()
#         conn.close()

#         return jsonify({"success": True, "message": f"AI summary saved for {product_handle}"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # GET: Fetch All Reviews
# # -------------------------------
# @app.route("/reviews/all", methods=["GET"])
# def get_all_reviews():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM reviews ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         reviews = []
#         for row in rows:
#             reviews.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "author": row[3],
#                 "title": row[4],
#                 "body": row[5],
#                 "rating": row[6],
#                 "date": row[7],
#                 "verified": bool(row[8]),
#                 "url": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "reviews": reviews})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # GET: Fetch Latest 100 Reviews
# # -------------------------------
# @app.route("/reviews/latest", methods=["GET"])
# def get_latest_reviews():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM reviews ORDER BY created_at DESC LIMIT 100")
#         rows = cur.fetchall()
#         conn.close()

#         reviews = []
#         for row in rows:
#             reviews.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "author": row[3],
#                 "title": row[4],
#                 "body": row[5],
#                 "rating": row[6],
#                 "date": row[7],
#                 "verified": bool(row[8]),
#                 "url": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "reviews": reviews})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # GET: Fetch All Summaries
# # -------------------------------
# @app.route("/summaries/all", methods=["GET"])
# def get_all_summaries():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM ai_summaries ORDER BY created_at DESC")
#         rows = cur.fetchall()
#         conn.close()

#         summaries = []
#         for row in rows:
#             summaries.append({
#                 "id": row[0],
#                 "productId": row[1],
#                 "productHandle": row[2],
#                 "summary": row[3],
#                 "model": row[4],
#                 "reviewsAnalyzed": row[5],
#                 "totalReviews": row[6],
#                 "averageRating": row[7],
#                 "fromCache": bool(row[8]),
#                 "generatedAt": row[9],
#                 "createdAt": row[10],
#             })

#         return jsonify({"success": True, "summaries": summaries})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # Scheduler Job Function
# # -------------------------------
# def job_scrape_and_save():
#     print("⚡ Running scheduled scrape + save task at", datetime.utcnow().isoformat())
#     conn = sqlite3.connect(DB_FILE)
#     cur = conn.cursor()
#     cur.execute("""
#         INSERT INTO reviews 
#         (product_id, product_handle, author, title, body, rating, review_date, verified, url)
#         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#     """, (
#         "demo-999",
#         "demo-product",
#         "SchedulerBot",
#         "Auto Review",
#         "This review was auto-scraped by scheduler.",
#         4.5,
#         datetime.utcnow().isoformat(),
#         1,
#         "http://example.com/demo-product"
#     ))

#     cur.execute("""
#         INSERT INTO ai_summaries 
#         (product_id, product_handle, summary, model, reviews_analyzed, total_reviews, average_rating, from_cache, generated_at)
#         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
#     """, (
#         "demo-999",
#         "demo-product",
#         "Auto-generated summary by scheduler.",
#         "scheduler-bot",
#         1,
#         1,
#         4.5,
#         0,
#         datetime.utcnow().isoformat()
#     ))

#     conn.commit()
#     conn.close()
#     print("✅ Scheduler inserted demo review & summary")

# # -------------------------------
# # Manual Trigger: Scrape Now
# # -------------------------------
# @app.route("/scrape-now", methods=["POST"])
# def scrape_now():
#     try:
#         job_scrape_and_save()
#         return jsonify({"success": True, "message": "Scrape + Save triggered manually"})
#     except Exception as e:
#         return jsonify({"success": False, "error": str(e)}), 500

# # -------------------------------
# # Run App + Scheduler
# # -------------------------------
# if __name__ == "__main__":
#     init_db()

#     scheduler = BackgroundScheduler()
#     scheduler.add_job(job_scrape_and_save, "interval", days=1)  # 🔥 daily scrape
#     scheduler.start()

#     print(app.url_map)   # <-- Yeh line scheduler.start() ke saath hi level me
#     app.run(host="0.0.0.0", port=5001, debug=True)


from flask import Flask, request, jsonify
from flask_cors import CORS
from db_service import init_db, insert_review, insert_summary, DB_FILE
import sqlite3
from datetime import datetime

app = Flask(__name__)
CORS(app)
app.url_map.strict_slashes = False


@app.route("/save-reviews", methods=["POST"])
def save_reviews():
    try:
        data = request.json
        product_id = data.get("productId")
        product_handle = data.get("productHandle")
        reviews = data.get("reviews", [])

        for review in reviews:
            insert_review(product_id, product_handle, review)

        return jsonify({"success": True, "message": f"Saved {len(reviews)} reviews for {product_handle}"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/save-summary", methods=["POST"])
def save_summary():
    try:
        data = request.json
        insert_summary(data)
        return jsonify({"success": True, "message": f"AI summary saved for {data.get('productHandle')}"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/reviews/all", methods=["GET"])
def get_all_reviews():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT * FROM reviews ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()

    reviews = [{
        "id": r[0], "productId": r[1], "productHandle": r[2], "author": r[3],
        "title": r[4], "body": r[5], "rating": r[6], "date": r[7],
        "verified": bool(r[8]), "url": r[9], "createdAt": r[10]
    } for r in rows]

    return jsonify({"success": True, "reviews": reviews})


@app.route("/summaries/all", methods=["GET"])
def get_all_summaries():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT * FROM ai_summaries ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()

    summaries = [{
        "id": s[0], "productId": s[1], "productHandle": s[2], "summary": s[3],
        "model": s[4], "reviewsAnalyzed": s[5], "totalReviews": s[6],
        "averageRating": s[7], "fromCache": bool(s[8]),
        "generatedAt": s[9], "createdAt": s[10]
    } for s in rows]

    return jsonify({"success": True, "summaries": summaries})


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5001, debug=True)
