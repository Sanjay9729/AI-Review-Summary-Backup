// test-multi-platform.js - Test the enhanced multi-platform review system

import reviewScraper from './services/reviewScraper.server.js';
const { scrapeProductReviews } = reviewScraper;
import ReviewCache from './services/reviewCache.server.js';

async function testMultiPlatformReviews() {
  console.log('🧪 Testing Multi-Platform Review System');
  console.log('=====================================');
  
  // Test product handle - adjust based on your store
  const productHandle = 'classic-cotton-t-shirt';
  
  try {
    // Clear cache to ensure fresh scraping
    await ReviewCache.clear(productHandle);
    console.log('🗑️ Cleared cache for fresh test');
    
    // Test 1: Scrape reviews
    console.log('\n📊 Test 1: Scraping reviews from all platforms...');
    const results = await scrapeProductReviews(productHandle);
    
    console.log('Results Summary:');
    console.log('- Success:', results.success);
    console.log('- Reviews found:', results.reviews?.length || 0);
    console.log('- Platforms detected:', results.reviewPlatforms || [results.reviewPlatform]);
    console.log('- Multi-platform mode:', results.debugInfo?.multiPlatformMode || false);
    
    if (results.platformInfo) {
      console.log('\nPlatform Details:');
      console.log('- Total raw reviews scraped:', results.platformInfo.totalReviewsFound);
      console.log('- Unique reviews after deduplication:', results.platformInfo.uniqueReviewsAfterDeduplication);
      console.log('- Duplicates removed:', results.platformInfo.duplicatesRemoved);
    }
    
    if (results.stats?.platformCounts) {
      console.log('\nPlatform Distribution:');
      Object.entries(results.stats.platformCounts).forEach(([platform, count]) => {
        console.log(`- ${platform}: ${count} reviews`);
      });
    }
    
    // Test 2: Show sample reviews with platform information
    if (results.reviews && results.reviews.length > 0) {
      console.log('\n📝 Sample Reviews:');
      results.reviews.slice(0, 3).forEach((review, index) => {
        console.log(`\nReview ${index + 1}:`);
        console.log(`- Author: ${review.author}`);
        console.log(`- Rating: ${review.rating}/5`);
        console.log(`- Platform: ${review.platform}`);
        console.log(`- Text: ${review.text?.substring(0, 100)}...`);
        if (review.isDuplicate) {
          console.log(`- 🔄 Found on multiple platforms: ${review.duplicateOnPlatforms?.join(', ')}`);
        }
      });
    }
    
    // Test 3: Test AI Summary generation
    console.log('\n🤖 Test 3: Generating AI Summary...');
    if (results.reviews && results.reviews.length > 0) {
      const aiResponse = await fetch('http://localhost:3000/api/ai-review-summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reviews: results.reviews,
          stats: results.stats,
          productHandle: productHandle,
          reviewPlatform: results.reviewPlatform,
          forceRegenerate: true
        })
      });
      
      if (aiResponse.ok) {
        const aiData = await aiResponse.json();
        console.log('AI Summary Generated:');
        console.log('- Success:', aiData.success);
        console.log('- Multi-platform:', aiData.metadata?.isMultiPlatform || false);
        console.log('- Platforms:', aiData.metadata?.reviewPlatforms || []);
        console.log('- Summary length:', aiData.summary?.length || 0, 'characters');
        console.log('- Summary preview:', aiData.summary?.substring(0, 200) + '...');
        
        if (aiData.metadata?.duplicateReviews > 0) {
          console.log(`- ✅ Consistency: ${aiData.metadata.duplicateReviews} duplicate reviews handled`);
        }
      } else {
        console.log('❌ AI Summary generation failed');
      }
    } else {
      console.log('⚠️ No reviews available for AI summary generation');
    }
    
    console.log('\n✅ Multi-platform test completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

// Test scenarios
async function testScenarios() {
  console.log('\n🔬 Testing Different Scenarios');
  console.log('==============================');
  
  // You can add more test scenarios here:
  // 1. Product with only Judge.me reviews
  // 2. Product with only Yotpo reviews
  // 3. Product with reviews on both platforms (same reviews)
  // 4. Product with reviews on both platforms (different reviews)
  // 5. Product with no reviews
  
  const testProducts = [
    'classic-cotton-t-shirt',  // Adjust based on your actual products
    // Add more product handles for comprehensive testing
  ];
  
  for (const productHandle of testProducts) {
    console.log(`\n🏷️ Testing product: ${productHandle}`);
    try {
      const results = await scrapeProductReviews(productHandle);
      console.log(`- Found ${results.reviews?.length || 0} reviews`);
      console.log(`- Platforms: ${(results.reviewPlatforms || [results.reviewPlatform]).join(', ')}`);
      console.log(`- Duplicates: ${results.stats?.duplicatesFound || 0}`);
    } catch (error) {
      console.error(`- Error: ${error.message}`);
    }
  }
}

// Run tests
if (process.argv[2] === 'test') {
  testMultiPlatformReviews()
    .then(() => testScenarios())
    .then(() => process.exit(0))
    .catch(error => {
      console.error('Test suite failed:', error);
      process.exit(1);
    });
}

export { testMultiPlatformReviews, testScenarios };
