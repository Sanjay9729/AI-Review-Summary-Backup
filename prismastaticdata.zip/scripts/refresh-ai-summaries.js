// scripts/refresh-ai-summaries.js
// Run this script periodically (e.g., every hour) to refresh AI summaries

import ReviewCache from "../services/reviewCache.server.js";
import reviewScraper from "../services/reviewScraper.server.js";

// List of products to check for updated reviews
const PRODUCTS_TO_CHECK = [
  'classic-cotton-t-shirt',
  'desert-bloom-camp-shirt',
  // Add more product handles here
];

async function refreshAISummaries() {
  console.log(`🔄 Starting AI summary refresh for ${PRODUCTS_TO_CHECK.length} products...`);
  
  for (const productHandle of PRODUCTS_TO_CHECK) {
    try {
      console.log(`\n🎯 Checking ${productHandle}...`);
      
      // Get cached data to check age
      const cachedData = await ReviewCache.get(productHandle);
      
      if (cachedData) {
        const cacheAge = Date.now() - new Date(cachedData.scrapedAt).getTime();
        const ageHours = Math.floor(cacheAge / (1000 * 60 * 60));
        
        console.log(`  📅 Cache age: ${ageHours} hours`);
        
        // Only refresh if cache is older than 1 hour
        if (ageHours < 1) {
          console.log(`  ✅ Cache is fresh, skipping ${productHandle}`);
          continue;
        }
      }
      
      // Clear cache and scrape fresh data
      await ReviewCache.delete(productHandle);
      console.log(`  🗑️ Cleared cache for ${productHandle}`);
      
      // Scrape fresh reviews (this will auto-generate AI summary)
      const reviewsData = await reviewScraper.default.scrapeProductReviews(productHandle);
      
      if (reviewsData.success) {
        console.log(`  ✅ Updated ${productHandle}: ${reviewsData.reviews.length} reviews`);
      } else {
        console.log(`  ⚠️ No reviews found for ${productHandle}`);
      }
      
      // Small delay between products
      await new Promise(resolve => setTimeout(resolve, 2000));
      
    } catch (error) {
      console.error(`  ❌ Error processing ${productHandle}:`, error.message);
    }
  }
  
  console.log(`\n🎉 AI summary refresh completed!`);
}

// Run the refresh
refreshAISummaries().catch(error => {
  console.error('❌ Refresh script failed:', error);
  process.exit(1);
});
