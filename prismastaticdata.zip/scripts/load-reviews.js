#!/usr/bin/env node

// scripts/load-reviews.js
import { loadProductReviews, getProductReviewsForDisplay, checkPlatformAvailability } from '../app/services/review-loader.js';

/**
 * CLI script for loading reviews
 * 
 * Usage:
 * node scripts/load-reviews.js --handle=product-handle --shop=shop.myshopify.com
 * node scripts/load-reviews.js --handle=product-handle --shop=shop.myshopify.com --display-only
 * node scripts/load-reviews.js --shop=shop.myshopify.com --check-platforms
 */

function parseArgs() {
  const args = {};
  process.argv.slice(2).forEach(arg => {
    if (arg.startsWith('--')) {
      const [key, value] = arg.slice(2).split('=');
      args[key] = value || true;
    }
  });
  return args;
}

function showHelp() {
  console.log(`
🔍 Review Loading CLI

Usage:
  Load reviews:         node scripts/load-reviews.js --handle=product-handle --shop=shop.myshopify.com
  Display reviews:      node scripts/load-reviews.js --handle=product-handle --shop=shop.myshopify.com --display-only
  Check platforms:      node scripts/load-reviews.js --shop=shop.myshopify.com --check-platforms
  
Options:
  --handle              Product handle/slug
  --shop                Shop domain (e.g., mystore.myshopify.com)
  --display-only        Only display existing reviews, don't fetch new ones
  --check-platforms     Check which platforms are available for the shop
  --judge-token         Judge.me API token (optional)
  --yotpo-key           Yotpo App Key (optional)
  --help                Show this help message

Examples:
  node scripts/load-reviews.js --handle=classic-white-t-shirt --shop=demo-store.myshopify.com
  node scripts/load-reviews.js --shop=demo-store.myshopify.com --check-platforms
  `);
}

async function main() {
  const args = parseArgs();
  
  if (args.help) {
    showHelp();
    process.exit(0);
  }
  
  const { handle, shop, 'display-only': displayOnly, 'check-platforms': checkPlatforms } = args;
  
  try {
    if (checkPlatforms) {
      if (!shop) {
        console.error('❌ Shop domain is required for platform check');
        process.exit(1);
      }
      
      console.log(`🔍 Checking platform availability for ${shop}...`);
      const result = await checkPlatformAvailability(shop, args['yotpo-key']);
      
      console.log('\\n📊 Platform Availability Report:');
      console.log('Judge.me:', result.judgeme.available ? '✅ Available' : '❌ Not available');
      console.log('Yotpo:', result.yotpo.available ? '✅ Available' : '❌ Not available');
      
      if (result.yotpo.configured) {
        console.log(`   App Key: ${result.yotpo.appKey}`);
      }
      
      process.exit(0);
    }
    
    if (!handle || !shop) {
      console.error('❌ Both --handle and --shop are required');
      showHelp();
      process.exit(1);
    }
    
    if (displayOnly) {
      console.log(`🔍 Displaying reviews for ${handle} from ${shop}...`);
      const result = await getProductReviewsForDisplay(handle, shop);
      
      if (result.success) {
        console.log(`\\n${result.message}`);
        console.log(`📊 Total reviews: ${result.reviews.length}`);
        console.log(`⭐ Average rating: ${result.stats?.averageRating || 'N/A'}/5`);
        console.log(`🏷️  Platforms: ${result.platforms?.join(', ') || 'None'}`);
        
        if (result.reviews.length > 0) {
          console.log('\\n📝 Recent Reviews:');
          result.reviews.slice(0, 3).forEach((review, index) => {
            console.log(`\\n${index + 1}. ${review.author} (${review.rating}⭐) - ${review.platform}`);
            if (review.title) console.log(`   Title: ${review.title}`);
            if (review.text) console.log(`   ${review.text.substring(0, 100)}${review.text.length > 100 ? '...' : ''}`);
          });
        }
      } else {
        console.error(`❌ ${result.message || result.error}`);
      }
      
    } else {
      console.log(`🚀 Loading reviews for ${handle} from ${shop}...`);
      
      const options = {};
      if (args['judge-token']) options.judgemeApiToken = args['judge-token'];
      if (args['yotpo-key']) options.yotpoAppKey = args['yotpo-key'];
      
      const result = await loadProductReviews(handle, shop, options);
      
      if (result.success) {
        console.log(`\\n✅ ${result.message}`);
        console.log(`\\n📊 Platform Summary:`);
        console.log(`Judge.me: ${result.platforms.judgeme.available ? '✅' : '❌'} Available, ${result.platforms.judgeme.loaded ? '📥' : '⏭️'} ${result.platforms.judgeme.loaded ? 'Loaded' : 'Skipped'} (${result.platforms.judgeme.count} reviews)`);
        console.log(`Yotpo: ${result.platforms.yotpo.available ? '✅' : '❌'} Available, ${result.platforms.yotpo.loaded ? '📥' : '⏭️'} ${result.platforms.yotpo.loaded ? 'Loaded' : 'Skipped'} (${result.platforms.yotpo.count} reviews)`);
        
        if (result.stats) {
          console.log(`\\n📈 Statistics:`);
          console.log(`Total reviews in DB: ${result.stats.total}`);
          console.log(`Average rating: ${result.stats.averageRating}/5`);
          console.log(`Platform breakdown:`, result.stats.platforms);
        }
        
        if (result.reviews.length > 0) {
          console.log(`\\n📝 Sample Reviews (${result.reviews.length} total):`);
          result.reviews.slice(0, 2).forEach((review, index) => {
            console.log(`\\n${index + 1}. ${review.author} (${review.rating}⭐) - ${review.platform}`);
            if (review.title) console.log(`   "${review.title}"`);
            if (review.text) console.log(`   ${review.text.substring(0, 150)}${review.text.length > 150 ? '...' : ''}`);
          });
        }
      } else {
        console.error(`❌ ${result.message || result.error}`);
        process.exit(1);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

// Run the script
main().catch(error => {
  console.error('❌ Unexpected error:', error);
  process.exit(1);
});
