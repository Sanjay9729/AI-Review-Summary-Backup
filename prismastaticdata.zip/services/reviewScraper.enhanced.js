// services/reviewScraper.enhanced.js - Enhanced Web Scraping for Third-Party Reviews
import puppeteer from 'puppeteer';
import { JSDOM } from 'jsdom';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Enhanced Review Scraper - Scrapes reviews from third-party platforms and stores in database
 */
class EnhancedReviewScraper {
  constructor(options = {}) {
    this.options = {
      headless: true,
      timeout: 30000,
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      maxConcurrent: 3,
      delayBetweenRequests: 2000,
      ...options
    };
    
    this.activeRequests = new Map();
    this.scrapingQueue = [];
    this.isProcessingQueue = false;
  }

  /**
   * Main scraping function - scrapes reviews and stores them in database
   * @param {Object} config - Scraping configuration
   * @param {string} config.url - URL to scrape
   * @param {string} config.productHandle - Product handle for database storage
   * @param {string} config.platform - Platform name (Judge.me, Yotpo, etc.)
   * @param {Object} config.selectors - Custom selectors for scraping
   * @returns {Promise<Object>} Scraping results
   */
  async scrapeAndStoreReviews(config) {
    const {
      url,
      productHandle,
      platform = 'Unknown',
      selectors = {},
      maxReviews = 50,
      storeInDB = true
    } = config;

    console.log(`🕷️ Starting scrape for ${productHandle} from ${platform}`);
    console.log(`📍 URL: ${url}`);

    // Check if already processing this request
    const requestKey = `${productHandle}-${platform}`;
    if (this.activeRequests.has(requestKey)) {
      console.log(`⏳ Request already in progress for ${requestKey}`);
      return await this.activeRequests.get(requestKey);
    }

    const requestPromise = this._performScraping(config);
    this.activeRequests.set(requestKey, requestPromise);

    try {
      const result = await requestPromise;
      
      // Store in database if enabled
      if (storeInDB && result.success && result.reviews.length > 0) {
        const dbResult = await this.storeReviewsInDatabase(result.reviews, productHandle, platform);
        result.stored = dbResult.stored;
        result.duplicates = dbResult.duplicates;
      }

      return result;
    } finally {
      this.activeRequests.delete(requestKey);
    }
  }

  /**
   * Internal scraping method using Puppeteer
   */
  async _performScraping(config) {
    const { url, platform, selectors } = config;
    let browser = null;
    let page = null;

    try {
      browser = await puppeteer.launch({
        headless: this.options.headless,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ]
      });

      page = await browser.newPage();
      
      // Block unnecessary resources to speed up scraping
      await page.setRequestInterception(true);
      page.on('request', (req) => {
        if (['image', 'stylesheet', 'font', 'media'].includes(req.resourceType())) {
          req.abort();
        } else {
          req.continue();
        }
      });

      await page.setUserAgent(this.options.userAgent);
      
      console.log(`🌐 Navigating to ${url}...`);
      await page.goto(url, { 
        waitUntil: 'domcontentloaded', 
        timeout: this.options.timeout 
      });

      // Handle password-protected stores
      const needsPassword = await page.evaluate(() => {
        return window.location.pathname === '/password' || 
               document.querySelector('input[type="password"]') !== null;
      });

      if (needsPassword) {
        const password = process.env.SHOPIFY_STORE_PASSWORD;
        if (password) {
          console.log(`🔓 Handling password protection...`);
          const passwordInput = await page.$('input[type="password"]');
          if (passwordInput) {
            await passwordInput.type(password);
            await passwordInput.press('Enter');
            await page.waitForNavigation({ waitUntil: 'domcontentloaded' });
          }
        }
      }

      // Wait for review widgets to load
      await this._waitForReviewWidgets(page, platform);

      // Extract reviews based on platform
      const reviews = await this._extractReviewsFromPage(page, platform, selectors);

      console.log(`✅ Extracted ${reviews.length} reviews from ${platform}`);

      return {
        success: true,
        reviews,
        platform,
        url,
        scrapedAt: new Date(),
        stats: this._calculateStats(reviews)
      };

    } catch (error) {
      console.error(`❌ Scraping failed for ${url}:`, error.message);
      return {
        success: false,
        error: error.message,
        reviews: [],
        platform,
        url,
        scrapedAt: new Date()
      };
    } finally {
      if (page) await page.close();
      if (browser) await browser.close();
    }
  }

  /**
   * Wait for review widgets to load
   */
  async _waitForReviewWidgets(page, platform) {
    const platformSelectors = {
      'Judge.me': [
        '#judgeme_product_reviews',
        '.jdgm-review-widget',
        '.jdgm-widget',
        '.jdgm-rev'
      ],
      'Yotpo': [
        '.yotpo-reviews',
        '.yotpo-main-widget',
        '[data-yotpo-element-id]',
        '.yotpo-review'
      ],
      'Stamped': [
        '.stamped-reviews-widget',
        '[data-widget-type="reviews"]',
        '.stamped-review'
      ]
    };

    const selectors = platformSelectors[platform] || [
      '[class*="review"]', 
      '[id*="review"]', 
      '[data-review]'
    ];

    console.log(`⌛ Waiting for ${platform} widgets...`);

    let widgetFound = false;
    for (const selector of selectors) {
      try {
        await page.waitForSelector(selector, { timeout: 5000 });
        console.log(`✅ Found widget: ${selector}`);
        widgetFound = true;
        break;
      } catch (error) {
        // Continue to next selector
      }
    }

    if (widgetFound) {
      // Additional wait for reviews to populate
      await page.waitForTimeout(3000);
    } else {
      console.log(`⚠️ No ${platform} widgets found, proceeding with generic scraping`);
    }
  }

  /**
   * Extract reviews from page based on platform
   */
  async _extractReviewsFromPage(page, platform, customSelectors = {}) {
    return await page.evaluate((platform, customSelectors) => {
      const reviews = [];

      // Platform-specific extraction strategies
      const extractionStrategies = {
        'Judge.me': () => {
          const selectors = {
            container: '.jdgm-rev, .jdgm-review, .jdgm-review-item',
            author: '.jdgm-rev__author, .jdgm-author',
            rating: '.jdgm-rev__rating, [data-score]',
            title: '.jdgm-rev__title, .jdgm-review-title',
            text: '.jdgm-rev__body, .jdgm-rev__content, .jdgm-review-text',
            verified: '.jdgm-rev__verified, .jdgm-verified',
            date: '.jdgm-rev__timestamp, .jdgm-rev__published-date'
          };
          
          return _extractWithSelectors(selectors);
        },

        'Yotpo': () => {
          const selectors = {
            container: '.yotpo-review, .yotpo-single-review, .yotpo-review-wrapper',
            author: '.yotpo-review-author, .yotpo-user-name, .yotpo-review-user-name',
            rating: '.yotpo-review-stars, [data-yotpo-review-rating], [data-score]',
            title: '.yotpo-review-title, .yotpo-title',
            text: '.yotpo-review-content, .yotpo-review-text, .yotpo-content',
            verified: '.yotpo-verified-buyer, .yotpo .verified',
            date: '.yotpo-review-date, .yotpo-date'
          };
          
          return _extractWithSelectors(selectors);
        },

        'Stamped': () => {
          const selectors = {
            container: '.stamped-review, .stamped-review-content',
            author: '.stamped-review-author, .stamped-author',
            rating: '.stamped-review-rating, [data-rating]',
            title: '.stamped-review-title',
            text: '.stamped-review-content, .stamped-review-text',
            verified: '.stamped-verified, [class*="verified"]',
            date: '.stamped-review-date, [data-date]'
          };
          
          return _extractWithSelectors(selectors);
        }
      };

      // Try platform-specific extraction first
      if (extractionStrategies[platform]) {
        const platformReviews = extractionStrategies[platform]();
        if (platformReviews.length > 0) {
          return platformReviews.map(review => ({ ...review, platform }));
        }
      }

      // Fallback to generic extraction
      return _genericReviewExtraction().map(review => ({ ...review, platform }));

      // Helper function for selector-based extraction
      function _extractWithSelectors(selectors) {
        const containers = document.querySelectorAll(selectors.container);
        const extractedReviews = [];

        containers.forEach((container, index) => {
          try {
            const review = {
              id: `scraped-${Date.now()}-${index}`,
              author: _extractText(container, selectors.author) || 'Anonymous',
              rating: _extractRating(container, selectors.rating),
              title: _extractText(container, selectors.title) || '',
              text: _extractText(container, selectors.text) || '',
              verified: !!container.querySelector(selectors.verified),
              date: _extractText(container, selectors.date) || '',
              scrapedAt: new Date().toISOString()
            };

            // Only add if we have meaningful content
            if (review.text.length > 20 || review.rating > 0) {
              extractedReviews.push(review);
            }
          } catch (error) {
            console.log(`Error extracting review ${index}:`, error);
          }
        });

        return extractedReviews;
      }

      // Helper function for generic extraction
      function _genericReviewExtraction() {
        const genericSelectors = [
          '[class*="review"]',
          '[id*="review"]',
          '[data-review]',
          '.review',
          '.review-item',
          '.review-wrapper'
        ];

        const reviews = [];
        for (const selector of genericSelectors) {
          const elements = document.querySelectorAll(selector);
          if (elements.length > 0) {
            elements.forEach((el, index) => {
              const text = el.textContent?.trim() || '';
              if (text.length > 50 && text.length < 2000) {
                reviews.push({
                  id: `generic-${Date.now()}-${index}`,
                  author: 'Customer',
                  rating: _extractGenericRating(el),
                  title: text.substring(0, 100),
                  text: text.substring(0, 500),
                  verified: text.toLowerCase().includes('verified'),
                  date: '',
                  scrapedAt: new Date().toISOString()
                });
              }
            });
            break; // Use first successful selector
          }
        }
        return reviews;
      }

      // Helper functions
      function _extractText(container, selectors) {
        if (!selectors) return '';
        const selectorList = Array.isArray(selectors) ? selectors : [selectors];
        
        for (const selector of selectorList) {
          const element = container.querySelector(selector);
          if (element && element.textContent?.trim()) {
            return element.textContent.trim();
          }
        }
        return '';
      }

      function _extractRating(container, selectors) {
        if (!selectors) return 0;
        const selectorList = Array.isArray(selectors) ? selectors : [selectors];
        
        for (const selector of selectorList) {
          const element = container.querySelector(selector);
          if (element) {
            // Try data attributes first
            const dataRating = element.getAttribute('data-score') || 
                             element.getAttribute('data-rating') ||
                             element.getAttribute('data-stars');
            if (dataRating) {
              return parseFloat(dataRating);
            }

            // Count star elements
            const stars = element.querySelectorAll('.star, .filled, [class*="star"]');
            if (stars.length > 0) {
              return stars.length;
            }

            // Extract from text
            const text = element.textContent || '';
            const ratingMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/)\s*5/);
            if (ratingMatch) {
              return parseFloat(ratingMatch[1]);
            }
          }
        }
        return 0;
      }

      function _extractGenericRating(element) {
        const stars = element.querySelectorAll('[class*="star"].filled, [class*="star"].active');
        if (stars.length > 0) return stars.length;
        
        const text = element.textContent || '';
        const ratingMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/)\s*5/);
        return ratingMatch ? parseFloat(ratingMatch[1]) : 5;
      }

      return reviews;
    }, platform, customSelectors);
  }

  /**
   * Store scraped reviews in database
   */
  async storeReviewsInDatabase(reviews, productHandle, platform) {
    console.log(`💾 Storing ${reviews.length} ${platform} reviews for ${productHandle}...`);

    // Find or create product
    let product = await prisma.product.findFirst({
      where: { 
        OR: [
          { handle: productHandle },
          { shopifyId: productHandle }
        ]
      }
    });

    if (!product) {
      // Create product if it doesn't exist
      product = await prisma.product.create({
        data: {
          shopifyId: `scraped-${productHandle}`,
          handle: productHandle,
          title: `Scraped Product: ${productHandle}`,
          shop: 'scraped-store.myshopify.com',
          status: 'ACTIVE'
        }
      });
      console.log(`📦 Created new product: ${product.title}`);
    }

    let stored = 0;
    let duplicates = 0;

    for (const reviewData of reviews) {
      try {
        // Check for duplicates
        const existing = await prisma.review.findFirst({
          where: {
            productId: product.id,
            platform,
            author: reviewData.author,
            text: reviewData.text?.substring(0, 500) // Compare first 500 chars
          }
        });

        if (existing) {
          duplicates++;
          continue;
        }

        // Store new review
        await prisma.review.create({
          data: {
            productId: product.id,
            author: reviewData.author || 'Anonymous Customer',
            rating: Math.max(1, Math.min(5, reviewData.rating || 5)),
            title: reviewData.title?.substring(0, 200) || null,
            text: reviewData.text?.substring(0, 2000) || '',
            verified: reviewData.verified || false,
            platform: platform,
            reviewDate: reviewData.date ? new Date(reviewData.date) : new Date(),
            scrapedAt: new Date()
          }
        });

        stored++;
        console.log(`  ✅ Stored: ${reviewData.author} (${reviewData.rating}★)`);

      } catch (error) {
        console.error(`  ❌ Error storing review: ${error.message}`);
      }
    }

    console.log(`📊 Storage complete: ${stored} stored, ${duplicates} duplicates skipped`);

    return {
      stored,
      duplicates,
      product: product.title
    };
  }

  /**
   * Batch scraping for multiple URLs
   */
  async batchScrape(configs, options = {}) {
    const { maxConcurrent = 3, delayBetweenRequests = 2000 } = options;
    const results = [];
    
    console.log(`🚀 Starting batch scraping of ${configs.length} targets...`);

    // Process in batches to avoid overwhelming servers
    for (let i = 0; i < configs.length; i += maxConcurrent) {
      const batch = configs.slice(i, i + maxConcurrent);
      
      const batchPromises = batch.map(config => 
        this.scrapeAndStoreReviews(config)
      );

      const batchResults = await Promise.allSettled(batchPromises);
      
      batchResults.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          results.push(result.value);
        } else {
          results.push({
            success: false,
            error: result.reason?.message || 'Unknown error',
            url: batch[index].url,
            platform: batch[index].platform
          });
        }
      });

      // Delay between batches
      if (i + maxConcurrent < configs.length) {
        console.log(`⏳ Waiting ${delayBetweenRequests}ms before next batch...`);
        await new Promise(resolve => setTimeout(resolve, delayBetweenRequests));
      }
    }

    return {
      total: configs.length,
      successful: results.filter(r => r.success).length,
      failed: results.filter(r => !r.success).length,
      results
    };
  }

  /**
   * Calculate statistics for scraped reviews
   */
  _calculateStats(reviews) {
    if (reviews.length === 0) {
      return { total: 0, average: 0, distribution: {}, verified: 0 };
    }

    const total = reviews.length;
    const sum = reviews.reduce((acc, review) => acc + (review.rating || 0), 0);
    const average = Math.round((sum / total) * 10) / 10;
    
    const distribution = reviews.reduce((acc, review) => {
      const rating = Math.round(review.rating || 5);
      acc[rating] = (acc[rating] || 0) + 1;
      return acc;
    }, {});

    const verified = reviews.filter(review => review.verified).length;

    return { total, average, distribution, verified };
  }

  /**
   * Close database connection
   */
  async close() {
    await prisma.$disconnect();
  }
}

export default EnhancedReviewScraper;
