// services/scrapingScheduler.js - Automated Review Scraping Scheduler
import EnhancedReviewScraper from './reviewScraper.enhanced.js';
import { PrismaClient } from '@prisma/client';
import cron from 'node-cron';

const prisma = new PrismaClient();

/**
 * Automated Review Scraping Scheduler
 * Handles scheduled scraping of reviews from third-party platforms
 */
class ScrapingScheduler {
  constructor(options = {}) {
    this.options = {
      defaultInterval: '0 */4 * * *', // Every 4 hours
      maxConcurrentJobs: 3,
      retryAttempts: 2,
      retryDelay: 5000,
      logLevel: 'info',
      ...options
    };
    
    this.jobs = new Map();
    this.scraper = new EnhancedReviewScraper();
    this.isRunning = false;
  }

  /**
   * Add a scheduled scraping job
   * @param {Object} jobConfig - Job configuration
   * @param {string} jobConfig.id - Unique job identifier
   * @param {string} jobConfig.url - URL to scrape
   * @param {string} jobConfig.productHandle - Product handle
   * @param {string} jobConfig.platform - Platform name
   * @param {string} jobConfig.schedule - Cron schedule expression
   * @param {boolean} jobConfig.enabled - Whether job is enabled
   */
  addJob(jobConfig) {
    const {
      id,
      url,
      productHandle,
      platform,
      schedule = this.options.defaultInterval,
      enabled = true,
      maxReviews = 50,
      storeInDB = true,
      metadata = {}
    } = jobConfig;

    if (this.jobs.has(id)) {
      throw new Error(`Job with id '${id}' already exists`);
    }

    const job = {
      id,
      url,
      productHandle,
      platform,
      schedule,
      enabled,
      maxReviews,
      storeInDB,
      metadata,
      stats: {
        totalRuns: 0,
        successfulRuns: 0,
        lastRun: null,
        lastSuccess: null,
        lastError: null
      },
      cronJob: null
    };

    this.jobs.set(id, job);
    
    if (enabled && this.isRunning) {
      this._scheduleJob(job);
    }

    this._log('info', `Added job '${id}' for ${platform} scraping of ${productHandle}`);
    return job;
  }

  /**
   * Remove a scheduled job
   */
  removeJob(jobId) {
    const job = this.jobs.get(jobId);
    if (job) {
      if (job.cronJob) {
        job.cronJob.stop();
        job.cronJob.destroy();
      }
      this.jobs.delete(jobId);
      this._log('info', `Removed job '${jobId}'`);
      return true;
    }
    return false;
  }

  /**
   * Enable/disable a job
   */
  toggleJob(jobId, enabled) {
    const job = this.jobs.get(jobId);
    if (!job) {
      throw new Error(`Job '${jobId}' not found`);
    }

    job.enabled = enabled;

    if (enabled && this.isRunning) {
      this._scheduleJob(job);
    } else if (job.cronJob) {
      job.cronJob.stop();
      job.cronJob.destroy();
      job.cronJob = null;
    }

    this._log('info', `Job '${jobId}' ${enabled ? 'enabled' : 'disabled'}`);
  }

  /**
   * Start the scheduler
   */
  start() {
    if (this.isRunning) {
      this._log('warn', 'Scheduler is already running');
      return;
    }

    this.isRunning = true;
    
    // Schedule all enabled jobs
    for (const job of this.jobs.values()) {
      if (job.enabled) {
        this._scheduleJob(job);
      }
    }

    this._log('info', `Scheduler started with ${this.jobs.size} jobs`);
  }

  /**
   * Stop the scheduler
   */
  stop() {
    if (!this.isRunning) {
      this._log('warn', 'Scheduler is not running');
      return;
    }

    this.isRunning = false;

    // Stop all cron jobs
    for (const job of this.jobs.values()) {
      if (job.cronJob) {
        job.cronJob.stop();
        job.cronJob.destroy();
        job.cronJob = null;
      }
    }

    this._log('info', 'Scheduler stopped');
  }

  /**
   * Run a job manually (outside of schedule)
   */
  async runJobNow(jobId) {
    const job = this.jobs.get(jobId);
    if (!job) {
      throw new Error(`Job '${jobId}' not found`);
    }

    this._log('info', `Manually running job '${jobId}'`);
    return await this._executeJob(job);
  }

  /**
   * Get job statistics
   */
  getJobStats(jobId) {
    const job = this.jobs.get(jobId);
    return job ? { ...job.stats } : null;
  }

  /**
   * Get all jobs with their current status
   */
  getAllJobs() {
    return Array.from(this.jobs.values()).map(job => ({
      id: job.id,
      url: job.url,
      productHandle: job.productHandle,
      platform: job.platform,
      schedule: job.schedule,
      enabled: job.enabled,
      stats: { ...job.stats },
      nextRun: job.cronJob ? this._getNextRun(job.cronJob) : null
    }));
  }

  /**
   * Add multiple jobs from a configuration array
   */
  addJobsFromConfig(jobsConfig) {
    const addedJobs = [];
    
    for (const jobConfig of jobsConfig) {
      try {
        const job = this.addJob(jobConfig);
        addedJobs.push(job);
      } catch (error) {
        this._log('error', `Failed to add job ${jobConfig.id}: ${error.message}`);
      }
    }

    return addedJobs;
  }

  /**
   * Save job statistics to database
   */
  async saveJobStats() {
    for (const job of this.jobs.values()) {
      try {
        await prisma.appMetadata.upsert({
          where: { 
            shop: `scraping-job-${job.id}` 
          },
          update: {
            settings: {
              jobConfig: {
                id: job.id,
                url: job.url,
                productHandle: job.productHandle,
                platform: job.platform,
                schedule: job.schedule,
                enabled: job.enabled
              },
              stats: job.stats
            },
            lastSync: new Date()
          },
          create: {
            shop: `scraping-job-${job.id}`,
            settings: {
              jobConfig: {
                id: job.id,
                url: job.url,
                productHandle: job.productHandle,
                platform: job.platform,
                schedule: job.schedule,
                enabled: job.enabled
              },
              stats: job.stats
            },
            lastSync: new Date()
          }
        });
      } catch (error) {
        this._log('error', `Failed to save stats for job ${job.id}: ${error.message}`);
      }
    }
  }

  /**
   * Load jobs from database
   */
  async loadJobsFromDatabase() {
    try {
      const savedJobs = await prisma.appMetadata.findMany({
        where: {
          shop: {
            startsWith: 'scraping-job-'
          }
        }
      });

      for (const savedJob of savedJobs) {
        if (savedJob.settings?.jobConfig) {
          const config = savedJob.settings.jobConfig;
          config.id = config.id || savedJob.shop.replace('scraping-job-', '');
          
          try {
            const job = this.addJob(config);
            if (savedJob.settings.stats) {
              job.stats = { ...job.stats, ...savedJob.settings.stats };
            }
          } catch (error) {
            this._log('error', `Failed to load job ${config.id}: ${error.message}`);
          }
        }
      }

      this._log('info', `Loaded ${this.jobs.size} jobs from database`);
    } catch (error) {
      this._log('error', `Failed to load jobs from database: ${error.message}`);
    }
  }

  /**
   * Schedule a specific job
   * @private
   */
  _scheduleJob(job) {
    if (job.cronJob) {
      job.cronJob.stop();
      job.cronJob.destroy();
    }

    job.cronJob = cron.schedule(job.schedule, async () => {
      await this._executeJob(job);
    }, {
      scheduled: true,
      timezone: 'UTC'
    });

    this._log('info', `Scheduled job '${job.id}' with pattern '${job.schedule}'`);
  }

  /**
   * Execute a scraping job
   * @private
   */
  async _executeJob(job) {
    const startTime = Date.now();
    job.stats.totalRuns++;
    job.stats.lastRun = new Date();

    this._log('info', `Executing job '${job.id}' - ${job.platform} scraping for ${job.productHandle}`);

    let attempt = 0;
    let lastError = null;

    while (attempt < this.options.retryAttempts) {
      try {
        const result = await this.scraper.scrapeAndStoreReviews({
          url: job.url,
          productHandle: job.productHandle,
          platform: job.platform,
          maxReviews: job.maxReviews,
          storeInDB: job.storeInDB
        });

        if (result.success) {
          job.stats.successfulRuns++;
          job.stats.lastSuccess = new Date();
          job.stats.lastError = null;

          const duration = Date.now() - startTime;
          this._log('info', `Job '${job.id}' completed successfully in ${duration}ms`);
          this._log('info', `  Reviews found: ${result.reviews?.length || 0}, stored: ${result.stored || 0}`);

          // Save updated stats
          await this.saveJobStats();

          return result;
        } else {
          throw new Error(result.error || 'Unknown scraping error');
        }
      } catch (error) {
        lastError = error;
        attempt++;
        
        if (attempt < this.options.retryAttempts) {
          this._log('warn', `Job '${job.id}' failed (attempt ${attempt}), retrying in ${this.options.retryDelay}ms...`);
          await new Promise(resolve => setTimeout(resolve, this.options.retryDelay));
        }
      }
    }

    // All attempts failed
    job.stats.lastError = lastError.message;
    const duration = Date.now() - startTime;
    this._log('error', `Job '${job.id}' failed after ${attempt} attempts in ${duration}ms: ${lastError.message}`);

    // Save updated stats
    await this.saveJobStats();

    return {
      success: false,
      error: lastError.message,
      jobId: job.id
    };
  }

  /**
   * Get next run time for a cron job
   * @private
   */
  _getNextRun(cronJob) {
    try {
      return cronJob.nextDate().toDate();
    } catch (error) {
      return null;
    }
  }

  /**
   * Internal logging method
   * @private
   */
  _log(level, message) {
    const timestamp = new Date().toISOString();
    const logLevel = this.options.logLevel;
    
    if (level === 'error' || 
        (level === 'warn' && ['warn', 'info', 'debug'].includes(logLevel)) ||
        (level === 'info' && ['info', 'debug'].includes(logLevel)) ||
        (level === 'debug' && logLevel === 'debug')) {
      console.log(`[${timestamp}] [${level.toUpperCase()}] ${message}`);
    }
  }

  /**
   * Cleanup resources
   */
  async close() {
    this.stop();
    await this.scraper.close();
    await prisma.$disconnect();
  }
}

export default ScrapingScheduler;
