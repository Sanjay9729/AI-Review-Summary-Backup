// services/realJudgemeAPI.js
import db from '../app/db.server.js';

/**
 * Real Judge.me API Integration
 * Fetches live reviews from Judge.me platform for any Shopify store
 */

/**
 * Check if a store has Judge.me installed by testing their widget endpoint
 * @param {string} shopDomain - Store domain (e.g., 'store.myshopify.com')
 * @returns {Promise<boolean>} Whether Judge.me is available
 */
export async function checkJudgemeInstalled(shopDomain) {
  try {
    // Judge.me stores typically have this pattern for their widget endpoints
    const shopHandle = shopDomain.replace('.myshopify.com', '');
    
    // Try the common Judge.me endpoints
    const testUrls = [
      `https://judge.me/reviews/${shopHandle}`,
      `https://${shopHandle}.judge.me/reviews`,
      `https://judge.me/api/v1/reviews?shop_domain=${shopDomain}`,
    ];
    
    for (const url of testUrls) {
      try {
        const response = await fetch(url, {
          method: 'HEAD',
          headers: {
            'User-Agent': 'ReviewFetcher/1.0'
          }
        });
        
        if (response.ok || response.status === 404) {
          console.log(`✅ Judge.me detected for ${shopDomain} via ${url}`);
          return true;
        }
      } catch (error) {
        // Continue to next URL
        continue;
      }
    }
    
    return false;
  } catch (error) {
    console.error(`Error checking Judge.me for ${shopDomain}:`, error);
    return false;
  }
}

/**
 * Fetch reviews from Judge.me public API
 * @param {string} shopDomain - Store domain
 * @param {string} productHandle - Product handle (optional)
 * @param {Object} options - Fetch options
 * @returns {Promise<Array>} Reviews array
 */
export async function fetchJudgemeReviews(shopDomain, productHandle = null, options = {}) {
  try {
    console.log(`🔍 Fetching Judge.me reviews for ${shopDomain}${productHandle ? ` / ${productHandle}` : ''}`);
    
    const shopHandle = shopDomain.replace('.myshopify.com', '');
    const { maxReviews = 50, page = 1 } = options;
    
    // Judge.me public API endpoints
    const apiUrls = [
      // Public reviews API
      `https://judge.me/api/v1/reviews?shop_domain=${shopDomain}&per_page=${maxReviews}&page=${page}`,
      // Widget endpoint
      `https://judge.me/reviews/${shopHandle}.json`,
      // Alternative endpoint
      `https://${shopHandle}.judge.me/api/v1/reviews?per_page=${maxReviews}`
    ];
    
    if (productHandle) {
      // Product-specific endpoints
      apiUrls.unshift(
        `https://judge.me/api/v1/reviews?shop_domain=${shopDomain}&handle=${productHandle}&per_page=${maxReviews}`,
        `https://judge.me/reviews/${shopHandle}/${productHandle}.json`
      );
    }
    
    for (const apiUrl of apiUrls) {
      try {
        console.log(`🚀 Trying Judge.me API: ${apiUrl}`);
        
        const response = await fetch(apiUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'ReviewFetcher/1.0',
            'Referer': `https://${shopDomain}`
          }
        });
        
        if (!response.ok) {
          console.warn(`⚠️ Judge.me API ${apiUrl} responded with ${response.status}`);
          continue;
        }
        
        const data = await response.json();
        console.log(`📦 Judge.me API response structure:`, Object.keys(data));
        
        // Parse different response formats
        let reviews = [];
        
        if (data.reviews && Array.isArray(data.reviews)) {
          reviews = data.reviews;
        } else if (data.data && Array.isArray(data.data)) {
          reviews = data.data;
        } else if (Array.isArray(data)) {
          reviews = data;
        } else if (data.widget && data.widget.reviews) {
          reviews = data.widget.reviews;
        }
        
        if (reviews.length > 0) {
          console.log(`✅ Found ${reviews.length} Judge.me reviews from ${apiUrl}`);
          return parseJudgemeReviews(reviews, shopDomain, productHandle);
        }
        
      } catch (error) {
        console.warn(`❌ Judge.me API error for ${apiUrl}:`, error.message);
        continue;
      }
    }
    
    console.log(`ℹ️ No Judge.me reviews found for ${shopDomain}`);
    return [];
    
  } catch (error) {
    console.error(`❌ Error fetching Judge.me reviews for ${shopDomain}:`, error);
    return [];
  }
}

/**
 * Parse Judge.me review data into standardized format
 * @param {Array} rawReviews - Raw review data from Judge.me API
 * @param {string} shopDomain - Store domain
 * @param {string} productHandle - Product handle
 * @returns {Array} Standardized reviews
 */
function parseJudgemeReviews(rawReviews, shopDomain, productHandle) {
  return rawReviews.map(review => {
    // Judge.me review structure can vary, handle different formats
    const standardizedReview = {
      externalId: review.id?.toString() || review.review_id?.toString() || null,
      author: review.reviewer?.name || review.name || review.customer_name || review.author || 'Anonymous',
      rating: parseFloat(review.rating || review.score || review.stars || 5),
      title: review.title || review.review_title || null,
      text: review.body || review.content || review.review_text || review.text || null,
      verified: review.verified_buyer || review.verified || false,
      platform: 'Judge.me',
      reviewDate: parseReviewDate(review.created_at || review.date || review.review_date),
      productHandle: productHandle || review.product_handle || null,
      productName: review.product?.title || review.product_title || null,
      shopDomain,
      
      // Additional Judge.me specific fields
      judgemeData: {
        reviewId: review.id,
        productId: review.product_external_id || review.product_id,
        featured: review.featured || false,
        helpfulCount: review.helpful_count || 0,
        pictures: review.pictures || [],
        videos: review.videos || []
      }
    };
    
    return standardizedReview;
  }).filter(review => review.author && review.rating); // Filter out invalid reviews
}

/**
 * Parse various date formats from Judge.me
 * @param {string|Date} dateStr - Date string or object
 * @returns {Date|null} Parsed date
 */
function parseReviewDate(dateStr) {
  if (!dateStr) return null;
  
  try {
    if (dateStr instanceof Date) return dateStr;
    
    // Handle various Judge.me date formats
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? null : date;
  } catch (error) {
    console.warn('Error parsing Judge.me date:', dateStr);
    return null;
  }
}

/**
 * Fetch and store Judge.me reviews for a specific shop/product
 * @param {string} shopDomain - Store domain
 * @param {string} productHandle - Product handle (optional)
 * @param {Object} options - Options
 * @returns {Promise<Object>} Result object
 */
export async function fetchAndStoreJudgemeReviews(shopDomain, productHandle = null, options = {}) {
  try {
    console.log(`🚀 Fetching and storing Judge.me reviews for ${shopDomain}${productHandle ? ` / ${productHandle}` : ''}`);
    
    // Check if Judge.me is available
    const isAvailable = await checkJudgemeInstalled(shopDomain);
    if (!isAvailable) {
      return {
        success: false,
        message: `Judge.me not detected for ${shopDomain}`,
        reviews: [],
        stored: 0
      };
    }
    
    // Fetch reviews
    const reviews = await fetchJudgemeReviews(shopDomain, productHandle, options);
    
    if (reviews.length === 0) {
      return {
        success: true,
        message: `No Judge.me reviews found for ${shopDomain}${productHandle ? ` / ${productHandle}` : ''}`,
        reviews: [],
        stored: 0
      };
    }
    
    // Store reviews in database
    let storedCount = 0;
    const productRecords = new Map();
    
    for (const review of reviews) {
      try {
        // Get or create product record
        let productId;
        const lookupKey = `${shopDomain}-${review.productHandle || 'unknown'}`;
        
        if (productRecords.has(lookupKey)) {
          productId = productRecords.get(lookupKey);
        } else {
          // Create/find product
          const productData = {
            shopifyId: review.judgemeData?.productId || `judgeme-${lookupKey}`,
            handle: review.productHandle || productHandle || 'unknown-product',
            title: review.productName || (review.productHandle || productHandle || 'Unknown Product').replace(/-/g, ' '),
            shop: shopDomain,
            status: 'ACTIVE'
          };
          
          const product = await upsertProduct(productData);
          productId = product.id;
          productRecords.set(lookupKey, productId);
        }
        
        // Check for duplicates
        const existingReview = await db.review.findFirst({
          where: {
            productId,
            platform: 'Judge.me',
            author: review.author,
            rating: review.rating,
            text: review.text
          }
        });
        
        if (!existingReview) {
          await db.review.create({
            data: {
              productId,
              author: review.author,
              rating: review.rating,
              title: review.title,
              text: review.text,
              verified: review.verified,
              platform: 'Judge.me',
              reviewDate: review.reviewDate,
              scrapedAt: new Date()
            }
          });
          storedCount++;
        }
        
      } catch (error) {
        console.error('Error storing Judge.me review:', error);
      }
    }
    
    const message = `Found ${reviews.length} Judge.me reviews, stored ${storedCount} new reviews`;
    console.log(`✅ ${message}`);
    
    return {
      success: true,
      message,
      reviews,
      stored: storedCount,
      total: reviews.length,
      shopDomain,
      productHandle
    };
    
  } catch (error) {
    console.error(`❌ Error in fetchAndStoreJudgemeReviews:`, error);
    return {
      success: false,
      error: error.message,
      message: `Failed to fetch Judge.me reviews: ${error.message}`,
      reviews: [],
      stored: 0
    };
  }
}

/**
 * Upsert product helper
 */
async function upsertProduct(productData) {
  return await db.product.upsert({
    where: {
      shopifyId: productData.shopifyId
    },
    update: {
      title: productData.title,
      handle: productData.handle,
      status: productData.status,
      updatedAt: new Date()
    },
    create: productData
  });
}

export default {
  checkJudgemeInstalled,
  fetchJudgemeReviews,
  fetchAndStoreJudgemeReviews
};
