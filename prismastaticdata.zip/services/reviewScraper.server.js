// app/services/reviewScraper.server.js - Further Enhanced Version
import puppeteer from 'puppeteer';

const activeRequests = new Map();

async function scrapeProductReviews(productHandle) {
  console.log(`🤖 Starting review scraping for product: ${productHandle}`);

  if (activeRequests.has(productHandle)) {
    console.log(`Request for ${productHandle} already in progress, waiting...`);
    return await activeRequests.get(productHandle);
  }

  const productUrl = `https://${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`;
  console.log(`📍 Product URL: ${productUrl}`);

  let reviews = [];
  let stats = { total: 0, average: 0, distribution: {}, verified: 0, totalWithText: 0 };
  let browser = null;
  let page = null;

  const requestPromise = (async () => {
    try {
      console.log(`🚀 Launching Puppeteer browser for ${productHandle}...`);
      browser = await puppeteer.launch({
        headless: true,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-web-security",
          "--disable-features=VizDisplayCompositor",
          "--disable-background-networking",
          "--disable-background-timer-throttling",
          "--disable-renderer-backgrounding",
          "--disable-backgrounding-occluded-windows",
        ],
      });

      page = await browser.newPage();

      // Block unnecessary resources
      await page.setRequestInterception(true);
      page.on('request', (req) => {
        if (['image', 'stylesheet', 'font', 'media'].includes(req.resourceType())) {
          req.abort();
        } else {
          req.continue();
        }
      });

      await page.setUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      );

      console.log(`🌐 Navigating to: ${productUrl}`);
      await page.goto(productUrl, { waitUntil: "domcontentloaded", timeout: 30000 });

      console.log(`Current URL after navigation: ${page.url()}`);
      console.log(`Page title: ${await page.title()}`);

      // Check if password page
      const needsPassword = await page.evaluate(() => {
        return (
          window.location.pathname === "/password" ||
          document.querySelector('input[type="password"]') !== null
        );
      });

      if (needsPassword) {
        console.log(`🔒 Password page detected for ${productHandle}, attempting login...`);

        const passwordInput = await page.$('input[type="password"]');
        if (!passwordInput) throw new Error("Password input not found on page");

        const storePassword = process.env.SHOPIFY_STORE_PASSWORD;
        if (!storePassword) throw new Error("SHOPIFY_STORE_PASSWORD env var not set");

        await passwordInput.type(storePassword);
        await passwordInput.press("Enter");

        try {
          await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 10000 });
          console.log(`✅ Store unlocked for ${productHandle}`);
        } catch {
          console.log(`⏱️ Navigation timeout after password for ${productHandle}, continuing...`);
        }

        if (page.url().includes("/password")) {
          throw new Error("Password authentication failed - check SHOPIFY_STORE_PASSWORD");
        }

        // Re-navigate to product page after unlock
        await page.goto(productUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
      }

      console.log(`✅ Successfully reached product page: ${page.url()}`);

      // Wait for review widgets to load (Judge.me, Yotpo, etc.)
      try {
        console.log(`⌛ Waiting for review widget containers...`);
        
        // Try to wait for either Judge.me or Yotpo widgets
        const widgetSelectors = [
          '#judgeme_product_reviews',
          '.jdgm-review-widget', 
          '.jdgm-widget',
          '.yotpo-reviews',
          '.yotpo-main-widget',
          '[data-yotpo-element-id]',
          '.stamped-reviews-widget',
          '[class*="reviews"]',
          '[id*="reviews"]'
        ];
        
        let widgetFound = false;
        for (const selector of widgetSelectors) {
          try {
            await page.waitForSelector(selector, { timeout: 3000 });
            console.log(`✅ Found widget: ${selector}`);
            widgetFound = true;
            break;
          } catch {
            // Continue to next selector
          }
        }
        
        if (!widgetFound) {
          console.log(`⚠️ No review widgets detected, will try generic scraping`);
        }

        console.log(`⌛ Additional wait for reviews to populate...`);
        await new Promise(resolve => setTimeout(resolve, 5000));
      } catch (error) {
        console.log(`❌ Error waiting for widgets: ${error.message}`);
      }

      // Log page content for debugging (truncated to avoid huge logs)
      const pageContent = await page.content();
      console.log(`📄 Page content snippet: ${pageContent.substring(0, 500)}...`);
      
      // Debug specific Yotpo elements
      const yotpoDebugInfo = await page.evaluate(() => {
        const yotpoElements = {
          mainWidget: document.querySelector('.yotpo-main-widget'),
          reviewsWidget: document.querySelector('.yotpo-reviews-widget'),
          reviewContainer: document.querySelector('.yotpo-review-wrapper'),
          yotpoDiv: document.querySelector('[data-yotpo-element-id]'),
          yotpoScript: document.querySelector('script[src*="yotpo"]'),
          yotpoReviews: document.querySelectorAll('.yotpo-review, [class*="yotpo-review"]'),
          allYotpoElements: document.querySelectorAll('[class*="yotpo"], [id*="yotpo"], [data-yotpo]')
        };
        
        return {
          hasYotpoScript: !!yotpoElements.yotpoScript,
          yotpoElementsCount: yotpoElements.allYotpoElements.length,
          yotpoReviewsCount: yotpoElements.yotpoReviews.length,
          yotpoClasses: Array.from(yotpoElements.allYotpoElements).map(el => {
            const className = el.className;
            if (typeof className === 'string') return className;
            if (className && className.toString) return className.toString();
            return '';
          }).filter(c => c),
          hasMainWidget: !!yotpoElements.mainWidget,
          hasReviewsWidget: !!yotpoElements.reviewsWidget
        };
      });
      console.log(`🔍 Yotpo debug info:`, JSON.stringify(yotpoDebugInfo, null, 2));
      
      // Comprehensive page debugging - find ALL elements that might contain reviews
      const pageDebugInfo = await page.evaluate(() => {
        const allElements = document.querySelectorAll('*');
        const debugInfo = {
          totalElements: allElements.length,
          reviewRelatedElements: [],
          judgeElements: [],
          yotpoElements: [],
          starElements: [],
          textContentSamples: []
        };
        
        // Find elements with review-related classes or IDs
        Array.from(allElements).forEach((el, index) => {
          const className = (typeof el.className === 'string' ? el.className : (el.className && el.className.toString ? el.className.toString() : '')) || '';
          const id = (el.id || '').toString();
          const textContent = (el.textContent || '').trim();
          
          // Check for review-related attributes
          if (className.toLowerCase().includes('review') || id.toLowerCase().includes('review')) {
            debugInfo.reviewRelatedElements.push({
              tag: el.tagName.toLowerCase(),
              className: className.substring(0, 100),
              id: id.substring(0, 50),
              textSnippet: textContent.substring(0, 100)
            });
          }
          
          // Check for Judge.me elements
          if (className.includes('jdgm') || id.includes('jdgm') || className.includes('judge')) {
            debugInfo.judgeElements.push({
              tag: el.tagName.toLowerCase(),
              className: className.substring(0, 100),
              id: id.substring(0, 50),
              textSnippet: textContent.substring(0, 100)
            });
          }
          
          // Check for Yotpo elements
          if (className.includes('yotpo') || id.includes('yotpo')) {
            debugInfo.yotpoElements.push({
              tag: el.tagName.toLowerCase(),
              className: className.substring(0, 100),
              id: id.substring(0, 50),
              textSnippet: textContent.substring(0, 100)
            });
          }
          
          // Check for star ratings
          if (textContent.includes('★') || textContent.includes('star') || className.includes('star')) {
            debugInfo.starElements.push({
              tag: el.tagName.toLowerCase(),
              className: className.substring(0, 100),
              textSnippet: textContent.substring(0, 50)
            });
          }
          
          // Collect interesting text samples
          if (textContent.length > 50 && textContent.length < 500 && 
              (textContent.includes('review') || textContent.includes('customer') || 
               textContent.includes('rating') || textContent.includes('★'))) {
            debugInfo.textContentSamples.push(textContent.substring(0, 200));
          }
        });
        
        return debugInfo;
      });
      
      console.log(`🔍 Page debug info:`);
      console.log(`  - Total elements: ${pageDebugInfo.totalElements}`);
      console.log(`  - Review-related elements: ${pageDebugInfo.reviewRelatedElements.length}`);
      console.log(`  - Judge.me elements: ${pageDebugInfo.judgeElements.length}`);
      console.log(`  - Yotpo elements: ${pageDebugInfo.yotpoElements.length}`);
      console.log(`  - Star elements: ${pageDebugInfo.starElements.length}`);
      console.log(`  - Text samples: ${pageDebugInfo.textContentSamples.length}`);
      
      if (pageDebugInfo.reviewRelatedElements.length > 0) {
        console.log(`📝 Review-related elements found:`, pageDebugInfo.reviewRelatedElements.slice(0, 5));
      }
      if (pageDebugInfo.judgeElements.length > 0) {
        console.log(`⚖️ Judge.me elements found:`, pageDebugInfo.judgeElements.slice(0, 5));
      }
      if (pageDebugInfo.yotpoElements.length > 0) {
        console.log(`💬 Yotpo elements found:`, pageDebugInfo.yotpoElements.slice(0, 5));
      }
      if (pageDebugInfo.textContentSamples.length > 0) {
        console.log(`📄 Interesting text samples:`, pageDebugInfo.textContentSamples.slice(0, 3));
      }

      // Enhanced Judge.me scraping with multiple fallback strategies
      const scrapedReviews = await page.evaluate(() => {
        const reviewList = [];
        
        console.log('Starting to scrape reviews...');

        // Strategy 1: Judge.me selectors
        let reviewElements = document.querySelectorAll('.jdgm-rev, .jdgm-review, .jdgm-review-item, .jdgm-widget .review, [data-jdgm-review], .jdgm-review-widget .jdgm-rev, .jdgm-rev-widg .jdgm-rev, .jdgm-outside-widget .jdgm-rev');
        let platform = 'Judge.me';
        console.log(`Strategy 1 (Judge.me): Found ${reviewElements.length} reviews`);

        // Strategy 2: Enhanced Yotpo selectors
        if (reviewElements.length === 0) {
          reviewElements = document.querySelectorAll(
            '.yotpo-review, ' +
            '.yotpo .review, ' + 
            '.yotpo-single-review, ' +
            '[data-yotpo-element-id="reviews"] .review, ' +
            '.yotpo-review-wrapper, ' +
            '.yotpo-reviews .review-container, ' +
            '.yotpo-review-content, ' +
            '.yotpo-reviews-list .review, ' +
            '.yotpo-main-widget .review, ' +
            '.yotpo-reviews-widget .review, ' +
            '[data-yotpo-review-id], ' +
            '.yotpo-review-item, ' +
            '.yotpo-modal-review, ' +
            '[class*="yotpo-review"], ' +
            '.yotpo-review-title, ' +
            '.yotpo-review-rating, ' +
            '.yotpo-review-author'
          );
          platform = 'Yotpo';
          console.log(`Strategy 2 (Enhanced Yotpo): Found ${reviewElements.length} reviews`);
          
          // Additional Yotpo detection - look for review containers that might contain multiple reviews
          if (reviewElements.length === 0) {
            const yotpoContainers = document.querySelectorAll('.yotpo-main-widget, .yotpo-reviews-widget, [data-yotpo-element-id]');
            const reviewsInContainers = [];
            yotpoContainers.forEach(container => {
              const reviews = container.querySelectorAll('div[class*="review"], div[data-review], .content, .text-content');
              reviewsInContainers.push(...reviews);
            });
            if (reviewsInContainers.length > 0) {
              reviewElements = reviewsInContainers;
              console.log(`Strategy 2b (Yotpo Containers): Found ${reviewElements.length} reviews inside Yotpo containers`);
            }
          }
        }

        // Strategy 3: Stamped.io selectors
        if (reviewElements.length === 0) {
          reviewElements = document.querySelectorAll('.stamped-review, .stamped-review-content, [data-widget-type="reviews"] .review');
          platform = 'Stamped';
          console.log(`Strategy 3 (Stamped): Found ${reviewElements.length} reviews`);
        }

        // Strategy 4: Generic review selectors
        if (reviewElements.length === 0) {
          reviewElements = document.querySelectorAll('[class*="review"], [id*="review"], [data-review], .review, .review-item, .review-wrapper');
          platform = 'Generic';
          console.log(`Strategy 4 (Generic): Found ${reviewElements.length} elements with review-related attributes`);
        }

        // Strategy 3: Look for Judge.me specific patterns
        if (reviewElements.length === 0) {
          reviewElements = document.querySelectorAll('.jdgm-widget *, [class*="jdgm"] *, [id*="jdgm"] *');
          reviewElements = Array.from(reviewElements).filter(el => {
            const text = el.textContent || '';
            return text.includes('★') || text.includes('star') || text.includes('review') || text.match(/\d+\.\d+.*5|5.*\d+\.\d+/);
          });
          console.log(`Strategy 3: Found ${reviewElements.length} Judge.me elements with star/review content`);
        }

        // Strategy 4: Generic review detection
        if (reviewElements.length === 0) {
          const allElements = document.querySelectorAll('*');
          reviewElements = Array.from(allElements).filter(el => {
            const className = (typeof el.className === 'string' ? el.className : (el.className && el.className.toString ? el.className.toString() : '')) || '';
            const id = (el.id || '').toString();
            const text = el.textContent || '';
            
            return (
              className.toLowerCase().includes('review') ||
              id.toLowerCase().includes('review') ||
              (text.includes('★') && text.length > 20 && text.length < 1000)
            );
          });
          console.log(`Strategy 4: Found ${reviewElements.length} elements with generic review patterns`);
        }

        console.log(`Total elements to process: ${reviewElements.length}`);

        reviewElements.forEach((el, index) => {
          try {
            console.log(`Processing element ${index + 1}...`);

            // Extract author with multiple strategies
            let author = 'Anonymous';
            const authorSelectors = [
              // Judge.me selectors
              '.jdgm-rev__author',
              '.jdgm-rev__author-wrapper', 
              '.jdgm-author',
              // Yotpo selectors
              '.yotpo-review-author',
              '.yotpo-user-name',
              '.yotpo-review-user-name',
              '.yotpo .user-name',
              '[data-yotpo-element-id="review-author"]',
              // Generic selectors
              '.review-author',
              '.reviewer-name',
              '.author',
              '.customer-name',
              '.review-name',
              '[class*="author"]',
              '[class*="reviewer"]',
              '[class*="user-name"]',
              '[class*="name"]'
            ];

            for (const selector of authorSelectors) {
              const authorEl = el.querySelector(selector);
              if (authorEl && authorEl.textContent.trim()) {
                author = authorEl.textContent.trim();
                break;
              }
            }

            // If no author found in child, look in parent or ancestors
            if (author === 'Anonymous') {
              let currentEl = el.parentElement;
              for (let i = 0; i < 3 && currentEl; i++) { // Check up to 3 levels up
                for (const selector of authorSelectors) {
                  const authorEl = currentEl.querySelector(selector);
                  if (authorEl && authorEl.textContent.trim()) {
                    author = authorEl.textContent.trim();
                    break;
                  }
                }
                if (author !== 'Anonymous') break;
                currentEl = currentEl.parentElement;
              }
            }

            // Extract rating with multiple strategies
            let rating = 0;
            
            // Strategy 1: Look for data attributes and rating elements
            const ratingSelectors = [
              // Data attributes
              '[data-score]',
              '[data-rating]',
              '[data-stars]',
              '[data-yotpo-review-rating]',
              // Judge.me selectors
              '.jdgm-rev__rating',
              '.jdgm-rev__rating-wrapper',
              // Yotpo selectors
              '.yotpo-review-stars',
              '.yotpo-stars',
              '.yotpo-rating',
              '.yotpo .rating',
              '.yotpo-review .stars',
              '[data-yotpo-element-id="rating"]',
              // Generic selectors
              '.rating',
              '.stars',
              '.star-rating',
              '.review-rating',
              '[class*="rating"]',
              '[class*="stars"]',
              '[aria-label*="out of 5 stars"]',
              '[aria-label*="rating"]'
            ];

            for (const selector of ratingSelectors) {
              const ratingEl = el.querySelector(selector);
              if (ratingEl) {
                const dataScore = ratingEl.getAttribute('data-score');
                const dataRating = ratingEl.getAttribute('data-rating');
                const dataStars = ratingEl.getAttribute('data-stars');
                const ariaLabel = ratingEl.getAttribute('aria-label');
                
                if (dataScore) rating = parseFloat(dataScore);
                else if (dataRating) rating = parseFloat(dataRating);
                else if (dataStars) rating = parseFloat(dataStars);
                else if (ariaLabel) {
                  const match = ariaLabel.match(/(\d+(?:\.\d+)?) out of 5/);
                  if (match) rating = parseFloat(match[1]);
                }
                
                if (rating > 0) break;
              }
            }

            // Strategy 2: Count star elements
            if (rating === 0) {
              const starSelectors = [
                // Judge.me star selectors
                '.jdgm-star.jdgm--on',
                '.jdgm-star.jdgm-star--on',
                // Yotpo star selectors
                '.yotpo-icon-star.yotpo-icon-full-star',
                '.yotpo .star.filled',
                '.yotpo .star.full',
                '.yotpo-star.filled',
                '.yotpo-star.full',
                // Generic star selectors
                '.star-filled',
                '.fa-star.filled',
                '.star.active',
                '.star.full',
                '.filled-star',
                '[class*="star"][class*="filled"]',
                '[class*="star"][class*="active"]',
                '[class*="star"][class*="on"]',
                '[class*="star"][class*="full"]'
              ];

              for (const selector of starSelectors) {
                const stars = el.querySelectorAll(selector);
                if (stars.length > 0) {
                  rating = stars.length;
                  break;
                }
              }
            }

            // Strategy 3: Look for rating in text content
            if (rating === 0) {
              const text = el.textContent || '';
              const ratingMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/|\s)\s*5|5\s*(?:out of|\/|\s)\s*(\d+(?:\.\d+)?)/);
              if (ratingMatch) {
                rating = parseFloat(ratingMatch[1] || ratingMatch[2]);
              }
            }

            // Extract review text
            let text = '';
            const textSelectors = [
              // Judge.me selectors
              '.jdgm-rev__body',
              '.jdgm-rev__content',
              '.jdgm-rev__text',
              '.jdgm-rev__review-text',
              // Yotpo selectors
              '.yotpo-review-content',
              '.yotpo-review-text',
              '.yotpo .review-content',
              '.yotpo .content-text',
              '.yotpo-content',
              '[data-yotpo-element-id="review-content"]',
              // Generic selectors
              '.review-text',
              '.review-content',
              '.review-body',
              '.comment',
              '.content',
              '.text',
              '[class*="review"][class*="text"]',
              '[class*="review"][class*="body"]',
              '[class*="review"][class*="content"]',
              '[class*="comment"]',
              '[class*="content"]'
            ];

            for (const selector of textSelectors) {
              const textEl = el.querySelector(selector);
              if (textEl && textEl.textContent.trim().length > 10) {
                text = textEl.textContent.trim();
                break;
              }
            }

            // If no specific text element, use element's own text (filtered)
            if (!text) {
              const elementText = el.textContent || '';
              if (elementText.length > 50 && elementText.length < 2000 && 
                  !elementText.toLowerCase().includes('write a review') &&
                  !elementText.toLowerCase().includes('load more')) {
                text = elementText.trim();
              }
            }

            // Extract title
            let title = '';
            const titleSelectors = [
              // Judge.me selectors
              '.jdgm-rev__title',
              '.jdgm-review-title',
              // Yotpo selectors
              '.yotpo-review-title',
              '.yotpo .review-title',
              '.yotpo-title',
              '[data-yotpo-element-id="review-title"]',
              // Generic selectors
              '.review-title',
              '.title',
              'h3', 'h4', 'h5'
            ];

            for (const selector of titleSelectors) {
              const titleEl = el.querySelector(selector);
              if (titleEl && titleEl.textContent.trim()) {
                title = titleEl.textContent.trim();
                break;
              }
            }

            // Check if verified
            const verified = !!(
              el.querySelector('.jdgm-rev__verified, .jdgm-rev__buyer-badge, .jdgm-verified, .jdgm-verified-badge, .yotpo-verified-buyer, .yotpo .verified, .verified, [class*="verified"], [class*="buyer"]') ||
              (el.textContent && (el.textContent.includes('Verified') || el.textContent.includes('verified buyer') || el.textContent.includes('Verified Purchase')))
            );

            // Extract date
            let date = '';
            const dateSelectors = [
              // Judge.me selectors
              '.jdgm-rev__timestamp',
              '.jdgm-rev__published-date',
              // Yotpo selectors
              '.yotpo-review-date',
              '.yotpo .review-date',
              '.yotpo-date',
              '[data-yotpo-element-id="review-date"]',
              // Generic selectors
              '.review-date',
              '.date',
              '.timestamp',
              '[class*="date"]',
              '[class*="time"]',
              '[data-date]',
              '[data-time]'
            ];

            for (const selector of dateSelectors) {
              const dateEl = el.querySelector(selector);
              if (dateEl && dateEl.textContent.trim()) {
                date = dateEl.textContent.trim();
                break;
              }
            }

            console.log(`📝 Extracted data for review ${index + 1}: ${JSON.stringify({
              author: author.substring(0, 20),
              rating,
              textLength: text.length,
              title: title.substring(0, 20),
              verified,
              date
            })}`);

            // Only add if we have meaningful data
            if (rating > 0 || text.length > 20 || author !== 'Anonymous') {
              reviewList.push({
                id: index,
                author,
                rating: Math.min(5, Math.max(0, rating)),
                text,
                title,
                verified,
                date,
                platform, // Add platform information
              });
            }
          } catch (err) {
            console.error(`❌ Error parsing review ${index}:`, err);
          }
        });

        console.log(`✅ Successfully extracted ${reviewList.length} reviews`);
        return reviewList;
      });

      reviews = scrapedReviews;
      console.log(`📊 Extracted ${reviews.length} reviews for ${productHandle}`);

      // Calculate stats
      if (reviews.length > 0) {
        const avg = reviews.reduce((acc, r) => acc + (r.rating || 0), 0) / reviews.length;

        stats = {
          total: reviews.length,
          average: Math.round(avg * 10) / 10,
          verified: reviews.filter((r) => r.verified).length,
          totalWithText: reviews.filter((r) => r.text.length > 0).length,
          distribution: reviews.reduce((acc, r) => {
            const star = Math.round(r.rating);
            acc[star] = (acc[star] || 0) + 1;
            return acc;
          }, {}),
        };
      }

      const result = {
        success: reviews.length > 0,
        reviews,
        stats,
        productHandle,
        scrapedAt: new Date().toISOString(),
        debugInfo: { 
          productUrl, 
          reviewCount: reviews.length,
          scrapingStrategies: 4,
          finalStats: stats
        },
      };

      return result;

    } catch (err) {
      console.error(`❌ Scraping error for ${productHandle}: ${err.message}`);
      return {
        success: false,
        reviews: [],
        stats,
        error: err.message,
        productHandle,
        scrapedAt: new Date().toISOString(),
      };
    } finally {
      if (page) await page.close().catch(() => {});
      if (browser) await browser.close().catch(() => {});
      activeRequests.delete(productHandle);
    }
  })();

  activeRequests.set(productHandle, requestPromise);

  return await requestPromise;
}

export default { scrapeProductReviews };