-- CreateTable
CREATE TABLE "public"."Session" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "isOnline" BOOLEAN NOT NULL DEFAULT false,
    "scope" TEXT,
    "expires" TIMESTAMP(3),
    "accessToken" TEXT NOT NULL,
    "userId" BIGINT,
    "firstName" TEXT,
    "lastName" TEXT,
    "email" TEXT,
    "accountOwner" BOOLEAN NOT NULL DEFAULT false,
    "locale" TEXT,
    "collaborator" BOOLEAN DEFAULT false,
    "emailVerified" BOOLEAN DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."Product" (
    "id" TEXT NOT NULL,
    "shopifyId" TEXT NOT NULL,
    "handle" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "status" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."Review" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "author" TEXT NOT NULL,
    "rating" DOUBLE PRECISION NOT NULL,
    "title" TEXT,
    "text" TEXT,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "platform" TEXT,
    "reviewDate" TIMESTAMP(3),
    "scrapedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Review_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."AiSummary" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "summary" TEXT NOT NULL,
    "model" TEXT,
    "reviewsAnalyzed" INTEGER NOT NULL DEFAULT 0,
    "totalReviews" INTEGER NOT NULL DEFAULT 0,
    "averageRating" DOUBLE PRECISION,
    "reviewPlatform" TEXT,
    "platforms" TEXT[],
    "platformCounts" JSONB,
    "isMultiPlatform" BOOLEAN NOT NULL DEFAULT false,
    "duplicateReviews" INTEGER NOT NULL DEFAULT 0,
    "consistencyScore" TEXT,
    "fromCache" BOOLEAN NOT NULL DEFAULT false,
    "generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AiSummary_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ReviewCache" (
    "id" TEXT NOT NULL,
    "productHandle" TEXT NOT NULL,
    "cacheKey" TEXT NOT NULL,
    "data" JSONB NOT NULL,
    "stats" JSONB,
    "platform" TEXT,
    "scrapedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ReviewCache_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."AppMetadata" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "settings" JSONB,
    "lastSync" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AppMetadata_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Session_shop_idx" ON "public"."Session"("shop");

-- CreateIndex
CREATE INDEX "Session_expires_idx" ON "public"."Session"("expires");

-- CreateIndex
CREATE UNIQUE INDEX "Product_shopifyId_key" ON "public"."Product"("shopifyId");

-- CreateIndex
CREATE INDEX "Product_shop_idx" ON "public"."Product"("shop");

-- CreateIndex
CREATE INDEX "Product_handle_idx" ON "public"."Product"("handle");

-- CreateIndex
CREATE INDEX "Product_shopifyId_idx" ON "public"."Product"("shopifyId");

-- CreateIndex
CREATE INDEX "Review_productId_idx" ON "public"."Review"("productId");

-- CreateIndex
CREATE INDEX "Review_platform_idx" ON "public"."Review"("platform");

-- CreateIndex
CREATE INDEX "Review_rating_idx" ON "public"."Review"("rating");

-- CreateIndex
CREATE INDEX "Review_verified_idx" ON "public"."Review"("verified");

-- CreateIndex
CREATE INDEX "Review_scrapedAt_idx" ON "public"."Review"("scrapedAt");

-- CreateIndex
CREATE INDEX "AiSummary_productId_idx" ON "public"."AiSummary"("productId");

-- CreateIndex
CREATE INDEX "AiSummary_generatedAt_idx" ON "public"."AiSummary"("generatedAt");

-- CreateIndex
CREATE INDEX "AiSummary_reviewPlatform_idx" ON "public"."AiSummary"("reviewPlatform");

-- CreateIndex
CREATE INDEX "AiSummary_isMultiPlatform_idx" ON "public"."AiSummary"("isMultiPlatform");

-- CreateIndex
CREATE UNIQUE INDEX "ReviewCache_productHandle_key" ON "public"."ReviewCache"("productHandle");

-- CreateIndex
CREATE INDEX "ReviewCache_productHandle_idx" ON "public"."ReviewCache"("productHandle");

-- CreateIndex
CREATE INDEX "ReviewCache_expiresAt_idx" ON "public"."ReviewCache"("expiresAt");

-- CreateIndex
CREATE INDEX "ReviewCache_platform_idx" ON "public"."ReviewCache"("platform");

-- CreateIndex
CREATE UNIQUE INDEX "AppMetadata_shop_key" ON "public"."AppMetadata"("shop");

-- CreateIndex
CREATE INDEX "AppMetadata_shop_idx" ON "public"."AppMetadata"("shop");

-- CreateIndex
CREATE INDEX "AppMetadata_lastSync_idx" ON "public"."AppMetadata"("lastSync");

-- AddForeignKey
ALTER TABLE "public"."Review" ADD CONSTRAINT "Review_productId_fkey" FOREIGN KEY ("productId") REFERENCES "public"."Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."AiSummary" ADD CONSTRAINT "AiSummary_productId_fkey" FOREIGN KEY ("productId") REFERENCES "public"."Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
