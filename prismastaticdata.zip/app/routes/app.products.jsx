// routes/app.products.jsx 
import fs from "fs/promises";
import path from "path";
import { json } from "@remix-run/node";
import { useLoaderData, useFetcher } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  IndexTable,
  Text,
  Box,
  Thumbnail,
  Button,
  InlineStack,
  Modal,
} from "@shopify/polaris";
import { useState, useCallback } from "react";
import shopify from "../shopify.server"; 

const CACHE_DIR = path.join(process.cwd(), "cache");

export const loader = async () => {
  try {
    const files = await fs.readdir(CACHE_DIR);
    const aiFiles = files.filter((f) => f.startsWith("ai_summary_"));

    const products = [];
    for (const file of aiFiles) {
      const content = await fs.readFile(path.join(CACHE_DIR, file), "utf8");
      const data = JSON.parse(content);

      const handleFromFile = file.replace("ai_summary_", "").replace(".json", "");
      let product = {
        id: handleFromFile,
        title: handleFromFile,
        image: null,
        summary: data.summary || "No summary",
      };

      try {
        const admin = await shopify.admin();
        const response = await admin.graphql(
          `#graphql
          query getProduct($handle: String!) {
            productByHandle(handle: $handle) {
              id
              title
              featuredImage {
                originalSrc
                altText
              }
            }
          }`,
          { variables: { handle: handleFromFile } }
        );
        const body = await response.json();
        const productData = body?.data?.productByHandle;
        if (productData) {
          product.title = productData.title;
          product.image = productData.featuredImage?.originalSrc || null;
        }
      } catch (err) {
        console.error("❌ Product fetch error:", err);
      }

      products.push(product);
    }

    return json({ products });
  } catch (err) {
    console.error("Products loader error:", err);
    return json({ products: [] });
  }
};

export default function ProductsPage() {
  const { products } = useLoaderData();
  const fetcher = useFetcher();

  // State for Modal
  const [activeProduct, setActiveProduct] = useState(null);
  const toggleModal = useCallback(() => setActiveProduct(null), []);

  const handleViewSummary = (product) => {
    setActiveProduct(product);
  };

const handleRegenerate = (productId) => {
  fetcher.submit(
    { productHandle: productId, forceRegenerate: true }, // 👈 added forceRegenerate
    { method: "post", action: "/api/ai-review-summary" }
  );
};


  return (
    <Page title="Products" fullWidth>
      <Box paddingInline="6">
        <Layout>
          <Layout.Section>
            <Card>
              {products.length === 0 ? (
                <Text tone="subdued">No products with AI summaries yet.</Text>
              ) : (
                <IndexTable
                  resourceName={{ singular: "product", plural: "products" }}
                  itemCount={products.length}
                  selectable={false}
                  headings={[
                    { title: "Product" },
                    { title: "AI Summary" },
                    { title: "Actions" },
                  ]}
                >
                  {products.map((p, index) => (
                    <IndexTable.Row id={p.id} key={p.id} position={index}>
                      <IndexTable.Cell>
                        <InlineStack gap="200" blockAlign="center">
                          {p.image ? (
                            <Thumbnail source={p.image} alt={p.title} size="small" />
                          ) : (
                            <Thumbnail source="" alt="No image" size="small" />
                          )}
                          <Text variant="bodyMd" fontWeight="bold">
                            {p.title}
                          </Text>
                        </InlineStack>
                      </IndexTable.Cell>

                      <IndexTable.Cell>
                        <Box
                          as="p"
                          paddingInline="6"
                          overflowWrap="break-word"
                          style={{ whiteSpace: "normal", margin: 0 }}
                        >
                          {p.summary}
                        </Box>
                      </IndexTable.Cell>

                      <IndexTable.Cell>
                        <InlineStack gap="200">
                          <Button size="slim" onClick={() => handleViewSummary(p)}>
                            View Full Summary
                          </Button>
                          <Button
                            size="slim"
                            tone="critical"
                            onClick={() => handleRegenerate(p.id)}
                          >
                            Regenerate
                          </Button>
                        </InlineStack>
                      </IndexTable.Cell>
                    </IndexTable.Row>
                  ))}
                </IndexTable>
              )}
            </Card>
          </Layout.Section>
        </Layout>
      </Box>

      {/* Modal for View Full Summary */}
      {activeProduct && (
        <Modal
          open
          onClose={toggleModal}
          title={activeProduct.title}
          primaryAction={{ content: "Close", onAction: toggleModal }}
        >
          <Modal.Section>
            <Text>{activeProduct.summary}</Text>
          </Modal.Section>
        </Modal>
      )}
    </Page>
  );
}
