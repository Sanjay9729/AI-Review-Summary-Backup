// app/routes/app.reviews._index.jsx
import { json } from '@remix-run/node';
import { useLoaderData, Form, useSubmit, useNavigation } from '@remix-run/react';
import { 
  Page, 
  Card, 
  TextField, 
  Button, 
  Banner, 
  Text, 
  BlockStack, 
  InlineStack,
  Badge,
  DataTable
} from '@shopify/polaris';
import { useState } from 'react';
import { loadProductReviews, checkPlatformAvailability } from '../services/review-loader.js';
import { authenticate } from '../shopify.server.js';

/**
 * Admin interface for managing reviews
 * URL: /app/reviews
 */

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  
  try {
    // Check platform availability for this shop
    const platformStatus = await checkPlatformAvailability(shop);
    
    return json({
      shop,
      platformStatus
    });
    
  } catch (error) {
    console.error('Reviews admin loader error:', error);
    return json({
      shop,
      platformStatus: {
        judgeme: { available: false, configured: false },
        yotpo: { available: false, configured: false }
      },
      error: error.message
    });
  }
}

export async function action({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  
  const formData = await request.formData();
  const action = formData.get('action');
  const productHandle = formData.get('productHandle');
  
  if (!productHandle) {
    return json({ 
      success: false, 
      error: 'Product handle is required' 
    }, { status: 400 });
  }
  
  try {
    if (action === 'loadReviews') {
      // Load reviews for the specified product
      const result = await loadProductReviews(productHandle, shop);
      return json(result);
      
    } else if (action === 'checkPlatforms') {
      // Check platform availability
      const result = await checkPlatformAvailability(shop);
      return json({ success: true, platformStatus: result });
      
    } else {
      return json({ 
        success: false, 
        error: 'Invalid action' 
      }, { status: 400 });
    }
    
  } catch (error) {
    console.error('Reviews admin action error:', error);
    return json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}

export default function ReviewsAdmin() {
  const { shop, platformStatus, error: loaderError } = useLoaderData();
  const submit = useSubmit();
  const navigation = useNavigation();
  const [productHandle, setProductHandle] = useState('');
  const [result, setResult] = useState(null);
  
  const isLoading = navigation.state !== 'idle';
  
  const handleLoadReviews = () => {
    if (!productHandle.trim()) {
      setResult({ success: false, error: 'Please enter a product handle' });
      return;
    }
    
    const formData = new FormData();
    formData.append('action', 'loadReviews');
    formData.append('productHandle', productHandle.trim());
    
    submit(formData, { method: 'post' });
  };
  
  const getPlatformStatusBadge = (platform, status) => {
    if (status.available) {
      return <Badge status="success">✅ Available</Badge>;
    } else if (status.configured) {
      return <Badge status="attention">⚠️ Configured but not responding</Badge>;
    } else {
      return <Badge status="critical">❌ Not configured</Badge>;
    }
  };
  
  // Show result from form submission
  if (navigation.formData) {
    const formResult = navigation.formData;
    // This will be replaced by the actual result when the action completes
  }

  return (
    <Page
      title="Review Management"
      subtitle={`Manage reviews for ${shop}`}
    >
      <BlockStack gap="500">
        
        {/* Error Banner */}
        {loaderError && (
          <Banner status="critical">
            <Text as="p">Error loading review management: {loaderError}</Text>
          </Banner>
        )}
        
        {/* Platform Status */}
        <Card>
          <BlockStack gap="300">
            <Text variant="headingMd" as="h2">Platform Status</Text>
            <Text variant="bodyMd" tone="subdued">
              Check which review platforms are configured for your store
            </Text>
            
            <InlineStack gap="400">
              <div>
                <Text variant="bodyMd" as="p" fontWeight="medium">Judge.me</Text>
                {getPlatformStatusBadge('judgeme', platformStatus.judgeme)}
                <Text variant="bodySm" tone="subdued">
                  {platformStatus.judgeme.available ? 'Ready to load reviews' : 'Not available or not configured'}
                </Text>
              </div>
              
              <div>
                <Text variant="bodyMd" as="p" fontWeight="medium">Yotpo</Text>
                {getPlatformStatusBadge('yotpo', platformStatus.yotpo)}
                <Text variant="bodySm" tone="subdued">
                  {platformStatus.yotpo.configured 
                    ? `App Key: ${platformStatus.yotpo.appKey}` 
                    : 'No App Key configured'}
                </Text>
              </div>
            </InlineStack>
          </BlockStack>
        </Card>
        
        {/* Load Reviews Form */}
        <Card>
          <BlockStack gap="300">
            <Text variant="headingMd" as="h2">Load Product Reviews</Text>
            <Text variant="bodyMd" tone="subdued">
              Enter a product handle to load reviews from Judge.me and/or Yotpo
            </Text>
            
            <InlineStack gap="300">
              <div style={{ flex: 1 }}>
                <TextField
                  label="Product Handle"
                  value={productHandle}
                  onChange={setProductHandle}
                  placeholder="e.g., classic-white-t-shirt"
                  helpText="The product handle from your Shopify product URL"
                  autoComplete="off"
                />
              </div>
              <Button
                variant="primary"
                onClick={handleLoadReviews}
                loading={isLoading}
                disabled={!productHandle.trim()}
              >
                Load Reviews
              </Button>
            </InlineStack>
          </BlockStack>
        </Card>
        
        {/* Results */}
        {result && (
          <Card>
            <BlockStack gap="300">
              <Text variant="headingMd" as="h2">Results</Text>
              
              {result.success === false ? (
                <Banner status="critical">
                  <Text as="p">{result.error || 'Failed to load reviews'}</Text>
                </Banner>
              ) : (
                <BlockStack gap="300">
                  <Banner status="success">
                    <Text as="p">{result.message}</Text>
                  </Banner>
                  
                  {result.stats && (
                    <div>
                      <Text variant="bodyMd" as="p">
                        <strong>Total Reviews:</strong> {result.stats.total} | 
                        <strong> Average Rating:</strong> {result.stats.averageRating}/5
                      </Text>
                      
                      <InlineStack gap="200" style={{ marginTop: '10px' }}>
                        {Object.entries(result.stats.platforms || {}).map(([platform, count]) => (
                          <Badge 
                            key={platform} 
                            status={platform === 'Judge.me' ? 'success' : 'info'}
                          >
                            {platform}: {count}
                          </Badge>
                        ))}
                      </InlineStack>
                    </div>
                  )}
                  
                  {result.platforms && (
                    <div>
                      <Text variant="bodyMd" as="p" fontWeight="medium">Platform Summary:</Text>
                      <BlockStack gap="100" style={{ marginTop: '5px' }}>
                        <Text variant="bodySm">
                          Judge.me: {result.platforms.judgeme.available ? '✅' : '❌'} 
                          {result.platforms.judgeme.loaded ? ' (Loaded)' : ' (Skipped)'} - 
                          {result.platforms.judgeme.count} reviews
                        </Text>
                        <Text variant="bodySm">
                          Yotpo: {result.platforms.yotpo.available ? '✅' : '❌'} 
                          {result.platforms.yotpo.loaded ? ' (Loaded)' : ' (Skipped)'} - 
                          {result.platforms.yotpo.count} reviews
                        </Text>
                      </BlockStack>
                    </div>
                  )}
                </BlockStack>
              )}
            </BlockStack>
          </Card>
        )}
        
        {/* Usage Instructions */}
        <Card>
          <BlockStack gap="300">
            <Text variant="headingMd" as="h2">How to Display Reviews</Text>
            <Text variant="bodyMd">
              After loading reviews, you can display them on your website using these methods:
            </Text>
            
            <BlockStack gap="200">
              <div>
                <Text variant="bodyMd" fontWeight="medium">1. Review Widget Component</Text>
                <Text variant="bodySm" tone="subdued">
                  Import and use the ReviewWidget component in your product pages
                </Text>
                <div style={{ background: '#f6f6f7', padding: '10px', marginTop: '5px', borderRadius: '4px' }}>
                  <code style={{ fontSize: '12px' }}>
                    {`import { ReviewWidget } from '../components/ReviewWidget';
<ReviewWidget productHandle="product-handle" shopDomain="${shop}" />`}
                  </code>
                </div>
              </div>
              
              <div>
                <Text variant="bodyMd" fontWeight="medium">2. Direct Page Link</Text>
                <Text variant="bodySm" tone="subdued">
                  Link to the dedicated reviews page for any product
                </Text>
                <div style={{ background: '#f6f6f7', padding: '10px', marginTop: '5px', borderRadius: '4px' }}>
                  <code style={{ fontSize: '12px' }}>
                    /app/reviews/your-product-handle
                  </code>
                </div>
              </div>
              
              <div>
                <Text variant="bodyMd" fontWeight="medium">3. Command Line</Text>
                <Text variant="bodySm" tone="subdued">
                  Use the CLI script to load reviews for multiple products
                </Text>
                <div style={{ background: '#f6f6f7', padding: '10px', marginTop: '5px', borderRadius: '4px' }}>
                  <code style={{ fontSize: '12px' }}>
                    node scripts/load-reviews.js --handle=product-handle --shop={shop}
                  </code>
                </div>
              </div>
            </BlockStack>
          </BlockStack>
        </Card>
        
      </BlockStack>
    </Page>
  );
}
