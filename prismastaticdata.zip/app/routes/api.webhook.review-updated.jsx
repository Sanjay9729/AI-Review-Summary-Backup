// app/routes/api.webhook.review-updated.jsx
import { json } from "@remix-run/node";
import ReviewCache from "../../services/reviewCache.server";

export async function action({ request }) {
  console.log("🔔 Review webhook received");
  
  try {
    const payload = await request.json();
    console.log("📦 Webhook payload:", JSON.stringify(payload, null, 2));
    
    // Extract product handle from webhook data
    // This will vary depending on your review platform (Judge.me, Yotpo, etc.)
    let productHandle = null;
    
    // Judge.me webhook format
    if (payload.product?.handle) {
      productHandle = payload.product.handle;
    }
    // Yotpo webhook format  
    else if (payload.product_id) {
      productHandle = payload.product_handle || payload.product_id;
    }
    // Generic format
    else if (payload.productHandle) {
      productHandle = payload.productHandle;
    }
    
    if (!productHandle) {
      console.log("⚠️ No product handle found in webhook payload");
      return json({ success: false, error: "No product handle" }, { status: 400 });
    }
    
    console.log(`🎯 Processing review update for product: ${productHandle}`);
    
    // Clear the cached review data for this product
    await ReviewCache.delete(productHandle);
    console.log(`🗑️ Cleared cache for ${productHandle}`);
    
    // Optional: Pre-generate new AI summary immediately
    // This ensures the summary is ready when users visit the page
    try {
      console.log(`🤖 Pre-generating AI summary for ${productHandle}...`);
      
      // Import the scraper function
      const reviewScraper = await import("../../services/reviewScraper.server.js");
      const scrapeProductReviews = reviewScraper.default.scrapeProductReviews;
      
      // Scrape fresh reviews
      const reviewsData = await scrapeProductReviews(productHandle);
      
      if (reviewsData.success && reviewsData.reviews.length > 0) {
        // The scraper already caches the data, so we're done
        console.log(`✅ Pre-generated summary for ${productHandle}: ${reviewsData.reviews.length} reviews`);
      } else {
        console.log(`⚠️ No reviews found for ${productHandle} during pre-generation`);
      }
      
    } catch (pregenError) {
      console.error(`❌ Pre-generation failed for ${productHandle}:`, pregenError.message);
      // Don't fail the webhook - cache clearing is the important part
    }
    
    return json({ 
      success: true, 
      message: `Cache cleared and AI summary updated for ${productHandle}`,
      productHandle,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error("❌ Webhook processing error:", error.message);
    return json({ 
      success: false, 
      error: error.message 
    }, { status: 500 });
  }
}

// Handle preflight OPTIONS requests for CORS
export async function options() {
  return new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
