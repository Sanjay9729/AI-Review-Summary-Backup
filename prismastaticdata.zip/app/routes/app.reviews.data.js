// app/routes/app.reviews.data.js
import { json } from '@remix-run/node';
import { getProductReviewsForDisplay } from '../services/review-loader.js';
import { authenticate } from '../shopify.server.js';

/**
 * Data endpoint for ReviewWidget component
 * Returns reviews with priority logic applied
 * URL: /app/reviews/data?handle=product-handle&shop=shop.myshopify.com&max=10
 */

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  
  const url = new URL(request.url);
  const handle = url.searchParams.get('handle');
  const shop = url.searchParams.get('shop') || session.shop;
  const max = parseInt(url.searchParams.get('max')) || 10;
  
  if (!handle) {
    return json({ 
      success: false, 
      error: 'Product handle is required',
      reviews: [],
      stats: null,
      source: 'error'
    }, { status: 400 });
  }
  
  try {
    // Get reviews using our priority logic
    const result = await getProductReviewsForDisplay(handle, shop);
    
    // Limit the number of reviews returned
    const limitedReviews = result.reviews ? result.reviews.slice(0, max) : [];
    
    return json({
      success: result.success,
      reviews: limitedReviews,
      stats: result.stats,
      source: result.source,
      platforms: result.platforms,
      message: result.message,
      totalAvailable: result.reviews ? result.reviews.length : 0
    });
    
  } catch (error) {
    console.error('Review data endpoint error:', error);
    return json({
      success: false,
      error: error.message,
      reviews: [],
      stats: null,
      source: 'error'
    }, { status: 500 });
  }
}
