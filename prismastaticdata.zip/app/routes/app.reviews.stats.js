// app/routes/app.reviews.stats.js
import { json } from '@remix-run/node';
import { getReviewStats, getProductByIdentifier } from '../services/review-db.js';
import { authenticate } from '../shopify.server.js';

/**
 * Stats endpoint for ReviewSummary component
 * Returns just the statistics (rating, count) for product listings
 * URL: /app/reviews/stats?handle=product-handle&shop=shop.myshopify.com
 */

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  
  const url = new URL(request.url);
  const handle = url.searchParams.get('handle');
  const shop = url.searchParams.get('shop') || session.shop;
  
  if (!handle) {
    return json({ 
      success: false, 
      error: 'Product handle is required',
      stats: null
    }, { status: 400 });
  }
  
  try {
    // Get product first
    const product = await getProductByIdentifier(handle, shop);
    
    if (!product) {
      return json({
        success: false,
        error: 'Product not found',
        stats: { total: 0, averageRating: 0, platforms: {} }
      });
    }
    
    // Get review statistics
    const stats = await getReviewStats(product.id);
    
    return json({
      success: true,
      stats,
      productId: product.id,
      handle,
      shop
    });
    
  } catch (error) {
    console.error('Review stats endpoint error:', error);
    return json({
      success: false,
      error: error.message,
      stats: null
    }, { status: 500 });
  }
}
