// app/routes/app.reviews.$handle.jsx
import { json } from '@remix-run/node';
import { useLoaderData, Form, useNavigation } from '@remix-run/react';
import { Page, Card, DataTable, Badge, Button, Banner, Text, BlockStack, InlineStack } from '@shopify/polaris';
import { loadProductReviews, getProductReviewsForDisplay } from '../services/review-loader.js';
import { authenticate } from '../shopify.server.js';

/**
 * Direct frontend integration for displaying reviews
 * URL: /app/reviews/product-handle
 */

export async function loader({ request, params }) {
  const { admin, session } = await authenticate.admin(request);
  const { handle } = params;
  const shop = session.shop;
  
  if (!handle) {
    throw new Response('Product handle is required', { status: 400 });
  }
  
  try {
    // Get existing reviews for display
    const reviewData = await getProductReviewsForDisplay(handle, shop);
    
    return json({
      handle,
      shop,
      reviewData
    });
    
  } catch (error) {
    console.error('Reviews loader error:', error);
    return json({
      handle,
      shop,
      reviewData: {
        success: false,
        error: error.message,
        reviews: [],
        source: 'error'
      }
    });
  }
}

export async function action({ request, params }) {
  const { admin, session } = await authenticate.admin(request);
  const { handle } = params;
  const shop = session.shop;
  
  try {
    // Load fresh reviews from platforms
    const result = await loadProductReviews(handle, shop);
    
    return json(result);
    
  } catch (error) {
    console.error('Reviews action error:', error);
    return json({
      success: false,
      error: error.message
    });
  }
}

export default function ProductReviews() {
  const { handle, shop, reviewData } = useLoaderData();
  const navigation = useNavigation();
  const isLoading = navigation.state !== 'idle';
  
  const formatDate = (dateString) => {
    if (!dateString) return 'No date';
    return new Date(dateString).toLocaleDateString();
  };
  
  const getSourceBadge = (source) => {
    switch (source) {
      case 'Judge.me':
        return <Badge status="success">Judge.me</Badge>;
      case 'Yotpo':
        return <Badge status="info">Yotpo</Badge>;
      case 'both':
        return <Badge status="attention">Both Platforms</Badge>;
      default:
        return <Badge status="critical">No Reviews</Badge>;
    }
  };
  
  const reviewRows = reviewData.reviews?.map((review) => [
    review.author || 'Anonymous',
    `${review.rating}/5`,
    review.title || '-',
    review.text ? review.text.substring(0, 100) + (review.text.length > 100 ? '...' : '') : '-',
    review.platform,
    formatDate(review.reviewDate),
    review.verified ? 'Yes' : 'No'
  ]) || [];
  
  return (
    <Page
      title={`Reviews for ${handle}`}
      subtitle={reviewData.message || 'Loading reviews...'}
      primaryAction={
        <Form method="post">
          <Button
            variant="primary"
            loading={isLoading}
            submit
          >
            Refresh Reviews
          </Button>
        </Form>
      }
    >
      <BlockStack gap="500">
        {/* Status Banner */}
        {reviewData.success === false && (
          <Banner status="critical">
            <Text as="p">{reviewData.error || 'Failed to load reviews'}</Text>
          </Banner>
        )}
        
        {reviewData.success && reviewData.reviews.length === 0 && (
          <Banner status="info">
            <Text as="p">No reviews found from Judge.me or Yotpo for this product.</Text>
          </Banner>
        )}
        
        {/* Review Statistics */}
        {reviewData.success && reviewData.stats && (
          <Card>
            <BlockStack gap="300">
              <Text variant="headingMd" as="h2">Review Statistics</Text>
              <InlineStack gap="400">
                <Text as="p"><strong>Total Reviews:</strong> {reviewData.stats.total}</Text>
                <Text as="p"><strong>Average Rating:</strong> {reviewData.stats.averageRating}/5</Text>
                {getSourceBadge(reviewData.source)}
              </InlineStack>
              {reviewData.stats.platforms && Object.keys(reviewData.stats.platforms).length > 0 && (
                <InlineStack gap="300">
                  {Object.entries(reviewData.stats.platforms).map(([platform, count]) => (
                    <Badge key={platform} status={platform === 'Judge.me' ? 'success' : 'info'}>
                      {platform}: {count}
                    </Badge>
                  ))}
                </InlineStack>
              )}
            </BlockStack>
          </Card>
        )}
        
        {/* Reviews Table */}
        {reviewData.success && reviewData.reviews.length > 0 && (
          <Card>
            <DataTable
              columnContentTypes={[
                'text',      // Author
                'text',      // Rating
                'text',      // Title
                'text',      // Content
                'text',      // Platform
                'text',      // Date
                'text'       // Verified
              ]}
              headings={[
                'Author',
                'Rating',
                'Title',
                'Review',
                'Platform',
                'Date',
                'Verified'
              ]}
              rows={reviewRows}
              truncate
            />
          </Card>
        )}
      </BlockStack>
    </Page>
  );
}
