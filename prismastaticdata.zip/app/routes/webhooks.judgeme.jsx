import { json } from "@remix-run/node";
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const prisma = new PrismaClient();

export async function action({ request }) {
  console.log("🎯 Judge.me webhook received");
  
  try {
    // Verify this is a POST request
    if (request.method !== "POST") {
      console.log("❌ Invalid method:", request.method);
      return json({ error: "Method not allowed" }, { status: 405 });
    }

    // Get the raw body and headers
    const body = await request.text();
    const signature = request.headers.get("x-judgeme-signature");
    const eventType = request.headers.get("x-judgeme-event");
    
    console.log("📥 Webhook event type:", eventType);
    console.log("🔐 Signature present:", !!signature);
    console.log("📄 Body length:", body.length);

    // Verify webhook signature if secret is configured
    const webhookSecret = process.env.JUDGEME_WEBHOOK_SECRET;
    if (webhookSecret && signature) {
      const expectedSignature = crypto
        .createHmac("sha256", webhookSecret)
        .update(body)
        .digest("hex");
      
      const receivedSignature = signature.replace("sha256=", "");
      
      if (expectedSignature !== receivedSignature) {
        console.log("❌ Invalid webhook signature");
        return json({ error: "Invalid signature" }, { status: 401 });
      }
      
      console.log("✅ Webhook signature verified");
    }

    // Parse the webhook payload
    let webhookData;
    try {
      webhookData = JSON.parse(body);
    } catch (error) {
      console.log("❌ Invalid JSON payload:", error.message);
      return json({ error: "Invalid JSON" }, { status: 400 });
    }

    console.log("📦 Webhook data keys:", Object.keys(webhookData));

    // Handle different webhook events
    switch (eventType) {
      case "review.created":
      case "review.published":
      case "review.updated":
        return await handleReviewWebhook(webhookData, eventType);
      
      default:
        console.log("⚠️ Unhandled webhook event:", eventType);
        return json({ message: "Event not handled", eventType }, { status: 200 });
    }

  } catch (error) {
    console.error("❌ Webhook processing error:", error);
    return json({ error: "Internal server error" }, { status: 500 });
  }
}

async function handleReviewWebhook(data, eventType) {
  console.log("🔍 Processing review webhook...");
  
  try {
    // Extract review data from webhook payload
    const review = data.review || data;
    
    console.log("📝 Review data:", {
      id: review.id,
      rating: review.rating,
      author: review.reviewer?.name || review.name,
      productId: review.external_id || review.product_id,
      body: review.body?.substring(0, 50) + "..."
    });

    // Find the product in our database
    const product = await prisma.product.findFirst({
      where: {
        shopifyId: (review.external_id || review.product_id)?.toString()
      }
    });

    if (!product) {
      console.log("⚠️ Product not found for external_id:", review.external_id || review.product_id);
      
      // Try to create the product if we have enough info
      if (review.product && review.product.title) {
        const newProduct = await prisma.product.create({
          data: {
            shopifyId: (review.external_id || review.product_id).toString(),
            handle: review.product.handle || review.product.title.toLowerCase().replace(/\s+/g, '-'),
            title: review.product.title,
            shop: "sanjayvaghela-testing.myshopify.com",
            status: "ACTIVE"
          }
        });
        
        console.log("✨ Created new product:", newProduct.title);
        return await saveReviewToDatabase(newProduct, review, eventType);
      }
      
      return json({ 
        error: "Product not found", 
        external_id: review.external_id || review.product_id 
      }, { status: 404 });
    }

    // Save the review to our database
    return await saveReviewToDatabase(product, review, eventType);

  } catch (error) {
    console.error("❌ Error handling review webhook:", error);
    return json({ error: error.message }, { status: 500 });
  }
}

async function saveReviewToDatabase(product, reviewData, eventType) {
  try {
    // Check if review already exists
    const existingReview = await prisma.review.findFirst({
      where: {
        productId: product.id,
        author: reviewData.reviewer?.name || reviewData.name || "Anonymous",
        text: reviewData.body || reviewData.content || ""
      }
    });

    if (existingReview) {
      if (eventType === "review.updated") {
        // Update existing review
        const updatedReview = await prisma.review.update({
          where: { id: existingReview.id },
          data: {
            rating: reviewData.rating || existingReview.rating,
            title: reviewData.title || existingReview.title,
            text: reviewData.body || reviewData.content || existingReview.text,
            verified: reviewData.verified || existingReview.verified,
            reviewDate: reviewData.created_at ? new Date(reviewData.created_at) : existingReview.reviewDate,
          }
        });

        console.log("🔄 Updated existing review:", updatedReview.id);
        return json({ 
          message: "Review updated", 
          reviewId: updatedReview.id,
          product: product.title
        });
      } else {
        console.log("⏭️ Review already exists, skipping");
        return json({ 
          message: "Review already exists", 
          product: product.title 
        });
      }
    }

    // Create new review
    const newReview = await prisma.review.create({
      data: {
        productId: product.id,
        author: reviewData.reviewer?.name || reviewData.name || "Anonymous Customer",
        rating: reviewData.rating || 5,
        title: reviewData.title || "Customer Review",
        text: reviewData.body || reviewData.content || "",
        verified: reviewData.verified || true,
        platform: "Judge.me",
        reviewDate: reviewData.created_at ? new Date(reviewData.created_at) : new Date(),
        scrapedAt: new Date(),
      }
    });

    console.log("✅ New review saved:", {
      id: newReview.id,
      author: newReview.author,
      rating: newReview.rating,
      product: product.title
    });

    // Optional: Trigger AI summary refresh
    await triggerAISummaryRefresh(product.id);

    return json({ 
      message: "Review processed successfully", 
      reviewId: newReview.id,
      product: product.title,
      author: newReview.author,
      rating: newReview.rating
    });

  } catch (error) {
    console.error("❌ Error saving review to database:", error);
    return json({ error: error.message }, { status: 500 });
  }
}

async function triggerAISummaryRefresh(productId) {
  try {
    // Get review count for this product
    const reviewCount = await prisma.review.count({
      where: { productId }
    });

    // Only refresh summary if we have multiple reviews
    if (reviewCount >= 2) {
      console.log("🤖 Triggering AI summary refresh for product:", productId);
      // You could implement AI summary generation here
      // For now, we'll just log it
    }
  } catch (error) {
    console.log("⚠️ AI summary refresh failed:", error.message);
  }
}

// Handle GET requests for webhook verification
export async function loader({ request }) {
  // Some webhook services send GET requests for verification
  const url = new URL(request.url);
  const challenge = url.searchParams.get("challenge");
  
  if (challenge) {
    console.log("🔍 Webhook verification challenge received");
    return new Response(challenge, { status: 200 });
  }
  
  return json({ 
    message: "Judge.me webhook endpoint", 
    methods: ["POST"],
    events: ["review.created", "review.published", "review.updated"]
  });
}
