// app/components/ReviewWidget.jsx
import { useState, useEffect } from 'react';
import { Badge, Card, Text, BlockStack, InlineStack, Spinner, EmptyState } from '@shopify/polaris';

/**
 * Review Widget Component
 * Displays reviews with priority logic directly on product pages
 * No external API calls - loads reviews from your PostgreSQL database
 */
export function ReviewWidget({ productHandle, shopDomain, maxReviews = 10 }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [source, setSource] = useState('none');
  const [error, setError] = useState(null);

  useEffect(() => {
    loadReviews();
  }, [productHandle, shopDomain]);

  const loadReviews = async () => {
    setLoading(true);
    setError(null);

    try {
      // Load reviews directly from database using our priority logic
      const response = await fetch(`/app/reviews/data?handle=${productHandle}&shop=${shopDomain}&max=${maxReviews}`);
      
      if (!response.ok) {
        throw new Error('Failed to load reviews');
      }
      
      const data = await response.json();
      
      setReviews(data.reviews || []);
      setStats(data.stats || null);
      setSource(data.source || 'none');
      
    } catch (err) {
      console.error('Error loading reviews:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString();
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span key={i} style={{ color: i <= rating ? '#ffc107' : '#e0e0e0' }}>
          ★
        </span>
      );
    }
    return <span style={{ fontSize: '18px' }}>{stars}</span>;
  };

  const getSourceBadge = () => {
    switch (source) {
      case 'Judge.me':
        return <Badge status="success">Judge.me Reviews</Badge>;
      case 'Yotpo':
        return <Badge status="info">Yotpo Reviews</Badge>;
      case 'both':
        return <Badge status="attention">Judge.me + Yotpo Reviews</Badge>;
      default:
        return null;
    }
  };

  const getPriorityMessage = () => {
    if (source === 'Judge.me') {
      return 'Showing Judge.me reviews (priority platform)';
    } else if (source === 'Yotpo') {
      return 'Showing Yotpo reviews (Judge.me not available)';
    } else if (source === 'both') {
      return 'Showing reviews from both Judge.me and Yotpo platforms';
    } else {
      return 'No reviews available from Judge.me or Yotpo';
    }
  };

  if (loading) {
    return (
      <Card>
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <Spinner size="large" />
          <Text as="p" variant="bodyMd">Loading reviews...</Text>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <div style={{ textAlign: 'center', padding: '20px' }}>
          <Text as="p" variant="bodyMd" tone="critical">
            Error loading reviews: {error}
          </Text>
        </div>
      </Card>
    );
  }

  if (reviews.length === 0) {
    return (
      <Card>
        <EmptyState
          heading="No reviews found"
          image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
        >
          <p>No reviews available from Judge.me or Yotpo for this product.</p>
        </EmptyState>
      </Card>
    );
  }

  return (
    <Card>
      <BlockStack gap="400">
        {/* Header with statistics */}
        <div>
          <InlineStack gap="300" align="space-between">
            <div>
              <Text variant="headingMd" as="h3">Customer Reviews</Text>
              <Text variant="bodyMd" tone="subdued">{getPriorityMessage()}</Text>
            </div>
            {getSourceBadge()}
          </InlineStack>
          
          {stats && (
            <InlineStack gap="300" style={{ marginTop: '10px' }}>
              <Text as="span">
                <strong>{stats.total}</strong> reviews
              </Text>
              <Text as="span">
                {renderStars(Math.round(stats.averageRating))} <strong>{stats.averageRating}/5</strong>
              </Text>
            </InlineStack>
          )}
        </div>

        {/* Reviews list */}
        <BlockStack gap="300">
          {reviews.slice(0, maxReviews).map((review, index) => (
            <Card key={`${review.platform}-${review.id || index}`} background="subdued">
              <BlockStack gap="200">
                <InlineStack gap="200" align="space-between">
                  <InlineStack gap="200">
                    <Text variant="bodyMd" as="span" fontWeight="bold">
                      {review.author || 'Anonymous'}
                    </Text>
                    {review.verified && (
                      <Badge size="small" status="success">Verified</Badge>
                    )}
                  </InlineStack>
                  <InlineStack gap="200">
                    <Badge size="small" status={review.platform === 'Judge.me' ? 'success' : 'info'}>
                      {review.platform}
                    </Badge>
                    <Text variant="bodySm" tone="subdued">
                      {formatDate(review.reviewDate)}
                    </Text>
                  </InlineStack>
                </InlineStack>
                
                <div>
                  {renderStars(review.rating)}
                  {review.title && (
                    <Text variant="bodyMd" as="p" fontWeight="medium" style={{ marginTop: '5px' }}>
                      {review.title}
                    </Text>
                  )}
                </div>
                
                {review.text && (
                  <Text variant="bodyMd" as="p">
                    {review.text}
                  </Text>
                )}
              </BlockStack>
            </Card>
          ))}
        </BlockStack>

        {/* Show more indicator */}
        {stats && stats.total > maxReviews && (
          <div style={{ textAlign: 'center', padding: '10px' }}>
            <Text variant="bodyMd" tone="subdued">
              Showing {maxReviews} of {stats.total} reviews
            </Text>
          </div>
        )}
      </BlockStack>
    </Card>
  );
}

/**
 * Compact Review Summary Component
 * Shows just the rating and count for product listings
 */
export function ReviewSummary({ productHandle, shopDomain }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, [productHandle, shopDomain]);

  const loadStats = async () => {
    try {
      const response = await fetch(`/app/reviews/stats?handle=${productHandle}&shop=${shopDomain}`);
      if (response.ok) {
        const data = await response.json();
        setStats(data.stats);
      }
    } catch (err) {
      console.error('Error loading review stats:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span key={i} style={{ color: i <= rating ? '#ffc107' : '#e0e0e0' }}>
          ★
        </span>
      );
    }
    return <span style={{ fontSize: '14px' }}>{stars}</span>;
  };

  if (loading || !stats || stats.total === 0) {
    return null;
  }

  return (
    <InlineStack gap="200" style={{ alignItems: 'center' }}>
      {renderStars(Math.round(stats.averageRating))}
      <Text variant="bodySm">
        {stats.averageRating.toFixed(1)} ({stats.total} reviews)
      </Text>
    </InlineStack>
  );
}

export default ReviewWidget;
