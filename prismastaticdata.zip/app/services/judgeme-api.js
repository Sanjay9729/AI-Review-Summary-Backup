// app/services/judgeme-api.js
import db from '../db.server.js';

/**
 * Judge.me API integration for fetching product reviews
 */

/**
 * Fetch reviews from Judge.me for a specific product
 * @param {string} shopDomain - The shop domain (e.g., 'mystore.myshopify.com')
 * @param {string} productHandle - Product handle/slug
 * @param {string} apiToken - Judge.me API token (optional for public reviews)
 * @returns {Promise<Array>} Array of review objects
 */
export async function fetchJudgeMeReviews(shopDomain, productHandle, apiToken = null) {
  try {
    console.log(`🔍 Fetching Judge.me reviews for ${productHandle} from ${shopDomain}`);
    
    // Judge.me API endpoint for product reviews
    // Public API: https://{shop}.judge.me/api/v1/reviews?shop_domain={domain}&handle={handle}
    // Private API requires authentication
    const baseUrl = apiToken 
      ? `https://${shopDomain.replace('.myshopify.com', '')}.judge.me/api/v1/reviews`
      : `https://${shopDomain.replace('.myshopify.com', '')}.judge.me/api/v1/reviews`;
    
    const params = new URLSearchParams({
      shop_domain: shopDomain,
      handle: productHandle,
      per_page: 100, // Max reviews per page
      page: 1
    });
    
    const headers = {
      'Content-Type': 'application/json',
      'User-Agent': 'Shopify-Review-App/1.0'
    };
    
    if (apiToken) {
      headers['Authorization'] = `Bearer ${apiToken}`;
    }
    
    const response = await fetch(`${baseUrl}?${params}`, {
      method: 'GET',
      headers
    });
    
    if (!response.ok) {
      console.warn(`❌ Judge.me API error: ${response.status} ${response.statusText}`);
      return [];
    }
    
    const data = await response.json();
    
    // Judge.me API response structure
    const reviews = data.reviews || data.data || [];
    
    return reviews.map(review => ({
      externalId: review.id?.toString(),
      author: review.reviewer?.name || review.name || 'Anonymous',
      rating: parseFloat(review.rating || 0),
      title: review.title || null,
      text: review.body || review.content || null,
      verified: review.verified_buyer || false,
      platform: 'Judge.me',
      reviewDate: review.created_at ? new Date(review.created_at) : null,
      productHandle,
      shopDomain
    }));
    
  } catch (error) {
    console.error('❌ Error fetching Judge.me reviews:', error);
    return [];
  }
}

/**
 * Check if Judge.me is installed/configured for a shop
 * @param {string} shopDomain - The shop domain
 * @returns {Promise<boolean>} Whether Judge.me reviews are available
 */
export async function isJudgeMeAvailable(shopDomain) {
  try {
    // Try to fetch a small sample to check if Judge.me is configured
    const testUrl = `https://${shopDomain.replace('.myshopify.com', '')}.judge.me/api/v1/reviews?shop_domain=${shopDomain}&per_page=1`;
    
    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Shopify-Review-App/1.0'
      }
    });
    
    // If we get a valid response (even if empty), Judge.me is available
    return response.ok;
    
  } catch (error) {
    console.warn('Judge.me availability check failed:', error);
    return false;
  }
}

/**
 * Store Judge.me reviews in PostgreSQL
 * @param {Array} reviews - Array of processed review objects
 * @param {string} productId - Internal product ID
 * @returns {Promise<number>} Number of reviews stored
 */
export async function storeJudgeMeReviews(reviews, productId) {
  if (!reviews || reviews.length === 0) {
    return 0;
  }
  
  let storedCount = 0;
  
  for (const review of reviews) {
    try {
      // Check if review already exists (avoid duplicates)
      const existingReview = await db.review.findFirst({
        where: {
          productId,
          platform: 'Judge.me',
          author: review.author,
          rating: review.rating,
          text: review.text
        }
      });
      
      if (!existingReview) {
        await db.review.create({
          data: {
            productId,
            author: review.author,
            rating: review.rating,
            title: review.title,
            text: review.text,
            verified: review.verified,
            platform: 'Judge.me',
            reviewDate: review.reviewDate,
            scrapedAt: new Date()
          }
        });
        storedCount++;
      }
    } catch (error) {
      console.error('Error storing Judge.me review:', error);
    }
  }
  
  console.log(`✅ Stored ${storedCount} Judge.me reviews for product ${productId}`);
  return storedCount;
}

/**
 * Get Judge.me reviews from database for a product
 * @param {string} productId - Internal product ID
 * @returns {Promise<Array>} Array of reviews from database
 */
export async function getStoredJudgeMeReviews(productId) {
  try {
    return await db.review.findMany({
      where: {
        productId,
        platform: 'Judge.me'
      },
      orderBy: {
        reviewDate: 'desc'
      }
    });
  } catch (error) {
    console.error('Error fetching stored Judge.me reviews:', error);
    return [];
  }
}
