// app/services/review-db.js
import db from '../db.server.js';

/**
 * Centralized database service for handling reviews from multiple platforms
 */

/**
 * Store reviews in PostgreSQL with duplicate prevention
 * @param {Array} reviews - Array of review objects
 * @param {string} productId - Internal product ID
 * @param {string} platform - Platform name (Judge.me, Yotpo, etc.)
 * @returns {Promise<{stored: number, duplicates: number}>} Results summary
 */
export async function storeReviews(reviews, productId, platform) {
  if (!reviews || reviews.length === 0) {
    return { stored: 0, duplicates: 0 };
  }
  
  let storedCount = 0;
  let duplicateCount = 0;
  
  for (const review of reviews) {
    try {
      // Create a unique hash for duplicate detection
      const reviewHash = createReviewHash(review, platform);
      
      // Check if review already exists
      const existingReview = await db.review.findFirst({
        where: {
          OR: [
            // Exact match on key fields
            {
              productId,
              platform,
              author: review.author,
              rating: review.rating,
              text: review.text
            },
            // Hash-based duplicate detection
            {
              productId,
              platform,
              // Store hash in a custom field if needed
            }
          ]
        }
      });
      
      if (!existingReview) {
        await db.review.create({
          data: {
            productId,
            author: review.author || 'Anonymous',
            rating: parseFloat(review.rating || 0),
            title: review.title,
            text: review.text,
            verified: review.verified || false,
            platform,
            reviewDate: review.reviewDate,
            scrapedAt: new Date()
          }
        });
        storedCount++;
      } else {
        duplicateCount++;
      }
    } catch (error) {
      console.error(`Error storing ${platform} review:`, error);
    }
  }
  
  console.log(`✅ Stored ${storedCount} ${platform} reviews for product ${productId} (${duplicateCount} duplicates skipped)`);
  return { stored: storedCount, duplicates: duplicateCount };
}

/**
 * Get all reviews for a product from database
 * @param {string} productId - Internal product ID
 * @param {string} platform - Optional platform filter
 * @returns {Promise<Array>} Array of reviews
 */
export async function getProductReviews(productId, platform = null) {
  try {
    const where = { productId };
    if (platform) {
      where.platform = platform;
    }
    
    return await db.review.findMany({
      where,
      orderBy: [
        { reviewDate: 'desc' },
        { createdAt: 'desc' }
      ]
    });
  } catch (error) {
    console.error('Error fetching product reviews:', error);
    return [];
  }
}

/**
 * Get review count by platform for a product
 * @param {string} productId - Internal product ID
 * @returns {Promise<Object>} Platform counts
 */
export async function getReviewCountsByPlatform(productId) {
  try {
    const counts = await db.review.groupBy({
      by: ['platform'],
      where: { productId },
      _count: {
        id: true
      }
    });
    
    return counts.reduce((acc, item) => {
      acc[item.platform] = item._count.id;
      return acc;
    }, {});
  } catch (error) {
    console.error('Error fetching review counts:', error);
    return {};
  }
}

/**
 * Check which platforms have reviews for a product
 * @param {string} productId - Internal product ID
 * @returns {Promise<Array>} Array of platform names that have reviews
 */
export async function getAvailablePlatforms(productId) {
  try {
    const platforms = await db.review.findMany({
      where: { productId },
      select: { platform: true },
      distinct: ['platform']
    });
    
    return platforms.map(p => p.platform).filter(Boolean);
  } catch (error) {
    console.error('Error fetching available platforms:', error);
    return [];
  }
}

/**
 * Get reviews with prioritization logic
 * @param {string} productId - Internal product ID
 * @param {Array} platformPriority - Array of platforms in order of preference
 * @returns {Promise<{reviews: Array, platforms: Array, source: string}>} Reviews with metadata
 */
export async function getReviewsWithPriority(productId, platformPriority = ['Judge.me', 'Yotpo']) {
  try {
    const availablePlatforms = await getAvailablePlatforms(productId);
    const counts = await getReviewCountsByPlatform(productId);
    
    console.log(`📊 Available platforms for product ${productId}:`, availablePlatforms);
    console.log(`📊 Review counts:`, counts);
    
    // Determine which platforms to show based on priority
    let platformsToShow = [];
    let source = 'none';
    
    // Check if Judge.me has reviews (highest priority)
    if (availablePlatforms.includes('Judge.me')) {
      platformsToShow.push('Judge.me');
      source = 'Judge.me';
    }
    
    // If Judge.me not available, check Yotpo
    if (!platformsToShow.length && availablePlatforms.includes('Yotpo')) {
      platformsToShow.push('Yotpo');
      source = 'Yotpo';
    }
    
    // If both are available, show both
    if (availablePlatforms.includes('Judge.me') && availablePlatforms.includes('Yotpo')) {
      platformsToShow = ['Judge.me', 'Yotpo'];
      source = 'both';
    }
    
    // Get reviews from selected platforms
    const reviews = platformsToShow.length > 0 
      ? await db.review.findMany({
          where: {
            productId,
            platform: { in: platformsToShow }
          },
          orderBy: [
            { reviewDate: 'desc' },
            { createdAt: 'desc' }
          ]
        })
      : [];
    
    return {
      reviews,
      platforms: platformsToShow,
      source,
      counts,
      availablePlatforms
    };
    
  } catch (error) {
    console.error('Error fetching reviews with priority:', error);
    return { reviews: [], platforms: [], source: 'error', counts: {}, availablePlatforms: [] };
  }
}

/**
 * Delete old reviews for a product (cleanup)
 * @param {string} productId - Internal product ID
 * @param {string} platform - Platform to clean
 * @param {number} daysOld - Delete reviews older than this many days
 * @returns {Promise<number>} Number of deleted reviews
 */
export async function cleanupOldReviews(productId, platform, daysOld = 90) {
  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);
    
    const deleted = await db.review.deleteMany({
      where: {
        productId,
        platform,
        scrapedAt: {
          lt: cutoffDate
        }
      }
    });
    
    console.log(`🧹 Cleaned up ${deleted.count} old ${platform} reviews for product ${productId}`);
    return deleted.count;
  } catch (error) {
    console.error('Error cleaning up old reviews:', error);
    return 0;
  }
}

/**
 * Get product by handle or Shopify ID
 * @param {string} identifier - Product handle or Shopify ID
 * @param {string} shop - Shop domain
 * @returns {Promise<Object|null>} Product object or null
 */
export async function getProductByIdentifier(identifier, shop) {
  try {
    // Try by handle first
    let product = await db.product.findFirst({
      where: {
        handle: identifier,
        shop
      }
    });
    
    // If not found, try by Shopify ID
    if (!product) {
      product = await db.product.findFirst({
        where: {
          shopifyId: identifier,
          shop
        }
      });
    }
    
    return product;
  } catch (error) {
    console.error('Error finding product:', error);
    return null;
  }
}

/**
 * Create or update product record
 * @param {Object} productData - Product data
 * @returns {Promise<Object>} Product object
 */
export async function upsertProduct(productData) {
  try {
    return await db.product.upsert({
      where: {
        shopifyId: productData.shopifyId
      },
      update: {
        title: productData.title,
        handle: productData.handle,
        status: productData.status,
        updatedAt: new Date()
      },
      create: {
        shopifyId: productData.shopifyId,
        handle: productData.handle,
        title: productData.title,
        shop: productData.shop,
        status: productData.status
      }
    });
  } catch (error) {
    console.error('Error upserting product:', error);
    throw error;
  }
}

/**
 * Create a simple hash for duplicate detection
 * @param {Object} review - Review object
 * @param {string} platform - Platform name
 * @returns {string} Simple hash string
 */
function createReviewHash(review, platform) {
  const content = `${platform}-${review.author}-${review.rating}-${(review.text || '').substring(0, 100)}`;
  return Buffer.from(content).toString('base64').substring(0, 32);
}

/**
 * Get review statistics for a product
 * @param {string} productId - Internal product ID
 * @returns {Promise<Object>} Review statistics
 */
export async function getReviewStats(productId) {
  try {
    const stats = await db.review.aggregate({
      where: { productId },
      _count: { id: true },
      _avg: { rating: true },
      _min: { rating: true },
      _max: { rating: true }
    });
    
    const platformBreakdown = await getReviewCountsByPlatform(productId);
    
    return {
      total: stats._count.id,
      averageRating: stats._avg.rating ? Number(stats._avg.rating.toFixed(2)) : 0,
      minRating: stats._min.rating || 0,
      maxRating: stats._max.rating || 0,
      platforms: platformBreakdown
    };
  } catch (error) {
    console.error('Error fetching review statistics:', error);
    return { total: 0, averageRating: 0, minRating: 0, maxRating: 0, platforms: {} };
  }
}
