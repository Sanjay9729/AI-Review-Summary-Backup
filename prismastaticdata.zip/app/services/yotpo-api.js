// app/services/yotpo-api.js
import db from '../db.server.js';

/**
 * Yotpo API integration for fetching product reviews
 */

/**
 * Fetch reviews from Yotpo for a specific product
 * @param {string} appKey - Yotpo App Key
 * @param {string} productId - Shopify product ID or handle
 * @param {string} secret - Yotpo secret (for authenticated requests)
 * @returns {Promise<Array>} Array of review objects
 */
export async function fetchYotpoReviews(appKey, productId, secret = null) {
  try {
    console.log(`🔍 Fetching Yotpo reviews for product ${productId}`);
    
    // Yotpo API endpoint for product reviews
    // Public API: https://api.yotpo.com/v1/apps/{app_key}/products/{product_id}/reviews
    const baseUrl = `https://api.yotpo.com/v1/apps/${appKey}/products/${productId}/reviews`;
    
    const params = new URLSearchParams({
      per_page: 100, // Max reviews per page
      page: 1,
      count: 100
    });
    
    const headers = {
      'Content-Type': 'application/json',
      'User-Agent': 'Shopify-Review-App/1.0'
    };
    
    // For authenticated requests, add authorization
    if (secret) {
      headers['Authorization'] = `Bearer ${secret}`;
    }
    
    const response = await fetch(`${baseUrl}?${params}`, {
      method: 'GET',
      headers
    });
    
    if (!response.ok) {
      console.warn(`❌ Yotpo API error: ${response.status} ${response.statusText}`);
      return [];
    }
    
    const data = await response.json();
    
    // Yotpo API response structure
    const reviews = data.reviews || [];
    
    return reviews.map(review => ({
      externalId: review.id?.toString(),
      author: review.user?.display_name || review.name || 'Anonymous',
      rating: parseFloat(review.score || 0),
      title: review.title || null,
      text: review.content || null,
      verified: review.verified_buyer || false,
      platform: 'Yotpo',
      reviewDate: review.created_at ? new Date(review.created_at) : null,
      productId,
      appKey
    }));
    
  } catch (error) {
    console.error('❌ Error fetching Yotpo reviews:', error);
    return [];
  }
}

/**
 * Check if Yotpo is installed/configured for a shop
 * @param {string} appKey - Yotpo App Key
 * @param {string} testProductId - A product ID to test with
 * @returns {Promise<boolean>} Whether Yotpo reviews are available
 */
export async function isYotpoAvailable(appKey, testProductId = 'test') {
  try {
    // Try to fetch a small sample to check if Yotpo is configured
    const testUrl = `https://api.yotpo.com/v1/apps/${appKey}/products/${testProductId}/reviews?per_page=1`;
    
    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Shopify-Review-App/1.0'
      }
    });
    
    // If we get a valid response (even if empty), Yotpo is available
    // Yotpo returns 200 even for non-existent products, but with empty reviews array
    return response.ok;
    
  } catch (error) {
    console.warn('Yotpo availability check failed:', error);
    return false;
  }
}

/**
 * Get Yotpo App Key from store configuration or environment
 * @param {string} shopDomain - The shop domain
 * @returns {Promise<string|null>} Yotpo App Key if configured
 */
export async function getYotpoAppKey(shopDomain) {
  try {
    // First check environment variables
    if (process.env.YOTPO_APP_KEY) {
      return process.env.YOTPO_APP_KEY;
    }
    
    // Check app metadata for shop-specific configuration
    const metadata = await db.appMetadata.findFirst({
      where: { shop: shopDomain }
    });
    
    if (metadata?.settings?.yotpoAppKey) {
      return metadata.settings.yotpoAppKey;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting Yotpo App Key:', error);
    return null;
  }
}

/**
 * Store Yotpo reviews in PostgreSQL
 * @param {Array} reviews - Array of processed review objects
 * @param {string} productId - Internal product ID
 * @returns {Promise<number>} Number of reviews stored
 */
export async function storeYotpoReviews(reviews, productId) {
  if (!reviews || reviews.length === 0) {
    return 0;
  }
  
  let storedCount = 0;
  
  for (const review of reviews) {
    try {
      // Check if review already exists (avoid duplicates)
      const existingReview = await db.review.findFirst({
        where: {
          productId,
          platform: 'Yotpo',
          author: review.author,
          rating: review.rating,
          text: review.text
        }
      });
      
      if (!existingReview) {
        await db.review.create({
          data: {
            productId,
            author: review.author,
            rating: review.rating,
            title: review.title,
            text: review.text,
            verified: review.verified,
            platform: 'Yotpo',
            reviewDate: review.reviewDate,
            scrapedAt: new Date()
          }
        });
        storedCount++;
      }
    } catch (error) {
      console.error('Error storing Yotpo review:', error);
    }
  }
  
  console.log(`✅ Stored ${storedCount} Yotpo reviews for product ${productId}`);
  return storedCount;
}

/**
 * Get Yotpo reviews from database for a product
 * @param {string} productId - Internal product ID
 * @returns {Promise<Array>} Array of reviews from database
 */
export async function getStoredYotpoReviews(productId) {
  try {
    return await db.review.findMany({
      where: {
        productId,
        platform: 'Yotpo'
      },
      orderBy: {
        reviewDate: 'desc'
      }
    });
  } catch (error) {
    console.error('Error fetching stored Yotpo reviews:', error);
    return [];
  }
}

/**
 * Fetch Yotpo reviews using bottom line API (alternative endpoint)
 * @param {string} appKey - Yotpo App Key
 * @param {string} domain - Store domain
 * @param {string} sku - Product SKU or handle
 * @returns {Promise<Array>} Array of review objects
 */
export async function fetchYotpoBottomLineReviews(appKey, domain, sku) {
  try {
    console.log(`🔍 Fetching Yotpo bottom line reviews for SKU ${sku}`);
    
    const url = `https://api.yotpo.com/products/${appKey}/${sku}/bottomline`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Shopify-Review-App/1.0'
      }
    });
    
    if (!response.ok) {
      console.warn(`❌ Yotpo Bottom Line API error: ${response.status}`);
      return [];
    }
    
    const data = await response.json();
    
    // Bottom line API returns aggregated data, not individual reviews
    // This is more for checking if product has reviews
    return data;
    
  } catch (error) {
    console.error('❌ Error fetching Yotpo bottom line:', error);
    return [];
  }
}
