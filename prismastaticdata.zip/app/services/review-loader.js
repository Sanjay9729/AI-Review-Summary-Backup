// app/services/review-loader.js
import { 
  fetchJudgeMeReviews, 
  isJudgeMeAvailable,
  storeJudgeMeReviews,
  getStoredJudgeMeReviews 
} from './judgeme-api.js';

import { 
  fetchYotpoReviews, 
  isYotpoAvailable,
  getYotpoAppKey,
  storeYotpoReviews,
  getStoredYotpoReviews 
} from './yotpo-api.js';

import {
  storeReviews,
  getReviewsWithPriority,
  getProductByIdentifier,
  upsertProduct,
  getReviewStats
} from './review-db.js';

/**
 * Main review loading orchestrator implementing the priority logic:
 * - If Judge.me reviews are loaded, show them in PostgreSQL
 * - If Judge.me reviews are not loaded, and Yotpo reviews are loaded, show Yotpo
 * - If both are loaded, show both
 */

/**
 * Load and store reviews for a product with priority logic
 * @param {string} productHandle - Product handle/slug
 * @param {string} shopDomain - Shop domain (e.g., 'mystore.myshopify.com')
 * @param {Object} options - Configuration options
 * @returns {Promise<Object>} Results with reviews and metadata
 */
export async function loadProductReviews(productHandle, shopDomain, options = {}) {
  console.log(`🚀 Loading reviews for product "${productHandle}" from shop "${shopDomain}"`);
  
  const {
    forceRefresh = false,
    judgemeApiToken = null,
    yotpoAppKey = null
  } = options;
  
  try {
    // Get or create product record
    let product = await getProductByIdentifier(productHandle, shopDomain);
    
    if (!product) {
      console.log(`📝 Creating new product record for ${productHandle}`);
      product = await upsertProduct({
        shopifyId: `temp_${productHandle}`, // This should be replaced with actual Shopify ID
        handle: productHandle,
        title: productHandle.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        shop: shopDomain,
        status: 'ACTIVE'
      });
    }
    
    const productId = product.id;
    
    // Check availability of review platforms
    const judgemeAvailable = await isJudgeMeAvailable(shopDomain);
    const yotpoKey = yotpoAppKey || await getYotpoAppKey(shopDomain);
    const yotpoAvailable = yotpoKey ? await isYotpoAvailable(yotpoKey, productHandle) : false;
    
    console.log(`🔍 Platform availability - Judge.me: ${judgemeAvailable}, Yotpo: ${yotpoAvailable}`);
    
    let results = {
      success: true,
      productId,
      productHandle,
      shopDomain,
      platforms: {
        judgeme: { available: judgemeAvailable, loaded: false, count: 0 },
        yotpo: { available: yotpoAvailable, loaded: false, count: 0 }
      },
      reviews: [],
      source: 'none',
      message: 'No reviews found'
    };
    
    // Load Judge.me reviews if available
    if (judgemeAvailable) {
      try {
        console.log(`📥 Fetching Judge.me reviews for ${productHandle}`);
        const judgemeReviews = await fetchJudgeMeReviews(shopDomain, productHandle, judgemeApiToken);
        
        if (judgemeReviews.length > 0) {
          const storeResult = await storeReviews(judgemeReviews, productId, 'Judge.me');
          results.platforms.judgeme.loaded = true;
          results.platforms.judgeme.count = storeResult.stored + storeResult.duplicates;
          console.log(`✅ Judge.me: ${storeResult.stored} new reviews stored, ${storeResult.duplicates} duplicates skipped`);
        }
      } catch (error) {
        console.error('❌ Error loading Judge.me reviews:', error);
        results.platforms.judgeme.error = error.message;
      }
    }
    
    // Load Yotpo reviews if available
    if (yotpoAvailable && yotpoKey) {
      try {
        console.log(`📥 Fetching Yotpo reviews for ${productHandle}`);
        const yotpoReviews = await fetchYotpoReviews(yotpoKey, productHandle);
        
        if (yotpoReviews.length > 0) {
          const storeResult = await storeReviews(yotpoReviews, productId, 'Yotpo');
          results.platforms.yotpo.loaded = true;
          results.platforms.yotpo.count = storeResult.stored + storeResult.duplicates;
          console.log(`✅ Yotpo: ${storeResult.stored} new reviews stored, ${storeResult.duplicates} duplicates skipped`);
        }
      } catch (error) {
        console.error('❌ Error loading Yotpo reviews:', error);
        results.platforms.yotpo.error = error.message;
      }
    }
    
    // Apply priority logic to determine which reviews to show
    const reviewsResult = await getReviewsWithPriority(productId);
    results.reviews = reviewsResult.reviews;
    results.source = reviewsResult.source;
    results.platformsToShow = reviewsResult.platforms;
    results.stats = await getReviewStats(productId);
    
    // Generate result message
    if (results.source === 'Judge.me') {
      results.message = `Showing ${results.reviews.length} Judge.me reviews`;
    } else if (results.source === 'Yotpo') {
      results.message = `Showing ${results.reviews.length} Yotpo reviews (Judge.me not available)`;
    } else if (results.source === 'both') {
      const judgeCount = results.stats.platforms['Judge.me'] || 0;
      const yotpoCount = results.stats.platforms['Yotpo'] || 0;
      results.message = `Showing ${results.reviews.length} reviews from both Judge.me (${judgeCount}) and Yotpo (${yotpoCount})`;
    } else {
      results.message = 'No reviews loaded from any platform';
      results.success = false;
    }
    
    console.log(`🎯 ${results.message}`);
    return results;
    
  } catch (error) {
    console.error('❌ Error in loadProductReviews:', error);
    return {
      success: false,
      error: error.message,
      productHandle,
      shopDomain,
      message: `Error loading reviews: ${error.message}`
    };
  }
}

/**
 * Get reviews for display with priority logic (without refreshing)
 * @param {string} productHandle - Product handle/slug
 * @param {string} shopDomain - Shop domain
 * @returns {Promise<Object>} Reviews with metadata
 */
export async function getProductReviewsForDisplay(productHandle, shopDomain) {
  try {
    const product = await getProductByIdentifier(productHandle, shopDomain);
    
    if (!product) {
      return {
        success: false,
        message: 'Product not found',
        reviews: [],
        source: 'none'
      };
    }
    
    const reviewsResult = await getReviewsWithPriority(product.id);
    const stats = await getReviewStats(product.id);
    
    return {
      success: true,
      productId: product.id,
      productHandle,
      shopDomain,
      reviews: reviewsResult.reviews,
      source: reviewsResult.source,
      platforms: reviewsResult.platforms,
      stats,
      message: generateDisplayMessage(reviewsResult, stats)
    };
    
  } catch (error) {
    console.error('Error getting reviews for display:', error);
    return {
      success: false,
      error: error.message,
      reviews: [],
      source: 'error'
    };
  }
}

/**
 * Check platform availability for a shop
 * @param {string} shopDomain - Shop domain
 * @param {string} yotpoAppKey - Optional Yotpo app key
 * @returns {Promise<Object>} Platform availability status
 */
export async function checkPlatformAvailability(shopDomain, yotpoAppKey = null) {
  try {
    const judgemeAvailable = await isJudgeMeAvailable(shopDomain);
    const yotpoKey = yotpoAppKey || await getYotpoAppKey(shopDomain);
    const yotpoAvailable = yotpoKey ? await isYotpoAvailable(yotpoKey) : false;
    
    return {
      judgeme: {
        available: judgemeAvailable,
        configured: judgemeAvailable
      },
      yotpo: {
        available: yotpoAvailable,
        configured: !!yotpoKey,
        appKey: yotpoKey ? '***' + yotpoKey.slice(-4) : null
      }
    };
  } catch (error) {
    console.error('Error checking platform availability:', error);
    return {
      judgeme: { available: false, configured: false },
      yotpo: { available: false, configured: false }
    };
  }
}

/**
 * Batch load reviews for multiple products
 * @param {Array} products - Array of {handle, shopDomain} objects
 * @param {Object} options - Configuration options
 * @returns {Promise<Array>} Array of results
 */
export async function batchLoadReviews(products, options = {}) {
  const results = [];
  
  for (const product of products) {
    try {
      const result = await loadProductReviews(product.handle, product.shopDomain, options);
      results.push(result);
    } catch (error) {
      results.push({
        success: false,
        productHandle: product.handle,
        shopDomain: product.shopDomain,
        error: error.message
      });
    }
  }
  
  return results;
}

/**
 * Generate display message based on review results
 * @param {Object} reviewsResult - Results from getReviewsWithPriority
 * @param {Object} stats - Review statistics
 * @returns {string} Display message
 */
function generateDisplayMessage(reviewsResult, stats) {
  const { source, reviews } = reviewsResult;
  const totalReviews = reviews.length;
  
  if (source === 'Judge.me') {
    return `Displaying ${totalReviews} Judge.me reviews (avg rating: ${stats.averageRating}/5)`;
  } else if (source === 'Yotpo') {
    return `Displaying ${totalReviews} Yotpo reviews (Judge.me not available, avg rating: ${stats.averageRating}/5)`;
  } else if (source === 'both') {
    const judgeCount = stats.platforms['Judge.me'] || 0;
    const yotpoCount = stats.platforms['Yotpo'] || 0;
    return `Displaying ${totalReviews} reviews from Judge.me (${judgeCount}) and Yotpo (${yotpoCount}) - avg rating: ${stats.averageRating}/5`;
  } else {
    return 'No reviews available from Judge.me or Yotpo';
  }
}

/**
 * Export the main function for backward compatibility
 */
export default loadProductReviews;
