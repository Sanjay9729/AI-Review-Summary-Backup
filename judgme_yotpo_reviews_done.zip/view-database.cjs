const { PrismaClient } = require('@prisma/client');
const http = require('http');
const url = require('url');

const prisma = new PrismaClient();
const PORT = 8080;

async function generateHTML() {
  try {
    // Get products with review counts
    const products = await prisma.product.findMany({
      include: {
        reviews: true,
        _count: {
          select: { reviews: true }
        }
      }
    });

    // Get all reviews
    const reviews = await prisma.review.findMany({
      include: {
        product: true
      },
      orderBy: {
        scrapedAt: 'desc'
      }
    });

    const totalReviews = reviews.length;
    const avgRating = reviews.length > 0 ? 
      (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : 0;

    let html = `
<!DOCTYPE html>
<html>
<head>
    <title>Shopify App - PostgreSQL Database Viewer</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .stats { display: flex; justify-content: space-around; margin: 20px 0; }
        .stat-card { background: #007cba; color: white; padding: 15px; border-radius: 8px; text-align: center; min-width: 100px; }
        .stat-number { font-size: 24px; font-weight: bold; }
        .stat-label { font-size: 14px; margin-top: 5px; }
        .section { margin: 30px 0; }
        .section h2 { color: #333; border-bottom: 2px solid #007cba; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #007cba; color: white; }
        tr:hover { background-color: #f5f5f5; }
        .rating { color: #ff6b35; font-weight: bold; }
        .product-link { color: #007cba; text-decoration: none; }
        .product-link:hover { text-decoration: underline; }
        .review-text { max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .expand { cursor: pointer; color: #007cba; }
        .refresh-btn { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin-bottom: 20px; }
        .refresh-btn:hover { background: #005a8a; }
    </style>
    <script>
        function expandText(element) {
            const td = element.parentElement;
            const fullText = td.getAttribute('data-full-text');
            td.innerHTML = fullText;
        }
        function refreshPage() {
            window.location.reload();
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛍️ Shopify App Database</h1>
            <p>PostgreSQL Database Content Viewer</p>
            <button class="refresh-btn" onclick="refreshPage()">🔄 Refresh Data</button>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">${products.length}</div>
                <div class="stat-label">Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${totalReviews}</div>
                <div class="stat-label">Reviews</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${avgRating}</div>
                <div class="stat-label">Avg Rating</div>
            </div>
        </div>

        <div class="section">
            <h2>📦 Products Overview</h2>
            <table>
                <thead>
                    <tr>
                        <th>Product Handle</th>
                        <th>Title</th>
                        <th>Reviews</th>
                        <th>Avg Rating</th>
                        <th>Shop</th>
                    </tr>
                </thead>
                <tbody>`;

    products.forEach(product => {
      const avgProductRating = product.reviews.length > 0 ? 
        (product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length).toFixed(1) : 'N/A';
      
      html += `
                    <tr>
                        <td><span class="product-link">${product.handle}</span></td>
                        <td>${product.title}</td>
                        <td>${product._count.reviews}</td>
                        <td><span class="rating">${avgProductRating}</span></td>
                        <td>${product.shop}</td>
                    </tr>`;
    });

    html += `
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>💬 Recent Reviews</h2>
            <table>
                <thead>
                    <tr>
                        <th>Author</th>
                        <th>Rating</th>
                        <th>Review Text</th>
                        <th>Product</th>
                        <th>Platform</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>`;

    reviews.forEach(review => {
      const reviewText = review.text || 'No text provided';
      const shortText = reviewText.length > 60 ? reviewText.substring(0, 60) + '...' : reviewText;
      const displayText = reviewText.length > 60 ? 
        `${shortText} <span class="expand" onclick="expandText(this)">Show more</span>` : 
        reviewText;

      html += `
                    <tr>
                        <td>${review.author}</td>
                        <td><span class="rating">${'⭐'.repeat(Math.floor(review.rating))}</span> ${review.rating}</td>
                        <td class="review-text" data-full-text="${reviewText.replace(/"/g, '&quot;')}">${displayText}</td>
                        <td><span class="product-link">${review.product.handle}</span></td>
                        <td>${review.platform}</td>
                        <td>${new Date(review.scrapedAt).toLocaleDateString()}</td>
                    </tr>`;
    });

    html += `
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>🔧 Database Connection Info</h2>
            <p><strong>Database:</strong> shopify_app_dev</p>
            <p><strong>Host:</strong> localhost:5432</p>
            <p><strong>User:</strong> postgres</p>
            <p><strong>Tables:</strong> Product, Review, AiSummary, ReviewCache, Session, AppMetadata</p>
            <p><strong>Last Updated:</strong> ${new Date().toLocaleString()}</p>
        </div>
    </div>
</body>
</html>`;

    return html;

  } catch (error) {
    return `
<!DOCTYPE html>
<html>
<head><title>Database Error</title></head>
<body>
    <h1>Database Connection Error</h1>
    <p>Could not connect to PostgreSQL database:</p>
    <pre>${error.message}</pre>
    <p>Make sure PostgreSQL is running and the database exists.</p>
</body>
</html>`;
  }
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  
  if (parsedUrl.pathname === '/') {
    try {
      const html = await generateHTML();
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(html);
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Server Error: ' + error.message);
    }
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Page not found');
  }
});

server.listen(PORT, () => {
  console.log(`🌐 Database Viewer running at: http://localhost:${PORT}`);
  console.log('📊 View your PostgreSQL data in your web browser!');
  console.log('Press Ctrl+C to stop the server');
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\\nShutting down database viewer...');
  await prisma.$disconnect();
  server.close(() => {
    console.log('Server closed.');
    process.exit(0);
  });
});
