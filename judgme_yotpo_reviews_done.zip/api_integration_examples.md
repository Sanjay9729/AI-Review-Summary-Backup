# Reviews Database API Integration Examples

## Database Connection Details
- **Host:** localhost
- **Port:** 5432
- **Database:** reviews_db
- **Username:** postgres
- **Password:** [your password]

## Table Schema
```sql
CREATE TABLE reviews (
    id SERIAL PRIMARY KEY,
    source VARCHAR(20) CHECK (source IN ('judgeme', 'yotpo', 'grok_ai')),
    source_review_id VARCHAR(255),
    product_id VARCHAR(255) NOT NULL,
    product_name VARCHAR(500),
    product_sku VARCHAR(255),
    customer_id VARCHAR(255),
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(255),
    review_text TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_featured BOOLEAN DEFAULT FALSE,
    helpful_votes INTEGER DEFAULT 0,
    review_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);
```

---

## 1. Node.js / JavaScript Integration

### Installation
```bash
npm install pg
```

### Connection Example
```javascript
const { Client } = require('pg');

const client = new Client({
  host: 'localhost',
  port: 5432,
  database: 'reviews_db',
  user: 'postgres',
  password: 'your_password'
});

client.connect();

// Insert Judge.me review
async function insertJudgeMeReview(reviewData) {
  const query = `
    INSERT INTO reviews (
      source, source_review_id, product_id, product_name, customer_name,
      customer_email, rating, title, review_text, is_verified, review_date, metadata
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    RETURNING id;
  `;
  
  const values = [
    'judgeme',
    reviewData.judgeme_review_id,
    reviewData.product_id,
    reviewData.product_name,
    reviewData.customer_name,
    reviewData.customer_email,
    reviewData.rating,
    reviewData.title,
    reviewData.review_text,
    reviewData.verified,
    reviewData.review_date,
    JSON.stringify(reviewData.metadata)
  ];
  
  const result = await client.query(query, values);
  return result.rows[0].id;
}

// Insert Yotpo review
async function insertYotpoReview(reviewData) {
  const query = `
    INSERT INTO reviews (
      source, source_review_id, product_id, product_name, customer_name,
      customer_email, rating, title, review_text, is_verified, metadata
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    RETURNING id;
  `;
  
  const values = [
    'yotpo',
    reviewData.yotpo_review_id,
    reviewData.product_id,
    reviewData.product_name,
    reviewData.customer_name,
    reviewData.customer_email,
    reviewData.rating,
    reviewData.title,
    reviewData.review_text,
    reviewData.verified,
    JSON.stringify({
      yotpo_sentiment: reviewData.sentiment,
      upvotes: reviewData.upvotes,
      tags: reviewData.tags
    })
  ];
  
  const result = await client.query(query, values);
  return result.rows[0].id;
}

// Insert Grok AI summary
async function insertGrokAISummary(summaryData) {
  const query = `
    INSERT INTO reviews (
      source, source_review_id, product_id, product_name, customer_name,
      customer_email, rating, title, review_text, metadata
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
    RETURNING id;
  `;
  
  const values = [
    'grok_ai',
    summaryData.grok_summary_id,
    summaryData.product_id,
    summaryData.product_name,
    'AI Analysis Bot',
    'system@grok.ai',
    summaryData.avg_rating,
    summaryData.summary_title,
    summaryData.summary_text,
    JSON.stringify({
      ai_confidence: summaryData.confidence,
      reviews_analyzed: summaryData.total_reviews,
      sentiment_breakdown: summaryData.sentiment_data,
      key_themes: summaryData.themes
    })
  ];
  
  const result = await client.query(query, values);
  return result.rows[0].id;
}

// Get product reviews
async function getProductReviews(productId) {
  const query = `
    SELECT * FROM reviews 
    WHERE product_id = $1 
    ORDER BY review_date DESC;
  `;
  
  const result = await client.query(query, [productId]);
  return result.rows;
}

// Get reviews summary
async function getReviewsSummary() {
  const query = `
    SELECT * FROM reviews_summary
    ORDER BY average_rating DESC;
  `;
  
  const result = await client.query(query);
  return result.rows;
}
```

---

## 2. Python Integration

### Installation
```bash
pip install psycopg2-binary
```

### Connection Example
```python
import psycopg2
import json
from datetime import datetime
from psycopg2.extras import RealDictCursor

class ReviewsDatabase:
    def __init__(self):
        self.conn = psycopg2.connect(
            host="localhost",
            port=5432,
            database="reviews_db",
            user="postgres",
            password="your_password"
        )
        self.cursor = self.conn.cursor(cursor_factory=RealDictCursor)
    
    def insert_judgeme_review(self, review_data):
        query = """
        INSERT INTO reviews (
            source, source_review_id, product_id, product_name, customer_name,
            customer_email, rating, title, review_text, is_verified, review_date, metadata
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id;
        """
        
        values = (
            'judgeme',
            review_data['judgeme_review_id'],
            review_data['product_id'],
            review_data['product_name'],
            review_data['customer_name'],
            review_data['customer_email'],
            review_data['rating'],
            review_data['title'],
            review_data['review_text'],
            review_data['verified'],
            review_data['review_date'],
            json.dumps(review_data['metadata'])
        )
        
        self.cursor.execute(query, values)
        result = self.cursor.fetchone()
        self.conn.commit()
        return result['id']
    
    def insert_yotpo_review(self, review_data):
        query = """
        INSERT INTO reviews (
            source, source_review_id, product_id, product_name, customer_name,
            customer_email, rating, title, review_text, is_verified, metadata
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id;
        """
        
        metadata = {
            'yotpo_sentiment': review_data.get('sentiment'),
            'upvotes': review_data.get('upvotes', 0),
            'tags': review_data.get('tags', [])
        }
        
        values = (
            'yotpo',
            review_data['yotpo_review_id'],
            review_data['product_id'],
            review_data['product_name'],
            review_data['customer_name'],
            review_data['customer_email'],
            review_data['rating'],
            review_data['title'],
            review_data['review_text'],
            review_data['verified'],
            json.dumps(metadata)
        )
        
        self.cursor.execute(query, values)
        result = self.cursor.fetchone()
        self.conn.commit()
        return result['id']
    
    def insert_grok_ai_summary(self, summary_data):
        query = """
        INSERT INTO reviews (
            source, source_review_id, product_id, product_name, customer_name,
            customer_email, rating, title, review_text, metadata
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id;
        """
        
        metadata = {
            'ai_confidence': summary_data['confidence'],
            'reviews_analyzed': summary_data['total_reviews'],
            'sentiment_breakdown': summary_data['sentiment_data'],
            'key_themes': summary_data.get('themes', [])
        }
        
        values = (
            'grok_ai',
            summary_data['grok_summary_id'],
            summary_data['product_id'],
            summary_data['product_name'],
            'AI Analysis Bot',
            'system@grok.ai',
            summary_data['avg_rating'],
            summary_data['summary_title'],
            summary_data['summary_text'],
            json.dumps(metadata)
        )
        
        self.cursor.execute(query, values)
        result = self.cursor.fetchone()
        self.conn.commit()
        return result['id']
    
    def get_product_reviews(self, product_id):
        query = """
        SELECT * FROM reviews 
        WHERE product_id = %s 
        ORDER BY review_date DESC;
        """
        
        self.cursor.execute(query, (product_id,))
        return self.cursor.fetchall()
    
    def get_reviews_by_source(self, source):
        query = """
        SELECT * FROM reviews 
        WHERE source = %s 
        ORDER BY created_at DESC;
        """
        
        self.cursor.execute(query, (source,))
        return self.cursor.fetchall()
    
    def close(self):
        self.cursor.close()
        self.conn.close()

# Usage example
if __name__ == "__main__":
    db = ReviewsDatabase()
    
    # Example Judge.me review
    judgeme_data = {
        'judgeme_review_id': 'jm_new123',
        'product_id': 'PROD_004',
        'product_name': 'Gaming Mouse',
        'customer_name': 'Alex Johnson',
        'customer_email': 'alex@example.com',
        'rating': 5,
        'title': 'Perfect for gaming!',
        'review_text': 'Amazing precision and comfortable grip.',
        'verified': True,
        'review_date': datetime.now(),
        'metadata': {'judge_me_score': 5.0, 'photos': []}
    }
    
    review_id = db.insert_judgeme_review(judgeme_data)
    print(f"Inserted review with ID: {review_id}")
    
    db.close()
```

---

## 3. PHP Integration

### Connection Example
```php
<?php

class ReviewsDatabase {
    private $pdo;
    
    public function __construct() {
        $host = 'localhost';
        $dbname = 'reviews_db';
        $username = 'postgres';
        $password = 'your_password';
        
        $dsn = "pgsql:host=$host;dbname=$dbname";
        $this->pdo = new PDO($dsn, $username, $password);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    
    public function insertJudgeMeReview($reviewData) {
        $sql = "
        INSERT INTO reviews (
            source, source_review_id, product_id, product_name, customer_name,
            customer_email, rating, title, review_text, is_verified, review_date, metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        RETURNING id
        ";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'judgeme',
            $reviewData['judgeme_review_id'],
            $reviewData['product_id'],
            $reviewData['product_name'],
            $reviewData['customer_name'],
            $reviewData['customer_email'],
            $reviewData['rating'],
            $reviewData['title'],
            $reviewData['review_text'],
            $reviewData['verified'],
            $reviewData['review_date'],
            json_encode($reviewData['metadata'])
        ]);
        
        return $stmt->fetchColumn();
    }
    
    public function insertYotpoReview($reviewData) {
        $sql = "
        INSERT INTO reviews (
            source, source_review_id, product_id, product_name, customer_name,
            customer_email, rating, title, review_text, is_verified, metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        RETURNING id
        ";
        
        $metadata = [
            'yotpo_sentiment' => $reviewData['sentiment'] ?? null,
            'upvotes' => $reviewData['upvotes'] ?? 0,
            'tags' => $reviewData['tags'] ?? []
        ];
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'yotpo',
            $reviewData['yotpo_review_id'],
            $reviewData['product_id'],
            $reviewData['product_name'],
            $reviewData['customer_name'],
            $reviewData['customer_email'],
            $reviewData['rating'],
            $reviewData['title'],
            $reviewData['review_text'],
            $reviewData['verified'],
            json_encode($metadata)
        ]);
        
        return $stmt->fetchColumn();
    }
    
    public function getProductReviews($productId) {
        $sql = "SELECT * FROM reviews WHERE product_id = ? ORDER BY review_date DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getReviewsSummary() {
        $sql = "SELECT * FROM reviews_summary ORDER BY average_rating DESC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Usage example
$db = new ReviewsDatabase();

// Example Yotpo review
$yotpoData = [
    'yotpo_review_id' => 'yp_new456',
    'product_id' => 'PROD_004',
    'product_name' => 'Gaming Mouse',
    'customer_name' => 'Sarah Davis',
    'customer_email' => 'sarah@example.com',
    'rating' => 4,
    'title' => 'Good mouse, great value',
    'review_text' => 'Works well for gaming and office work. Good build quality.',
    'verified' => true,
    'sentiment' => 'positive',
    'upvotes' => 8,
    'tags' => ['gaming', 'value', 'comfortable']
];

$reviewId = $db->insertYotpoReview($yotpoData);
echo "Inserted review with ID: $reviewId\n";
?>
```

---

## 4. Webhook Integration Examples

### Judge.me Webhook Handler (Node.js)
```javascript
const express = require('express');
const app = express();

app.use(express.json());

app.post('/webhooks/judgeme', async (req, res) => {
    try {
        const reviewData = req.body;
        
        const review = {
            judgeme_review_id: reviewData.id,
            product_id: reviewData.product_id,
            product_name: reviewData.product_title,
            customer_name: reviewData.reviewer.name,
            customer_email: reviewData.reviewer.email,
            rating: reviewData.rating,
            title: reviewData.title,
            review_text: reviewData.body,
            verified: reviewData.verified === 'yes',
            review_date: new Date(reviewData.created_at),
            metadata: {
                judge_me_score: reviewData.score,
                photos: reviewData.pictures || [],
                location: reviewData.reviewer.location
            }
        };
        
        const reviewId = await insertJudgeMeReview(review);
        console.log(`Judge.me review inserted with ID: ${reviewId}`);
        
        res.status(200).json({ success: true, review_id: reviewId });
    } catch (error) {
        console.error('Error processing Judge.me webhook:', error);
        res.status(500).json({ error: 'Failed to process webhook' });
    }
});

app.listen(3000, () => {
    console.log('Webhook server listening on port 3000');
});
```

### Yotpo Webhook Handler (Node.js)
```javascript
app.post('/webhooks/yotpo', async (req, res) => {
    try {
        const reviewData = req.body;
        
        const review = {
            yotpo_review_id: reviewData.review.id,
            product_id: reviewData.review.product.id,
            product_name: reviewData.review.product.name,
            customer_name: reviewData.review.user.display_name,
            customer_email: reviewData.review.user.email,
            rating: reviewData.review.score,
            title: reviewData.review.title,
            review_text: reviewData.review.content,
            verified: reviewData.review.verified_buyer,
            metadata: {
                yotpo_sentiment: reviewData.review.sentiment,
                upvotes: reviewData.review.votes_up,
                tags: reviewData.review.custom_fields?.tags || []
            }
        };
        
        const reviewId = await insertYotpoReview(review);
        console.log(`Yotpo review inserted with ID: ${reviewId}`);
        
        res.status(200).json({ success: true, review_id: reviewId });
    } catch (error) {
        console.error('Error processing Yotpo webhook:', error);
        res.status(500).json({ error: 'Failed to process webhook' });
    }
});
```

---

## 5. REST API Endpoints

### Get Product Reviews
```javascript
app.get('/api/products/:productId/reviews', async (req, res) => {
    try {
        const { productId } = req.params;
        const reviews = await getProductReviews(productId);
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
```

### Get Reviews Summary
```javascript
app.get('/api/reviews/summary', async (req, res) => {
    try {
        const summary = await getReviewsSummary();
        res.json(summary);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
```

### Add Review
```javascript
app.post('/api/reviews', async (req, res) => {
    try {
        const { source, ...reviewData } = req.body;
        
        let reviewId;
        switch (source) {
            case 'judgeme':
                reviewId = await insertJudgeMeReview(reviewData);
                break;
            case 'yotpo':
                reviewId = await insertYotpoReview(reviewData);
                break;
            case 'grok_ai':
                reviewId = await insertGrokAISummary(reviewData);
                break;
            default:
                throw new Error('Invalid review source');
        }
        
        res.status(201).json({ success: true, review_id: reviewId });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});
```

---

This setup provides a comprehensive solution for storing and managing reviews from Judge.me, Yotpo, and Grok AI in your PostgreSQL database!
