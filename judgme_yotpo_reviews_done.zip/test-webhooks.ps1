# test-webhooks.ps1
# PowerShell script to test webhook functionality

param(
    [string]$ServerUrl = "http://localhost:3000",
    [string]$ProductHandle = "classic-cotton-t-shirt"
)

Write-Host "🔔 Testing Webhook System..." -ForegroundColor Green
Write-Host "Server: $ServerUrl" -ForegroundColor Yellow
Write-Host "Product: $ProductHandle" -ForegroundColor Yellow
Write-Host ""

# Function to make HTTP requests with error handling
function Invoke-WebhookTest {
    param(
        [string]$Url,
        [string]$Method = "POST",
        [hashtable]$Headers = @{"Content-Type" = "application/json"},
        [string]$Body = $null,
        [string]$TestName
    )
    
    Write-Host "📋 $TestName" -ForegroundColor Cyan
    Write-Host "   URL: $Url" -ForegroundColor Gray
    
    try {
        if ($Body) {
            $response = Invoke-RestMethod -Uri $Url -Method $Method -Headers $Headers -Body $Body -TimeoutSec 10
            Write-Host "   ✅ Success:" -ForegroundColor Green
        } else {
            $response = Invoke-RestMethod -Uri $Url -Method $Method -Headers $Headers -TimeoutSec 10
            Write-Host "   ✅ Success:" -ForegroundColor Green
        }
        
        # Display response
        if ($response -is [string]) {
            Write-Host "   Response: $response" -ForegroundColor White
        } else {
            $response | ConvertTo-Json -Depth 3 | Write-Host -ForegroundColor White
        }
        
        return $true
    }
    catch {
        Write-Host "   ❌ Failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Test 1: Check if server is running
Write-Host "🚀 Checking if server is running..." -ForegroundColor Magenta
try {
    $healthCheck = Invoke-RestMethod -Uri "$ServerUrl/api/reviews/$ProductHandle" -Method GET -TimeoutSec 5
    Write-Host "✅ Server is running and responding" -ForegroundColor Green
} catch {
    Write-Host "❌ Server not responding. Please start with: npm run dev" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Test 2: Basic Webhook Test
$webhookBody1 = @{
    productHandle = $ProductHandle
    event = "review.created"
    timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
} | ConvertTo-Json

$test1 = Invoke-WebhookTest -Url "$ServerUrl/api/webhook/review-updated" -Body $webhookBody1 -TestName "Basic Webhook Test"

Write-Host ""

# Test 3: Judge.me Style Webhook
$judgeWebhook = @{
    product = @{
        handle = $ProductHandle
        id = 123456789
    }
    review = @{
        rating = 5
        body = "Great product!"
        reviewer_name = "John Doe"
    }
    event = "review_created"
} | ConvertTo-Json -Depth 3

$test2 = Invoke-WebhookTest -Url "$ServerUrl/api/webhook/review-updated" -Body $judgeWebhook -TestName "Judge.me Style Webhook"

Write-Host ""

# Test 4: Yotpo Style Webhook
$yotpoWebhook = @{
    product_id = $ProductHandle
    product_handle = $ProductHandle
    review_id = 987654321
    rating = 4
    content = "Nice quality shirt"
    user_name = "Jane Smith"
    event_type = "review.create"
} | ConvertTo-Json

$test3 = Invoke-WebhookTest -Url "$ServerUrl/api/webhook/review-updated" -Body $yotpoWebhook -TestName "Yotpo Style Webhook"

Write-Host ""

# Test 5: Manual Refresh Trigger
$test4 = Invoke-WebhookTest -Url "$ServerUrl/api/trigger-refresh/$ProductHandle" -TestName "Manual Refresh Trigger"

Write-Host ""

# Test 6: Verify AI Summary
Write-Host "📋 Verifying AI Summary Updated" -ForegroundColor Cyan
Write-Host "   Waiting 3 seconds for processing..." -ForegroundColor Gray
Start-Sleep -Seconds 3

try {
    $summary = Invoke-RestMethod -Uri "$ServerUrl/api/reviews/$ProductHandle" -Method GET
    Write-Host "   ✅ AI Summary Retrieved:" -ForegroundColor Green
    Write-Host "   - Success: $($summary.success)" -ForegroundColor White
    Write-Host "   - Reviews: $($summary.reviews.Count)" -ForegroundColor White
    Write-Host "   - Average Rating: $($summary.stats.average)" -ForegroundColor White
    Write-Host "   - Scraped At: $($summary.scrapedAt)" -ForegroundColor White
    $test5 = $true
} catch {
    Write-Host "   ❌ Failed to get AI summary: $($_.Exception.Message)" -ForegroundColor Red
    $test5 = $false
}

# Summary
Write-Host ""
Write-Host "=" * 60 -ForegroundColor Yellow
Write-Host "🎯 TEST RESULTS SUMMARY" -ForegroundColor Green
Write-Host "=" * 60 -ForegroundColor Yellow

$results = @{
    "Server Health Check" = $true
    "Basic Webhook" = $test1
    "Judge.me Webhook" = $test2
    "Yotpo Webhook" = $test3
    "Manual Refresh" = $test4
    "AI Summary Verification" = $test5
}

$passed = 0
$total = $results.Count

foreach ($test in $results.GetEnumerator()) {
    $status = if ($test.Value) { "✅ PASS" } else { "❌ FAIL" }
    $color = if ($test.Value) { "Green" } else { "Red" }
    Write-Host "$($test.Key): $status" -ForegroundColor $color
    if ($test.Value) { $passed++ }
}

Write-Host ""
Write-Host "Overall Score: $passed/$total tests passed" -ForegroundColor $(if ($passed -eq $total) { "Green" } else { "Yellow" })

if ($passed -eq $total) {
    Write-Host "🎉 All webhook tests PASSED! Your real-time system is working perfectly!" -ForegroundColor Green
    Write-Host ""
    Write-Host "🚀 Next Steps:" -ForegroundColor Cyan
    Write-Host "1. Set up webhooks in Judge.me/Yotpo admin panels" -ForegroundColor White
    Write-Host "2. Configure Windows Task Scheduler for backup refresh" -ForegroundColor White
    Write-Host "3. Monitor logs when real reviews are submitted" -ForegroundColor White
    Write-Host "4. Deploy to production and update webhook URLs" -ForegroundColor White
} else {
    Write-Host "⚠️ Some tests failed. Check the error messages above and:" -ForegroundColor Yellow
    Write-Host "- Ensure your server is running (npm run dev)" -ForegroundColor White
    Write-Host "- Check server logs for detailed error messages" -ForegroundColor White
    Write-Host "- Verify all dependencies are installed" -ForegroundColor White
}

Write-Host ""
Write-Host "📊 To run this test again: .\test-webhooks.ps1" -ForegroundColor Gray
