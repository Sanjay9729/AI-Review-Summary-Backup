-- Create database if it doesn't exist
-- This script creates the reviews database and populates it with real sample data

-- Database creation is handled by the setup script

-- Use the database
-- Note: The \c command needs to be run separately
-- After running this, you'll need to connect to reviews_db and run the table creation

-- Table creation and data (to be run after connecting to reviews_db)
CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY,
    source VARCHAR(20) NOT NULL CHECK (source IN ('judgeme', 'yotpo', 'grok_ai')),
    source_review_id VARCHAR(255),
    product_id VARCHAR(255) NOT NULL,
    product_name VARCHAR(500),
    product_sku VARCHAR(255),
    customer_id VARCHAR(255),
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(255),
    review_text TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_featured BOOLEAN DEFAULT FALSE,
    helpful_votes INTEGER DEFAULT 0,
    review_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB,
    CONSTRAINT unique_source_review UNIQUE (source, source_review_id)
);

-- Insert real sample data
INSERT INTO reviews (
    source, source_review_id, product_id, product_name, customer_name, 
    customer_email, rating, title, review_text, is_verified, review_date, metadata
) VALUES 
-- Judge.me reviews
('judgeme', 'jm_123456', 'PROD_001', 'Wireless Bluetooth Headphones', 'John Doe', 'john.doe@email.com', 
 5, 'Amazing sound quality!', 'These headphones exceeded my expectations. Crystal clear audio, comfortable fit, and excellent noise cancellation. Perfect for long flights and daily commutes.', 
 true, '2024-09-15 10:30:00+00', '{"judge_me_score": 5.0, "photos": ["headphones_photo1.jpg", "headphones_photo2.jpg"], "location": "New York, USA", "verified_purchase": true}'),

('judgeme', 'jm_789012', 'PROD_002', 'Premium Smartphone Case', 'Jane Smith', 'jane.smith@email.com', 
 4, 'Good protection, slightly bulky', 'Sturdy case that protects my phone well. Survived several drops without damage. A bit bulky but worth it for the protection. Would recommend.', 
 true, '2024-09-14 15:45:00+00', '{"judge_me_score": 4.0, "verified_buyer": true, "helpful_votes": 8}'),

('judgeme', 'jm_345678', 'PROD_003', 'Ergonomic Gaming Mouse', 'Alex Johnson', 'alex.j@email.com', 
 5, 'Perfect for gaming sessions', 'This mouse is incredible for gaming. Precise tracking, comfortable grip, and customizable buttons. My gaming performance improved significantly.', 
 true, '2024-09-13 20:15:00+00', '{"judge_me_score": 5.0, "photos": ["mouse_setup.jpg"], "gaming_hours": 120}'),

-- Yotpo reviews
('yotpo', 'yp_345678', 'PROD_001', 'Wireless Bluetooth Headphones', 'Mike Johnson', 'mike.johnson@email.com', 
 5, 'Perfect for workouts', 'Love these headphones for my gym sessions. Completely sweat-proof, great battery life (8+ hours), and they stay in place during intense workouts.', 
 true, '2024-09-13 08:20:00+00', '{"yotpo_sentiment": "positive", "tags": ["workout", "battery", "sweatproof"], "upvotes": 15, "downvotes": 0}'),

('yotpo', 'yp_901234', 'PROD_004', 'Smart Coffee Maker', 'Sarah Wilson', 'sarah.w@email.com', 
 3, 'Good coffee but confusing interface', 'Makes excellent coffee with multiple brew options. However, the touch interface is not intuitive and takes time to learn. Customer service was helpful though.', 
 false, '2024-09-12 12:00:00+00', '{"yotpo_sentiment": "neutral", "helpful_count": 12, "tags": ["coffee", "interface", "customer_service"]}'),

('yotpo', 'yp_567890', 'PROD_005', 'Portable Power Bank', 'David Chen', 'david.chen@email.com', 
 4, 'Reliable and fast charging', 'Charges my phone 3-4 times on a single charge. Fast charging works as advertised. Slightly heavy but acceptable for the capacity.', 
 true, '2024-09-11 16:30:00+00', '{"yotpo_sentiment": "positive", "tags": ["charging", "portable", "capacity"], "upvotes": 9}'),

-- Grok AI generated reviews and summaries
('grok_ai', 'grok_567890', 'PROD_001', 'Wireless Bluetooth Headphones', 'AI Analysis System', 'ai@grok.com', 
 5, 'AI Summary: Highly Rated Audio Experience', 'Analysis of 247 customer reviews reveals exceptional satisfaction with sound quality and comfort. Key highlights: 94% praise audio clarity, 89% appreciate comfort for extended use, 87% value noise cancellation. Common positive themes: premium build quality, long battery life, excellent customer support.', 
 false, '2024-09-16 07:00:00+00', '{"ai_confidence": 0.94, "reviews_analyzed": 247, "sentiment_breakdown": {"positive": 0.83, "neutral": 0.12, "negative": 0.05}, "key_themes": ["audio_quality", "comfort", "battery_life", "build_quality"]}'),

('grok_ai', 'grok_123789', 'PROD_002', 'Premium Smartphone Case', 'AI Analysis System', 'ai@grok.com', 
 4, 'AI Summary: Excellent Protection with Minor Trade-offs', 'Comprehensive analysis of 156 reviews shows strong protective performance. 91% report successful drop protection, 78% satisfied with overall design. Minor concerns: 23% mention bulkiness, 15% note difficulty with wireless charging. Overall recommendation: excellent for protection-focused users.', 
 false, '2024-09-16 07:05:00+00', '{"ai_confidence": 0.89, "reviews_analyzed": 156, "key_themes": ["protection", "durability", "bulky", "wireless_charging"], "recommendation_score": 4.2}'),

('grok_ai', 'grok_999888', 'PROD_003', 'Ergonomic Gaming Mouse', 'AI Analysis System', 'ai@grok.com', 
 5, 'AI Summary: Top-Tier Gaming Performance', 'Analysis of 189 gaming enthusiast reviews shows outstanding performance metrics. 96% report improved gaming accuracy, 92% praise ergonomic design, 88% highlight customization options. Professional gamers rate it 4.8/5. Highly recommended for competitive gaming.', 
 false, '2024-09-16 07:10:00+00', '{"ai_confidence": 0.96, "reviews_analyzed": 189, "professional_gamer_rating": 4.8, "accuracy_improvement": "23%", "key_features": ["precision", "ergonomics", "customization"]});

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_reviews_source ON reviews (source);
CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON reviews (product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews (rating);
CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON reviews (created_at);

-- Create a summary view
CREATE OR REPLACE VIEW reviews_summary AS
SELECT 
    product_id,
    product_name,
    COUNT(*) as total_reviews,
    COUNT(CASE WHEN source = 'judgeme' THEN 1 END) as judgeme_count,
    COUNT(CASE WHEN source = 'yotpo' THEN 1 END) as yotpo_count,
    COUNT(CASE WHEN source = 'grok_ai' THEN 1 END) as ai_summaries,
    ROUND(AVG(rating), 2) as average_rating,
    COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star,
    COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star,
    COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star,
    COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star,
    COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star,
    COUNT(CASE WHEN is_verified = true THEN 1 END) as verified_reviews,
    MAX(review_date) as latest_review_date
FROM reviews 
GROUP BY product_id, product_name
ORDER BY average_rating DESC, total_reviews DESC;
