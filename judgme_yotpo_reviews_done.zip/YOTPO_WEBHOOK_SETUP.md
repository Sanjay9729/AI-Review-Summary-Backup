# Yotpo Webhook Setup Guide

## Overview
This guide will help you configure Yotpo webhooks to automatically trigger AI review summary updates when new reviews are posted.

## Prerequisites
- Yotpo app installed on your Shopify store
- Your AI review summary system running
- Cloudflare tunnel or public URL for your webhook endpoint
- Yotpo API access (may require premium plan)

## Step 1: Get Your Webhook URL

First, determine your webhook endpoint URL:

### Development (using Cloudflare tunnel):
```
https://your-cloudflare-tunnel.trycloudflare.com/api/webhook/review-updated
```

### Production:
```
https://your-domain.com/api/webhook/review-updated
```

## Step 2: Access Yotpo Webhook Settings

### Option A: Yotpo Admin Dashboard (Recommended)

1. **Log into your Yotpo Dashboard**
   - Go to https://yap.yotpo.com/
   - Sign in with your Yotpo account credentials

2. **Navigate to Settings**
   - Click **Settings** in the left sidebar
   - Go to **General Settings** → **Webhooks**
   - Or navigate to: https://yap.yotpo.com/#/settings/webhooks

### Option B: Yotpo API (Advanced)

If webhooks aren't available in the dashboard, you may need to use the Yotpo API:
- Contact Yotpo support to enable webhook access
- Use their REST API to configure webhooks programmatically

## Step 3: Configure the Webhook

1. **Click "Add New Webhook" or "Create Webhook"**

2. **Fill in the webhook details:**
   ```
   Webhook URL: https://your-cloudflare-tunnel.trycloudflare.com/api/webhook/review-updated
   Event Type: Review Created
   Method: POST
   Content Type: application/json
   Status: Active
   ```

3. **Select Events to Monitor:**
   - ✅ **Review Created** (most important)
   - ✅ **Review Updated** (optional)
   - ✅ **Review Published** (optional)
   - ✅ **Review Approved** (if using moderation)

4. **Authentication Settings:**
   ```
   Authentication Type: None (or Custom Headers if needed)
   ```

   If authentication is required:
   ```
   Custom Headers:
   Authorization: Bearer your-api-key
   X-Yotpo-Signature: your-secret-key
   ```

## Step 4: Configure Webhook Events

Yotpo typically supports these webhook events:

### Review Events:
- `review_create` - When a new review is submitted
- `review_update` - When a review is modified
- `review_publish` - When a review is published/approved
- `review_delete` - When a review is deleted

### Product Events (optional):
- `product_create` - When a product is added
- `product_update` - When product info changes

**Select the events that should trigger AI summary updates.**

## Step 5: Verify Webhook Payload

Yotpo typically sends webhooks with this structure:

```json
{
  "webhook": {
    "yotpo_id": "12345678",
    "store_id": "your-store-id",
    "platform": "shopify",
    "event_type": "review_create",
    "sent_at": "2025-01-16T06:29:45Z"
  },
  "review": {
    "id": 98765432,
    "product_yotpo_id": "product-id",
    "product_external_id": "product-handle",
    "content": "Amazing product! Love it.",
    "title": "Great quality",
    "score": 5,
    "user": {
      "display_name": "John D.",
      "email": "john@example.com"
    },
    "created_at": "2025-01-16T06:29:45Z",
    "updated_at": "2025-01-16T06:29:45Z",
    "published": true,
    "archived": false
  }
}
```

## Step 6: Test the Webhook

### Method 1: Yotpo Test Feature
1. In Yotpo webhook settings
2. Look for "Test" or "Send Test" button
3. Click to send a test payload
4. Check your server logs

### Method 2: Create Test Review
1. Go to a product page with Yotpo reviews
2. Submit a test review
3. Monitor your server logs for webhook delivery

## Step 7: Save and Activate

1. **Click "Save" or "Create Webhook"**
2. **Ensure webhook status is "Active"**
3. **Copy the webhook ID** for future reference

## Advanced Configuration

### Webhook Signature Verification
Yotpo may include signature headers for security:
```
X-Yotpo-Hmac-Sha256: signature-hash
X-Yotpo-Topic: review_create
```

### Filtering Options
Some Yotpo plans allow filtering webhooks by:
- Product categories
- Review scores (e.g., only 4-5 star reviews)
- Review status (published, pending)

### Rate Limiting
Configure rate limits if you expect high review volumes:
```
Rate Limit: 100 requests per minute
Retry Policy: Exponential backoff
Max Retries: 3
```

## Alternative: Yotpo API Polling (If Webhooks Unavailable)

If webhooks aren't available, you can use scheduled API polling:

1. **Get Yotpo API Credentials:**
   - App Key and Secret from Yotpo dashboard
   - Generate API token

2. **Use Yotpo Reviews API:**
   ```bash
   GET https://api.yotpo.com/v1/apps/{app_key}/reviews
   ```

3. **Set up scheduled polling:**
   - Check for new reviews every 5-15 minutes
   - Store last check timestamp
   - Process only new reviews since last check

## Expected Server Response

Your webhook endpoint should return:
```json
{
  "success": true,
  "message": "Yotpo webhook processed successfully",
  "product_handle": "product-handle"
}
```

Status Code: `200 OK`

## Troubleshooting

### Common Issues:

1. **Webhook Not Available in Dashboard**
   - Webhooks may require Yotpo Growth or Premium plan
   - Contact Yotpo support to enable webhook access
   - Consider API polling as alternative

2. **401 Unauthorized**
   - Verify API credentials in Yotpo dashboard
   - Check webhook authentication settings
   - Ensure your app has proper permissions

3. **Webhook Delivery Failures**
   - Check Yotpo webhook logs for delivery status
   - Verify your endpoint URL is accessible
   - Ensure HTTPS is properly configured

4. **Missing Product Handle**
   - Yotpo uses `product_external_id` for Shopify product handles
   - Verify this field is present in webhook payload
   - Check product sync between Shopify and Yotpo

### Debug Steps:

1. **Check Yotpo Webhook Logs:**
   ```
   Yotpo Dashboard → Settings → Webhooks → View Logs
   ```

2. **Test Endpoint Manually:**
   ```bash
   curl -X POST https://your-webhook-url/api/webhook/review-updated \
     -H "Content-Type: application/json" \
     -d '{
       "webhook": {
         "event_type": "review_create"
       },
       "review": {
         "product_external_id": "test-product",
         "content": "Test review",
         "score": 5
       }
     }'
   ```

3. **Monitor Server Logs:**
   ```bash
   npm run dev
   # Look for "Yotpo webhook received" messages
   ```

## Plan Requirements

### Yotpo Pricing Tiers:
- **Free Plan**: Basic reviews, no webhooks
- **Growth Plan**: May include webhook access
- **Premium Plan**: Full webhook and API access

**Note**: Webhook availability varies by plan. Contact Yotpo support to confirm webhook access for your account.

## Alternative Integration Methods

If webhooks aren't available:

1. **Yotpo Reviews API Polling**
   - Check for new reviews periodically
   - Use cron jobs or scheduled tasks

2. **Shopify Product Update Webhooks**
   - Listen for product updates from Shopify
   - Trigger review rescraping when products change

3. **Manual Trigger**
   - Provide admin interface to manually refresh summaries
   - Use when major review updates occur

## Next Steps

After successful webhook setup:
1. Test with real review submissions
2. Monitor webhook delivery reliability
3. Implement error handling and retries
4. Set up monitoring and alerting
5. Consider implementing webhook signature verification

## Support

For Yotpo webhook issues:
- Yotpo Help Center: https://support.yotpo.com/
- Yotpo API Documentation: https://core-api.yotpo.com/reference
- Contact Yotpo support for webhook access questions
- Check your Yotpo plan limitations
