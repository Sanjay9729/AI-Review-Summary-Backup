// scripts/migrate-cache-to-postgres.js
// Migration script to transfer cached review data to PostgreSQL

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { PrismaClient } from '@prisma/client';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const prisma = new PrismaClient();
const CACHE_DIR = path.join(process.cwd(), 'cache');

async function migrateReviewsToPostgreSQL() {
  console.log('🚀 Starting migration from file cache to PostgreSQL...\n');
  
  try {
    // Read all review cache files
    const files = await fs.readdir(CACHE_DIR);
    const reviewFiles = files.filter(file => file.startsWith('reviews_') && file.endsWith('.json'));
    
    console.log(`Found ${reviewFiles.length} review files to migrate:\n`);
    
    let totalMigrated = 0;
    const defaultShop = process.env.SHOPIFY_STORE_URL || 'demo-store.myshopify.com';
    
    for (const file of reviewFiles) {
      const filePath = path.join(CACHE_DIR, file);
      const productHandle = file.replace('reviews_', '').replace('.json', '');
      
      console.log(`📦 Processing: ${productHandle}...`);
      
      try {
        // Read cached data
        const data = await fs.readFile(filePath, 'utf8');
        const reviewData = JSON.parse(data);
        
        if (!reviewData.reviews || reviewData.reviews.length === 0) {
          console.log(`   ⚠️  No reviews found, skipping.`);
          continue;
        }
        
        // Create or find product
        let product = await prisma.product.findFirst({
          where: { handle: productHandle, shop: defaultShop }
        });
        
        if (!product) {
          product = await prisma.product.create({
            data: {
              shopifyId: `migrated_${productHandle}_${Date.now()}`,
              handle: productHandle,
              title: reviewData.productTitle || `Product ${productHandle}`,
              shop: defaultShop,
              status: 'ACTIVE'
            }
          });
          console.log(`   ✅ Created product: ${product.handle}`);
        } else {
          console.log(`   🔍 Found existing product: ${product.handle}`);
        }
        
        // Delete existing reviews for this product
        const deletedReviews = await prisma.review.deleteMany({
          where: { productId: product.id }
        });
        
        if (deletedReviews.count > 0) {
          console.log(`   🗑️  Removed ${deletedReviews.count} existing reviews`);
        }
        
        // Prepare review data for insertion
        const reviewsToInsert = reviewData.reviews.map(review => ({
          productId: product.id,
          author: review.author || 'Anonymous',
          rating: Math.max(0, Math.min(5, parseFloat(review.rating) || 0)),
          title: review.title || null,
          text: review.text || '',
          verified: review.verified || false,
          platform: review.platform || review.extractedFrom || 'Unknown',
          reviewDate: review.date ? new Date(review.date) : null,
          scrapedAt: reviewData.scrapedAt ? new Date(reviewData.scrapedAt) : new Date()
        }));
        
        // Insert reviews
        const result = await prisma.review.createMany({
          data: reviewsToInsert,
          skipDuplicates: true
        });
        
        console.log(`   ✅ Migrated ${result.count} reviews`);
        totalMigrated += result.count;
        
        // Cache the data in PostgreSQL cache table
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24); // 24 hour cache
        
        await prisma.reviewCache.upsert({
          where: { productHandle },
          update: {
            data: reviewData,
            stats: reviewData.stats || {},
            platform: reviewData.reviewPlatform || 'Unknown',
            expiresAt,
            scrapedAt: new Date()
          },
          create: {
            productHandle,
            cacheKey: `migrated_${productHandle}_${Date.now()}`,
            data: reviewData,
            stats: reviewData.stats || {},
            platform: reviewData.reviewPlatform || 'Unknown',
            expiresAt,
            scrapedAt: new Date()
          }
        });
        
        console.log(`   💾 Cached data in PostgreSQL`);
        console.log();
        
      } catch (fileError) {
        console.error(`   ❌ Error processing ${productHandle}:`, fileError.message);
      }
    }
    
    console.log(`\n🎉 Migration completed!`);
    console.log(`📊 Total reviews migrated: ${totalMigrated}`);
    console.log(`📦 Products processed: ${reviewFiles.length}`);
    
    // Display final stats
    const [productCount, reviewCount, cacheCount] = await Promise.all([
      prisma.product.count(),
      prisma.review.count(), 
      prisma.reviewCache.count()
    ]);
    
    console.log(`\n📈 PostgreSQL Database Stats:`);
    console.log(`   Products: ${productCount}`);
    console.log(`   Reviews: ${reviewCount}`);
    console.log(`   Cached items: ${cacheCount}`);
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await prisma.$disconnect();
  }
}

// Run migration if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  migrateReviewsToPostgreSQL().catch(console.error);
}

export default migrateReviewsToPostgreSQL;
