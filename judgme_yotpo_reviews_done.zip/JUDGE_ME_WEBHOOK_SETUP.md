# Judge.me Webhook Setup Guide

## Overview
This guide will help you configure Judge.me webhooks to automatically trigger AI review summary updates when new reviews are posted.

## Prerequisites
- Judge.me app installed on your Shopify store
- Your AI review summary system running
- Cloudflare tunnel or public URL for your webhook endpoint

## Step 1: Get Your Webhook URL

First, determine your webhook endpoint URL:

### Development (using Cloudflare tunnel):
```
https://your-cloudflare-tunnel.trycloudflare.com/api/webhook/review-updated
```

### Production:
```
https://your-domain.com/api/webhook/review-updated
```

## Step 2: Access Judge.me Webhook Settings

1. **Log into your Judge.me Dashboard**
   - Go to https://judge.me/
   - Sign in with your account credentials

2. **Navigate to Webhooks**
   - In the dashboard, go to **Settings** → **Webhooks**
   - Or directly visit: https://judge.me/account/settings/webhooks

## Step 3: Configure the Webhook

1. **Click "Add New Webhook"**

2. **Fill in the webhook details:**
   ```
   Webhook URL: https://your-cloudflare-tunnel.trycloudflare.com/api/webhook/review-updated
   Event: Review Created
   Method: POST
   Content Type: application/json
   ```

3. **Select Events to Monitor:**
   - ✅ **Review Created** (most important)
   - ✅ **Review Updated** (optional)
   - ✅ **Review Published** (optional)

4. **Optional: Add Headers** (if needed for authentication):
   ```
   Authorization: Bearer your-api-key
   X-API-Key: your-secret-key
   ```

## Step 4: Test the Webhook

1. **In Judge.me Dashboard:**
   - Click **"Test Webhook"** button
   - This will send a test payload to your endpoint

2. **Check Your Server Logs:**
   - Look for incoming webhook requests
   - Verify the payload is being processed

## Step 5: Verify Webhook Payload

Judge.me typically sends webhooks with this structure:

```json
{
  "event": "review.created",
  "shop_domain": "your-store.myshopify.com",
  "data": {
    "id": 12345,
    "product_external_id": "product-handle",
    "title": "Great product!",
    "body": "I love this product...",
    "rating": 5,
    "reviewer": {
      "name": "John Doe",
      "email": "john@example.com"
    },
    "created_at": "2025-01-16T06:29:45Z",
    "updated_at": "2025-01-16T06:29:45Z"
  }
}
```

## Step 6: Save and Activate

1. **Click "Save Webhook"**
2. **Ensure the webhook is "Active"**
3. **Note the webhook ID** for future reference

## Advanced Configuration

### Custom Headers
If your system requires authentication:
```
X-Shopify-Shop-Domain: your-store.myshopify.com
X-Webhook-Secret: your-secret-key
```

### Webhook Signature Verification
Judge.me may include signature headers for security:
```
X-Judge-Me-Signature: sha256=hash-value
```

## Testing Your Setup

### Method 1: Create a Test Review
1. Go to a product page on your store
2. Leave a review using Judge.me widget
3. Check your server logs for webhook delivery
4. Verify AI summary is updated

### Method 2: Use Judge.me Test Feature
1. In Judge.me webhook settings
2. Click "Send Test" for your configured webhook
3. Monitor your server logs

## Expected Server Response

Your webhook endpoint should return:
```json
{
  "success": true,
  "message": "Webhook processed successfully",
  "product_handle": "product-handle"
}
```

## Troubleshooting

### Common Issues:

1. **404 Not Found**
   - Verify your webhook URL is correct
   - Ensure your server is running
   - Check Cloudflare tunnel is active

2. **500 Internal Server Error**
   - Check server logs for errors
   - Verify environment variables are set
   - Test your AI summary generation manually

3. **Webhook Not Triggering**
   - Confirm webhook is "Active" in Judge.me
   - Check Judge.me webhook logs
   - Verify event types are correctly selected

4. **SSL/HTTPS Issues**
   - Judge.me requires HTTPS URLs
   - Ensure your Cloudflare tunnel uses HTTPS
   - Check SSL certificate validity

### Debug Steps:

1. **Check Judge.me Webhook Logs:**
   - In Judge.me dashboard, check webhook delivery logs
   - Look for failed deliveries and error messages

2. **Monitor Server Logs:**
   ```bash
   # Start your server with detailed logging
   npm run dev
   
   # Check for incoming webhooks
   # Look for "Webhook received" messages
   ```

3. **Test Endpoint Manually:**
   ```bash
   curl -X POST https://your-webhook-url/api/webhook/review-updated \
     -H "Content-Type: application/json" \
     -d '{"event":"review.created","data":{"product_external_id":"test-product"}}'
   ```

## Next Steps

After successful webhook setup:
1. Monitor webhook deliveries for a few days
2. Check AI summaries are updating correctly
3. Consider setting up webhook retry logic
4. Implement webhook signature verification for security

## Support

If you encounter issues:
- Check Judge.me documentation: https://developers.judge.me/
- Review your server error logs
- Test webhook endpoint manually
- Contact Judge.me support if webhook delivery fails
