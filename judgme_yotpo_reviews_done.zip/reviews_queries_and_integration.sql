-- =============================================
-- Sample Queries and Integration Examples
-- For Reviews Database
-- =============================================

-- Connect to reviews database
\c reviews_db;

-- =============================================
-- SAMPLE QUERIES
-- =============================================

-- 1. Get all reviews for a specific product
SELECT 
    source,
    customer_name,
    rating,
    title,
    review_text,
    review_date
FROM reviews 
WHERE product_id = 'PROD_001'
ORDER BY review_date DESC;

-- 2. Get average ratings by source
SELECT 
    source,
    COUNT(*) as total_reviews,
    ROUND(AVG(rating), 2) as avg_rating,
    MIN(rating) as min_rating,
    MAX(rating) as max_rating
FROM reviews 
GROUP BY source
ORDER BY avg_rating DESC;

-- 3. Get recent reviews (last 7 days)
SELECT 
    source,
    product_name,
    customer_name,
    rating,
    title,
    created_at
FROM reviews 
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
ORDER BY created_at DESC;

-- 4. Find products with highest average ratings
SELECT 
    product_id,
    product_name,
    COUNT(*) as review_count,
    ROUND(AVG(rating), 2) as avg_rating
FROM reviews 
GROUP BY product_id, product_name
HAVING COUNT(*) >= 2  -- Only products with 2+ reviews
ORDER BY avg_rating DESC, review_count DESC;

-- 5. Get AI-generated summaries
SELECT 
    product_name,
    title,
    review_text,
    metadata->>'ai_confidence' as confidence,
    metadata->>'reviews_analyzed' as analyzed_count
FROM reviews 
WHERE source = 'grok_ai'
ORDER BY (metadata->>'ai_confidence')::float DESC;

-- 6. Find verified vs unverified reviews
SELECT 
    source,
    is_verified,
    COUNT(*) as count,
    ROUND(AVG(rating), 2) as avg_rating
FROM reviews 
GROUP BY source, is_verified
ORDER BY source, is_verified;

-- 7. Search reviews by keyword
SELECT 
    source,
    product_name,
    customer_name,
    rating,
    title,
    review_text
FROM reviews 
WHERE review_text ILIKE '%sound%' OR title ILIKE '%sound%'
ORDER BY rating DESC;

-- 8. Get reviews with metadata analysis
SELECT 
    r.*,
    CASE 
        WHEN r.source = 'yotpo' THEN r.metadata->>'yotpo_sentiment'
        WHEN r.source = 'grok_ai' THEN 'AI Generated'
        ELSE 'Standard Review'
    END as review_type
FROM reviews r
ORDER BY r.created_at DESC;

-- =============================================
-- USEFUL VIEWS
-- =============================================

-- Create product analytics view
CREATE OR REPLACE VIEW product_analytics AS
SELECT 
    product_id,
    product_name,
    COUNT(*) as total_reviews,
    COUNT(CASE WHEN source = 'judgeme' THEN 1 END) as judgeme_reviews,
    COUNT(CASE WHEN source = 'yotpo' THEN 1 END) as yotpo_reviews,
    COUNT(CASE WHEN source = 'grok_ai' THEN 1 END) as ai_summaries,
    ROUND(AVG(rating), 2) as overall_rating,
    ROUND(AVG(CASE WHEN source != 'grok_ai' THEN rating END), 2) as human_rating,
    COUNT(CASE WHEN is_verified = true THEN 1 END) as verified_reviews,
    MAX(review_date) as latest_review,
    MIN(review_date) as first_review
FROM reviews 
GROUP BY product_id, product_name;

-- Create recent activity view
CREATE OR REPLACE VIEW recent_activity AS
SELECT 
    id,
    source,
    product_name,
    customer_name,
    rating,
    title,
    created_at,
    EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - created_at))/3600 as hours_ago
FROM reviews 
WHERE created_at >= CURRENT_TIMESTAMP - INTERVAL '30 days'
ORDER BY created_at DESC;

-- =============================================
-- STORED PROCEDURES
-- =============================================

-- Function to add a new review
CREATE OR REPLACE FUNCTION add_review(
    p_source VARCHAR(20),
    p_source_review_id VARCHAR(255),
    p_product_id VARCHAR(255),
    p_product_name VARCHAR(500),
    p_customer_name VARCHAR(255),
    p_customer_email VARCHAR(255),
    p_rating INTEGER,
    p_title VARCHAR(255),
    p_review_text TEXT,
    p_is_verified BOOLEAN DEFAULT FALSE,
    p_review_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    p_metadata JSONB DEFAULT '{}'
)
RETURNS INTEGER AS $$
DECLARE
    new_review_id INTEGER;
BEGIN
    INSERT INTO reviews (
        source, source_review_id, product_id, product_name, customer_name,
        customer_email, rating, title, review_text, is_verified, review_date, metadata
    ) VALUES (
        p_source, p_source_review_id, p_product_id, p_product_name, p_customer_name,
        p_customer_email, p_rating, p_title, p_review_text, p_is_verified, p_review_date, p_metadata
    ) RETURNING id INTO new_review_id;
    
    RETURN new_review_id;
END;
$$ LANGUAGE plpgsql;

-- Function to get product rating summary
CREATE OR REPLACE FUNCTION get_product_rating_summary(p_product_id VARCHAR(255))
RETURNS TABLE (
    total_reviews BIGINT,
    avg_rating NUMERIC,
    rating_distribution JSON
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*) as total_reviews,
        ROUND(AVG(rating), 2) as avg_rating,
        JSON_BUILD_OBJECT(
            '5_star', COUNT(CASE WHEN rating = 5 THEN 1 END),
            '4_star', COUNT(CASE WHEN rating = 4 THEN 1 END),
            '3_star', COUNT(CASE WHEN rating = 3 THEN 1 END),
            '2_star', COUNT(CASE WHEN rating = 2 THEN 1 END),
            '1_star', COUNT(CASE WHEN rating = 1 THEN 1 END)
        ) as rating_distribution
    FROM reviews 
    WHERE product_id = p_product_id;
END;
$$ LANGUAGE plpgsql;
