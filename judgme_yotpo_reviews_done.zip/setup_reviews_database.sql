-- =============================================
-- PostgreSQL Reviews Database Setup
-- For Judge.me, Yotpo, and Grok AI Reviews
-- =============================================

-- Create database for reviews
CREATE DATABASE reviews_db;

-- Connect to the reviews database
\c reviews_db;

-- Create reviews table with comprehensive schema
CREATE TABLE IF NOT EXISTS reviews (
    -- Primary key
    id SERIAL PRIMARY KEY,
    
    -- Source information
    source VARCHAR(20) NOT NULL CHECK (source IN ('judgeme', 'yotpo', 'grok_ai')),
    source_review_id VARCHAR(255), -- Original review ID from the source platform
    
    -- Product information
    product_id VARCHAR(255) NOT NULL,
    product_name VARCHAR(500),
    product_sku VARCHAR(255),
    
    -- Customer information
    customer_id VARCHAR(255),
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    
    -- Review content
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(255),
    review_text TEXT,
    
    -- Review metadata
    is_verified BOOLEAN DEFAULT FALSE,
    is_featured BOOLEAN DEFAULT FALSE,
    helpful_votes INTEGER DEFAULT 0,
    
    -- Timestamps
    review_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Additional metadata (JSON for flexibility)
    metadata JSONB,
    
    -- Create indexes for better performance
    CONSTRAINT unique_source_review UNIQUE (source, source_review_id)
);

-- Create indexes for better query performance
CREATE INDEX idx_reviews_source ON reviews (source);
CREATE INDEX idx_reviews_product_id ON reviews (product_id);
CREATE INDEX idx_reviews_rating ON reviews (rating);
CREATE INDEX idx_reviews_review_date ON reviews (review_date);
CREATE INDEX idx_reviews_created_at ON reviews (created_at);
CREATE INDEX idx_reviews_customer_email ON reviews (customer_email);

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_reviews_updated_at 
    BEFORE UPDATE ON reviews 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data for testing
INSERT INTO reviews (
    source, source_review_id, product_id, product_name, customer_name, 
    customer_email, rating, title, review_text, is_verified, review_date, metadata
) VALUES 
-- Judge.me reviews
('judgeme', 'jm_123456', 'PROD_001', 'Wireless Headphones', 'John Doe', 'john@example.com', 
 5, 'Amazing sound quality!', 'These headphones exceeded my expectations. Crystal clear audio and comfortable fit.', 
 true, '2024-09-15 10:30:00+00', '{"judge_me_score": 5.0, "photos": ["photo1.jpg"], "location": "New York"}'),

('judgeme', 'jm_789012', 'PROD_002', 'Smartphone Case', 'Jane Smith', 'jane@example.com', 
 4, 'Good protection', 'Sturdy case that protects my phone well. A bit bulky but worth it.', 
 true, '2024-09-14 15:45:00+00', '{"judge_me_score": 4.0, "verified_buyer": true}'),

-- Yotpo reviews
('yotpo', 'yp_345678', 'PROD_001', 'Wireless Headphones', 'Mike Johnson', 'mike@example.com', 
 5, 'Perfect for workouts', 'Love these headphones for my gym sessions. Sweat-proof and great battery life.', 
 true, '2024-09-13 08:20:00+00', '{"yotpo_sentiment": "positive", "tags": ["workout", "battery"], "upvotes": 12}'),

('yotpo', 'yp_901234', 'PROD_003', 'Coffee Maker', 'Sarah Wilson', 'sarah@example.com', 
 3, 'Decent but could be better', 'Makes good coffee but the interface is confusing. Takes some getting used to.', 
 false, '2024-09-12 12:00:00+00', '{"yotpo_sentiment": "neutral", "helpful_count": 5}'),

-- Grok AI generated reviews
('grok_ai', 'grok_567890', 'PROD_001', 'Wireless Headphones', 'AI Analysis Bot', 'system@grok.ai', 
 4, 'AI Summary: Highly Rated Product', 'Based on 150+ reviews, customers praise the sound quality and comfort. Common mentions: excellent bass, comfortable for long use, good value for money.', 
 false, '2024-09-16 07:00:00+00', '{"ai_confidence": 0.92, "reviews_analyzed": 157, "sentiment_breakdown": {"positive": 0.78, "neutral": 0.15, "negative": 0.07}}'),

('grok_ai', 'grok_123789', 'PROD_002', 'Smartphone Case', 'AI Analysis Bot', 'system@grok.ai', 
 4, 'AI Summary: Reliable Protection', 'Customers consistently rate this case for its protective qualities. Most appreciate the durability, though some find it slightly bulky.', 
 false, '2024-09-16 07:05:00+00', '{"ai_confidence": 0.87, "reviews_analyzed": 89, "key_themes": ["protection", "durability", "bulky"]});

-- Create a view for easy querying
CREATE VIEW reviews_summary AS
SELECT 
    source,
    product_id,
    product_name,
    COUNT(*) as total_reviews,
    ROUND(AVG(rating), 2) as average_rating,
    COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star_count,
    COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star_count,
    COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star_count,
    COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star_count,
    COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star_count,
    MAX(review_date) as latest_review_date
FROM reviews 
GROUP BY source, product_id, product_name
ORDER BY average_rating DESC, total_reviews DESC;

-- Grant permissions (adjust as needed for your application users)
-- CREATE USER reviews_app_user WITH PASSWORD 'secure_password_here';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON reviews TO reviews_app_user;
-- GRANT USAGE, SELECT ON SEQUENCE reviews_id_seq TO reviews_app_user;

-- Display setup completion message
SELECT 'Reviews database setup completed successfully!' as status,
       'Database: reviews_db' as database,
       'Table: reviews' as table_name,
       COUNT(*) as sample_records_inserted
FROM reviews;
