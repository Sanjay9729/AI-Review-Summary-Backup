// clear-cache.js - Clear all cache files
import fs from 'fs/promises';
import path from 'path';

const CACHE_DIR = path.join(process.cwd(), 'cache');

async function clearCache() {
  try {
    console.log('🗑️ Clearing cache directory...');
    
    // Read all files in cache directory
    const files = await fs.readdir(CACHE_DIR);
    console.log(`Found ${files.length} cache files:`, files);
    
    // Delete each file
    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(CACHE_DIR, file);
        await fs.unlink(filePath);
        console.log(`✅ Deleted: ${file}`);
      }
    }
    
    console.log('🎉 Cache cleared successfully!');
    
  } catch (error) {
    console.error('❌ Error clearing cache:', error);
  }
}

clearCache();
