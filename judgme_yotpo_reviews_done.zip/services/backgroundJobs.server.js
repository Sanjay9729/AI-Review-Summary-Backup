// app/services/backgroundJobs.server.js
import ReviewCache from './reviewCache.server.js';

class BackgroundJobManager {
  constructor() {
    this.intervals = new Map();
    this.isRunning = false;
  }

  // Start the background job system
  start() {
    if (this.isRunning) {
      console.log('Background jobs already running');
      return;
    }

    console.log('Starting background job system...');
    this.isRunning = true;

    // Check for review updates every 30 minutes
    const reviewCheckInterval = setInterval(async () => {
      console.log('Running background review update check...');
      try {
        await ReviewCache.checkAllProductsForUpdates();
      } catch (error) {
        console.error('Background review check failed:', error);
      }
    }, 30 * 60 * 1000); // 30 minutes

    this.intervals.set('reviewCheck', reviewCheckInterval);

    // Cleanup old cache files every 6 hours
    const cleanupInterval = setInterval(async () => {
      console.log('Running cache cleanup...');
      try {
        await this.cleanupOldCache();
      } catch (error) {
        console.error('Cache cleanup failed:', error);
      }
    }, 6 * 60 * 60 * 1000); // 6 hours

    this.intervals.set('cleanup', cleanupInterval);

    // Run initial check after 2 minutes
    setTimeout(async () => {
      console.log('Running initial background review check...');
      await ReviewCache.checkAllProductsForUpdates();
    }, 2 * 60 * 1000);

    console.log('Background jobs started successfully');
  }

  // Stop all background jobs
  stop() {
    if (!this.isRunning) {
      return;
    }

    console.log('Stopping background jobs...');
    this.intervals.forEach((interval, name) => {
      clearInterval(interval);
      console.log(`Stopped ${name} job`);
    });
    
    this.intervals.clear();
    this.isRunning = false;
    console.log('All background jobs stopped');
  }

  // Cleanup old cache files
  async cleanupOldCache() {
    const fs = await import('fs/promises');
    const path = await import('path');
    
    const CACHE_DIR = path.join(process.cwd(), 'cache');
    const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

    try {
      const files = await fs.readdir(CACHE_DIR);
      let cleanedCount = 0;

      for (const file of files) {
        try {
          const filePath = path.join(CACHE_DIR, file);
          const stats = await fs.stat(filePath);
          
          if (Date.now() - stats.mtime.getTime() > CACHE_DURATION) {
            await fs.unlink(filePath);
            cleanedCount++;
          }
        } catch (error) {
          console.error(`Error processing file ${file}:`, error);
        }
      }

      console.log(`Cleaned up ${cleanedCount} old cache files`);
    } catch (error) {
      console.error('Error during cache cleanup:', error);
    }
  }

  // Get job status
  getStatus() {
    return {
      isRunning: this.isRunning,
      activeJobs: Array.from(this.intervals.keys()),
      jobCount: this.intervals.size,
      startedAt: this.startedAt || null
    };
  }

  // Force run a specific job
  async runJob(jobName) {
    console.log(`Manually running job: ${jobName}`);
    
    switch (jobName) {
      case 'reviewCheck':
        await ReviewCache.checkAllProductsForUpdates();
        break;
      case 'cleanup':
        await this.cleanupOldCache();
        break;
      default:
        throw new Error(`Unknown job: ${jobName}`);
    }
  }
}

// Export singleton instance
const backgroundJobs = new BackgroundJobManager();

// Auto-start in production
if (process.env.NODE_ENV === 'production') {
  backgroundJobs.start();
}

export default backgroundJobs;