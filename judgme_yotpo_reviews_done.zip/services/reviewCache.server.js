// app/services/reviewCache.server.js - Enhanced Version
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

const CACHE_DIR = path.join(process.cwd(), 'cache');
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours
const REVIEW_CHECK_INTERVAL = 0 * 1 * 1000; // 30 minutes

// Ensure cache directory exists
async function ensureCacheDir() {
  try {
    await fs.access(CACHE_DIR);
  } catch {
    await fs.mkdir(CACHE_DIR, { recursive: true });
  }
}

class ReviewCache {
  static getCacheKey(productHandle) {
    return `reviews_${productHandle}.json`;
  }

  static getAICacheKey(productHandle) {
    return `ai_summary_${productHandle}.json`;
  }

  static getMetaCacheKey(productHandle) {
    return `meta_${productHandle}.json`;
  }

  static getCachePath(filename) {
    return path.join(CACHE_DIR, filename);
  }

  // Generate hash of reviews to detect changes
  static generateReviewsHash(reviews) {
    const reviewsString = JSON.stringify(reviews.map(r => ({
      author: r.author,
      rating: r.rating,
      text: r.text,
      date: r.date
    })));
    return crypto.createHash('md5').update(reviewsString).digest('hex');
  }

  // Get cached reviews with freshness check
  static async get(productHandle) {
    try {
      await ensureCacheDir();
      const cacheKey = this.getCacheKey(productHandle);
      const cachePath = this.getCachePath(cacheKey);
      
      const stats = await fs.stat(cachePath);
      const isExpired = Date.now() - stats.mtime.getTime() > CACHE_DURATION;
      
      if (isExpired) {
        console.log(`Cache expired for ${productHandle}, clearing...`);
        await this.clear(productHandle);
        return null;
      }

      const data = await fs.readFile(cachePath, 'utf8');
      const parsedData = JSON.parse(data);

      // Check if we need to validate freshness
      const shouldCheckFreshness = await this.shouldCheckFreshness(productHandle);
      if (shouldCheckFreshness) {
        console.log(`Checking freshness for ${productHandle}...`);
        const isFresh = await this.validateCacheFreshness(productHandle, parsedData);
        if (!isFresh) {
          console.log(`Cache is stale for ${productHandle}, invalidating...`);
          await this.clear(productHandle);
          return null;
        }
        await this.updateLastChecked(productHandle);
      }

      return parsedData;
    } catch (error) {
      console.log(`Cache miss for ${productHandle}:`, error.message);
      return null;
    }
  }

  // Check if we should validate cache freshness
  static async shouldCheckFreshness(productHandle) {
    try {
      const metaKey = this.getMetaCacheKey(productHandle);
      const metaPath = this.getCachePath(metaKey);
      
      const metaData = await fs.readFile(metaPath, 'utf8');
      const meta = JSON.parse(metaData);
      
      const timeSinceLastCheck = Date.now() - new Date(meta.lastChecked).getTime();
      return timeSinceLastCheck > REVIEW_CHECK_INTERVAL;
    } catch {
      return true; // If no meta data, check freshness
    }
  }

  // Update last checked timestamp
  static async updateLastChecked(productHandle) {
    try {
      const metaKey = this.getMetaCacheKey(productHandle);
      const metaPath = this.getCachePath(metaKey);
      
      let meta = {};
      try {
        const existingMeta = await fs.readFile(metaPath, 'utf8');
        meta = JSON.parse(existingMeta);
      } catch {
        // File doesn't exist, create new meta
      }

      meta.lastChecked = new Date().toISOString();
      await fs.writeFile(metaPath, JSON.stringify(meta, null, 2));
    } catch (error) {
      console.error(`Failed to update last checked for ${productHandle}:`, error);
    }
  }

  // Validate if cached data is still fresh by comparing with live data
  static async validateCacheFreshness(productHandle, cachedData) {
    try {
      // Import scraping function dynamically to avoid circular imports
      const reviewScraper = await import('./reviewScraper.server.js');
      
      // Get fresh data from website
      const freshData = await reviewScraper.default.scrapeProductReviews(productHandle);
      
      if (!freshData.success || !cachedData.success) {
        return false;
      }

      // Compare review counts
      if (freshData.reviews.length !== cachedData.reviews.length) {
        console.log(`Review count changed for ${productHandle}: ${cachedData.reviews.length} -> ${freshData.reviews.length}`);
        return false;
      }

      // Compare review hashes
      const cachedHash = this.generateReviewsHash(cachedData.reviews);
      const freshHash = this.generateReviewsHash(freshData.reviews);
      
      if (cachedHash !== freshHash) {
        console.log(`Review content changed for ${productHandle}`);
        return false;
      }

      // Compare average ratings
      if (Math.abs(freshData.stats.average - cachedData.stats.average) > 0.1) {
        console.log(`Rating changed for ${productHandle}: ${cachedData.stats.average} -> ${freshData.stats.average}`);
        return false;
      }

      console.log(`Cache is fresh for ${productHandle}`);
      return true;
    } catch (error) {
      console.error(`Error validating cache freshness for ${productHandle}:`, error);
      return false; // If validation fails, consider cache stale
    }
  }

  // Enhanced set method with metadata
  static async set(productHandle, data) {
    try {
      await ensureCacheDir();
      const cacheKey = this.getCacheKey(productHandle);
      const cachePath = this.getCachePath(cacheKey);
      
      // Add hash and metadata
      const reviewsHash = this.generateReviewsHash(data.reviews || []);
      const cacheData = {
        ...data,
        reviewsHash,
        cachedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + CACHE_DURATION).toISOString()
      };

      await fs.writeFile(cachePath, JSON.stringify(cacheData, null, 2));
      
      // Update metadata
      await this.updateMetadata(productHandle, {
        reviewCount: data.reviews?.length || 0,
        averageRating: data.stats?.average || 0,
        reviewsHash,
        lastUpdated: new Date().toISOString(),
        lastChecked: new Date().toISOString()
      });

      console.log(`Cached reviews for ${productHandle} with hash: ${reviewsHash}`);
    } catch (error) {
      console.error(`Failed to cache reviews for ${productHandle}:`, error);
    }
  }

  // Update metadata file
  static async updateMetadata(productHandle, metadata) {
    try {
      const metaKey = this.getMetaCacheKey(productHandle);
      const metaPath = this.getCachePath(metaKey);
      await fs.writeFile(metaPath, JSON.stringify(metadata, null, 2));
    } catch (error) {
      console.error(`Failed to update metadata for ${productHandle}:`, error);
    }
  }

  // Enhanced AI summary methods
  static async getAISummary(productHandle) {
    try {
      await ensureCacheDir();
      const cacheKey = this.getAICacheKey(productHandle);
      const cachePath = this.getCachePath(cacheKey);
      
      const stats = await fs.stat(cachePath);
      const isExpired = Date.now() - stats.mtime.getTime() > CACHE_DURATION;
      
      if (isExpired) {
        await fs.unlink(cachePath);
        return null;
      }

      const data = await fs.readFile(cachePath, 'utf8');
      const summaryData = JSON.parse(data);

      // Check if AI summary is based on outdated reviews
      const currentReviewsCache = await this.get(productHandle);
      if (currentReviewsCache && currentReviewsCache.reviewsHash !== summaryData.reviewsHash) {
        console.log(`AI summary outdated for ${productHandle}, clearing...`);
        await fs.unlink(cachePath);
        return null;
      }

      return summaryData;
    } catch (error) {
      console.log(`AI cache miss for ${productHandle}:`, error.message);
      return null;
    }
  }

  static async setAISummary(productHandle, summaryData) {
    try {
      await ensureCacheDir();
      const cacheKey = this.getAICacheKey(productHandle);
      const cachePath = this.getCachePath(cacheKey);
      
      // Get current reviews hash to link AI summary with specific review set
      const currentReviewsCache = await this.get(productHandle);
      const reviewsHash = currentReviewsCache?.reviewsHash;

      const cacheData = {
        ...summaryData,
        reviewsHash,
        cachedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + CACHE_DURATION).toISOString()
      };

      await fs.writeFile(cachePath, JSON.stringify(cacheData, null, 2));
      console.log(`Cached AI summary for ${productHandle} linked to reviews hash: ${reviewsHash}`);
    } catch (error) {
      console.error(`Failed to cache AI summary for ${productHandle}:`, error);
    }
  }

  // Force refresh - clears cache and regenerates
  static async forceRefresh(productHandle) {
    try {
      console.log(`Force refreshing ${productHandle}...`);
      
      // Clear all cache
      await this.clear(productHandle);
      
      // Get fresh reviews
      const { scrapeProductReviews } = await import('./reviewScraper.server.js');
      const freshData = await scrapeProductReviews(productHandle);
      
      if (freshData.success) {
        // Cache fresh reviews
        await this.set(productHandle, freshData);
        
        // Regenerate AI summary
        await this.regenerateAISummary(productHandle, freshData);
        
        console.log(`Force refresh completed for ${productHandle}`);
        return { success: true, data: freshData };
      }
      
      return { success: false, error: 'Failed to fetch fresh reviews' };
    } catch (error) {
      console.error(`Force refresh failed for ${productHandle}:`, error);
      return { success: false, error: error.message };
    }
  }

  // Regenerate AI summary
  static async regenerateAISummary(productHandle, reviewsData) {
    try {
      console.log(`Regenerating AI summary for ${productHandle}...`);
      
      // Call AI summary generation
      const response = await fetch(`${process.env.APP_URL || 'http://localhost:3000'}/api/ai-review-summary`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reviews: reviewsData.reviews,
          stats: reviewsData.stats,
          productHandle: productHandle
        })
      });

      if (response.ok) {
        console.log(`AI summary regenerated for ${productHandle}`);
        return true;
      } else {
        console.error(`Failed to regenerate AI summary for ${productHandle}`);
        return false;
      }
    } catch (error) {
      console.error(`Error regenerating AI summary for ${productHandle}:`, error);
      return false;
    }
  }

  // Delete specific product cache (alias for clear)
  static async delete(productHandle) {
    return await this.clear(productHandle);
  }

  // Clear specific product cache
  static async clear(productHandle) {
    try {
      const reviewsCacheKey = this.getCacheKey(productHandle);
      const aiCacheKey = this.getAICacheKey(productHandle);
      const metaCacheKey = this.getMetaCacheKey(productHandle);
      
      await Promise.all([
        fs.unlink(this.getCachePath(reviewsCacheKey)).catch(() => {}),
        fs.unlink(this.getCachePath(aiCacheKey)).catch(() => {}),
        fs.unlink(this.getCachePath(metaCacheKey)).catch(() => {})
      ]);
      
      console.log(`Cleared all cache for ${productHandle}`);
    } catch (error) {
      console.error(`Failed to clear cache for ${productHandle}:`, error);
    }
  }

  // Clear all cache
  static async clearAll() {
    try {
      await ensureCacheDir();
      const files = await fs.readdir(CACHE_DIR);
      
      await Promise.all(
        files
          .filter(file => file.endsWith('.json'))
          .map(file => fs.unlink(this.getCachePath(file)))
      );
      
      console.log('Cleared all cache files');
    } catch (error) {
      console.error('Failed to clear all cache:', error);
    }
  }

  // Background job to check all cached products for updates
  static async checkAllProductsForUpdates() {
    try {
      await ensureCacheDir();
      const files = await fs.readdir(CACHE_DIR);
      const reviewFiles = files.filter(file => file.startsWith('reviews_') && file.endsWith('.json'));
      
      console.log(`Checking ${reviewFiles.length} products for updates...`);
      
      for (const file of reviewFiles) {
        const productHandle = file.replace('reviews_', '').replace('.json', '');
        
        try {
          // Check if this product needs freshness validation
          const shouldCheck = await this.shouldCheckFreshness(productHandle);
          if (shouldCheck) {
            const cachedData = await fs.readFile(this.getCachePath(file), 'utf8');
            const parsedData = JSON.parse(cachedData);
            
            const isFresh = await this.validateCacheFreshness(productHandle, parsedData);
            if (!isFresh) {
              console.log(`Detected stale cache for ${productHandle}, refreshing...`);
              await this.forceRefresh(productHandle);
            } else {
              await this.updateLastChecked(productHandle);
            }
          }
        } catch (error) {
          console.error(`Error checking ${productHandle}:`, error);
        }
      }
      
      console.log('Completed checking all products for updates');
    } catch (error) {
      console.error('Error in background update check:', error);
    }
  }

  // Get cache statistics
  static async getCacheStats() {
    try {
      await ensureCacheDir();
      const files = await fs.readdir(CACHE_DIR);
      
      const stats = {
        totalFiles: files.length,
        reviewsFiles: files.filter(f => f.startsWith('reviews_')).length,
        aiFiles: files.filter(f => f.startsWith('ai_summary_')).length,
        metaFiles: files.filter(f => f.startsWith('meta_')).length,
        lastUpdated: new Date().toISOString()
      };
      
      return stats;
    } catch (error) {
      console.error('Error getting cache stats:', error);
      return null;
    }
  }
}

export default ReviewCache;