// services/database.server.js - PostgreSQL Database Service
import prisma from "../app/db.server.js";

class DatabaseService {
  // ===== PRODUCT OPERATIONS =====

  static async createProduct(productData) {
    try {
      const product = await prisma.product.create({
        data: {
          shopifyId: productData.shopifyId,
          handle: productData.handle,
          title: productData.title,
          shop: productData.shop,
          status: productData.status || 'ACTIVE'
        }
      });
      console.log(`Created product: ${product.handle}`);
      return product;
    } catch (error) {
      if (error.code === 'P2002' && error.meta?.target?.includes('shopifyId')) {
        // Product with this shopifyId already exists, fetch it
        return await this.getProductByShopifyId(productData.shopifyId);
      }
      console.error('Error creating product:', error);
      throw error;
    }
  }

  static async getProductByHandle(handle, shop) {
    try {
      return await prisma.product.findFirst({
        where: { handle, shop }
      });
    } catch (error) {
      console.error('Error fetching product by handle:', error);
      return null;
    }
  }

  static async getProductByShopifyId(shopifyId) {
    try {
      return await prisma.product.findUnique({
        where: { shopifyId }
      });
    } catch (error) {
      console.error('Error fetching product by shopifyId:', error);
      return null;
    }
  }

  // ===== REVIEW OPERATIONS =====

  static async saveReviews(productId, reviews) {
    try {
      const reviewsToCreate = reviews.map(review => ({
        productId,
        author: review.author || 'Anonymous',
        rating: Math.max(0, Math.min(5, review.rating || 0)),
        title: review.title || null,
        text: review.text || '',
        verified: review.verified || false,
        platform: review.platform || 'Unknown',
        reviewDate: review.date ? new Date(review.date) : null,
        scrapedAt: new Date()
      }));

      // Clear existing reviews for this product first
      await prisma.review.deleteMany({
        where: { productId }
      });

      // Insert new reviews
      const result = await prisma.review.createMany({
        data: reviewsToCreate,
        skipDuplicates: true
      });

      console.log(`Saved ${result.count} reviews for product ${productId}`);
      return result;
    } catch (error) {
      console.error('Error saving reviews:', error);
      throw error;
    }
  }

  static async getReviewsByProduct(productId) {
    try {
      return await prisma.review.findMany({
        where: { productId },
        orderBy: { scrapedAt: 'desc' }
      });
    } catch (error) {
      console.error('Error fetching reviews:', error);
      return [];
    }
  }

  static async getReviewStats(productId) {
    try {
      const reviews = await this.getReviewsByProduct(productId);
      
      if (reviews.length === 0) {
        return {
          total: 0,
          average: 0,
          verified: 0,
          totalWithText: 0,
          distribution: {}
        };
      }

      const total = reviews.length;
      const average = reviews.reduce((sum, r) => sum + r.rating, 0) / total;
      const verified = reviews.filter(r => r.verified).length;
      const totalWithText = reviews.filter(r => r.text && r.text.trim().length > 0).length;
      
      const distribution = reviews.reduce((acc, r) => {
        const star = Math.round(r.rating);
        acc[star] = (acc[star] || 0) + 1;
        return acc;
      }, {});

      return {
        total,
        average: Math.round(average * 10) / 10,
        verified,
        totalWithText,
        distribution
      };
    } catch (error) {
      console.error('Error calculating review stats:', error);
      return { total: 0, average: 0, verified: 0, totalWithText: 0, distribution: {} };
    }
  }

  // ===== AI SUMMARY OPERATIONS =====

  static async saveAISummary(productId, summaryData) {
    try {
      // Delete existing AI summary for this product
      await prisma.aiSummary.deleteMany({
        where: { productId }
      });

      const aiSummary = await prisma.aiSummary.create({
        data: {
          productId,
          summary: summaryData.summary,
          model: summaryData.model || null,
          reviewsAnalyzed: summaryData.reviewsAnalyzed || 0,
          totalReviews: summaryData.totalReviews || 0,
          averageRating: summaryData.averageRating || null,
          reviewPlatform: summaryData.reviewPlatform || null,
          platforms: summaryData.platforms || [],
          platformCounts: summaryData.platformCounts || {},
          isMultiPlatform: summaryData.isMultiPlatform || false,
          duplicateReviews: summaryData.duplicateReviews || 0,
          consistencyScore: summaryData.consistencyScore || null,
          fromCache: summaryData.fromCache || false
        }
      });

      console.log(`Saved AI summary for product ${productId}`);
      return aiSummary;
    } catch (error) {
      console.error('Error saving AI summary:', error);
      throw error;
    }
  }

  static async getAISummaryByProduct(productId) {
    try {
      return await prisma.aiSummary.findFirst({
        where: { productId },
        orderBy: { generatedAt: 'desc' }
      });
    } catch (error) {
      console.error('Error fetching AI summary:', error);
      return null;
    }
  }

  // ===== CACHE OPERATIONS =====

  static async getCachedReviews(productHandle) {
    try {
      const cacheEntry = await prisma.reviewCache.findUnique({
        where: { productHandle }
      });

      if (!cacheEntry) {
        return null;
      }

      // Check if cache is expired
      if (new Date() > cacheEntry.expiresAt) {
        await this.clearCache(productHandle);
        return null;
      }

      return {
        ...cacheEntry.data,
        fromCache: true,
        cachedAt: cacheEntry.scrapedAt.toISOString()
      };
    } catch (error) {
      console.error('Error getting cached reviews:', error);
      return null;
    }
  }

  static async setCachedReviews(productHandle, reviewsData, cacheDurationHours = 24) {
    try {
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + cacheDurationHours);

      const cacheData = {
        productHandle,
        cacheKey: `reviews_${productHandle}_${Date.now()}`,
        data: reviewsData,
        stats: reviewsData.stats || {},
        platform: reviewsData.reviewPlatform || 'Unknown',
        expiresAt
      };

      await prisma.reviewCache.upsert({
        where: { productHandle },
        update: cacheData,
        create: cacheData
      });

      console.log(`Cached reviews for ${productHandle}, expires at ${expiresAt.toISOString()}`);
    } catch (error) {
      console.error('Error caching reviews:', error);
    }
  }

  static async clearCache(productHandle) {
    try {
      await prisma.reviewCache.delete({
        where: { productHandle }
      });
      console.log(`Cleared cache for ${productHandle}`);
    } catch (error) {
      if (error.code !== 'P2025') { // Not found error
        console.error('Error clearing cache:', error);
      }
    }
  }

  // ===== SESSION OPERATIONS =====

  static async saveSession(sessionData) {
    try {
      return await prisma.session.upsert({
        where: { id: sessionData.id },
        update: sessionData,
        create: sessionData
      });
    } catch (error) {
      console.error('Error saving session:', error);
      throw error;
    }
  }

  static async getSession(sessionId) {
    try {
      return await prisma.session.findUnique({
        where: { id: sessionId }
      });
    } catch (error) {
      console.error('Error fetching session:', error);
      return null;
    }
  }

  static async deleteSession(sessionId) {
    try {
      await prisma.session.delete({
        where: { id: sessionId }
      });
    } catch (error) {
      if (error.code !== 'P2025') { // Not found error
        console.error('Error deleting session:', error);
      }
    }
  }

  // ===== APP METADATA OPERATIONS =====

  static async saveAppMetadata(shop, settings) {
    try {
      return await prisma.appMetadata.upsert({
        where: { shop },
        update: { settings, lastSync: new Date() },
        create: { shop, settings, lastSync: new Date() }
      });
    } catch (error) {
      console.error('Error saving app metadata:', error);
      throw error;
    }
  }

  static async getAppMetadata(shop) {
    try {
      return await prisma.appMetadata.findUnique({
        where: { shop }
      });
    } catch (error) {
      console.error('Error fetching app metadata:', error);
      return null;
    }
  }

  // ===== HEALTH CHECK =====

  static async healthCheck() {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return { status: 'healthy', database: 'connected', timestamp: new Date().toISOString() };
    } catch (error) {
      console.error('Database health check failed:', error);
      return { status: 'unhealthy', error: error.message, timestamp: new Date().toISOString() };
    }
  }

  // ===== UTILITY METHODS =====

  static async getOrCreateProduct(productData) {
    let product = await this.getProductByHandle(productData.handle, productData.shop);
    if (!product) {
      product = await this.createProduct(productData);
    }
    return product;
  }

  // Get complete product data with reviews and AI summary
  static async getProductComplete(productHandle, shop) {
    try {
      const product = await prisma.product.findFirst({
        where: { handle: productHandle, shop },
        include: {
          reviews: {
            orderBy: { scrapedAt: 'desc' }
          },
          aiSummaries: {
            orderBy: { generatedAt: 'desc' },
            take: 1
          }
        }
      });

      if (!product) {
        return null;
      }

      const stats = await this.getReviewStats(product.id);

      return {
        product,
        reviews: product.reviews,
        aiSummary: product.aiSummaries[0] || null,
        stats
      };
    } catch (error) {
      console.error('Error fetching complete product data:', error);
      return null;
    }
  }
}

export default DatabaseService;
