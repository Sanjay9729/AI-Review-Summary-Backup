# 🚀 Real-Time AI Review Summary Setup

## 🎯 Overview

Your system now supports **real-time AI review summaries** through two methods:
1. **Webhooks** - Instant updates when reviews are added
2. **Scheduled Refresh** - Periodic checks for review changes

## 🔧 Method 1: Webhook Setup (Recommended)

### Judge.me Webhooks

1. **Login to Judge.me Admin**
   - Go to your Judge.me dashboard
   - Navigate to **Settings > Integrations > Webhooks**

2. **Add New Webhook**
   ```
   Webhook URL: https://yourdomain.com/api/webhook/review-updated
   Events: Review Created, Review Updated, Review Approved
   Method: POST
   ```

3. **Test Webhook**
   - Judge.me provides a test webhook feature
   - Check your server logs for: `🔔 Review webhook received`

### Yotpo Webhooks

1. **Login to Yotpo Admin**
   - Go to your Yotpo dashboard  
   - Navigate to **Settings > General Settings > Webhooks**

2. **Add New Webhook**
   ```
   Webhook URL: https://yourdomain.com/api/webhook/review-updated
   Events: review.create, review.update
   Method: POST
   Content-Type: application/json
   ```

3. **Configure Webhook Data**
   - Ensure the webhook sends product handle/ID
   - Enable review data in webhook payload

### Webhook Endpoint Features

Your webhook endpoint (`/api/webhook/review-updated`) automatically:
- ✅ Clears old cached data
- ✅ Pre-generates fresh AI summary
- ✅ Handles multiple webhook formats
- ✅ Provides error logging
- ✅ Returns success/failure status

## 🕒 Method 2: Scheduled Refresh

### Manual Testing

Test the refresh script manually:
```bash
node scripts/refresh-ai-summaries.js
```

### Windows Task Scheduler Setup

1. **Open Task Scheduler**
   - Press `Win + R`, type `taskschd.msc`, press Enter

2. **Create Basic Task**
   - Click **"Create Basic Task"**
   - Name: `AI Review Summary Refresh`
   - Description: `Automatically refresh AI summaries for product reviews`

3. **Set Trigger**
   - **Daily** - for light traffic stores
   - **Hourly** - for high traffic stores
   - Choose start time (e.g., every day at 2:00 AM)

4. **Set Action**
   - Action: **Start a program**
   - Program: `D:\demo\scripts\refresh-summaries.bat`
   - Start in: `D:\demo`

5. **Configure Advanced Settings**
   - ✅ Run whether user is logged on or not
   - ✅ Run with highest privileges
   - Configure for: Windows 10

### Linux/Mac Cron Job Setup

If you're on Linux/Mac, add to crontab:
```bash
# Run every hour
0 * * * * cd /path/to/demo && node scripts/refresh-ai-summaries.js

# Run every 6 hours  
0 */6 * * * cd /path/to/demo && node scripts/refresh-ai-summaries.js

# Run daily at 2 AM
0 2 * * * cd /path/to/demo && node scripts/refresh-ai-summaries.js
```

## ⚙️ Configuration

### Product List Configuration

Edit `scripts/refresh-ai-summaries.js` to add your products:
```javascript
const PRODUCTS_TO_CHECK = [
  'classic-cotton-t-shirt',
  'desert-bloom-camp-shirt',
  'your-product-handle-1',
  'your-product-handle-2',
  // Add more products here
];
```

### Cache Settings

Adjust cache duration in `services/reviewCache.server.js`:
```javascript
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours (default)
const REVIEW_CHECK_INTERVAL = 60 * 60 * 1000; // 1 hour (default)
```

## 🔍 Monitoring & Testing

### Log Monitoring

Watch for these log messages:
```
✅ Webhook received and processed
🗑️ Cleared cache for product-handle  
🤖 Pre-generating AI summary...
✅ Updated product-handle: 5 reviews
🎉 AI summary refresh completed!
```

### Testing New Reviews

1. **Add Test Review**
   - Submit a review on your product page
   - OR add via Judge.me/Yotpo admin

2. **Check Webhook (if enabled)**
   - Should see webhook log within seconds
   - AI summary should update automatically

3. **Check Scheduled Refresh**
   - Wait for scheduled time OR run manually
   - Should see refresh logs in console

### API Endpoints for Testing

Test your webhooks:
```bash
# Test webhook endpoint
curl -X POST https://yourdomain.com/api/webhook/review-updated \
  -H "Content-Type: application/json" \
  -d '{"productHandle": "classic-cotton-t-shirt"}'

# Check if AI summary updated
curl https://yourdomain.com/api/reviews/classic-cotton-t-shirt
```

## 🚨 Troubleshooting

### Webhook Issues

**Webhook not triggering:**
- Check webhook URL is publicly accessible
- Verify HTTPS is enabled
- Check webhook configuration in review platform
- Look for webhook delivery logs in platform admin

**Webhook errors:**
- Check server logs for errors
- Verify product handle extraction
- Confirm ReviewCache.delete() works
- Test scraper function independently

### Scheduled Refresh Issues

**Script not running:**
- Check Task Scheduler is active
- Verify file paths are correct
- Test batch file manually
- Check Windows Event Logs

**Script errors:**
- Run script manually to see errors
- Check Node.js is in PATH
- Verify all imports are working
- Check product handles exist

### Performance Issues

**Slow webhook response:**
- Consider making AI generation async
- Cache webhook responses
- Add rate limiting

**High server load:**
- Reduce refresh frequency
- Limit concurrent scraping
- Add request queuing

## ✅ Success Indicators

You'll know it's working when:

1. **New Review Added** → Cache cleared within seconds
2. **Product Page Viewed** → Fresh AI summary appears
3. **Logs Show** → Regular refresh activity
4. **AI Summary Changes** → Based on new review content

## 🎯 Next Steps

1. **Setup Webhooks** - Start with this for instant updates
2. **Configure Scheduled Refresh** - As backup for missed webhooks  
3. **Monitor Logs** - Watch for successful operations
4. **Test Thoroughly** - Add reviews and verify updates
5. **Optimize Performance** - Adjust timing based on your traffic

Your real-time AI review summary system is now **fully operational**! 🎉
