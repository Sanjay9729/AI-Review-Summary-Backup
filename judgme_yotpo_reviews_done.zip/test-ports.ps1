# test-ports.ps1
# Quick test to find which port is serving your app

$portsToTest = @(
    "http://127.0.0.1:9293",
    "http://localhost:9293", 
    "http://127.0.0.1:3457",
    "http://localhost:3457",
    "https://roads-conference-golf-walnut.trycloudflare.com"
)

Write-Host "🔍 Testing ports to find your server..." -ForegroundColor Green

foreach ($url in $portsToTest) {
    Write-Host "`n📋 Testing: $url" -ForegroundColor Cyan
    try {
        $response = Invoke-WebRequest -Uri $url -Method GET -TimeoutSec 5 -UseBasicParsing
        Write-Host "   ✅ SUCCESS! Status: $($response.StatusCode)" -ForegroundColor Green
        Write-Host "   Content Length: $($response.Content.Length) bytes" -ForegroundColor White
        
        # Test API endpoint
        try {
            $apiUrl = "$url/api/reviews/classic-cotton-t-shirt"
            Write-Host "   Testing API endpoint: $apiUrl" -ForegroundColor Yellow
            $apiResponse = Invoke-WebRequest -Uri $apiUrl -Method GET -TimeoutSec 5 -UseBasicParsing
            Write-Host "   ✅ API WORKS! Status: $($apiResponse.StatusCode)" -ForegroundColor Green
            Write-Host "   🎯 USE THIS URL: $url" -ForegroundColor Magenta
        } catch {
            Write-Host "   ⚠️ Main site works but API might not be available" -ForegroundColor Yellow
        }
        
    } catch {
        Write-Host "   ❌ Failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`n📊 Summary:" -ForegroundColor Green
Write-Host "- Look for URLs marked with '🎯 USE THIS URL'" -ForegroundColor White
Write-Host "- Copy that URL and use it in the webhook test interface" -ForegroundColor White
