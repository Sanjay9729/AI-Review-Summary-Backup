# 🔔 Manual Webhook Testing Guide

## 🚀 Prerequisites
1. Start your development server: `npm run dev`
2. Server should be running on `http://localhost:3000`

## 📋 Test Commands

### Test 1: Basic Webhook Test
```bash
# Test basic webhook functionality
curl -X POST http://localhost:3000/api/webhook/review-updated \
  -H "Content-Type: application/json" \
  -d "{\"productHandle\": \"classic-cotton-t-shirt\", \"event\": \"review.created\"}"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Cache cleared and AI summary updated for classic-cotton-t-shirt",
  "productHandle": "classic-cotton-t-shirt",
  "timestamp": "2024-01-16T10:30:00.000Z"
}
```

### Test 2: Judge.me Style Webhook
```bash
# Simulate Judge.me webhook payload
curl -X POST http://localhost:3000/api/webhook/review-updated \
  -H "Content-Type: application/json" \
  -d "{
    \"product\": {
      \"handle\": \"classic-cotton-t-shirt\",
      \"id\": 123456789
    },
    \"review\": {
      \"rating\": 5,
      \"body\": \"Great product!\",
      \"reviewer_name\": \"John Doe\"
    },
    \"event\": \"review_created\"
  }"
```

### Test 3: Yotpo Style Webhook
```bash
# Simulate Yotpo webhook payload
curl -X POST http://localhost:3000/api/webhook/review-updated \
  -H "Content-Type: application/json" \
  -d "{
    \"product_id\": \"classic-cotton-t-shirt\",
    \"product_handle\": \"classic-cotton-t-shirt\",
    \"review_id\": 987654321,
    \"rating\": 4,
    \"content\": \"Nice quality shirt\",
    \"user_name\": \"Jane Smith\",
    \"event_type\": \"review.create\"
  }"
```

### Test 4: Manual Refresh Trigger
```bash
# Test manual refresh endpoint
curl -X POST http://localhost:3000/api/trigger-refresh/classic-cotton-t-shirt \
  -H "Content-Type: application/json"
```

### Test 5: Verify AI Summary Updated
```bash
# Check if AI summary was refreshed
curl http://localhost:3000/api/reviews/classic-cotton-t-shirt
```

## 🔍 What to Look For

### ✅ Success Indicators:
- `"success": true` in webhook responses
- Cache clearing logs in server console
- Updated `scrapedAt` timestamp in AI summary
- Server logs showing webhook processing

### ❌ Error Signs:
- `"success": false` responses
- 404 errors (endpoint not found)
- 500 errors (server issues)
- No log activity in server console

## 📊 Expected Server Logs

When webhooks work correctly, you should see:
```
🔔 Review webhook received
📦 Webhook payload: {...}
🎯 Processing review update for product: classic-cotton-t-shirt
🗑️ Cleared cache for classic-cotton-t-shirt
🤖 Pre-generating AI summary for classic-cotton-t-shirt...
✅ Pre-generated summary for classic-cotton-t-shirt: X reviews
```

## 🐛 Troubleshooting

### Webhook Not Working:
1. **Check server is running**: Visit `http://localhost:3000` in browser
2. **Verify endpoint exists**: Should see webhook processing logs
3. **Check JSON format**: Ensure valid JSON in curl commands
4. **Review server logs**: Look for error messages

### PowerShell Users:
If using PowerShell instead of bash, use this format:
```powershell
# PowerShell version of webhook test
Invoke-RestMethod -Uri "http://localhost:3000/api/webhook/review-updated" `
  -Method Post `
  -ContentType "application/json" `
  -Body '{"productHandle": "classic-cotton-t-shirt", "event": "review.created"}'
```

## 🎯 Next Steps After Testing

1. **Webhooks Work Locally** → Set up real webhooks in Judge.me/Yotpo
2. **Deploy to Production** → Update webhook URLs to your live domain
3. **Monitor Real Reviews** → Watch for actual webhook activity
4. **Set Up Scheduled Backup** → Configure Windows Task Scheduler

## 📞 Test Results Template

Copy this template to record your test results:

```
📋 WEBHOOK TEST RESULTS
Date: ___________
Server Running: [ ] Yes [ ] No
Webhook Endpoint: [ ] Success [ ] Failed
Judge.me Format: [ ] Success [ ] Failed  
Yotpo Format: [ ] Success [ ] Failed
Manual Refresh: [ ] Success [ ] Failed
AI Summary Update: [ ] Success [ ] Failed

Notes:
_________________________________
```
