# Webhook Troubleshooting Guide

## Overview
This guide helps you diagnose and fix common issues with Judge.me and Yotpo webhooks in your AI review summary system.

## Quick Diagnostic Commands

```powershell
# Check server status
netstat -an | findstr :9293

# Test webhook endpoint
curl -X POST http://127.0.0.1:9293/api/webhook/review-updated -H "Content-Type: application/json" -d "{\"test\":true}"

# Check server logs
Get-Content server.log | Select-String -Pattern "webhook|error" | Select-Object -Last 10

# Verify environment variables
Get-ChildItem Env: | Where-Object {$_.Name -like "*SHOPIFY*" -or $_.Name -like "*OPENAI*"}
```

## Common Issues & Solutions

### 1. 404 Not Found - Webhook Endpoint

#### Symptoms:
```
❌ POST /api/webhook/review-updated → 404 Not Found
❌ Webhook delivery failed: 404 (Judge.me/Yotpo logs)
```

#### Root Causes:
- Server not running
- Wrong endpoint URL
- Missing Shopify authentication context
- Incorrect routing configuration

#### Solutions:

**Step 1: Verify Server is Running**
```powershell
# Check if server process exists
Get-Process | Where-Object {$_.ProcessName -like "*node*"}

# Check port binding
netstat -an | findstr :9293

# If not running, start server
npm run dev
```

**Step 2: Verify Endpoint URL**
```powershell
# Test endpoint directly
curl -I http://127.0.0.1:9293/api/webhook/review-updated
# Should return: HTTP/1.1 200 OK or 405 Method Not Allowed (not 404)

# Check Cloudflare tunnel URL (if using)
curl -I https://your-tunnel-url.trycloudflare.com/api/webhook/review-updated
```

**Step 3: Check Shopify Context**
- Ensure you're using `npm run dev` (not `node server.js`)
- Verify Shopify app is properly configured
- Check `shopify.app.toml` configuration

**Step 4: Verify Route Configuration**
```javascript
// Check if route exists in your code
// app/routes/api.webhook.review-updated.jsx should exist
```

### 2. 500 Internal Server Error

#### Symptoms:
```
❌ POST /api/webhook/review-updated → 500 Internal Server Error
❌ Server crashes when webhook received
```

#### Root Causes:
- Missing environment variables
- Database connection issues
- Unhandled errors in webhook processing
- Missing dependencies

#### Solutions:

**Step 1: Check Environment Variables**
```powershell
# Verify all required variables are set
echo $env:SHOPIFY_API_KEY
echo $env:SHOPIFY_API_SECRET
echo $env:OPENAI_API_KEY
echo $env:SHOPIFY_STORE_URL
echo $env:SHOPIFY_STORE_PASSWORD

# Check .env file
Get-Content .env
```

**Step 2: Check Server Logs**
```powershell
# Monitor logs in real-time
Get-Content server.log -Wait

# Look for specific errors
Get-Content server.log | Select-String -Pattern "ERROR|error|Error" | Select-Object -Last 5
```

**Step 3: Test Components Individually**
```powershell
# Test AI summary generation
curl "http://127.0.0.1:9293/api/ai-review-summary?productHandle=test-product"

# Test cache system
curl "http://127.0.0.1:9293/api/cache-management?action=status"

# Test database connection
npm run test:db
```

**Step 4: Add Error Handling**
Check your webhook handler has proper error handling:
```javascript
export const action = async ({ request }) => {
  try {
    // webhook processing code
    return json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return json({ error: error.message }, { status: 500 });
  }
};
```

### 3. Webhook Processing but AI Summary Not Updating

#### Symptoms:
```
✅ Webhook received successfully
✅ Cache invalidated
❌ AI summary remains unchanged
```

#### Root Causes:
- Cache invalidation not working properly
- AI summary generation failing silently
- Product handle mismatch
- Review scraping issues

#### Solutions:

**Step 1: Verify Cache Invalidation**
```powershell
# Check cache directory before webhook
ls cache/

# Send test webhook
curl -X POST http://127.0.0.1:9293/api/webhook/review-updated -H "Content-Type: application/json" -d '{"data":{"product_external_id":"test-product"}}'

# Check cache directory after webhook (should be empty or updated)
ls cache/
```

**Step 2: Test AI Summary Generation**
```powershell
# Force regenerate AI summary
curl "http://127.0.0.1:9293/api/ai-review-summary?productHandle=test-product&force=true"

# Check for AI generation errors
Get-Content server.log | Select-String -Pattern "AI|OpenAI|summary" | Select-Object -Last 5
```

**Step 3: Verify Product Handle Mapping**
```powershell
# Check what product handle the webhook extracted
# Look in server logs for: "Product handle extracted: ..."
Get-Content server.log | Select-String -Pattern "Product handle extracted" | Select-Object -Last 3
```

**Step 4: Test Review Scraping**
```powershell
# Test review scraping directly
curl "http://127.0.0.1:9293/api/reviews/test-product?debug=true"
```

### 4. Connection Refused / Timeout Errors

#### Symptoms:
```
❌ Connection refused
❌ Request timeout
❌ ECONNREFUSED 127.0.0.1:9293
```

#### Root Causes:
- Server not listening on expected port
- Firewall blocking connections
- Port already in use
- Cloudflare tunnel issues

#### Solutions:

**Step 1: Check Port Usage**
```powershell
# Find what's using port 9293
netstat -ano | findstr :9293

# Kill process if needed (replace PID)
taskkill /PID <PID> /F

# Start server on specific port
$env:PORT = "9293"; npm run dev
```

**Step 2: Check Firewall**
```powershell
# Check Windows Firewall (Run as Administrator)
netsh advfirewall firewall show rule name="Node.js"

# Add firewall rule if needed
netsh advfirewall firewall add rule name="Node.js" dir=in action=allow protocol=TCP localport=9293
```

**Step 3: Test Different URLs**
```powershell
# Try different localhost formats
curl -I http://127.0.0.1:9293
curl -I http://localhost:9293
curl -I http://[::1]:9293

# Test from external machine (if accessible)
curl -I http://your-ip:9293
```

**Step 4: Cloudflare Tunnel Issues**
```bash
# Check tunnel status
cloudflared tunnel list

# Restart tunnel
cloudflared tunnel run your-tunnel-name

# Check tunnel logs
cloudflared tunnel run your-tunnel-name --loglevel debug
```

### 5. Judge.me Specific Issues

#### Issue: Judge.me Webhook Not Triggering

**Symptoms:**
- Reviews submitted successfully
- No webhook received in server logs
- Judge.me dashboard shows webhook as active

**Solutions:**

1. **Check Judge.me Webhook Logs:**
   - Go to Judge.me dashboard → Settings → Webhooks
   - Click on your webhook to view delivery logs
   - Look for failed deliveries

2. **Verify Event Configuration:**
   ```
   ✅ Review Created - enabled
   ✅ Review Published - enabled (if using moderation)
   ❌ Review Updated - may cause duplicate webhooks
   ```

3. **Test Judge.me Webhook:**
   - Use Judge.me's built-in test feature
   - Send test webhook from dashboard
   - Monitor server logs

4. **Check SSL/HTTPS:**
   - Judge.me requires HTTPS URLs
   - Verify SSL certificate is valid
   - Test with: `curl -I https://your-domain.com/api/webhook/review-updated`

#### Issue: Judge.me Payload Format Issues

**Symptoms:**
- Webhook received but product handle not extracted
- Error parsing Judge.me payload

**Solutions:**

1. **Log Raw Payload:**
   ```javascript
   // Add to webhook handler
   console.log('Raw webhook payload:', await request.text());
   ```

2. **Verify Expected Format:**
   ```json
   {
     "event": "review.created",
     "data": {
       "product_external_id": "your-product-handle"
     }
   }
   ```

3. **Handle Alternative Formats:**
   ```javascript
   // Handle both formats
   const productHandle = payload.data?.product_external_id || 
                        payload.data?.product_handle ||
                        payload.product_external_id;
   ```

### 6. Yotpo Specific Issues

#### Issue: Yotpo Webhooks Not Available

**Symptoms:**
- No webhook option in Yotpo dashboard
- "Feature not available" message

**Solutions:**

1. **Check Plan Requirements:**
   - Webhooks require Yotpo Growth or Premium plan
   - Contact Yotpo support to verify access

2. **Use API Polling Alternative:**
   ```javascript
   // Schedule periodic review checks
   setInterval(async () => {
     // Poll Yotpo API for new reviews
     const reviews = await fetchYotpoReviews();
     // Process new reviews
   }, 300000); // Every 5 minutes
   ```

3. **Contact Yotpo Support:**
   - Request webhook access
   - Ask about API alternatives

#### Issue: Yotpo Authentication Errors

**Symptoms:**
```
❌ 401 Unauthorized from Yotpo
❌ Invalid API credentials
```

**Solutions:**

1. **Verify API Credentials:**
   - Check Yotpo dashboard for App Key and Secret
   - Ensure credentials are correctly set in environment

2. **Generate New Token:**
   ```bash
   # Get new Yotpo API token
   curl -X POST https://api.yotpo.com/oauth/token \
     -H "Content-Type: application/json" \
     -d '{"client_id":"your-app-key","client_secret":"your-secret","grant_type":"client_credentials"}'
   ```

### 7. Performance Issues

#### Issue: Slow Webhook Processing

**Symptoms:**
- Webhooks time out
- Long response times
- Judge.me/Yotpo shows delivery failures

**Solutions:**

1. **Optimize AI Generation:**
   ```javascript
   // Process webhooks asynchronously
   export const action = async ({ request }) => {
     const payload = await request.json();
     
     // Quick response to webhook
     setTimeout(async () => {
       await processWebhookAsync(payload);
     }, 100);
     
     return json({ success: true });
   };
   ```

2. **Implement Caching:**
   - Cache AI summaries aggressively
   - Only regenerate when necessary
   - Use background jobs for heavy processing

3. **Add Request Queuing:**
   ```javascript
   // Queue webhook processing
   const webhookQueue = [];
   const processQueue = async () => {
     while (webhookQueue.length > 0) {
       const webhook = webhookQueue.shift();
       await processWebhook(webhook);
     }
   };
   ```

## Diagnostic Scripts

### Complete System Health Check

```powershell
# Save as: system-health-check.ps1

Write-Host "🏥 AI Review Summary System Health Check" -ForegroundColor Green
Write-Host "=" * 50

# Check 1: Server Status
Write-Host "1. Checking server status..." -ForegroundColor Yellow
try {
    $serverResponse = Invoke-WebRequest -Uri "http://127.0.0.1:9293" -Method HEAD -TimeoutSec 5
    Write-Host "✅ Server is running (Status: $($serverResponse.StatusCode))" -ForegroundColor Green
} catch {
    Write-Host "❌ Server not responding: $($_.Exception.Message)" -ForegroundColor Red
}

# Check 2: Environment Variables
Write-Host "2. Checking environment variables..." -ForegroundColor Yellow
$requiredEnvVars = @("SHOPIFY_API_KEY", "SHOPIFY_API_SECRET", "OPENAI_API_KEY", "SHOPIFY_STORE_URL")
foreach ($envVar in $requiredEnvVars) {
    if ([Environment]::GetEnvironmentVariable($envVar)) {
        Write-Host "✅ $envVar is set" -ForegroundColor Green
    } else {
        Write-Host "❌ $envVar is missing" -ForegroundColor Red
    }
}

# Check 3: Webhook Endpoint
Write-Host "3. Testing webhook endpoint..." -ForegroundColor Yellow
try {
    $webhookResponse = Invoke-RestMethod -Uri "http://127.0.0.1:9293/api/webhook/review-updated" -Method POST -Body '{"test":true}' -ContentType "application/json" -TimeoutSec 10
    Write-Host "✅ Webhook endpoint is accessible" -ForegroundColor Green
} catch {
    Write-Host "❌ Webhook endpoint error: $($_.Exception.Message)" -ForegroundColor Red
}

# Check 4: AI Summary Endpoint
Write-Host "4. Testing AI summary endpoint..." -ForegroundColor Yellow
try {
    $aiResponse = Invoke-RestMethod -Uri "http://127.0.0.1:9293/api/ai-review-summary?productHandle=test-product" -Method GET -TimeoutSec 15
    Write-Host "✅ AI summary endpoint is working" -ForegroundColor Green
} catch {
    Write-Host "⚠️ AI summary endpoint issue: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Check 5: Cache System
Write-Host "5. Checking cache system..." -ForegroundColor Yellow
if (Test-Path "cache") {
    $cacheFiles = Get-ChildItem "cache" -File
    Write-Host "✅ Cache directory exists ($($cacheFiles.Count) files)" -ForegroundColor Green
} else {
    Write-Host "⚠️ Cache directory not found" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "🎉 Health check completed!" -ForegroundColor Green
```

### Webhook Payload Logger

```powershell
# Save as: webhook-payload-logger.ps1

Write-Host "📝 Webhook Payload Logger - Listening for webhooks..." -ForegroundColor Green

# Monitor server logs for webhook payloads
Get-Content server.log -Wait | Where-Object { $_ -match "webhook|Webhook|WEBHOOK" }
```

## Getting Help

### 1. Check Server Logs First
```powershell
# View recent errors
Get-Content server.log | Select-String -Pattern "ERROR|error|Error" | Select-Object -Last 10

# Monitor live logs
Get-Content server.log -Wait
```

### 2. Enable Debug Mode
```javascript
// Add to your webhook handler
const DEBUG = true;
if (DEBUG) {
  console.log('Raw request:', await request.text());
  console.log('Headers:', request.headers);
}
```

### 3. Test Each Component Separately
- Test webhook endpoint: ✅/❌
- Test AI summary generation: ✅/❌  
- Test review scraping: ✅/❌
- Test cache invalidation: ✅/❌

### 4. Contact Support Resources
- **Judge.me**: https://support.judge.me/
- **Yotpo**: https://support.yotpo.com/
- **Shopify**: https://partners.shopify.com/
- **OpenAI**: https://help.openai.com/

### 5. Community Resources
- Shopify Community Forums
- GitHub Issues (if using open source components)
- Stack Overflow (tag: shopify, webhooks, ai)

## Prevention Tips

1. **Monitor Webhook Delivery**
   - Set up alerts for failed webhooks
   - Check webhook logs regularly
   - Implement retry mechanisms

2. **Implement Proper Logging**
   - Log all webhook receipts
   - Log processing steps
   - Log errors with context

3. **Use Health Checks**
   - Implement `/api/health` endpoint
   - Monitor system components
   - Set up automated alerts

4. **Test Regularly**
   - Weekly webhook tests
   - Monitor AI summary quality
   - Verify cache invalidation

Your AI review summary webhook system should now be robust and well-monitored! 🎉
