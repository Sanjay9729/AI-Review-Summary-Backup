// app/routes/api.trigger-refresh.$productHandle.jsx
// Manual trigger for testing real-time AI summary updates
import { json } from "@remix-run/node";
import ReviewCache from "../../services/reviewCache.server";

export async function action({ params }) {
  const { productHandle } = params;
  
  console.log(`🔄 Manual refresh triggered for: ${productHandle}`);
  
  if (!productHandle) {
    return json({ 
      success: false, 
      error: "No product handle provided" 
    }, { status: 400 });
  }

  try {
    // Use the force refresh method from ReviewCache
    const result = await ReviewCache.forceRefresh(productHandle);
    
    if (result.success) {
      console.log(`✅ Manual refresh completed for ${productHandle}: ${result.data.reviews?.length || 0} reviews`);
      
      return json({
        success: true,
        message: `AI summary refreshed for ${productHandle}`,
        productHandle,
        reviewCount: result.data.reviews?.length || 0,
        averageRating: result.data.stats?.average || 0,
        timestamp: new Date().toISOString(),
        trigger: "manual"
      });
    } else {
      return json({
        success: false,
        error: result.error || "Unknown error",
        productHandle,
        timestamp: new Date().toISOString()
      }, { status: 500 });
    }
    
  } catch (error) {
    console.error(`❌ Manual refresh failed for ${productHandle}:`, error.message);
    return json({
      success: false,
      error: error.message,
      productHandle,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function loader({ params }) {
  return json({
    message: "Use POST method to trigger refresh",
    productHandle: params.productHandle,
    usage: `POST /api/trigger-refresh/${params.productHandle}`
  });
}

// Handle preflight OPTIONS requests
export async function options() {
  return new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
