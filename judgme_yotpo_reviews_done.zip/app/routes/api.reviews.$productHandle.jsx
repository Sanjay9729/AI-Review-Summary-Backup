// app/routes/api.reviews.$productHandle.jsx - Original Scraping Version
import { json } from "@remix-run/node";
import ReviewCache from "../../services/reviewCache.server";
import reviewScraper from "../../services/reviewScraper.server";

// In-memory request tracking to prevent concurrent requests
const activeRequests = new Map();

async function scrapeProductReviews(productHandle) {
  console.log(`Starting review scraping for product: ${productHandle}`);

  // Check if request is already in progress
  if (activeRequests.has(productHandle)) {
    console.log(`Request for ${productHandle} already in progress, waiting...`);
    return await activeRequests.get(productHandle);
  }

  // Create promise for this request
  const requestPromise = reviewScraper.scrapeProductReviews(productHandle);

  // Store the promise
  activeRequests.set(productHandle, requestPromise);

  try {
    const result = await requestPromise;
    return result;
  } finally {
    // Clean up the active request
    activeRequests.delete(productHandle);
  }
}

// -------------------------------
// Loader
// -------------------------------
export const loader = async ({ params }) => {
  const { productHandle } = params;
  console.log(`API hit: reviews for ${productHandle}`);

  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (!productHandle) {
    return json({ success: false, error: "No product handle provided" }, { headers });
  }

  try {
    // First check cache
    const cachedData = await ReviewCache.get(productHandle);
    if (cachedData) {
      console.log(`Cache hit for ${productHandle}: ${cachedData.reviews?.length || 0} reviews`);
      return json(cachedData, { headers });
    }

    console.log(`Cache miss for ${productHandle}, scraping...`);
    
    // If not in cache, scrape
    const reviewsData = await scrapeProductReviews(productHandle);
    console.log(
      `Returning fresh data for ${productHandle}: ${reviewsData.reviews?.length || 0} reviews`
    );
    return json(reviewsData, { headers });
  } catch (error) {
    console.error(`API error for ${productHandle}:`, error);

    return json(
      {
        success: false,
        error: error.message,
        productHandle,
        reviews: [],
        stats: { total: 0, average: 0 },
      },
      { status: 500, headers }
    );
  }
};

// -------------------------------
// Options
// -------------------------------
export const options = () =>
  new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
