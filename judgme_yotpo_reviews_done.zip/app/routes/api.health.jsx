// app/routes/api.health.jsx - Database Health Check
import { json } from "@remix-run/node";
import DatabaseService from "../../services/database.server.js";

export const loader = async () => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  try {
    const healthStatus = await DatabaseService.healthCheck();
    
    // Also check if we can query basic table info
    const tableStats = await DatabaseService.getTableStats();
    
    return json({
      ...healthStatus,
      tables: tableStats
    }, { headers });
  } catch (error) {
    return json({
      status: "unhealthy",
      error: error.message,
      database: "disconnected",
      timestamp: new Date().toISOString()
    }, { status: 500, headers });
  }
};

// Add table stats method to DatabaseService
DatabaseService.getTableStats = async function() {
  try {
    const [
      productCount,
      reviewCount,
      aiSummaryCount,
      cacheCount,
      sessionCount
    ] = await Promise.all([
      this.prisma?.product?.count() || 0,
      this.prisma?.review?.count() || 0,
      this.prisma?.aiSummary?.count() || 0,
      this.prisma?.reviewCache?.count() || 0,
      this.prisma?.session?.count() || 0
    ]);

    return {
      products: productCount,
      reviews: reviewCount,
      aiSummaries: aiSummaryCount,
      cachedReviews: cacheCount,
      sessions: sessionCount
    };
  } catch (error) {
    console.error('Error getting table stats:', error);
    return {
      products: 'error',
      reviews: 'error', 
      aiSummaries: 'error',
      cachedReviews: 'error',
      sessions: 'error'
    };
  }
};
