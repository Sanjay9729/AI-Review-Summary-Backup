// app/routes/api.cache.jsx
import { json } from "@remix-run/node";

export const action = async ({ request }) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    const { action, productHandle } = await request.json();

    switch (action) {
      case 'clear':
        if (productHandle) {
          await ReviewCache.clear(productHandle);
          return json({
            success: true,
            message: `Cache cleared for ${productHandle}`
          }, { headers });
        } else {
          await ReviewCache.clearAll();
          return json({
            success: true,
            message: 'All cache cleared'
          }, { headers });
        }

      case 'status':
        // You could implement cache status checking here
        return json({
          success: true,
          message: 'Cache status checked'
        }, { headers });

      default:
        return json({
          success: false,
          error: 'Invalid action'
        }, { status: 400, headers });
    }
  } catch (error) {
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  }
};

export const options = () => {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
};