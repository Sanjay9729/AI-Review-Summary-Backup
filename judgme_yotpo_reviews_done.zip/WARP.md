# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

This is a **Multi-Platform AI Reviews Shopify App** built with **Remix** that scrapes product reviews from both **Judge.me** and **Yotpo** platforms, generates AI summaries using Groq's LLaMA model, and provides a comprehensive dashboard for merchants.

### Key Technologies
- **Frontend**: Remix (React-based full-stack framework)
- **Authentication**: Shopify App Authentication with Prisma sessions  
- **Database**: SQLite (development), supports MySQL for production
- **AI**: Groq API with LLaMA-3.1-8b-instant model
- **Multi-Platform Scraping**: Puppeteer for Judge.me and Yotpo review extraction
- **Styling**: Shopify Polaris design system

## Essential Commands

### Development Setup
```bash
# Install dependencies
npm install

# Setup database (generates Prisma client + runs migrations)
npm run setup

# Start development server (includes tunnel + Shopify CLI)
npm run dev
```

### Building & Deployment
```bash
# Build for production
npm run build

# Deploy to Shopify
npm run deploy

# Start production server
npm run start

# Docker production start
npm run docker-start
```

### Database Management
```bash
# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate deploy

# Access Prisma studio (GUI)
npx prisma studio
```

### Code Quality
```bash
# Lint code
npm run lint

# Run GraphQL codegen
npm run graphql-codegen
```

### Shopify CLI Commands
```bash
# Link app configuration
npm run config:link

# Generate app extensions
npm run generate

# Manage environment variables
npm run env

# Use different app configuration
npm run config:use
```

## Architecture Overview

### Application Structure
```
app/
├── routes/
│   ├── app.jsx                 # Main app shell with Polaris & navigation
│   ├── app._index.jsx          # Products dashboard with multi-platform review scraping
│   ├── api.ai-review-summary.jsx # AI summary generation with platform awareness
│   ├── api.reviews.$productHandle.jsx # Multi-platform review scraping API
│   ├── api.cache.jsx           # Cache management API
│   └── webhooks/               # Shopify webhook handlers
├── shopify.server.js           # Shopify app configuration & authentication
└── db.server.js                # Prisma database client

services/
├── reviewScraper.server.js     # Multi-platform Puppeteer scraping (Judge.me + Yotpo)
└── reviewCache.server.js       # Caching layer for reviews & AI summaries

extensions/
└── ai-reviews-block/           # Shopify theme extension
```

### Key Multi-Platform Features

1. **Unified Review Scraping**: 
   - Automatically detects Judge.me or Yotpo review widgets on product pages
   - Uses platform-specific selectors and fallback strategies
   - Handles password-protected stores automatically
   - Tags each review with its source platform

2. **Platform-Aware AI Generation**:
   - Identifies review sources (Judge.me, Yotpo, or mixed)
   - Includes platform information in AI prompts
   - Generates contextually aware summaries that mention review sources
   - Caches results with platform metadata

3. **Smart Platform Detection**:
   - Runtime detection of review platforms on each product page
   - Fallback strategies for unknown or mixed platforms
   - Platform-specific CSS selectors for optimal extraction
   - Debug information includes detected platforms

### Supported Review Platforms

#### Judge.me
- **Detection**: `.jdgm-widget`, `.jdgm-review-widget`, `#judgeme_product_reviews`
- **Review Elements**: `.jdgm-rev`, `.jdgm-review`, `.jdgm-review-item`
- **Author**: `.jdgm-rev__author`, `.jdgm-author`
- **Rating**: `.jdgm-rev__rating`, `[data-score]`
- **Text**: `.jdgm-rev__body`, `.jdgm-rev__content`
- **Verified**: `.jdgm-rev__verified`, `.jdgm-verified`

#### Yotpo
- **Detection**: `.yotpo-reviews-widget`, `.yotpo-review`, `.yotpo-reviews-container`
- **Review Elements**: `.yotpo-review`, `.yotpo-review-wrapper`, `[data-review-id]`
- **Author**: `.yotpo-user-name`, `.yotpo-review-author`
- **Rating**: `.yotpo-review-stars`, `.yotpo-stars`, `.yotpo-review-rating`
- **Text**: `.yotpo-review-content`, `.content-review`
- **Verified**: `.yotpo-verified-buyer`, `.verified-buyer`

### Data Flow
1. Merchant authenticates via Shopify OAuth
2. App fetches products via Shopify GraphQL Admin API
3. Reviews are scraped from public product pages using multi-platform detection
4. Each review is tagged with its source platform (Judge.me/Yotpo)
5. AI summaries are generated with platform context via Groq API
6. Data is cached locally
7. Dashboard displays products with platform-aware review sections

## Important Environment Variables

Required for development:
```bash
SHOPIFY_API_KEY=                # From Shopify Partner Dashboard
SHOPIFY_API_SECRET=             # From Shopify Partner Dashboard  
SHOPIFY_STORE_URL=              # Target store domain (without https://)
SHOPIFY_STORE_PASSWORD=         # Password for locked stores
GROQ_API_KEY=                   # For AI summary generation
```

## Development Notes

### Multi-Platform Review Scraping
- The app automatically detects which review platform is in use (Judge.me, Yotpo, or both)
- Uses platform-specific CSS selectors with intelligent fallbacks
- Supports mixed platforms on the same product page
- Each scraped review includes platform metadata
- Debug logs show platform detection and scraping strategies used

### AI Summary Features
- Analyzes review platform distribution and mentions it in summaries
- Handles reviews from single or multiple platforms gracefully
- Platform information is included in the AI prompt for context
- Generated summaries can reference specific review sources
- Error handling for mixed or unknown platform scenarios

### Platform-Specific Considerations

#### Judge.me Integration
- Well-established CSS class structure
- Reliable data attributes for ratings and metadata
- Consistent verified buyer indicators
- Standard review pagination patterns

#### Yotpo Integration
- More complex DOM structure with nested elements
- Dynamic loading patterns may require additional wait time
- Multiple CSS class variations across versions
- Platform-specific verified buyer badges

### Testing Multi-Platform Functionality
- Test with stores that use Judge.me exclusively
- Test with stores that use Yotpo exclusively
- Test with stores that may have both platforms (edge case)
- Verify platform badges display correctly in UI
- Check AI summaries mention correct review sources

### Common Issues & Solutions
- **No reviews detected**: Check if correct review platform is installed on store
- **Mixed platform detection**: App handles this automatically, reviews tagged individually
- **Platform badges not showing**: Verify review objects contain `platform` property
- **AI summaries missing platform info**: Check that `reviewPlatform` is passed to AI API
- **Scraping failures**: Check console logs for platform detection and selector strategies

## Production Deployment

For production deployments:
1. Set `NODE_ENV=production`
2. Configure production database URLs in Prisma schema
3. Update Shopify app URLs in `shopify.app.toml`
4. Ensure all environment variables are properly configured
6. Test multi-platform functionality across different store configurations
7. Monitor platform detection accuracy and scraping success rates

## API Endpoints

### Multi-Platform Review API
- **GET/POST** `/api/reviews/${productHandle}`: Scrapes reviews with platform detection
- **Response includes**: `reviewPlatform`, platform-tagged reviews, debug info

### AI Summary API  
- **POST** `/api/ai-review-summary`: Generates platform-aware AI summaries
- **Parameters**: `reviews`, `stats`, `reviewPlatform`, `forceRegenerate`
- **Response includes**: Platform counts, primary platform, AI summary with context

### Cache Management
- **POST** `/api/cache-management`: Force refresh with platform re-detection
- **Actions**: `force-refresh`, `clear`, `status`

## Integration Points

- **Shopify Admin API**: Product data, webhooks, authentication
- **Groq API**: AI summary generation with platform context
- **Judge.me**: Primary review platform scraping (external service)
- **Yotpo**: Secondary review platform scraping (external service)  
- **Shopify Theme Extensions**: Multi-platform storefront integration capability

## Platform Detection Logic

```javascript
// Platform detection happens at runtime
const reviewPlatform = await page.evaluate(() => {
  if (document.querySelector('.jdgm-widget, .jdgm-review-widget, #judgeme_product_reviews')) {
    return 'Judge.me';
  } else if (document.querySelector('.yotpo-reviews-widget, .yotpo-review, .yotpo-reviews-container')) {
    return 'Yotpo';
  } else {
    return 'Unknown';
  }
});
```

This multi-platform approach ensures the app works seamlessly regardless of which review platform the merchant is using, providing consistent AI-powered review summaries across different review services.
