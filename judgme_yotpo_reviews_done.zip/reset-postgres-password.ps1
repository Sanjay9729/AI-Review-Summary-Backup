# PostgreSQL Password Reset Script
# Run this script as Administrator

Write-Host "PostgreSQL Password Reset Script" -ForegroundColor Green
Write-Host "=================================" -ForegroundColor Green

# Check if running as administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "ERROR: This script must be run as Administrator!" -ForegroundColor Red
    Write-Host "Right-click PowerShell and select 'Run as Administrator'" -ForegroundColor Yellow
    exit 1
}

$serviceName = "postgresql-x64-17"
$pgPath = "C:\Program Files\PostgreSQL\17"
$dataPath = "$pgPath\data"
$pgHbaPath = "$dataPath\pg_hba.conf"
$backupPath = "$dataPath\pg_hba.conf.backup"

try {
    Write-Host "Step 1: Stopping PostgreSQL service..." -ForegroundColor Yellow
    Stop-Service -Name $serviceName -Force -ErrorAction Stop
    Write-Host "✓ PostgreSQL service stopped" -ForegroundColor Green
    
    Write-Host "Step 2: Backing up pg_hba.conf..." -ForegroundColor Yellow
    if (Test-Path $pgHbaPath) {
        Copy-Item $pgHbaPath $backupPath -ErrorAction Stop
        Write-Host "✓ Configuration backed up to $backupPath" -ForegroundColor Green
    } else {
        Write-Host "ERROR: Could not find $pgHbaPath" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Step 3: Modifying authentication settings..." -ForegroundColor Yellow
    $content = Get-Content $pgHbaPath
    $newContent = $content -replace "host\s+all\s+all\s+127\.0\.0\.1/32\s+scram-sha-256", "host all all 127.0.0.1/32 trust"
    $newContent = $newContent -replace "host\s+all\s+all\s+::1/128\s+scram-sha-256", "host all all ::1/128 trust"
    $newContent | Set-Content $pgHbaPath -ErrorAction Stop
    Write-Host "✓ Authentication temporarily changed to 'trust'" -ForegroundColor Green
    
    Write-Host "Step 4: Starting PostgreSQL service..." -ForegroundColor Yellow
    Start-Service -Name $serviceName -ErrorAction Stop
    Start-Sleep -Seconds 3
    Write-Host "✓ PostgreSQL service started" -ForegroundColor Green
    
    Write-Host "Step 5: Setting new password..." -ForegroundColor Yellow
    $newPassword = Read-Host -Prompt "Enter new password for postgres user" -AsSecureString
    $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($newPassword))
    
    # Connect and change password
    $env:PGPASSWORD = ""  # Empty password for trust authentication
    & "$pgPath\bin\psql.exe" -U postgres -h localhost -c "ALTER USER postgres PASSWORD '$plainPassword';" -d postgres
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Password changed successfully!" -ForegroundColor Green
    } else {
        Write-Host "ERROR: Failed to change password" -ForegroundColor Red
        throw "Password change failed"
    }
    
    Write-Host "Step 6: Restoring secure authentication..." -ForegroundColor Yellow
    Stop-Service -Name $serviceName -Force -ErrorAction Stop
    Copy-Item $backupPath $pgHbaPath -ErrorAction Stop
    Start-Service -Name $serviceName -ErrorAction Stop
    Write-Host "✓ Secure authentication restored" -ForegroundColor Green
    
    Write-Host "`nSUCCESS! You can now connect to PostgreSQL with:" -ForegroundColor Green
    Write-Host "psql -U postgres -h localhost" -ForegroundColor Cyan
    Write-Host "Use the password you just set." -ForegroundColor Cyan
    
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Attempting to restore original configuration..." -ForegroundColor Yellow
    
    try {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        if (Test-Path $backupPath) {
            Copy-Item $backupPath $pgHbaPath -Force
            Write-Host "✓ Original configuration restored" -ForegroundColor Green
        }
        Start-Service -Name $serviceName -ErrorAction SilentlyContinue
        Write-Host "✓ PostgreSQL service restarted" -ForegroundColor Green
    } catch {
        Write-Host "Failed to restore configuration. Manual intervention may be required." -ForegroundColor Red
    }
}
