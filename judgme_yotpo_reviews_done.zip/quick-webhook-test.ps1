# quick-webhook-test.ps1
# Quick one-command webhook test

param(
    [string]$ServerUrl = "http://localhost:3000"
)

Write-Host "🔔 Quick Webhook Test" -ForegroundColor Green
Write-Host "Server: $ServerUrl" -ForegroundColor Yellow

# Test basic webhook
Write-Host "Testing webhook..." -ForegroundColor Yellow
try {
    $body = @{
        productHandle = "classic-cotton-t-shirt"
        event = "test.webhook"
        timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$ServerUrl/api/webhook/review-updated" -Method POST -ContentType "application/json" -Body $body

    Write-Host "✅ Webhook Test SUCCESS!" -ForegroundColor Green
    Write-Host "Response: $($response | ConvertTo-Json)" -ForegroundColor White
    
    # Quick AI summary check
    Write-Host "`nChecking AI summary..." -ForegroundColor Yellow
    $summary = Invoke-RestMethod -Uri "$ServerUrl/api/reviews/classic-cotton-t-shirt" -Method GET
    Write-Host "✅ AI Summary: $($summary.reviews.Count) reviews, Rating: $($summary.stats.average)" -ForegroundColor Green
    
} catch {
    Write-Host "❌ Test Failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Make sure server is running: npm run dev" -ForegroundColor Yellow
}
