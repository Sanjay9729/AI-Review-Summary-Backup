# 🔔 Webhook Testing Instructions

## 🚀 Quick Start

### Step 1: Start Your Server
```bash
npm run dev
```
**Wait for:** `Server running on http://localhost:3000`

### Step 2: Test Webhooks (Choose One)

#### Option A: Quick Test (Recommended)
```powershell
.\quick-webhook-test.ps1
```

#### Option B: Full Test Suite  
```powershell
.\test-webhooks.ps1
```

#### Option C: Manual Commands
```powershell
# Test basic webhook
Invoke-RestMethod -Uri "http://localhost:3000/api/webhook/review-updated" -Method Post -ContentType "application/json" -Body '{"productHandle": "classic-cotton-t-shirt", "event": "test"}'

# Check AI summary updated
Invoke-RestMethod -Uri "http://localhost:3000/api/reviews/classic-cotton-t-shirt" -Method Get
```

## ✅ What You Should See

### Successful Webhook Response:
```json
{
  "success": true,
  "message": "Cache cleared and AI summary updated for classic-cotton-t-shirt",
  "productHandle": "classic-cotton-t-shirt",
  "timestamp": "2024-01-16T10:30:00.000Z"
}
```

### Server Console Logs:
```
🔔 Review webhook received
📦 Webhook payload: {...}
🎯 Processing review update for product: classic-cotton-t-shirt
🗑️ Cleared cache for classic-cotton-t-shirt
🤖 Pre-generating AI summary for classic-cotton-t-shirt...
✅ Pre-generated summary for classic-cotton-t-shirt: X reviews
```

## ❌ Troubleshooting

### "Connection Refused" Error
- Server not running → Run `npm run dev`
- Wrong port → Check server is on port 3000

### "Webhook Failed" Error  
- Check server logs for detailed errors
- Verify JSON format in webhook payload
- Ensure all dependencies installed

### "AI Summary Not Updated"
- Check GROQ_API_KEY in .env file
- Verify reviews data is available
- Look for scraper errors in logs

## 🎯 Test Results Interpretation

### ✅ All Tests Pass = Ready for Production
- Webhook endpoint working
- Cache clearing functional  
- AI summary regeneration working
- System performance acceptable

### ⚠️ Some Tests Fail = Needs Investigation
- Check specific error messages
- Review server logs
- Verify environment setup

## 🚀 Next Steps After Success

1. **Production Deployment**
   - Deploy your app to live server
   - Update webhook URLs to production domain

2. **Configure Real Webhooks**
   - Judge.me: Settings > Integrations > Webhooks
   - Yotpo: Settings > General Settings > Webhooks
   - Use URL: `https://yourdomain.com/api/webhook/review-updated`

3. **Set Up Scheduled Backup**
   - Configure Windows Task Scheduler  
   - Run `scripts/refresh-summaries.bat` hourly/daily

4. **Monitor & Optimize**
   - Watch server logs for webhook activity
   - Monitor AI summary generation performance
   - Adjust cache timing as needed

## 🔧 Quick Commands Reference

```powershell
# Start server
npm run dev

# Quick webhook test
.\quick-webhook-test.ps1

# Full webhook test suite
.\test-webhooks.ps1

# Manual refresh trigger
Invoke-RestMethod -Uri "http://localhost:3000/api/trigger-refresh/classic-cotton-t-shirt" -Method Post

# Check reviews API
Invoke-RestMethod -Uri "http://localhost:3000/api/reviews/classic-cotton-t-shirt" -Method Get
```

**Your webhook system is ready to test!** 🎉
