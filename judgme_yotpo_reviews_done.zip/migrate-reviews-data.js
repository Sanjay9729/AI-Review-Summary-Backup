import { PrismaClient } from '@prisma/client';
import pkg from 'pg';
const { Pool } = pkg;

const prisma = new PrismaClient();

// Connection to the old reviews table in reviews_db
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'reviews_db',
  password: 'AiReviews@123',
  port: 5432,
});

// Note: Prisma will connect to shopify_app_dev via .env

async function migrateReviewData() {
  try {
    console.log('🔄 Starting review data migration...');
    
    // Get all reviews from the old table
    const oldReviews = await pool.query('SELECT * FROM public.reviews ORDER BY created_at');
    console.log(`📊 Found ${oldReviews.rows.length} reviews to migrate`);
    
    // Group reviews by product to create Product entries
    const productMap = new Map();
    
    for (const review of oldReviews.rows) {
      if (!productMap.has(review.product_id)) {
        productMap.set(review.product_id, {
          shopifyId: review.product_id,
          handle: review.product_name ? review.product_name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') : review.product_id,
          title: review.product_name || 'Unknown Product',
          shop: 'sanjayvaghela-testing.myshopify.com'
        });
      }
    }
    
    console.log(`🏪 Creating ${productMap.size} products...`);
    
    // Create products
    const createdProducts = new Map();
    for (const [productId, productData] of productMap) {
      try {
        const product = await prisma.product.create({
          data: productData
        });
        createdProducts.set(productId, product.id);
        console.log(`✅ Created product: ${productData.title}`);
      } catch (error) {
        console.log(`⚠️ Product ${productData.title} might already exist, trying to find it...`);
        const existingProduct = await prisma.product.findUnique({
          where: { shopifyId: productId }
        });
        if (existingProduct) {
          createdProducts.set(productId, existingProduct.id);
        } else {
          console.error(`❌ Error with product ${productData.title}:`, error.message);
        }
      }
    }
    
    console.log(`📝 Migrating ${oldReviews.rows.length} reviews...`);
    
    // Create reviews
    let successCount = 0;
    for (const oldReview of oldReviews.rows) {
      const prismaProductId = createdProducts.get(oldReview.product_id);
      if (!prismaProductId) {
        console.log(`⚠️ Skipping review ${oldReview.id} - no matching product`);
        continue;
      }
      
      try {
        await prisma.review.create({
          data: {
            productId: prismaProductId,
            author: oldReview.customer_name || 'Anonymous',
            rating: parseFloat(oldReview.rating),
            title: oldReview.title,
            text: oldReview.review_text,
            verified: oldReview.is_verified || false,
            platform: oldReview.source,
            reviewDate: oldReview.review_date ? new Date(oldReview.review_date) : new Date(oldReview.created_at),
            scrapedAt: new Date(oldReview.created_at)
          }
        });
        successCount++;
        if (successCount % 5 === 0) {
          console.log(`✅ Migrated ${successCount}/${oldReviews.rows.length} reviews...`);
        }
      } catch (error) {
        console.error(`❌ Error migrating review ${oldReview.id}:`, error.message);
      }
    }
    
    console.log(`🎉 Migration completed! Successfully migrated ${successCount} reviews.`);
    
    // Show summary
    const reviewCount = await prisma.review.count();
    const productCount = await prisma.product.count();
    console.log(`📊 Final counts: ${productCount} products, ${reviewCount} reviews`);
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await prisma.$disconnect();
    await pool.end();
  }
}

migrateReviewData();
