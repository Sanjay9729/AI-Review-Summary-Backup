# Load environment variables from .env file and run webhook test
Write-Host "🔧 Loading environment variables from .env file..." -ForegroundColor Green

# Function to load .env file
function Load-EnvFile {
    param([string]$Path)
    
    if (Test-Path $Path) {
        Get-Content $Path | ForEach-Object {
            if ($_ -match '^([^#][^=]+)=(.*)$') {
                $key = $matches[1].Trim()
                $value = $matches[2].Trim()
                
                # Remove quotes if present
                if ($value.StartsWith('"') -and $value.EndsWith('"')) {
                    $value = $value.Substring(1, $value.Length - 2)
                }
                
                # Set environment variable for current session
                [Environment]::SetEnvironmentVariable($key, $value, "Process")
                Write-Host "✅ Loaded $key" -ForegroundColor Green
            }
        }
    } else {
        Write-Host "❌ .env file not found at $Path" -ForegroundColor Red
        exit 1
    }
}

# Load .env file
Load-EnvFile -Path ".\.env"

Write-Host ""
Write-Host "🚀 Running webhook verification test with loaded environment..." -ForegroundColor Green
Write-Host ""

# Now run the webhook verification test
& ".\webhook-verification-test.ps1"
