-- View all products and their review counts
SELECT 
    p.handle,
    p.title,
    COUNT(r.id) as review_count,
    CAST(AVG(r.rating) AS DECIMAL(3,1)) as avg_rating
FROM "Product" p 
LEFT JOIN "Review" r ON p.id = r."productId" 
GROUP BY p.id, p.handle, p.title 
ORDER BY review_count DESC;

-- View sample reviews
SELECT 
    r.author,
    r.rating,
    SUBSTRING(r.text FROM 1 FOR 60) as review_snippet,
    p.handle as product
FROM "Review" r 
JOIN "Product" p ON r."productId" = p.id 
LIMIT 5;

-- Get total stats
SELECT 
    (SELECT COUNT(*) FROM "Product") as total_products,
    (SELECT COUNT(*) FROM "Review") as total_reviews,
    (SELECT CAST(AVG(rating) AS DECIMAL(3,1)) FROM "Review") as overall_avg_rating;
