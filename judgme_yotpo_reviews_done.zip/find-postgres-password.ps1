# Script to find the correct PostgreSQL password
Write-Host "Testing PostgreSQL connection with different passwords..." -ForegroundColor Yellow

$commonPasswords = @(
    "admin123",
    "postgres", 
    "newpassword123",
    "password123",
    "demo123",
    "shopify123",
    "dev123",
    "test123",
    "",
    "password",
    "admin",
    "root"
)

$found = $false

foreach ($pwd in $commonPasswords) {
    Write-Host "Testing password: '$pwd'" -ForegroundColor Cyan
    
    $env:PGPASSWORD = $pwd
    
    # Try to connect to postgres database
    $output = psql -U postgres -d postgres -c "SELECT 'SUCCESS' as result;" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ SUCCESS! PostgreSQL password is: '$pwd'" -ForegroundColor Green
        Write-Host "Update your .env file with this password:" -ForegroundColor Yellow
        Write-Host "DATABASE_URL=`"postgresql://postgres:$pwd@localhost:5432/shopify_app_dev?schema=public`"" -ForegroundColor White
        $found = $true
        break
    } else {
        Write-Host "❌ Failed with password: '$pwd'" -ForegroundColor Red
    }
}

if (-not $found) {
    Write-Host "" -ForegroundColor Red
    Write-Host "None of the common passwords worked." -ForegroundColor Red
    Write-Host "You may need to reset the PostgreSQL password as Administrator." -ForegroundColor Yellow
    Write-Host "" 
    Write-Host "To reset as Administrator:" -ForegroundColor Cyan
    Write-Host "1. Right-click PowerShell and 'Run as Administrator'" -ForegroundColor White
    Write-Host "2. Run: .\reset-postgres-password.ps1" -ForegroundColor White
}
