# Webhook Verification & Testing Guide

## Overview
This guide provides comprehensive steps to verify your Judge.me or Yotpo webhooks are working correctly with your AI review summary system.

## Quick Verification Checklist

### ✅ Pre-Setup Verification
- [ ] Server is running (`npm run dev`)
- [ ] Cloudflare tunnel is active (if using)
- [ ] Environment variables are configured
- [ ] Webhook endpoint URL is accessible

### ✅ Post-Setup Verification  
- [ ] Webhook is configured in Judge.me/Yotpo dashboard
- [ ] Test webhook delivery is successful
- [ ] Real review submission triggers webhook
- [ ] AI summary is regenerated after webhook
- [ ] Server logs show webhook processing

## Detailed Verification Steps

### Step 1: Verify Server Status

```powershell
# Check if your server is running
netstat -an | findstr :9293
# Should show: TCP    127.0.0.1:9293    0.0.0.0:0    LISTENING

# Test basic server connectivity
curl -I http://127.0.0.1:9293
# Should return: HTTP/1.1 200 OK
```

### Step 2: Test Webhook Endpoint Manually

Create a test webhook payload and send it to your endpoint:

```powershell
# Test Judge.me webhook format
curl -X POST http://127.0.0.1:9293/api/webhook/review-updated `
  -H "Content-Type: application/json" `
  -H "X-Shopify-Shop-Domain: your-store.myshopify.com" `
  -d '{
    "event": "review.created",
    "shop_domain": "your-store.myshopify.com",
    "data": {
      "product_external_id": "test-product-handle",
      "title": "Test Review",
      "body": "This is a test review for webhook verification",
      "rating": 5,
      "reviewer": {
        "name": "Test User",
        "email": "test@example.com"
      }
    }
  }'
```

```powershell
# Test Yotpo webhook format  
curl -X POST http://127.0.0.1:9293/api/webhook/review-updated `
  -H "Content-Type: application/json" `
  -H "X-Shopify-Shop-Domain: your-store.myshopify.com" `
  -d '{
    "webhook": {
      "event_type": "review_create"
    },
    "review": {
      "product_external_id": "test-product-handle",
      "content": "This is a test review for Yotpo webhook verification",
      "title": "Great Product",
      "score": 5,
      "user": {
        "display_name": "Test User",
        "email": "test@example.com"
      }
    }
  }'
```

### Step 3: Monitor Server Logs

Watch your server logs while testing:

```bash
# Start server with verbose logging
npm run dev

# In another terminal, monitor logs
tail -f your-log-file.log
```

**Look for these log messages:**
```
✅ Webhook received from Judge.me/Yotpo
✅ Product handle extracted: test-product-handle  
✅ Cache invalidated for product: test-product-handle
✅ AI summary regeneration triggered
✅ Webhook processed successfully
```

### Step 4: Verify Cache Invalidation

Check if cache is properly cleared:

```powershell
# Check cache directory before webhook
ls cache/

# Send test webhook (from Step 2)

# Check cache directory after webhook - should be cleared
ls cache/
```

### Step 5: Test with Real Review Submission

1. **Go to your product page**
   ```
   https://your-store.myshopify.com/products/test-product-handle
   ```

2. **Submit a real review using the review widget**

3. **Monitor server logs** for webhook delivery

4. **Verify AI summary updates** by refreshing the product page

### Step 6: Verify AI Summary Regeneration

Test the complete flow:

```powershell
# 1. Check current AI summary
curl "http://127.0.0.1:9293/api/ai-review-summary?productHandle=test-product-handle"

# 2. Send webhook to trigger regeneration
curl -X POST http://127.0.0.1:9293/api/webhook/review-updated `
  -H "Content-Type: application/json" `
  -d '{"data":{"product_external_id":"test-product-handle"}}'

# 3. Check AI summary again (should be updated)
curl "http://127.0.0.1:9293/api/ai-review-summary?productHandle=test-product-handle"
```

## Automated Testing Scripts

### Create PowerShell Test Script

```powershell
# Save as: webhook-verification-test.ps1

Write-Host "🔧 AI Review Summary Webhook Verification Test" -ForegroundColor Green
Write-Host "=" * 50

$ServerUrl = "http://127.0.0.1:9293"
$WebhookEndpoint = "$ServerUrl/api/webhook/review-updated"
$TestProductHandle = "test-product-handle"

Write-Host "1. Testing server connectivity..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri $ServerUrl -Method HEAD -TimeoutSec 10
    Write-Host "✅ Server is responding (Status: $($response.StatusCode))" -ForegroundColor Green
} catch {
    Write-Host "❌ Server connection failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "2. Testing webhook endpoint..." -ForegroundColor Yellow
$webhookPayload = @{
    event = "review.created"
    data = @{
        product_external_id = $TestProductHandle
        title = "Test Review"
        body = "Automated test review"
        rating = 5
        reviewer = @{
            name = "Test User"
            email = "test@example.com"
        }
    }
} | ConvertTo-Json -Depth 3

try {
    $webhookResponse = Invoke-RestMethod -Uri $WebhookEndpoint -Method POST -Body $webhookPayload -ContentType "application/json" -TimeoutSec 30
    Write-Host "✅ Webhook endpoint responded successfully" -ForegroundColor Green
    Write-Host "Response: $($webhookResponse | ConvertTo-Json)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Webhook test failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "3. Checking AI summary endpoint..." -ForegroundColor Yellow
try {
    $summaryUrl = "$ServerUrl/api/ai-review-summary?productHandle=$TestProductHandle"
    $summaryResponse = Invoke-RestMethod -Uri $summaryUrl -Method GET -TimeoutSec 30
    Write-Host "✅ AI summary endpoint is working" -ForegroundColor Green
    Write-Host "Summary: $($summaryResponse.summary)" -ForegroundColor Cyan
} catch {
    Write-Host "⚠️ AI summary endpoint test: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host "" 
Write-Host "🎉 Webhook verification test completed!" -ForegroundColor Green
Write-Host "Check your server logs for detailed webhook processing information." -ForegroundColor Cyan
```

### Run the Test

```powershell
# Make executable and run
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\webhook-verification-test.ps1
```

## Expected Results

### Successful Webhook Processing

**Server Logs Should Show:**
```
📨 Webhook received: POST /api/webhook/review-updated
🔍 Processing webhook payload...
✅ Product handle extracted: test-product-handle
🗑️ Cache invalidated for product: test-product-handle  
🤖 AI summary regeneration queued
✅ Webhook processed successfully
```

**Client Response Should Be:**
```json
{
  "success": true,
  "message": "Webhook processed successfully",
  "product_handle": "test-product-handle",
  "timestamp": "2025-01-16T06:29:45.000Z"
}
```

### Successful AI Summary Update

**Before webhook:**
```json
{
  "summary": "Previous AI summary...",
  "generated_at": "2025-01-15T10:00:00.000Z",
  "review_count": 10
}
```

**After webhook:**
```json  
{
  "summary": "Updated AI summary with new review...",
  "generated_at": "2025-01-16T06:30:00.000Z",
  "review_count": 11
}
```

## Common Issues & Solutions

### 1. Webhook Endpoint Returns 404

**Symptoms:**
```
❌ Webhook test failed: 404 Not Found
```

**Solutions:**
- Verify server is running on correct port
- Check webhook endpoint URL spelling
- Ensure Shopify authentication context

### 2. Cache Not Clearing

**Symptoms:**  
- Webhook processes successfully
- AI summary doesn't update
- Old cached data still present

**Solutions:**
```powershell
# Manually clear cache
Remove-Item -Path "cache\*" -Recurse -Force

# Restart server
npm run dev
```

### 3. AI Summary Not Regenerating

**Symptoms:**
- Webhook processes successfully  
- Cache clears properly
- AI summary endpoint still returns old data

**Solutions:**
- Check OpenAI API key configuration
- Verify review scraping is working
- Check server logs for AI generation errors

### 4. Server Connection Refused

**Symptoms:**
```
❌ Server connection failed: Connection refused
```

**Solutions:**
```powershell
# Check if server process is running
Get-Process | Where-Object {$_.ProcessName -like "*node*"}

# Start server
npm run dev

# Check port availability
netstat -an | findstr :9293
```

## Integration Testing with Real Services

### Judge.me Integration Test

1. **Configure webhook in Judge.me dashboard**
2. **Submit real review on product page**
3. **Check Judge.me webhook logs**
4. **Verify webhook delivery in your server logs**
5. **Confirm AI summary updates**

### Yotpo Integration Test

1. **Configure webhook in Yotpo dashboard**
2. **Submit real review on product page**
3. **Check Yotpo webhook delivery logs**
4. **Verify webhook processing in your server logs**
5. **Confirm AI summary regeneration**

## Monitoring & Alerting Setup

### Log Monitoring
```powershell
# Monitor webhook deliveries
Select-String -Path "server.log" -Pattern "Webhook received"

# Monitor errors  
Select-String -Path "server.log" -Pattern "ERROR"

# Monitor AI summary generation
Select-String -Path "server.log" -Pattern "AI summary generated"
```

### Health Check Endpoint
Create a health check to monitor webhook system:

```powershell
# Test health endpoint
curl http://127.0.0.1:9293/api/health
```

Expected response:
```json
{
  "status": "healthy",
  "webhook_endpoint": "active",
  "ai_service": "connected",
  "cache_system": "operational"
}
```

## Next Steps After Verification

1. **✅ Basic webhook processing works**
   - Configure production webhooks
   - Set up monitoring
   - Implement error handling

2. **✅ AI summaries update correctly**
   - Monitor summary quality
   - Adjust AI prompts if needed
   - Set up performance monitoring

3. **✅ Real review integration works**
   - Test with multiple products
   - Monitor webhook delivery reliability
   - Set up backup/retry mechanisms

Your webhook integration is now fully verified and ready for production use! 🎉
