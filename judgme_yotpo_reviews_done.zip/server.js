import express from 'express';
import { Pool } from 'pg';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 5050;

// PostgreSQL connection configuration
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'reviews_db',
  password: process.env.POSTGRES_PASSWORD || 'AiReviews@123', // Set your password here or via environment variable
  port: 5432,
});

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Test database connection
async function testConnection() {
  try {
    const client = await pool.connect();
    console.log('✅ Connected to PostgreSQL database');
    client.release();
  } catch (err) {
    console.error('❌ Database connection error:', err.message);
    console.log('Make sure PostgreSQL is running and the reviews_db database exists');
  }
}

// Routes

// Home page - serve the main dashboard
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API endpoint to get all reviews
app.get('/api/reviews', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        id, source, product_name, customer_name, rating, title, 
        review_text, is_verified, review_date, created_at,
        CASE 
          WHEN LENGTH(review_text) > 150 THEN SUBSTRING(review_text, 1, 150) || '...'
          ELSE review_text 
        END as short_text
      FROM reviews 
      ORDER BY created_at DESC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching reviews:', err);
    res.status(500).json({ error: 'Failed to fetch reviews' });
  }
});

// API endpoint to get reviews by source
app.get('/api/reviews/source/:source', async (req, res) => {
  try {
    const { source } = req.params;
    const result = await pool.query(
      'SELECT * FROM reviews WHERE source = $1 ORDER BY created_at DESC',
      [source]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching reviews by source:', err);
    res.status(500).json({ error: 'Failed to fetch reviews' });
  }
});

// API endpoint to get reviews summary
app.get('/api/reviews/summary', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM reviews_summary');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching summary:', err);
    res.status(500).json({ error: 'Failed to fetch summary' });
  }
});

// API endpoint to get product reviews
app.get('/api/products/:productId/reviews', async (req, res) => {
  try {
    const { productId } = req.params;
    const result = await pool.query(
      'SELECT * FROM reviews WHERE product_id = $1 ORDER BY review_date DESC',
      [productId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching product reviews:', err);
    res.status(500).json({ error: 'Failed to fetch product reviews' });
  }
});

// API endpoint to get statistics
app.get('/api/stats', async (req, res) => {
  try {
    const queries = await Promise.all([
      pool.query('SELECT COUNT(*) as total_reviews FROM reviews'),
      pool.query('SELECT COUNT(DISTINCT product_id) as total_products FROM reviews'),
      pool.query('SELECT ROUND(AVG(rating), 2) as avg_rating FROM reviews'),
      pool.query('SELECT source, COUNT(*) as count FROM reviews GROUP BY source'),
      pool.query('SELECT COUNT(*) as verified_count FROM reviews WHERE is_verified = true')
    ]);

    const stats = {
      total_reviews: parseInt(queries[0].rows[0].total_reviews),
      total_products: parseInt(queries[1].rows[0].total_products),
      average_rating: parseFloat(queries[2].rows[0].avg_rating),
      by_source: queries[3].rows,
      verified_reviews: parseInt(queries[4].rows[0].verified_count)
    };

    res.json(stats);
  } catch (err) {
    console.error('Error fetching stats:', err);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// API endpoint to add a new review
app.post('/api/reviews', async (req, res) => {
  try {
    const {
      source, source_review_id, product_id, product_name,
      customer_name, customer_email, rating, title, review_text,
      is_verified, metadata
    } = req.body;

    const result = await pool.query(`
      INSERT INTO reviews (
        source, source_review_id, product_id, product_name,
        customer_name, customer_email, rating, title, review_text,
        is_verified, review_date, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), $11)
      RETURNING id
    `, [
      source, source_review_id, product_id, product_name,
      customer_name, customer_email, rating, title, review_text,
      is_verified, JSON.stringify(metadata || {})
    ]);

    res.status(201).json({ 
      success: true, 
      review_id: result.rows[0].id,
      message: 'Review added successfully'
    });
  } catch (err) {
    console.error('Error adding review:', err);
    res.status(500).json({ error: 'Failed to add review' });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(port, () => {
  console.log(`\n🚀 Reviews Database Server Started!`);
  console.log(`📊 Dashboard: http://localhost:${port}`);
  console.log(`🔗 API Base: http://localhost:${port}/api`);
  console.log(`\n📋 Available API Endpoints:`);
  console.log(`   GET  /api/reviews - All reviews`);
  console.log(`   GET  /api/reviews/summary - Reviews summary`);
  console.log(`   GET  /api/reviews/source/:source - Reviews by source`);
  console.log(`   GET  /api/products/:productId/reviews - Product reviews`);
  console.log(`   GET  /api/stats - Database statistics`);
  console.log(`   POST /api/reviews - Add new review`);
  console.log(`\n⚡ Press Ctrl+C to stop the server\n`);
  
  // Test database connection on startup
  testConnection();
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Shutting down server...');
  pool.end().then(() => {
    console.log('Database connections closed.');
    process.exit(0);
  });
});

export default app;

