# Reviews Database Server Setup Script
Write-Host "🗄️ Reviews Database Server Setup" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

# Get PostgreSQL password from user
$password = Read-Host -Prompt "Enter your PostgreSQL password" -AsSecureString
$plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($password))

Write-Host "`n📋 Step 1: Creating database and tables..." -ForegroundColor Yellow

# Create database
try {
    $env:PGPASSWORD = $plainPassword
    & psql -U postgres -h localhost -c "CREATE DATABASE reviews_db;" 2>$null
    Write-Host "✅ Database 'reviews_db' created (or already exists)" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Database might already exist, continuing..." -ForegroundColor Yellow
}

# Run the database setup script
Write-Host "`n📋 Step 2: Setting up tables and inserting data..." -ForegroundColor Yellow
try {
    & psql -U postgres -h localhost -d reviews_db -f "create_database.sql"
    Write-Host "✅ Tables created and sample data inserted" -ForegroundColor Green
} catch {
    Write-Host "❌ Error setting up database: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Update server.js with the password
Write-Host "`n📋 Step 3: Configuring server..." -ForegroundColor Yellow
$serverContent = Get-Content "server.js" -Raw
$updatedContent = $serverContent -replace "password: process\.env\.POSTGRES_PASSWORD \|\| 'your_password_here'", "password: process.env.POSTGRES_PASSWORD || '$plainPassword'"
$updatedContent | Set-Content "server.js"
Write-Host "✅ Server configured with your password" -ForegroundColor Green

# Install Node.js dependencies if needed
Write-Host "`n📋 Step 4: Installing Node.js dependencies..." -ForegroundColor Yellow
if (!(Test-Path "node_modules\express")) {
    npm install express pg
    Write-Host "✅ Dependencies installed" -ForegroundColor Green
} else {
    Write-Host "✅ Dependencies already installed" -ForegroundColor Green
}

Write-Host "`n🚀 Setup Complete!" -ForegroundColor Green
Write-Host "To start your server, run:" -ForegroundColor White
Write-Host "  node server.js" -ForegroundColor Cyan
Write-Host "`nThen visit: http://localhost:5050" -ForegroundColor White

# Ask if user wants to start the server now
$startNow = Read-Host "`nWould you like to start the server now? (y/n)"
if ($startNow -eq 'y' -or $startNow -eq 'Y') {
    Write-Host "`n🚀 Starting server..." -ForegroundColor Green
    node server.js
}
