const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

async function migrate() {
  try {
    console.log('🚀 Starting migration from file cache to PostgreSQL...\n');
    
    const files = fs.readdirSync('cache').filter(f => f.startsWith('reviews_') && f.endsWith('.json'));
    console.log(`Found ${files.length} review files to migrate:\n`);
    
    let totalMigrated = 0;
    
    for (const file of files) {
      const handle = file.replace('reviews_', '').replace('.json', '');
      console.log(`📦 Processing: ${handle}...`);
      
      try {
        const data = JSON.parse(fs.readFileSync(path.join('cache', file), 'utf8'));
        
        if (!data.reviews || data.reviews.length === 0) {
          console.log(`   ⚠️  No reviews found, skipping.`);
          continue;
        }
        
        // Create product
        const product = await prisma.product.create({
          data: {
            shopifyId: `migrated_${handle}_${Date.now()}`,
            handle: handle,
            title: `Product ${handle}`,
            shop: 'demo-store'
          }
        });
        
        console.log(`   ✅ Created product: ${product.handle}`);
        
        // Create reviews
        const reviewsData = data.reviews.map(review => ({
          productId: product.id,
          author: review.author || 'Anonymous',
          rating: parseFloat(review.rating) || 0,
          title: review.title || null,
          text: review.text || '',
          verified: review.verified || false,
          platform: review.platform || review.extractedFrom || 'Unknown',
          reviewDate: review.date ? new Date(review.date) : null,
          scrapedAt: new Date()
        }));
        
        const result = await prisma.review.createMany({
          data: reviewsData
        });
        
        console.log(`   ✅ Migrated ${result.count} reviews`);
        totalMigrated += result.count;
        
      } catch (error) {
        console.error(`   ❌ Error processing ${handle}:`, error.message);
      }
    }
    
    console.log(`\n🎉 Migration completed!`);
    console.log(`📊 Total reviews migrated: ${totalMigrated}`);
    
    // Show final stats
    const [productCount, reviewCount] = await Promise.all([
      prisma.product.count(),
      prisma.review.count()
    ]);
    
    console.log(`\n📈 PostgreSQL Database Stats:`);
    console.log(`   Products: ${productCount}`);
    console.log(`   Reviews: ${reviewCount}`);
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await prisma.$disconnect();
  }
}

migrate();
