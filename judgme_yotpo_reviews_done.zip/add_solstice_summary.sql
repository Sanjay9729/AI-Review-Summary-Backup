-- Add AI summary for The Solstice Shirt
INSERT INTO "AiSummary" (
    id, 
    "productId", 
    summary, 
    model, 
    "reviewsAnalyzed", 
    "totalReviews", 
    "averageRating", 
    "reviewPlatform",
    "updatedAt"
) VALUES (
    'ai_cmfkz1dh6000072gcg64mojh7',
    'cmfkz1dh6000072gcg64mojh7',
    'Based on customer feedback, The Solstice Shirt is highly praised for its perfect balance of comfort and sophistication. Customers love the crisp, stylish design and breathable fabric that makes it versatile for both casual and semi-formal occasions. The tailored fit and timeless design make it a wardrobe essential that adds elegance to any outfit. With excellent ratings, this white shirt is consistently recommended for its quality and style.',
    'gpt-3.5-turbo',
    1,
    1,
    5.0,
    'Judge.me',
    CURRENT_TIMESTAMP
);
