# Simple PostgreSQL password reset script
Write-Host "PostgreSQL Password Reset" -ForegroundColor Green
Write-Host "=========================" -ForegroundColor Green
Write-Host ""

# Check if running as Administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "ERROR: This script must be run as Administrator!" -ForegroundColor Red
    Write-Host "Right-click PowerShell and select 'Run as Administrator'" -ForegroundColor Yellow
    exit 1
}

Write-Host "Running as Administrator ✓" -ForegroundColor Green

# Stop PostgreSQL service
Write-Host "Stopping PostgreSQL service..." -ForegroundColor Yellow
Stop-Service -Name "postgresql-x64-17" -Force -ErrorAction SilentlyContinue

# Find PostgreSQL installation path
$pgPaths = @(
    "C:\Program Files\PostgreSQL\17",
    "C:\PostgreSQL\17",
    "C:\Program Files (x86)\PostgreSQL\17"
)

$pgPath = $null
foreach ($path in $pgPaths) {
    if (Test-Path "$path\bin\psql.exe") {
        $pgPath = $path
        break
    }
}

if (-not $pgPath) {
    Write-Host "PostgreSQL installation not found!" -ForegroundColor Red
    exit 1
}

$dataDir = "$pgPath\data"
Write-Host "PostgreSQL path: $pgPath" -ForegroundColor Green
Write-Host "Data directory: $dataDir" -ForegroundColor Green

# Backup and modify pg_hba.conf
$hbaFile = "$dataDir\pg_hba.conf"
$hbaBackup = "$dataDir\pg_hba.conf.backup"

if (Test-Path $hbaFile) {
    Copy-Item $hbaFile $hbaBackup -Force
    Write-Host "Backed up pg_hba.conf" -ForegroundColor Green
    
    # Create temporary pg_hba.conf with trust authentication
    $trustConfig = @"
# Temporary configuration for password reset
local   all             postgres                                trust
host    all             postgres        127.0.0.1/32            trust
host    all             postgres        ::1/128                 trust
local   all             all                                     trust
host    all             all             127.0.0.1/32            trust
host    all             all             ::1/128                 trust
"@
    
    $trustConfig | Out-File -FilePath $hbaFile -Encoding UTF8
    Write-Host "Modified pg_hba.conf for trust authentication" -ForegroundColor Green
}

# Start PostgreSQL service
Write-Host "Starting PostgreSQL service..." -ForegroundColor Yellow
Start-Service -Name "postgresql-x64-17"
Start-Sleep -Seconds 10

# Reset password using psql
Write-Host "Resetting postgres password to 'admin123'..." -ForegroundColor Yellow
& "$pgPath\bin\psql.exe" -U postgres -c "ALTER USER postgres PASSWORD 'admin123';"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Password reset successful!" -ForegroundColor Green
} else {
    Write-Host "Password reset failed!" -ForegroundColor Red
    # Restore backup and exit
    if (Test-Path $hbaBackup) {
        Copy-Item $hbaBackup $hbaFile -Force
        Remove-Item $hbaBackup
    }
    Restart-Service -Name "postgresql-x64-17"
    exit 1
}

# Restore original pg_hba.conf
if (Test-Path $hbaBackup) {
    Copy-Item $hbaBackup $hbaFile -Force
    Remove-Item $hbaBackup
    Write-Host "Restored original pg_hba.conf" -ForegroundColor Green
}

# Restart PostgreSQL service
Write-Host "Restarting PostgreSQL service..." -ForegroundColor Yellow
Restart-Service -Name "postgresql-x64-17"
Start-Sleep -Seconds 10

Write-Host ""
Write-Host "Password reset complete!" -ForegroundColor Green
Write-Host "New password: admin123" -ForegroundColor Yellow
Write-Host ""
Write-Host "Now update your .env file with:" -ForegroundColor Cyan
Write-Host 'DATABASE_URL="postgresql://postgres:admin123@localhost:5432/shopify_app_dev?schema=public"' -ForegroundColor White
