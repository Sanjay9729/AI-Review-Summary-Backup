// app/routes/api.ai-review-summary.jsx - Fixed Version
import { json } from "@remix-run/node";
import ReviewCache from "../../services/reviewCache.server";

async function generateReviewSummary(reviews, stats, productHandle, forceRegenerate = false) {
  
  console.log(`🤖 Starting AI summary generation for ${productHandle}`);
  console.log(`📊 Review stats: ${stats.total} reviews, ${stats.average} average rating`);

  // CRITICAL VALIDATION: Never generate AI content without real reviews
  if (!reviews || reviews.length === 0) {
    console.log(`❌ No reviews found for ${productHandle} - cannot generate AI summary`);
    return {
      success: false,
      error: "No reviews available for AI analysis",
      summary: null
    };
  }

  if (!process.env.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY not configured');
  }

  try {
    // Check for cached AI summary first (unless forcing regeneration)
    if (!forceRegenerate) {
      const cachedSummary = await ReviewCache.getAISummary(productHandle);
      if (cachedSummary) {
        console.log(`📋 AI summary cache hit for ${productHandle}`);
        return {
          success: true,
          ...cachedSummary,
          fromCache: true
        };
      }
    }

    console.log(`💨 AI summary cache miss for ${productHandle}, generating...`);

    // Prepare review data for AI - get top reviews with text
    const reviewTexts = reviews
      .filter(review => review.text && review.text.trim().length > 0)
      .slice(0, 8)
      .map(review => ({
        rating: review.rating,
        text: review.text.trim().substring(0, 200),
        title: review.title || '',
        verified: review.verified,
        author: review.author
      }));

    console.log(`📝 Processing ${reviewTexts.length} reviews with text content`);

    // STRICT CHECK: Must have meaningful review content
    if (reviewTexts.length === 0) {
      console.log(`❌ No meaningful review content found for ${productHandle}`);
      return {
        success: false,
        error: "No detailed reviews available for AI analysis",
        summary: null
      };
    }

    // Additional validation: Check if reviews have actual content
    const meaningfulReviews = reviewTexts.filter(review => 
      review.text.length > 10 && 
      review.rating > 0 &&
      !review.text.toLowerCase().includes('no review') &&
      !review.text.toLowerCase().includes('no comment')
    );

    if (meaningfulReviews.length === 0) {
      console.log(`❌ No meaningful review content after filtering for ${productHandle}`);
      return {
        success: false,
        error: "No substantial reviews available for AI analysis",
        summary: null
      };
    }

    const prompt = `
Analyze these customer reviews for "${productHandle.replace(/-/g, ' ')}" and create a helpful summary:

Product Statistics:
- Total Reviews: ${stats.total}
- Average Rating: ${stats.average}/5 stars
- Verified Reviews: ${stats.verified}

Customer Reviews:
${meaningfulReviews.map((review, index) => `
Review ${index + 1}: ${review.rating}⭐ ${review.verified ? '[Verified Purchase]' : ''}
${review.title ? `"${review.title}"` : ''}
"${review.text}"
---`).join('')}

Create a natural, helpful product summary that:
1. Highlights what customers love most about this product
2. Mentions any common themes or standout features
3. Gives potential buyers a clear idea of what to expect
4. Sounds like a friend recommending the product

Write in a conversational tone, 60-100 words. Focus on the actual product benefits customers mention, not just generic positive statements.
`;

    console.log(`🚀 Sending request to Groq API...`);

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful product reviewer who creates natural, conversational summaries based on real customer feedback. Focus on specific product benefits and features customers actually mention. Avoid generic marketing language. Write like you\'re telling a friend about the product.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 200,
        temperature: 0.7,
        top_p: 0.9,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ Groq API error: ${response.status} - ${errorText}`);
      throw new Error(`Groq API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log(`✅ Received response from Groq API`);

    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error('Invalid response format from Groq API');
    }

    const summary = data.choices[0].message.content.trim();
    console.log(`📖 Generated summary length: ${summary.length} characters`);

    const summaryResult = {
      success: true,
      summary,
      reviewsAnalyzed: meaningfulReviews.length,
      totalReviews: stats.total,
      averageRating: stats.average,
      generatedAt: new Date().toISOString(),
      model: 'llama-3.1-8b-instant',
      fromCache: false
    };

    // Cache the AI summary
    await ReviewCache.setAISummary(productHandle, summaryResult);

   // 🔥 Save into PostgreSQL via Python API
    try {
      await fetch("http://localhost:5001/save-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: productHandle,        // PostgreSQL column: product_id
          productHandle: productHandle,    // PostgreSQL column: product_handle
          summary: summaryResult.summary,
          model: summaryResult.model,
          reviewsAnalyzed: summaryResult.reviewsAnalyzed,
          totalReviews: summaryResult.totalReviews,
          averageRating: summaryResult.averageRating,
          fromCache: summaryResult.fromCache,
          generatedAt: summaryResult.generatedAt
        })
      });
      console.log(`✅ Saved AI summary for ${productHandle} into PostgreSQL`);
    } catch (dbErr) {
      console.error(`❌ Failed to save AI summary for ${productHandle}:`, dbErr);
    }

    return summaryResult;

  } catch (error) {
    console.error(`❌ Error in AI summary generation:`, error);
    throw error;
  }
}

export const action = async ({ request }) => {
  console.log(`🤖 AI Summary API called`);
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',  
    'Access-Control-Allow-Headers': 'Content-Type',
  };
  
  try {
    const requestData = await request.json();
    const { reviews, stats, productHandle, forceRegenerate = false } = requestData;
    
    if (!productHandle) {
      return json({
        success: false,
        error: 'No product handle provided'
      }, { status: 400, headers });
    }
    
    // CRITICAL: Validate reviews exist and have content
    if (!reviews || reviews.length === 0) {
      console.log(`❌ No reviews provided for AI analysis - ${productHandle}`);
      return json({
        success: false,
        error: 'No reviews available for AI analysis',
        message: 'This product needs customer reviews before an AI summary can be generated.'
      }, { status: 400, headers });
    }

    // Additional validation for meaningful reviews
    const meaningfulReviews = reviews.filter(review => 
      review.text && 
      review.text.trim().length > 10 && 
      review.rating > 0
    );

    if (meaningfulReviews.length === 0) {
      console.log(`❌ No meaningful reviews found for AI analysis - ${productHandle}`);
      return json({
        success: false,
        error: 'No detailed reviews available for AI analysis',
        message: 'This product needs more detailed customer reviews before an AI summary can be generated.'
      }, { status: 400, headers });
    }

    // Generate AI summary using Groq
    const summaryResult = await generateReviewSummary(reviews, stats, productHandle, forceRegenerate);
    
    if (!summaryResult.success) {
      return json({
        success: false,
        error: summaryResult.error,
        message: 'Unable to generate AI summary - not enough review content available.'
      }, { status: 400, headers });
    }
    
    console.log(`✅ AI summary generated successfully for ${productHandle}`);
    
    return json({
      success: true,
      summary: summaryResult.summary,
      metadata: {
        reviewsAnalyzed: summaryResult.reviewsAnalyzed,
        totalReviews: summaryResult.totalReviews,
        averageRating: summaryResult.averageRating,
        generatedAt: summaryResult.generatedAt,
        model: summaryResult.model,
        productHandle,
        fromCache: summaryResult.fromCache || false
      }
    }, { headers });

  } catch (error) {
    console.error(`❌ AI Summary API error:`, error);
    
    return json({
      success: false,
      error: error.message || 'Failed to generate AI summary',
      message: 'There was an error generating the AI summary. Please try again later.'
    }, { status: 500, headers });
  }
};

// Enhanced GET method to retrieve AI summary directly with proper validation
export const loader = async ({ request }) => {
  const url = new URL(request.url);
  const productHandle = url.searchParams.get('productHandle');
  const forceRefresh = url.searchParams.get('forceRefresh') === 'true';
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (!productHandle) {
    return json({
      success: false,
      error: 'No product handle provided'
    }, { status: 400, headers });
  }

  try {
    // If force refresh is requested, clear cache first
    if (forceRefresh) {
      console.log(`Force refreshing AI summary for ${productHandle}`);
      await ReviewCache.clear(productHandle);
      
      // Get fresh reviews and generate new AI summary
      try {
        const { scrapeProductReviews } = await import('../../services/reviewScraper.server.js');
        const freshReviews = await scrapeProductReviews(productHandle);
        
        if (freshReviews.success && freshReviews.reviews.length > 0) {
          const summaryResult = await generateReviewSummary(
            freshReviews.reviews, 
            freshReviews.stats, 
            productHandle, 
            true
          );
          
          if (summaryResult.success) {
            return json({
              success: true,
              summary: summaryResult.summary,
              metadata: {
                reviewsAnalyzed: summaryResult.reviewsAnalyzed,
                totalReviews: summaryResult.totalReviews,
                averageRating: summaryResult.averageRating,
                generatedAt: summaryResult.generatedAt,
                model: summaryResult.model,
                productHandle,
                fromCache: false,
                refreshed: true
              }
            }, { headers });
          } else {
            return json({
              success: false,
              error: summaryResult.error || 'Failed to generate AI summary',
              productHandle
            }, { status: 400, headers });
          }
        } else {
          return json({
            success: false,
            error: 'No reviews found for this product',
            message: 'This product needs customer reviews before an AI summary can be generated.',
            productHandle
          }, { status: 404, headers });
        }
      } catch (importError) {
        console.error('Error importing reviewScraper:', importError);
        return json({
          success: false,
          error: 'Failed to refresh reviews',
          productHandle
        }, { status: 500, headers });
      }
    }

    // Try to get cached AI summary
    const cachedSummary = await ReviewCache.getAISummary(productHandle);
    
    if (cachedSummary) {
      return json({
        success: true,
        summary: cachedSummary.summary,
        metadata: {
          reviewsAnalyzed: cachedSummary.reviewsAnalyzed,
          totalReviews: cachedSummary.totalReviews,
          averageRating: cachedSummary.averageRating,
          generatedAt: cachedSummary.generatedAt,
          model: cachedSummary.model,
          productHandle,
          fromCache: true
        }
      }, { headers });
    } else {
      return json({
        success: false,
        error: 'No AI summary found',
        message: 'No AI summary available. This product needs customer reviews before a summary can be generated.',
        productHandle
      }, { status: 404, headers });
    }
  } catch (error) {
    console.error(`❌ Loader error for ${productHandle}:`, error);
    return json({
      success: false,
      error: error.message,
      productHandle
    }, { status: 500, headers });
  }
};

export const options = () => {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
};