// routes/reviews.$productHandle.jsx
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate, Link } from "@remix-run/react";
import {
  Page,
  Layout,
  Text,
  Card,
  BlockStack,
  DataTable,
  Badge,
  EmptyState,
  InlineStack,
  Button,
  Spinner,
  Banner,
  Icon,
  Divider,
} from "@shopify/polaris";
import { 
  StarIcon,
  ChevronLeftIcon,
  RefreshIcon,
} from '@shopify/polaris-icons';
import { TitleBar } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import reviewScraper from "../../services/reviewScraper";

// Loader function to fetch product info and reviews
export const loader = async ({ request, params }) => {
  const { admin } = await authenticate.admin(request);
  const { productHandle } = params;

  if (!productHandle) {
    throw new Response("Product handle is required", { status: 400 });
  }

  try {
    // Step 1: Get product info from Shopify
    const productResponse = await admin.graphql(
      `#graphql
        query getProductByHandle($handle: String!) {
          productByHandle(handle: $handle) {
            id
            title
            handle
            status
            createdAt
            updatedAt
            description
            vendor
            productType
            tags
            featuredImage {
              url
              altText
            }
          }
        }`,
      {
        variables: { handle: productHandle },
      }
    );

    const productData = await productResponse.json();
    
    if (productData.errors) {
      console.error('GraphQL Errors:', productData.errors);
      return json({
        success: false,
        error: 'Failed to fetch product information',
        product: null,
        reviews: [],
        stats: {},
      });
    }

    const product = productData.data?.productByHandle;
    
    if (!product) {
      return json({
        success: false,
        error: 'Product not found',
        product: null,
        reviews: [],
        stats: {},
      });
    }

    // Step 2: Scrape reviews from the product page
    console.log(`Scraping reviews for product: ${productHandle}`);
    const reviewResult = await reviewScraper.scrapeProductReviews(productHandle);

    // Step 3: Format the response
    return json({
      success: true,
      product: {
        ...product,
        adminUrl: `shopify:admin/products/${product.id.replace("gid://shopify/Product/", "")}`,
        storeUrl: `${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`,
      },
      reviews: reviewResult.reviews || [],
      stats: reviewResult.stats || {},
      scrapingResult: reviewResult,
      scrapedAt: new Date().toISOString(),
    });

  } catch (error) {
    console.error('Error in reviews loader:', error);
    return json({
      success: false,
      error: error.message,
      product: null,
      reviews: [],
      stats: {},
    });
  }
};

// Action handler for refresh functionality
export const action = async ({ request, params }) => {
  const { productHandle } = params;
  const formData = await request.formData();
  const actionType = formData.get('action');

  if (actionType === 'refresh') {
    // Force refresh of reviews
    const reviewResult = await reviewScraper.scrapeProductReviews(productHandle);
    
    return json({
      success: true,
      message: 'Reviews refreshed successfully',
      reviews: reviewResult.reviews,
      stats: reviewResult.stats,
    });
  }

  return json({ success: false, error: 'Invalid action' });
};

// Helper function to render star rating
function StarRating({ rating, size = "small" }) {
  const stars = [];
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 !== 0;
  
  for (let i = 1; i <= 5; i++) {
    if (i <= fullStars) {
      stars.push(
        <Icon
          key={i}
          source={StarIcon}
          tone="warning"
        />
      );
    } else if (i === fullStars + 1 && hasHalfStar) {
      stars.push(
        <Icon
          key={i}
          source={StarIcon}
          tone="subdued"
        />
      );
    } else {
      stars.push(
        <Icon
          key={i}
          source={StarIcon}
          tone="subdued"
        />
      );
    }
  }
  
  return <InlineStack gap="100">{stars}</InlineStack>;
}

// Helper function to format date
function formatDate(dateString) {
  if (!dateString) return 'No date';
  
  try {
    // Try to parse various date formats
    let date;
    if (dateString.includes('/')) {
      // Handle MM/DD/YYYY or DD/MM/YYYY format
      date = new Date(dateString);
    } else if (dateString.includes('-')) {
      // Handle ISO format
      date = new Date(dateString);
    } else {
      // Try to parse relative dates like "2 days ago"
      return dateString;
    }
    
    if (isNaN(date.getTime())) {
      return dateString; // Return original if parsing fails
    }
    
    return date.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch (error) {
    return dateString;
  }
}

export default function ProductReviews() {
  const { success, product, reviews, stats, error, scrapingResult } = useLoaderData();
  const navigate = useNavigate();

  // Prepare data for reviews table
  const reviewRows = reviews.map((review, index) => [
    // Serial Number
    <Text variant="bodyMd" fontWeight="medium">
      {index + 1}
    </Text>,
    // Author
    <Text variant="bodyMd">
      {review.author || 'Anonymous'}
    </Text>,
    // Rating
    <InlineStack gap="200" align="center">
      <StarRating rating={review.rating} />
      <Text variant="bodySm" tone="subdued">
        ({review.rating}/5)
      </Text>
    </InlineStack>,
    // Review Text (truncated)
    <Text variant="bodyMd">
      {review.text ? 
        (review.text.length > 100 ? 
          `${review.text.substring(0, 100)}...` : 
          review.text
        ) : 
        'No review text'
      }
    </Text>,
    // Date
    <Text variant="bodySm" tone="subdued">
      {formatDate(review.date)}
    </Text>,
    // Verified Badge
    review.verified ? (
      <Badge tone="success">Verified</Badge>
    ) : (
      <Badge tone="subdued">Unverified</Badge>
    ),
  ]);

  const reviewTableHeadings = [
    '#',
    'Author',
    'Rating',
    'Review',
    'Date',
    'Status'
  ];

  if (!success) {
    return (
      <Page>
        <TitleBar title="Product Reviews - Error" />
        <Layout>
          <Layout.Section>
            <Card>
              <EmptyState
                heading="Error loading reviews"
                image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
              >
                <p>{error || 'Something went wrong while fetching reviews.'}</p>
                <br />
                <Button onClick={() => navigate('/app')}>
                  Back to Products
                </Button>
              </EmptyState>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  return (
    <Page>
      <TitleBar title={`Reviews - ${product?.title || 'Product'}`} />
      
      <BlockStack gap="500">
        {/* Navigation */}
        <Card>
          <InlineStack align="space-between">
            <Button
              icon={ChevronLeftIcon}
              onClick={() => navigate('/app')}
            >
              Back to Products
            </Button>
            <InlineStack gap="200">
              <Button
                icon={RefreshIcon}
                onClick={() => window.location.reload()}
              >
                Refresh Reviews
              </Button>
              {product?.storeUrl && (
                <Link
                  url={product.storeUrl}
                  target="_blank"
                  removeUnderline
                >
                  <Button variant="primary">
                    View on Store
                  </Button>
                </Link>
              )}
            </InlineStack>
          </InlineStack>
        </Card>

        {/* Product Information */}
        {product && (
          <Card>
            <BlockStack gap="400">
              <InlineStack gap="400" align="start">
                {product.featuredImage && (
                  <img
                    src={product.featuredImage.url}
                    alt={product.featuredImage.altText || product.title}
                    style={{
                      width: '100px',
                      height: '100px',
                      objectFit: 'cover',
                      borderRadius: '8px'
                    }}
                  />
                )}
                <BlockStack gap="200">
                  <Text as="h1" variant="headingLg">
                    {product.title}
                  </Text>
                  <InlineStack gap="200">
                    <Badge tone={
                      product.status === 'ACTIVE' ? 'success' : 
                      product.status === 'DRAFT' ? 'attention' : 'critical'
                    }>
                      {product.status.toLowerCase()}
                    </Badge>
                    <Text variant="bodySm" tone="subdued">
                      Handle: {product.handle}
                    </Text>
                  </InlineStack>
                  {product.description && (
                    <Text variant="bodyMd" tone="subdued">
                      {product.description.length > 200 ? 
                        `${product.description.substring(0, 200)}...` : 
                        product.description
                      }
                    </Text>
                  )}
                </BlockStack>
              </InlineStack>
            </BlockStack>
          </Card>
        )}

        {/* Scraping Status Banner */}
        {scrapingResult && !scrapingResult.success && (
          <Banner tone="warning" title="Review Scraping Issues">
            <p>
              There were issues scraping reviews: {scrapingResult.error}
              <br />
              This might be due to the third-party review app's structure or authentication issues.
            </p>
          </Banner>
        )}

        <Layout>
          <Layout.Section>
            {/* Reviews Table */}
            <Card>
              <BlockStack gap="500">
                <InlineStack align="space-between">
                  <Text as="h2" variant="headingLg">
                    Customer Reviews ({reviews.length})
                  </Text>
                  {stats.average > 0 && (
                    <InlineStack gap="200" align="center">
                      <StarRating rating={stats.average} />
                      <Text variant="headingMd" fontWeight="bold">
                        {stats.average}
                      </Text>
                      <Text variant="bodySm" tone="subdued">
                        ({stats.total} reviews)
                      </Text>
                    </InlineStack>
                  )}
                </InlineStack>

                {reviews.length === 0 ? (
                  <EmptyState
                    heading="No reviews found"
                    image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                  >
                    <p>
                      No reviews were found for this product. This could be because:
                    </p>
                    <ul>
                      <li>The product has no reviews yet</li>
                      <li>The review app structure has changed</li>
                      <li>Reviews are loaded dynamically via JavaScript</li>
                    </ul>
                    <br />
                    <Button
                      onClick={() => window.location.reload()}
                      variant="primary"
                    >
                      Try Again
                    </Button>
                  </EmptyState>
                ) : (
                  <DataTable
                    columnContentTypes={[
                      'text',      // Serial Number
                      'text',      // Author
                      'text',      // Rating
                      'text',      // Review Text
                      'text',      // Date
                      'text',      // Status
                    ]}
                    headings={reviewTableHeadings}
                    rows={reviewRows}
                    footerContent={`Showing ${reviews.length} reviews • Scraped at ${new Date(scrapingResult?.scrapedAt || new Date()).toLocaleString('en-IN')}`}
                  />
                )}
              </BlockStack>
            </Card>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <BlockStack gap="500">
              {/* Review Statistics */}
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">
                    Review Statistics
                  </Text>
                  
                  {stats.total > 0 ? (
                    <BlockStack gap="300">
                      <InlineStack align="space-between">
                        <Text variant="bodyMd">Average Rating</Text>
                        <InlineStack gap="200" align="center">
                          <StarRating rating={stats.average} />
                          <Text variant="bodyMd" fontWeight="bold" tone="success">
                            {stats.average}/5
                          </Text>
                        </InlineStack>
                      </InlineStack>
                      
                      <InlineStack align="space-between">
                        <Text variant="bodyMd">Total Reviews</Text>
                        <Text variant="bodyMd" fontWeight="bold">
                          {stats.total}
                        </Text>
                      </InlineStack>

                      {stats.totalWithText > 0 && (
                        <InlineStack align="space-between">
                          <Text variant="bodyMd">With Text</Text>
                          <Text variant="bodyMd" fontWeight="bold">
                            {stats.totalWithText}
                          </Text>
                        </InlineStack>
                      )}

                      {stats.verified > 0 && (
                        <InlineStack align="space-between">
                          <Text variant="bodyMd">Verified</Text>
                          <Text variant="bodyMd" fontWeight="bold" tone="success">
                            {stats.verified}
                          </Text>
                        </InlineStack>
                      )}

                      <Divider />
                      
                      <Text as="h3" variant="headingSm">
                        Rating Distribution
                      </Text>
                      
                      {Object.entries(stats.distribution || {}).reverse().map(([rating, count]) => (
                        <InlineStack key={rating} align="space-between">
                          <InlineStack gap="200" align="center">
                            <Text variant="bodyMd">{rating}</Text>
                            <Icon source={StarIcon} tone="warning" />
                          </InlineStack>
                          <InlineStack gap="200" align="center">
                            <div
                              style={{
                                width: '100px',
                                height: '8px',
                                backgroundColor: '#e1e3e5',
                                borderRadius: '4px',
                                overflow: 'hidden'
                              }}
                            >
                              <div
                                style={{
                                  width: `${stats.total > 0 ? (count / stats.total) * 100 : 0}%`,
                                  height: '100%',
                                  backgroundColor: '#007ace',
                                }}
                              />
                            </div>
                            <Text variant="bodyMd" fontWeight="medium">
                              {count}
                            </Text>
                          </InlineStack>
                        </InlineStack>
                      ))}
                    </BlockStack>
                  ) : (
                    <Text variant="bodyMd" tone="subdued">
                      No review statistics available
                    </Text>
                  )}
                </BlockStack>
              </Card>

              {/* Scraping Information */}
              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Scraping Details
                  </Text>
                  
                  <BlockStack gap="200">
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Status</Text>
                      <Badge tone={scrapingResult?.success ? 'success' : 'critical'}>
                        {scrapingResult?.success ? 'Success' : 'Failed'}
                      </Badge>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Reviews Found</Text>
                      <Text variant="bodyMd" fontWeight="bold">
                        {reviews.length}
                      </Text>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Last Scraped</Text>
                      <Text variant="bodyMd">
                        {scrapingResult?.scrapedAt ? 
                          new Date(scrapingResult.scrapedAt).toLocaleString('en-IN') : 
                          'Unknown'
                        }
                      </Text>
                    </InlineStack>

                    {product?.storeUrl && (
                      <InlineStack align="space-between">
                        <Text variant="bodyMd">Source URL</Text>
                        <Link
                          url={product.storeUrl}
                          target="_blank"
                          removeUnderline
                        >
                          <Text variant="bodyMd" tone="magic">
                            View Page
                          </Text>
                        </Link>
                      </InlineStack>
                    )}
                  </BlockStack>
                </BlockStack>
              </Card>

              {/* Technical Info */}
              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Technical Information
                  </Text>
                  
                  <BlockStack gap="200">
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Scraper Version</Text>
                      <Text variant="bodyMd">v1.0.0</Text>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Method</Text>
                      <Text variant="bodyMd">HTML Parsing</Text>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Store Password</Text>
                      <Badge tone="attention">Protected</Badge>
                    </InlineStack>
                    
                    <Text variant="bodySm" tone="subdued">
                      Reviews are scraped directly from your store's product pages, 
                      including those from third-party review applications.
                    </Text>
                  </BlockStack>
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>

        {/* Individual Review Cards (Optional detailed view) */}
        {reviews.length > 0 && reviews.length <= 10 && (
          <Card>
            <BlockStack gap="500">
              <Text as="h2" variant="headingLg">
                Detailed Reviews
              </Text>
              
              <BlockStack gap="400">
                {reviews.map((review, index) => (
                  <Card key={review.id || index} sectioned>
                    <BlockStack gap="300">
                      {/* Review Header */}
                      <InlineStack align="space-between">
                        <InlineStack gap="200" align="center">
                          <Text variant="bodyMd" fontWeight="bold">
                            {review.author || 'Anonymous Customer'}
                          </Text>
                          {review.verified && (
                            <Badge tone="success" size="small">
                              Verified
                            </Badge>
                          )}
                        </InlineStack>
                        <Text variant="bodySm" tone="subdued">
                          {formatDate(review.date)}
                        </Text>
                      </InlineStack>

                      {/* Rating */}
                      <InlineStack gap="200" align="center">
                        <StarRating rating={review.rating} />
                        <Text variant="bodyMd" fontWeight="medium">
                          {review.rating}/5
                        </Text>
                      </InlineStack>

                      {/* Review Title */}
                      {review.title && (
                        <Text variant="bodyMd" fontWeight="medium">
                          {review.title}
                        </Text>
                      )}

                      {/* Review Text */}
                      {review.text && (
                        <Text variant="bodyMd">
                          {review.text}
                        </Text>
                      )}

                      {/* Helpful Count */}
                      {review.helpful > 0 && (
                        <Text variant="bodySm" tone="subdued">
                          {review.helpful} people found this helpful
                        </Text>
                      )}
                    </BlockStack>
                  </Card>
                ))}
              </BlockStack>
            </BlockStack>
          </Card>
        )}
      </BlockStack>
    </Page>
  );
}