// This makes your API accessible via app proxy
// routes/apps.api.reviews.$productHandle.jsx
export { loader } from './api.reviews.$productHandle';


