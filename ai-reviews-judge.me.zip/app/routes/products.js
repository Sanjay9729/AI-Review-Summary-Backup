// Config File: config/products.js

// products.js 
export const PRODUCTS_CONFIG = {
  // GraphQL Query Configuration
  QUERY: {
    DEFAULT_LIMIT: 100,
    MAX_LIMIT: 250,
    FIELDS: [
      'id',
      'title',
      'handle', 
      'status',
      'createdAt',
      'updatedAt'
    ]
  },

  // Table Configuration
  TABLE: {
    HEADINGS: [
      '#',
      'Product Name', 
      'Status',
      'Created Date'
    ],
    COLUMN_TYPES: [
      'text',      // Serial Number
      'text',      // Product Name
      'text',      // Status
      'text'       // Created Date
    ]
  },

  // Status Configuration
  STATUS: {
    ACTIVE: 'ACTIVE',
    DRAFT: 'DRAFT', 
    ARCHIVED: 'ARCHIVED',
    COLORS: {
      ACTIVE: 'success',
      DRAFT: 'attention',
      ARCHIVED: 'critical'
    }
  },

  // Display Configuration
  DISPLAY: {
    DATE_LOCALE: 'en-IN',
    DATE_FORMAT: {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    },
    EMPTY_STATE: {
      HEADING: 'No products found',
      DESCRIPTION: 'No products available in your store.',
      IMAGE: 'https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png'
    }
  },

  // Error Messages
  ERRORS: {
    FETCH_FAILED: 'Failed to fetch products',
    GENERIC_ERROR: 'Something went wrong while fetching products.',
    NO_DATA: 'No product data available',
    INVALID_RESPONSE: 'Invalid response from Shopify API'
  },

  // Success Messages  
  MESSAGES: {
    LOADING: 'Loading products...',
    SUCCESS: 'Products loaded successfully',
    REFRESH: 'Products refreshed'
  }
};

// GraphQL Queries
export const GRAPHQL_QUERIES = {
  GET_PRODUCTS: `#graphql
    query getProducts($first: Int!) {
      products(first: $first) {
        edges {
          node {
            id
            title
            handle
            status
            createdAt
            updatedAt
          }
        }
        pageInfo {
          hasNextPage
          endCursor
        }
      }
    }`,
    
  GET_PRODUCTS_WITH_PAGINATION: `#graphql
    query getProductsWithPagination($first: Int!, $after: String) {
      products(first: $first, after: $after) {
        edges {
          node {
            id
            title
            handle
            status
            createdAt
            updatedAt
          }
        }
        pageInfo {
          hasNextPage
          hasPreviousPage
          startCursor
          endCursor
        }
      }
    }`
};

export default PRODUCTS_CONFIG;