// // services/reviewScraper.js

// import puppeteer from 'puppeteer';

// /**
//  * Scrape product reviews from a Shopify product page
//  * @param {string} productHandle - The product's handle used in the URL
//  * @returns {Promise<Object>} - Reviews and statistics object
//  */
// async function scrapeProductReviews(productHandle) {
//     debugger
//   const productUrl = `https://${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`;
//   let reviews = [];
//   let stats = {
//     total: 0,
//     average: 0,
//     distribution: {},
//     verified: 0,
//     totalWithText: 0,
//   };

//   try {
//     const browser = await puppeteer.launch({ headless: true });
//     const page = await browser.newPage();

//     // Go to the product page
//     await page.goto(productUrl, { waitUntil: 'domcontentloaded' });

//     // Wait for reviews to load (this may depend on the third-party review app you're using)
//     await page.waitForSelector('.jdgm-rev'); // Update selector as per the actual review app's class name

//     // Scrape reviews data
//     const scrapedReviews = await page.evaluate(() => {
//       const reviewList = [];
//       const reviewElements = document.querySelectorAll('.jdgm-rev');
      
//       reviewElements.forEach((review) => {
//         const author = review.querySelector('.jdgm-author')?.textContent || 'Anonymous';
//         const rating = parseFloat(review.querySelector('.jdgm-rating')?.textContent || '0');
//         const text = review.querySelector('.jdgm-review')?.textContent || '';
//         const verified = review.querySelector('.jdgm-verified') ? true : false;
//         const date = review.querySelector('.jdgm-date')?.textContent || '';
        
//         reviewList.push({
//           author,
//           rating,
//           text,
//           verified,
//           date,
//         });
//       });

//       return reviewList;
//     });

//     // Calculate statistics
//     if (scrapedReviews.length > 0) {
//       const totalReviews = scrapedReviews.length;
//       const averageRating = scrapedReviews.reduce((acc, review) => acc + review.rating, 0) / totalReviews;
//       const distribution = scrapedReviews.reduce((acc, review) => {
//         acc[Math.round(review.rating)] = (acc[Math.round(review.rating)] || 0) + 1;
//         return acc;
//       }, {});

//       const totalWithText = scrapedReviews.filter((review) => review.text.length > 0).length;
//       const verifiedReviews = scrapedReviews.filter((review) => review.verified).length;

//       stats = {
//         total: totalReviews,
//         average: averageRating,
//         distribution,
//         verified: verifiedReviews,
//         totalWithText,
//       };
//     }

//     reviews = scrapedReviews;

//     await browser.close();
//   } catch (error) {
//     console.error('Error scraping reviews:', error);
//   }

//   return {
//     reviews,
//     stats,
//     success: true,
//   };
// }

// export default {
//   scrapeProductReviews,
// };
