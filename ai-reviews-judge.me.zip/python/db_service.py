# import os
# import time
# import requests
# from bs4 import BeautifulSoup
# from datetime import datetime, timezone
# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.by import By
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from webdriver_manager.chrome import ChromeDriverManager

# # 🔑 Load .env and Groq client
# from dotenv import load_dotenv
# from groq import Groq

# load_dotenv()
# client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# # ==========================
# STORE_URL = "https://sanjayvaghela-testing.myshopify.com"
# STORE_PASSWORD = "skawng"
# FLASK_API_URL = "http://127.0.0.1:5001"
# # ==========================


# def generate_ai_summary(product_handle, product_id, reviews):
#     """Generate AI summary using Groq"""
#     if not reviews:
#         print(f"⚠️ No reviews to summarize for {product_handle}")
#         return None

#     review_texts = "\n".join([f"- {r['body']}" for r in reviews if r.get("body")])

#     prompt = f"""
#     Summarize the following customer reviews for the product '{product_handle}':

#     {review_texts}

#     Provide a concise summary highlighting:
#     - Key pros
#     - Any cons
#     - Overall impression
#     """

#     try:
#         response = client.chat.completions.create(
#             model="llama-3.1-8b-instant",
#             messages=[{"role": "user", "content": prompt}],
#             max_tokens=300,
#         )

#         summary_text = response.choices[0].message.content
#         avg_rating = sum([r.get("rating", 0) for r in reviews]) / len(reviews)

#         payload = {
#             "productId": product_id,
#             "productHandle": product_handle,
#             "summary": summary_text,
#             "model": "llama-3.1-8b-instant",
#             "reviewsAnalyzed": len(reviews),
#             "totalReviews": len(reviews),
#             "averageRating": avg_rating,
#             "fromCache": False,
#             "generatedAt": datetime.utcnow().isoformat(),
#         }

#         resp = requests.post(f"{FLASK_API_URL}/save-summary", json=payload)
#         print("🧠 AI Summary saved:", resp.status_code, resp.json())

#     except Exception as e:
#         print("❌ Error generating summary:", e)


# def scrape_store():
#     print("🔍 Opening store homepage...")

#     chrome_options = Options()
#     chrome_options.add_argument("--headless=new")
#     chrome_options.add_argument("--no-sandbox")
#     chrome_options.add_argument("--disable-dev-shm-usage")

#     driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

#     try:
#         # Step 1: Open password page
#         driver.get(f"{STORE_URL}/password")
#         try:
#             pwd_input = WebDriverWait(driver, 10).until(
#                 EC.presence_of_element_located((By.NAME, "password"))
#             )
#             pwd_input.send_keys(STORE_PASSWORD)
#             driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
#             print("🔑 Password submitted...")
#         except:
#             print("⚠️ Could not auto-fill password")

#         # Step 2: Open homepage
#         driver.get(STORE_URL)
#         time.sleep(3)

#         # Collect product links
#         links = driver.find_elements(By.CSS_SELECTOR, "a[href*='/products/']")
#         product_links = list({l.get_attribute("href") for l in links})
#         print(f"🛒 Found {len(product_links)} product links")

#         for link in product_links:
#             print(f"🔍 Opening product: {link}")
#             driver.get(link)

#             try:
#                 WebDriverWait(driver, 15).until(
#                     EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".jdgm-rev"))
#                 )
#                 print("✅ Reviews found in DOM")
#             except:
#                 print("⚠️ No reviews found for this product")
#                 continue

#             # Load all reviews via "Load More"
#             while True:
#                 try:
#                     load_more = driver.find_element(By.CSS_SELECTOR, ".jdgm-load-more__text")
#                     driver.execute_script("arguments[0].click();", load_more)
#                     time.sleep(2)
#                 except:
#                     break

#             # Scrape reviews
#             html = driver.page_source
#             soup = BeautifulSoup(html, "html.parser")
#             review_elements = soup.select(".jdgm-rev")

#             reviews = []
#             for idx, r in enumerate(review_elements, start=1):
#                 reviews.append({
#                     "id": idx,
#                     "productId": link.split("/")[-1],
#                     "productHandle": link.split("/")[-1],
#                     "author": r.select_one(".jdgm-rev__author").get_text(strip=True) if r.select_one(".jdgm-rev__author") else "Anonymous",
#                     "title": r.select_one(".jdgm-rev__title").get_text(strip=True) if r.select_one(".jdgm-rev__title") else "",
#                     "body": r.select_one(".jdgm-rev__body").get_text(strip=True) if r.select_one(".jdgm-rev__body") else "",
#                     "rating": float(r.select_one(".jdgm-rev__rating").get("data-score")) if r.select_one(".jdgm-rev__rating") else 0,
#                     "date": datetime.now(timezone.utc).isoformat(),
#                     "verified": "Verified" in r.get_text(),
#                     "url": link,
#                     "createdAt": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
#                 })

#             if reviews:
#                 print(f"✅ Scraped {len(reviews)} reviews from {link}")

#                 # Save to Flask API
#                 payload = {
#                     "productId": link.split("/")[-1],
#                     "productHandle": link.split("/")[-1],
#                     "reviews": reviews
#                 }
#                 resp = requests.post(f"{FLASK_API_URL}/save-reviews", json=payload)
#                 print("📡 Sent to Flask API:", resp.status_code, resp.json())

#                 # Generate AI summary
#                 generate_ai_summary(link.split("/")[-1], link.split("/")[-1], reviews)
#             else:
#                 print(f"⚠️ No reviews scraped for {link}")

#     finally:
#         driver.quit()


# if __name__ == "__main__":
#     scrape_store()

import sqlite3
from datetime import datetime, timezone

DB_FILE = "reviews.db"


def init_db():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id TEXT,
        product_handle TEXT,
        author TEXT,
        title TEXT,
        body TEXT,
        rating REAL,
        date TEXT,
        verified INTEGER,
        url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS ai_summaries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id TEXT,
        product_handle TEXT,
        summary TEXT,
        model TEXT,
        reviews_analyzed INTEGER,
        total_reviews INTEGER,
        average_rating REAL,
        from_cache INTEGER,
        generated_at TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()
    print("✅ Tables ensured (reviews, ai_summaries)")


def insert_review(product_id, product_handle, review):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO reviews 
        (product_id, product_handle, author, title, body, rating, date, verified, url)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        product_id,
        product_handle,
        review.get("author"),
        review.get("title"),
        review.get("body"),
        review.get("rating"),
        review.get("date"),
        int(review.get("verified", False)),
        review.get("url")
    ))
    conn.commit()
    conn.close()


def insert_summary(payload):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO ai_summaries
        (product_id, product_handle, summary, model, reviews_analyzed, total_reviews, average_rating, from_cache, generated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        payload["productId"],
        payload["productHandle"],
        payload["summary"],
        payload["model"],
        payload["reviewsAnalyzed"],
        payload["totalReviews"],
        payload["averageRating"],
        int(payload.get("fromCache", False)),
        payload.get("generatedAt", datetime.now(timezone.utc).isoformat())
    ))

    conn.commit()
    conn.close()
