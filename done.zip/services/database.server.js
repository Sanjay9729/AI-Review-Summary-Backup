// // services/database.server.js - PostgreSQL Database Service
// import prisma from "../app/db.server.js";

// class DatabaseService {
//   // ===== PRODUCT OPERATIONS =====

//   static async createProduct(productData) {
//     try {
//       const product = await prisma.product.create({
//         data: {
//           shopifyId: productData.shopifyId,
//           handle: productData.handle,
//           title: productData.title,
//           shop: productData.shop,
//           status: productData.status || 'ACTIVE'
//         }
//       });
//       console.log(`Created product: ${product.handle}`);
//       return product;
//     } catch (error) {
//       if (error.code === 'P2002' && error.meta?.target?.includes('shopifyId')) {
//         // Product with this shopifyId already exists, fetch it
//         return await this.getProductByShopifyId(productData.shopifyId);
//       }
//       console.error('Error creating product:', error);
//       throw error;
//     }
//   }

//   static async getProductByHandle(handle, shop) {
//     try {
//       return await prisma.product.findFirst({
//         where: { handle, shop }
//       });
//     } catch (error) {
//       console.error('Error fetching product by handle:', error);
//       return null;
//     }
//   }

//   static async getProductByShopifyId(shopifyId) {
//     try {
//       return await prisma.product.findUnique({
//         where: { shopifyId }
//       });
//     } catch (error) {
//       console.error('Error fetching product by shopifyId:', error);
//       return null;
//     }
//   }

//   // ===== REVIEW OPERATIONS =====

//   static async saveReviews(productId, reviews) {
//     try {
//       const reviewsToCreate = reviews.map(review => ({
//         productId,
//         author: review.author || 'Anonymous',
//         rating: Math.max(0, Math.min(5, review.rating || 0)),
//         title: review.title || null,
//         text: review.text || '',
//         verified: review.verified || false,
//         platform: review.platform || 'Unknown',
//         reviewDate: review.date ? new Date(review.date) : null,
//         scrapedAt: new Date()
//       }));

//       // Clear existing reviews for this product first
//       await prisma.review.deleteMany({
//         where: { productId }
//       });

//       // Insert new reviews
//       const result = await prisma.review.createMany({
//         data: reviewsToCreate,
//         skipDuplicates: true
//       });

//       console.log(`Saved ${result.count} reviews for product ${productId}`);
//       return result;
//     } catch (error) {
//       console.error('Error saving reviews:', error);
//       throw error;
//     }
//   }

//   static async getReviewsByProduct(productId) {
//     try {
//       return await prisma.review.findMany({
//         where: { productId },
//         orderBy: { scrapedAt: 'desc' }
//       });
//     } catch (error) {
//       console.error('Error fetching reviews:', error);
//       return [];
//     }
//   }

//   static async getReviewStats(productId) {
//     try {
//       const reviews = await this.getReviewsByProduct(productId);
      
//       if (reviews.length === 0) {
//         return {
//           total: 0,
//           average: 0,
//           verified: 0,
//           totalWithText: 0,
//           distribution: {}
//         };
//       }

//       const total = reviews.length;
//       const average = reviews.reduce((sum, r) => sum + r.rating, 0) / total;
//       const verified = reviews.filter(r => r.verified).length;
//       const totalWithText = reviews.filter(r => r.text && r.text.trim().length > 0).length;
      
//       const distribution = reviews.reduce((acc, r) => {
//         const star = Math.round(r.rating);
//         acc[star] = (acc[star] || 0) + 1;
//         return acc;
//       }, {});

//       return {
//         total,
//         average: Math.round(average * 10) / 10,
//         verified,
//         totalWithText,
//         distribution
//       };
//     } catch (error) {
//       console.error('Error calculating review stats:', error);
//       return { total: 0, average: 0, verified: 0, totalWithText: 0, distribution: {} };
//     }
//   }

//   // ===== AI SUMMARY OPERATIONS =====

//   static async saveAISummary(productId, summaryData) {
//     try {
//       // Delete existing AI summary for this product
//       await prisma.aiSummary.deleteMany({
//         where: { productId }
//       });

//       const aiSummary = await prisma.aiSummary.create({
//         data: {
//           productId,
//           summary: summaryData.summary,
//           model: summaryData.model || null,
//           reviewsAnalyzed: summaryData.reviewsAnalyzed || 0,
//           totalReviews: summaryData.totalReviews || 0,
//           averageRating: summaryData.averageRating || null,
//           reviewPlatform: summaryData.reviewPlatform || null,
//           platforms: summaryData.platforms || [],
//           platformCounts: summaryData.platformCounts || {},
//           isMultiPlatform: summaryData.isMultiPlatform || false,
//           duplicateReviews: summaryData.duplicateReviews || 0,
//           consistencyScore: summaryData.consistencyScore || null,
//           fromCache: summaryData.fromCache || false
//         }
//       });

//       console.log(`Saved AI summary for product ${productId}`);
//       return aiSummary;
//     } catch (error) {
//       console.error('Error saving AI summary:', error);
//       throw error;
//     }
//   }

//   static async getAISummaryByProduct(productId) {
//     try {
//       return await prisma.aiSummary.findFirst({
//         where: { productId },
//         orderBy: { generatedAt: 'desc' }
//       });
//     } catch (error) {
//       console.error('Error fetching AI summary:', error);
//       return null;
//     }
//   }

//   // ===== CACHE OPERATIONS =====

//   static async getCachedReviews(productHandle) {
//     try {
//       const cacheEntry = await prisma.reviewCache.findUnique({
//         where: { productHandle }
//       });

//       if (!cacheEntry) {
//         return null;
//       }

//       // Check if cache is expired
//       if (new Date() > cacheEntry.expiresAt) {
//         await this.clearCache(productHandle);
//         return null;
//       }

//       return {
//         ...cacheEntry.data,
//         fromCache: true,
//         cachedAt: cacheEntry.scrapedAt.toISOString()
//       };
//     } catch (error) {
//       console.error('Error getting cached reviews:', error);
//       return null;
//     }
//   }

//   static async setCachedReviews(productHandle, reviewsData, cacheDurationHours = 24) {
//     try {
//       const expiresAt = new Date();
//       expiresAt.setHours(expiresAt.getHours() + cacheDurationHours);

//       const cacheData = {
//         productHandle,
//         cacheKey: `reviews_${productHandle}_${Date.now()}`,
//         data: reviewsData,
//         stats: reviewsData.stats || {},
//         platform: reviewsData.reviewPlatform || 'Unknown',
//         expiresAt
//       };

//       await prisma.reviewCache.upsert({
//         where: { productHandle },
//         update: cacheData,
//         create: cacheData
//       });

//       console.log(`Cached reviews for ${productHandle}, expires at ${expiresAt.toISOString()}`);
//     } catch (error) {
//       console.error('Error caching reviews:', error);
//     }
//   }

//   static async clearCache(productHandle) {
//     try {
//       await prisma.reviewCache.delete({
//         where: { productHandle }
//       });
//       console.log(`Cleared cache for ${productHandle}`);
//     } catch (error) {
//       if (error.code !== 'P2025') { // Not found error
//         console.error('Error clearing cache:', error);
//       }
//     }
//   }

//   // ===== SESSION OPERATIONS =====

//   static async saveSession(sessionData) {
//     try {
//       return await prisma.session.upsert({
//         where: { id: sessionData.id },
//         update: sessionData,
//         create: sessionData
//       });
//     } catch (error) {
//       console.error('Error saving session:', error);
//       throw error;
//     }
//   }

//   static async getSession(sessionId) {
//     try {
//       return await prisma.session.findUnique({
//         where: { id: sessionId }
//       });
//     } catch (error) {
//       console.error('Error fetching session:', error);
//       return null;
//     }
//   }

//   static async deleteSession(sessionId) {
//     try {
//       await prisma.session.delete({
//         where: { id: sessionId }
//       });
//     } catch (error) {
//       if (error.code !== 'P2025') { // Not found error
//         console.error('Error deleting session:', error);
//       }
//     }
//   }

//   // ===== APP METADATA OPERATIONS =====

//   static async saveAppMetadata(shop, settings) {
//     try {
//       return await prisma.appMetadata.upsert({
//         where: { shop },
//         update: { settings, lastSync: new Date() },
//         create: { shop, settings, lastSync: new Date() }
//       });
//     } catch (error) {
//       console.error('Error saving app metadata:', error);
//       throw error;
//     }
//   }

//   static async getAppMetadata(shop) {
//     try {
//       return await prisma.appMetadata.findUnique({
//         where: { shop }
//       });
//     } catch (error) {
//       console.error('Error fetching app metadata:', error);
//       return null;
//     }
//   }

//   // ===== HEALTH CHECK =====

//   static async healthCheck() {
//     try {
//       await prisma.$queryRaw`SELECT 1`;
//       return { status: 'healthy', database: 'connected', timestamp: new Date().toISOString() };
//     } catch (error) {
//       console.error('Database health check failed:', error);
//       return { status: 'unhealthy', error: error.message, timestamp: new Date().toISOString() };
//     }
//   }

//   // ===== UTILITY METHODS =====

//   static async getOrCreateProduct(productData) {
//     let product = await this.getProductByHandle(productData.handle, productData.shop);
//     if (!product) {
//       product = await this.createProduct(productData);
//     }
//     return product;
//   }

//   // Get complete product data with reviews and AI summary
//   static async getProductComplete(productHandle, shop) {
//     try {
//       const product = await prisma.product.findFirst({
//         where: { handle: productHandle, shop },
//         include: {
//           reviews: {
//             orderBy: { scrapedAt: 'desc' }
//           },
//           aiSummaries: {
//             orderBy: { generatedAt: 'desc' },
//             take: 1
//           }
//         }
//       });

//       if (!product) {
//         return null;
//       }

//       const stats = await this.getReviewStats(product.id);

//       return {
//         product,
//         reviews: product.reviews,
//         aiSummary: product.aiSummaries[0] || null,
//         stats
//       };
//     } catch (error) {
//       console.error('Error fetching complete product data:', error);
//       return null;
//     }
//   }
// }

// export default DatabaseService;



// services/database.server.js - Database Service Layer
import crypto from 'crypto';
import prisma from '../lib/prisma.js';

class DatabaseService {
  // Generate content hash for duplicate detection
  static generateContentHash(author, rating, text, date) {
    const content = `${author}|${rating}|${text}|${date}`;
    return crypto.createHash('md5').update(content).digest('hex');
  }

  // Generate reviews hash for AI summary linking
  static generateReviewsHash(reviews) {
    const reviewsString = JSON.stringify(reviews.map(r => ({
      author: r.author,
      rating: r.rating,
      text: r.text,
      reviewDate: r.reviewDate
    })));
    return crypto.createHash('md5').update(reviewsString).digest('hex');
  }

  // Find or create product by handle
  static async findOrCreateProduct(productHandle, productData = {}) {
    try {
      let product = await prisma.product.findUnique({
        where: { handle: productHandle }
      });

      if (!product) {
        console.log(`Creating new product record for: ${productHandle}`);
        product = await prisma.product.create({
          data: {
            handle: productHandle,
            title: productData.title || productHandle.replace(/-/g, ' '),
            shopifyId: productData.shopifyId,
            status: productData.status || 'ACTIVE',
            description: productData.description,
            vendor: productData.vendor,
            productType: productData.productType,
            tags: productData.tags || [],
            featuredImageUrl: productData.featuredImageUrl,
          }
        });
      }

      return product;
    } catch (error) {
      console.error(`Error finding/creating product ${productHandle}:`, error);
      throw error;
    }
  }

  // Save reviews to database
  static async saveReviews(productHandle, reviewsData) {
    try {
      console.log(`Saving ${reviewsData.reviews?.length || 0} reviews for ${productHandle}...`);

      const product = await this.findOrCreateProduct(productHandle);
      const reviews = reviewsData.reviews || [];
      
      if (reviews.length === 0) {
        console.log(`No reviews to save for ${productHandle}`);
        return { success: true, saved: 0, skipped: 0 };
      }

      let savedCount = 0;
      let skippedCount = 0;

      // Process reviews in batches to avoid overwhelming database
      const batchSize = 50;
      for (let i = 0; i < reviews.length; i += batchSize) {
        const batch = reviews.slice(i, i + batchSize);
        
        for (const review of batch) {
          try {
            const contentHash = this.generateContentHash(
              review.author,
              review.rating,
              review.text,
              review.reviewDate || review.date
            );

            // Try to create review, skip if duplicate
            const savedReview = await prisma.review.upsert({
              where: {
                productId_contentHash: {
                  productId: product.id,
                  contentHash: contentHash
                }
              },
              update: {
                // Update fields that might change
                helpful: review.helpful || 0,
                updatedAt: new Date(),
              },
              create: {
                productId: product.id,
                author: review.author || 'Anonymous',
                rating: Math.min(5, Math.max(0, review.rating || 0)),
                title: review.title || '',
                text: review.text || '',
                verified: review.verified || false,
                helpful: review.helpful || 0,
                platform: review.platform || 'Judge.me',
                reviewDate: review.reviewDate || review.date,
                contentHash: contentHash,
              }
            });

            if (savedReview) savedCount++;
          } catch (error) {
            console.error(`Error saving individual review:`, error);
            skippedCount++;
          }
        }
      }

      // Update cache metadata
      const reviewsHash = this.generateReviewsHash(reviews);
      await this.updateCacheMetadata(product.id, {
        reviewCount: reviews.length,
        averageRating: reviewsData.stats?.average || 0,
        reviewsHash: reviewsHash,
        lastScraped: new Date(),
        lastChecked: new Date(),
        lastError: null,
        consecutiveErrors: 0,
        isStale: false
      });

      console.log(`Saved ${savedCount} reviews, skipped ${skippedCount} for ${productHandle}`);
      
      return {
        success: true,
        saved: savedCount,
        skipped: skippedCount,
        total: reviews.length,
        productId: product.id
      };
    } catch (error) {
      console.error(`Error saving reviews for ${productHandle}:`, error);
      throw error;
    }
  }

  // Get reviews from database
  static async getReviews(productHandle, options = {}) {
    try {
      const product = await prisma.product.findUnique({
        where: { handle: productHandle },
        include: {
          reviews: {
            orderBy: { scrapedAt: 'desc' },
            take: options.limit || undefined
          },
          cacheMetadata: true
        }
      });

      if (!product) {
        return {
          success: false,
          error: 'Product not found',
          reviews: [],
          stats: { total: 0, average: 0 }
        };
      }

      // Calculate stats
      const reviews = product.reviews;
      const stats = this.calculateStats(reviews);

      return {
        success: true,
        reviews: reviews.map(review => ({
          id: review.id,
          author: review.author,
          rating: review.rating,
          title: review.title,
          text: review.text,
          verified: review.verified,
          helpful: review.helpful,
          platform: review.platform,
          date: review.reviewDate,
          scrapedAt: review.scrapedAt
        })),
        stats,
        productHandle,
        cachedAt: product.cacheMetadata?.lastScraped || null,
        reviewsHash: product.cacheMetadata?.reviewsHash || null
      };
    } catch (error) {
      console.error(`Error getting reviews for ${productHandle}:`, error);
      throw error;
    }
  }

  // Calculate review statistics
  static calculateStats(reviews) {
    if (!reviews || reviews.length === 0) {
      return { total: 0, average: 0, distribution: {}, verified: 0, totalWithText: 0 };
    }

    const total = reviews.length;
    const average = reviews.reduce((acc, r) => acc + r.rating, 0) / total;
    const verified = reviews.filter(r => r.verified).length;
    const totalWithText = reviews.filter(r => r.text && r.text.length > 0).length;
    
    const distribution = reviews.reduce((acc, r) => {
      const star = Math.round(r.rating);
      acc[star] = (acc[star] || 0) + 1;
      return acc;
    }, {});

    return {
      total,
      average: Math.round(average * 10) / 10,
      distribution,
      verified,
      totalWithText
    };
  }

  // Update cache metadata
  static async updateCacheMetadata(productId, metadata) {
    try {
      await prisma.cacheMetadata.upsert({
        where: { productId },
        update: {
          ...metadata,
          updatedAt: new Date()
        },
        create: {
          productId,
          ...metadata
        }
      });
    } catch (error) {
      console.error(`Error updating cache metadata for product ${productId}:`, error);
      throw error;
    }
  }

  // Save AI summary
  static async saveAISummary(productHandle, summaryData) {
    try {
      const product = await this.findOrCreateProduct(productHandle);
      
      const summary = await prisma.aiSummary.upsert({
        where: { productId: product.id },
        update: {
          summary: summaryData.summary,
          reviewsAnalyzed: summaryData.reviewsAnalyzed,
          totalReviews: summaryData.totalReviews,
          averageRating: summaryData.averageRating,
          model: summaryData.model || 'llama-3.1-8b-instant',
          reviewsHash: summaryData.reviewsHash,
          updatedAt: new Date()
        },
        create: {
          productId: product.id,
          summary: summaryData.summary,
          reviewsAnalyzed: summaryData.reviewsAnalyzed,
          totalReviews: summaryData.totalReviews,
          averageRating: summaryData.averageRating,
          model: summaryData.model || 'llama-3.1-8b-instant',
          reviewsHash: summaryData.reviewsHash
        }
      });

      console.log(`Saved AI summary for ${productHandle}`);
      return summary;
    } catch (error) {
      console.error(`Error saving AI summary for ${productHandle}:`, error);
      throw error;
    }
  }

  // Get AI summary
  static async getAISummary(productHandle) {
    try {
      const product = await prisma.product.findUnique({
        where: { handle: productHandle },
        include: {
          aiSummaries: true,
          cacheMetadata: true
        }
      });

      if (!product || !product.aiSummaries.length) {
        return null;
      }

      const summary = product.aiSummaries[0];
      
      // Check if summary is based on outdated reviews
      const currentReviewsHash = product.cacheMetadata?.reviewsHash;
      if (currentReviewsHash && currentReviewsHash !== summary.reviewsHash) {
        console.log(`AI summary outdated for ${productHandle}, clearing...`);
        return null;
      }

      return {
        success: true,
        summary: summary.summary,
        reviewsAnalyzed: summary.reviewsAnalyzed,
        totalReviews: summary.totalReviews,
        averageRating: summary.averageRating,
        generatedAt: summary.generatedAt.toISOString(),
        model: summary.model,
        reviewsHash: summary.reviewsHash,
        fromCache: true
      };
    } catch (error) {
      console.error(`Error getting AI summary for ${productHandle}:`, error);
      return null;
    }
  }

  // Clear product data
  static async clearProduct(productHandle) {
    try {
      const product = await prisma.product.findUnique({
        where: { handle: productHandle }
      });

      if (product) {
        await prisma.product.delete({
          where: { id: product.id }
        });
        console.log(`Cleared all data for ${productHandle}`);
      }
    } catch (error) {
      console.error(`Error clearing product ${productHandle}:`, error);
      throw error;
    }
  }

  // Clear all data
  static async clearAll() {
    try {
      await prisma.review.deleteMany({});
      await prisma.aiSummary.deleteMany({});
      await prisma.cacheMetadata.deleteMany({});
      await prisma.product.deleteMany({});
      console.log('Cleared all database data');
    } catch (error) {
      console.error('Error clearing all data:', error);
      throw error;
    }
  }

  // Get database statistics
  static async getStats() {
    try {
      const [productCount, reviewCount, aiSummaryCount] = await Promise.all([
        prisma.product.count(),
        prisma.review.count(),
        prisma.aiSummary.count()
      ]);

      const recentReviews = await prisma.review.findMany({
        take: 5,
        orderBy: { scrapedAt: 'desc' },
        include: {
          product: {
            select: { title: true, handle: true }
          }
        }
      });

      return {
        totalProducts: productCount,
        totalReviews: reviewCount,
        aiSummaries: aiSummaryCount,
        recentReviews: recentReviews.map(review => ({
          product: review.product.title,
          author: review.author,
          rating: review.rating,
          text: review.text,
          scrapedAt: review.scrapedAt.toISOString()
        })),
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting database stats:', error);
      throw error;
    }
  }

  // Check if cache is fresh
  static async isCacheFresh(productHandle, maxAge = 24 * 60 * 60 * 1000) {
    try {
      const metadata = await prisma.cacheMetadata.findFirst({
        where: {
          product: {
            handle: productHandle
          }
        }
      });

      if (!metadata) return false;

      const age = Date.now() - metadata.lastScraped.getTime();
      return age < maxAge && !metadata.isStale;
    } catch (error) {
      console.error(`Error checking cache freshness for ${productHandle}:`, error);
      return false;
    }
  }

  // Get products needing refresh
  static async getProductsNeedingRefresh(maxAge = 24 * 60 * 60 * 1000) {
    try {
      const cutoffTime = new Date(Date.now() - maxAge);
      
      const products = await prisma.product.findMany({
        where: {
          OR: [
            {
              cacheMetadata: {
                lastScraped: {
                  lt: cutoffTime
                }
              }
            },
            {
              cacheMetadata: {
                isStale: true
              }
            },
            {
              cacheMetadata: null
            }
          ]
        },
        include: {
          cacheMetadata: true
        }
      });

      return products.map(p => p.handle);
    } catch (error) {
      console.error('Error getting products needing refresh:', error);
      return [];
    }
  }
}

export default DatabaseService;