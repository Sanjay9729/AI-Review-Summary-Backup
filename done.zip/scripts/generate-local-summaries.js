// scripts/generate-local-summaries.js - No API required
import pkg from '@prisma/client';
const { PrismaClient } = pkg;
import dotenv from "dotenv";

dotenv.config();

const prisma = new PrismaClient();

/**
 * Generate summary using local analysis (no API required)
 */
function generateLocalSummary(reviews, productTitle) {
  const totalReviews = reviews.length;
  
  if (totalReviews === 0) {
    return "No reviews available for this product.";
  }

  // Calculate rating statistics
  const ratings = reviews.map(r => r.rating);
  const averageRating = (ratings.reduce((sum, r) => sum + r, 0) / totalReviews).toFixed(1);
  
  const ratingCounts = {
    5: ratings.filter(r => r === 5).length,
    4: ratings.filter(r => r === 4).length,
    3: ratings.filter(r => r === 3).length,
    2: ratings.filter(r => r === 2).length,
    1: ratings.filter(r => r === 1).length
  };

  // Categorize reviews
  const positiveReviews = reviews.filter(r => r.rating >= 4);
  const neutralReviews = reviews.filter(r => r.rating === 3);
  const negativeReviews = reviews.filter(r => r.rating <= 2);

  // Extract common words from review texts
  const allReviewText = reviews.map(r => r.text).join(' ').toLowerCase();
  const words = allReviewText.split(/\s+/).filter(word => 
    word.length > 3 && 
    !['this', 'that', 'with', 'have', 'will', 'been', 'from', 'they', 'were', 'said', 'each', 'which', 'their', 'time', 'into', 'only', 'other', 'after', 'first', 'well', 'also', 'some', 'very', 'what', 'know', 'just', 'like', 'good', 'great'].includes(word)
  );

  const wordFreq = {};
  words.forEach(word => {
    wordFreq[word] = (wordFreq[word] || 0) + 1;
  });

  const topWords = Object.entries(wordFreq)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 8)
    .map(([word]) => word);

  // Analyze sentiment
  const positiveWords = ['great', 'excellent', 'amazing', 'perfect', 'love', 'best', 'fantastic', 'awesome', 'wonderful', 'beautiful', 'comfortable', 'quality', 'recommend', 'happy', 'satisfied'];
  const negativeWords = ['bad', 'terrible', 'awful', 'hate', 'worst', 'poor', 'cheap', 'disappointed', 'uncomfortable', 'defective', 'problems', 'issues'];

  let positiveScore = 0;
  let negativeScore = 0;

  reviews.forEach(review => {
    const text = review.text.toLowerCase();
    positiveWords.forEach(word => {
      if (text.includes(word)) positiveScore++;
    });
    negativeWords.forEach(word => {
      if (text.includes(word)) negativeScore++;
    });
  });

  // Determine overall sentiment
  let overallSentiment;
  if (averageRating >= 4.0) {
    overallSentiment = "Very Positive";
  } else if (averageRating >= 3.5) {
    overallSentiment = "Positive";
  } else if (averageRating >= 2.5) {
    overallSentiment = "Mixed";
  } else {
    overallSentiment = "Negative";
  }

  // Generate recent reviews sample
  const recentReviews = reviews.slice(-3);
  const recentQuotes = recentReviews.map(r => `"${r.text.substring(0, 100)}${r.text.length > 100 ? '...' : ''}" - ${r.author}`);

  // Build comprehensive summary
  const summary = `
## ${productTitle} - Customer Review Summary

### Overall Rating: ${averageRating}/5 stars (${totalReviews} reviews)

**Customer Sentiment:** ${overallSentiment}

### Rating Distribution:
- 5 stars: ${ratingCounts[5]} reviews (${Math.round(ratingCounts[5]/totalReviews*100)}%)
- 4 stars: ${ratingCounts[4]} reviews (${Math.round(ratingCounts[4]/totalReviews*100)}%)
- 3 stars: ${ratingCounts[3]} reviews (${Math.round(ratingCounts[3]/totalReviews*100)}%)
- 2 stars: ${ratingCounts[2]} reviews (${Math.round(ratingCounts[2]/totalReviews*100)}%)
- 1 star: ${ratingCounts[1]} reviews (${Math.round(ratingCounts[1]/totalReviews*100)}%)

### Key Insights:
${positiveReviews.length > 0 ? `**Positive Feedback (${positiveReviews.length} reviews):**
- Customers particularly appreciate: ${topWords.slice(0, 4).join(', ')}
- High satisfaction rate: ${Math.round(positiveReviews.length/totalReviews*100)}% of customers rated 4+ stars` : ''}

${negativeReviews.length > 0 ? `**Areas for Improvement (${negativeReviews.length} reviews):**
- Common concerns mentioned in lower-rated reviews
- ${Math.round(negativeReviews.length/totalReviews*100)}% of customers had concerns` : ''}

### Recent Customer Feedback:
${recentQuotes.join('\n')}

### Recommendation:
${averageRating >= 4.0 
  ? `Highly recommended product with excellent customer satisfaction. ${positiveReviews.length} out of ${totalReviews} customers gave positive reviews.`
  : averageRating >= 3.0 
  ? `Generally good product with mostly positive feedback. Consider reviewing common concerns mentioned by customers.`
  : `Product has mixed reviews. Significant improvements needed based on customer feedback.`
}

### Top Keywords: ${topWords.join(', ')}

*Analysis based on ${totalReviews} verified customer reviews*
`;

  return summary.trim();
}

/**
 * Calculate review statistics
 */
function calculateReviewStats(reviews) {
  const totalReviews = reviews.length;
  const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
  const averageRating = totalReviews > 0 ? (totalRating / totalReviews).toFixed(2) : 0;

  return {
    totalReviews,
    averageRating: parseFloat(averageRating)
  };
}

/**
 * Generate and store local summary for a product
 */
async function generateSummaryForProduct(product) {
  console.log(`📝 Generating local summary for: ${product.title}`);

  // Get all reviews for this product
  const reviews = await prisma.review.findMany({
    where: { productId: product.id },
    select: {
      rating: true,
      author: true,
      title: true,
      text: true,
      reviewDate: true
    }
  });

  if (reviews.length === 0) {
    console.log(`⚠️ No reviews found for ${product.title}, skipping...`);
    return;
  }

  try {
    // Generate local summary
    const localSummary = generateLocalSummary(reviews, product.title);
    
    // Calculate statistics
    const stats = calculateReviewStats(reviews);

    // Store in database
    await prisma.aiSummary.upsert({
      where: { productId: product.id },
      create: {
        productId: product.id,
        summary: localSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating
      },
      update: {
        summary: localSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating,
        updatedAt: new Date()
      }
    });

    console.log(`✅ Summary generated and stored for ${product.title}`);
    console.log(`📊 Stats: ${stats.totalReviews} reviews, ${stats.averageRating} avg rating`);

  } catch (error) {
    console.error(`❌ Failed to generate summary for ${product.title}:`, error.message);
  }
}

/**
 * Generate summaries for all products with reviews
 */
async function generateAllSummaries() {
  console.log("🚀 Starting local summary generation...");

  try {
    // Get all products that have reviews
    const products = await prisma.product.findMany({
      where: {
        reviews: {
          some: {}
        }
      },
      select: {
        id: true,
        title: true,
        handle: true,
        _count: {
          select: {
            reviews: true
          }
        }
      }
    });

    console.log(`📦 Found ${products.length} products with reviews`);

    if (products.length === 0) {
      console.log("⚠️ No products with reviews found");
      return;
    }

    // Generate summaries for each product
    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      console.log(`\n[${i + 1}/${products.length}] Processing: ${product.title} (${product._count.reviews} reviews)`);
      
      await generateSummaryForProduct(product);
    }

    console.log("\n🎉 Local summary generation completed!");

    // Display final stats
    const summaryCount = await prisma.aiSummary.count();
    console.log(`📈 Total summaries in database: ${summaryCount}`);

  } catch (error) {
    console.error("❌ Error in summary generation:", error);
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Generate summary for specific product by handle
 */
async function generateSummaryForSpecificProduct(productHandle) {
  try {
    const product = await prisma.product.findUnique({
      where: { handle: productHandle },
      select: { id: true, title: true, handle: true }
    });

    if (!product) {
      console.log(`❌ Product not found: ${productHandle}`);
      return;
    }

    await generateSummaryForProduct(product);

  } catch (error) {
    console.error(`❌ Error generating summary for ${productHandle}:`, error);
  } finally {
    await prisma.$disconnect();
  }
}

// Command line interface
const args = process.argv.slice(2);

if (args.length === 0) {
  // Generate summaries for all products
  generateAllSummaries();
} else if (args[0] === '--product' && args[1]) {
  // Generate summary for specific product
  generateSummaryForSpecificProduct(args[1]);
} else {
  console.log("Usage:");
  console.log("  node scripts/generate-local-summaries.js                    # All products");
  console.log("  node scripts/generate-local-summaries.js --product [handle] # Specific product");
  process.exit(1);
}