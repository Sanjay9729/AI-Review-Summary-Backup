// scripts/generate-ai-summaries.js - Updated for GROQ API
import { PrismaClient } from "@prisma/client";
import dotenv from "dotenv";

dotenv.config();

const prisma = new PrismaClient();

// GROQ API configuration
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_API_KEY = process.env.GROQ_API_KEY;

/**
 * Call GROQ AI API to generate summary
 */
async function generateSummaryWithGroq(reviews, productTitle) {
  if (!GROQ_API_KEY) {
    throw new Error("GROQ_API_KEY not found in environment variables");
  }

  const reviewsText = reviews.map(review => 
    `Rating: ${review.rating}/5
Author: ${review.author}
Review: ${review.text}
${review.title ? `Title: ${review.title}` : ''}
---`
  ).join('\n');

  const prompt = `Analyze these customer reviews for "${productTitle}" and create a comprehensive summary:

${reviewsText}

Please provide:
1. Overall sentiment analysis
2. Key positive points mentioned by customers
3. Common concerns or negative feedback
4. Average rating and review distribution
5. Recommendations for potential buyers
6. Areas for product improvement

Format the response as a well-structured summary that would be helpful for both customers and the business.`;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: "You are an expert at analyzing customer reviews and creating helpful summaries for e-commerce products."
          },
          {
            role: "user", 
            content: prompt
          }
        ],
        model: "llama-3.1-8b-instant", // Updated GROQ model
        temperature: 0.7,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`GROQ API error: ${response.status} ${response.statusText} - ${errorData}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;

  } catch (error) {
    console.error("Error calling GROQ AI:", error);
    throw error;
  }
}

/**
 * Calculate review statistics
 */
function calculateReviewStats(reviews) {
  const totalReviews = reviews.length;
  const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
  const averageRating = totalReviews > 0 ? (totalRating / totalReviews).toFixed(2) : 0;

  // Rating distribution
  const ratingDistribution = {
    5: reviews.filter(r => r.rating === 5).length,
    4: reviews.filter(r => r.rating === 4).length,
    3: reviews.filter(r => r.rating === 3).length,
    2: reviews.filter(r => r.rating === 2).length,
    1: reviews.filter(r => r.rating === 1).length
  };

  return {
    totalReviews,
    averageRating: parseFloat(averageRating),
    ratingDistribution
  };
}

/**
 * Generate and store AI summary for a product
 */
async function generateSummaryForProduct(product) {
  console.log(`🤖 Generating AI summary for: ${product.title}`);

  // Get all reviews for this product
  const reviews = await prisma.review.findMany({
    where: { productId: product.id },
    select: {
      rating: true,
      author: true,
      title: true,
      text: true,
      reviewDate: true
    }
  });

  if (reviews.length === 0) {
    console.log(`⚠️ No reviews found for ${product.title}, skipping...`);
    return;
  }

  try {
    // Generate AI summary
    const aiSummary = await generateSummaryWithGroq(reviews, product.title);
    
    // Calculate statistics
    const stats = calculateReviewStats(reviews);

    // Store in database
    await prisma.aiSummary.upsert({
      where: { productId: product.id },
      create: {
        productId: product.id,
        summary: aiSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating
      },
      update: {
        summary: aiSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating,
        updatedAt: new Date()
      }
    });

    console.log(`✅ Summary generated and stored for ${product.title}`);
    console.log(`📊 Stats: ${stats.totalReviews} reviews, ${stats.averageRating} avg rating`);

  } catch (error) {
    console.error(`❌ Failed to generate summary for ${product.title}:`, error.message);
  }
}

/**
 * Generate summaries for all products with reviews
 */
async function generateAllSummaries() {
  console.log("🚀 Starting AI summary generation...");

  try {
    // Get all products that have reviews
    const products = await prisma.product.findMany({
      where: {
        reviews: {
          some: {}
        }
      },
      select: {
        id: true,
        title: true,
        handle: true,
        _count: {
          select: {
            reviews: true
          }
        }
      }
    });

    console.log(`📦 Found ${products.length} products with reviews`);

    if (products.length === 0) {
      console.log("⚠️ No products with reviews found");
      return;
    }

    // Generate summaries for each product
    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      console.log(`\n[${i + 1}/${products.length}] Processing: ${product.title} (${product._count.reviews} reviews)`);
      
      await generateSummaryForProduct(product);
      
      // Add delay to avoid rate limiting
      if (i < products.length - 1) {
        console.log("⏳ Waiting 2 seconds...");
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    console.log("\n🎉 AI summary generation completed!");

    // Display final stats
    const summaryCount = await prisma.aiSummary.count();
    console.log(`📈 Total AI summaries in database: ${summaryCount}`);

  } catch (error) {
    console.error("❌ Error in summary generation:", error);
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Generate summary for specific product by handle
 */
async function generateSummaryForSpecificProduct(productHandle) {
  try {
    const product = await prisma.product.findUnique({
      where: { handle: productHandle },
      select: { id: true, title: true, handle: true }
    });

    if (!product) {
      console.log(`❌ Product not found: ${productHandle}`);
      return;
    }

    await generateSummaryForProduct(product);

  } catch (error) {
    console.error(`❌ Error generating summary for ${productHandle}:`, error);
  } finally {
    await prisma.$disconnect();
  }
}

// Command line interface
const args = process.argv.slice(2);

if (args.length === 0) {
  // Generate summaries for all products
  generateAllSummaries();
} else if (args[0] === '--product' && args[1]) {
  // Generate summary for specific product
  generateSummaryForSpecificProduct(args[1]);
} else {
  console.log("Usage:");
  console.log("  node scripts/generate-ai-summaries.js                    # All products");
  console.log("  node scripts/generate-ai-summaries.js --product [handle] # Specific product");
  process.exit(1);
}