// import { PassThrough } from "stream";
// import { renderToPipeableStream } from "react-dom/server";
// import { RemixServer } from "@remix-run/react";
// import { createReadableStreamFromReadable } from "@remix-run/node";
// import { isbot } from "isbot";
// import { addDocumentResponseHeaders } from "./shopify.server";

// export const streamTimeout = 5000;

// export default async function handleRequest(
//   request,
//   responseStatusCode,
//   responseHeaders,
//   remixContext,
// ) {
//   addDocumentResponseHeaders(request, responseHeaders);
//   const userAgent = request.headers.get("user-agent");
//   const callbackName = isbot(userAgent ?? "") ? "onAllReady" : "onShellReady";

//   return new Promise((resolve, reject) => {
//     const { pipe, abort } = renderToPipeableStream(
//       <RemixServer context={remixContext} url={request.url} />,
//       {
//         [callbackName]: () => {
//           const body = new PassThrough();
//           const stream = createReadableStreamFromReadable(body);

//           responseHeaders.set("Content-Type", "text/html");
//           resolve(
//             new Response(stream, {
//               headers: responseHeaders,
//               status: responseStatusCode,
//             }),
//           );
//           pipe(body);
//         },
//         onShellError(error) {
//           reject(error);
//         },
//         onError(error) {
//           responseStatusCode = 500;
//           console.error(error);
//         },
//       },
//     );

//     // Automatically timeout the React renderer after 6 seconds, which ensures
//     // React has enough time to flush down the rejected boundary contents
//     setTimeout(abort, streamTimeout + 1000);
//   });
// }


import { PassThrough } from "stream";
import { renderToPipeableStream } from "react-dom/server";
import { RemixServer } from "@remix-run/react";
import { createReadableStreamFromReadable } from "@remix-run/node";
import { isbot } from "isbot";
import { addDocumentResponseHeaders } from "./shopify.server";

// Import background jobs system
import backgroundJobs from "./services/backgroundJobs.server";

export const streamTimeout = 5000;

// Initialize background jobs on server startup
if (process.env.NODE_ENV === "production") {
  console.log("Starting background job system...");
  backgroundJobs.start();
  
  const gracefulShutdown = () => {
    console.log('Received shutdown signal, stopping background jobs...');
    backgroundJobs.stop();
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
} else {
  console.log("Development mode: Background jobs available but not auto-started");
}

export default async function handleRequest(
  request,
  responseStatusCode,
  responseHeaders,
  remixContext,
) {
  addDocumentResponseHeaders(request, responseHeaders);
  const userAgent = request.headers.get("user-agent");
  const callbackName = isbot(userAgent ?? "") ? "onAllReady" : "onShellReady";

  return new Promise((resolve, reject) => {
    const { pipe, abort } = renderToPipeableStream(
      <RemixServer context={remixContext} url={request.url} />,
      {
        [callbackName]: () => {
          const body = new PassThrough();
          const stream = createReadableStreamFromReadable(body);

          responseHeaders.set("Content-Type", "text/html");
          resolve(
            new Response(stream, {
              headers: responseHeaders,
              status: responseStatusCode,
            }),
          );
          pipe(body);
        },
        onShellError(error) {
          reject(error);
        },
        onError(error) {
          responseStatusCode = 500;
          console.error(error);
        },
      },
    );

    // Automatically timeout the React renderer after 6 seconds, which ensures
    // React has enough time to flush down the rejected boundary contents
    setTimeout(abort, streamTimeout + 1000);
  });
}