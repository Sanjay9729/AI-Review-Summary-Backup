// This makes your API accessible via app proxy
// routes/apps.ai-reviews.ai-review-summary.jsx
export { loader, action, options } from './api.ai-review-summary';