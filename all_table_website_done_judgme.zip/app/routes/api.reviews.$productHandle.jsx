// // app/routes/api.reviews.$productHandle.jsx - Original Scraping Version
// import { json } from "@remix-run/node";
// import ReviewCache from "../../services/reviewCache.server";
// import reviewScraper from "../../services/reviewScraper.server";

// // In-memory request tracking to prevent concurrent requests
// const activeRequests = new Map();

// async function scrapeProductReviews(productHandle) {
//   console.log(`Starting review scraping for product: ${productHandle}`);

//   // Check if request is already in progress
//   if (activeRequests.has(productHandle)) {
//     console.log(`Request for ${productHandle} already in progress, waiting...`);
//     return await activeRequests.get(productHandle);
//   }

//   // Create promise for this request
//   const requestPromise = reviewScraper.scrapeProductReviews(productHandle);

//   // Store the promise
//   activeRequests.set(productHandle, requestPromise);

//   try {
//     const result = await requestPromise;
//     return result;
//   } finally {
//     // Clean up the active request
//     activeRequests.delete(productHandle);
//   }
// }

// // -------------------------------
// // Loader
// // -------------------------------
// export const loader = async ({ params }) => {
//   const { productHandle } = params;
//   console.log(`API hit: reviews for ${productHandle}`);

//   const headers = {
//     "Access-Control-Allow-Origin": "*",
//     "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
//     "Access-Control-Allow-Headers": "Content-Type",
//   };

//   if (!productHandle) {
//     return json({ success: false, error: "No product handle provided" }, { headers });
//   }

//   try {
//     // First check cache
//     const cachedData = await ReviewCache.get(productHandle);
//     if (cachedData) {
//       console.log(`Cache hit for ${productHandle}: ${cachedData.reviews?.length || 0} reviews`);
//       return json(cachedData, { headers });
//     }

//     console.log(`Cache miss for ${productHandle}, scraping...`);
    
//     // If not in cache, scrape
//     const reviewsData = await scrapeProductReviews(productHandle);
//     console.log(
//       `Returning fresh data for ${productHandle}: ${reviewsData.reviews?.length || 0} reviews`
//     );
//     return json(reviewsData, { headers });
//   } catch (error) {
//     console.error(`API error for ${productHandle}:`, error);

//     return json(
//       {
//         success: false,
//         error: error.message,
//         productHandle,
//         reviews: [],
//         stats: { total: 0, average: 0 },
//       },
//       { status: 500, headers }
//     );
//   }
// };

// // -------------------------------
// // Options
// // -------------------------------
// export const options = () =>
//   new Response(null, {
//     status: 200,
//     headers: {
//       "Access-Control-Allow-Origin": "*",
//       "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
//       "Access-Control-Allow-Headers": "Content-Type",
//     },
//   });

// app/routes/api.reviews.$productHandle.jsx - Updated with Database Integration
import { json } from "@remix-run/node";
import DatabaseService from "../../services/database.server.js";
import reviewScraper from "../../services/reviewScraper.server.js";

// In-memory request tracking to prevent concurrent requests
const activeRequests = new Map();

async function getProductReviews(productHandle, forceRefresh = false) {
  console.log(`Starting review fetch for product: ${productHandle}`);

  // Check if request is already in progress
  if (activeRequests.has(productHandle)) {
    console.log(`Request for ${productHandle} already in progress, waiting...`);
    return await activeRequests.get(productHandle);
  }

  // Create promise for this request
  const requestPromise = (async () => {
    try {
      // If not forcing refresh, try database first
      if (!forceRefresh) {
        const isFresh = await DatabaseService.isCacheFresh(productHandle);
        if (isFresh) {
          console.log(`📋 Database cache hit for ${productHandle}`);
          const cachedData = await DatabaseService.getReviews(productHandle);
          if (cachedData.success) {
            return cachedData;
          }
        }
      }

      console.log(`💨 Database cache miss or force refresh for ${productHandle}, scraping...`);
      
      // Scrape fresh reviews
      const scrapedData = await reviewScraper.scrapeProductReviews(productHandle);
      
      return scrapedData;
    } catch (error) {
      console.error(`Error in getProductReviews for ${productHandle}:`, error);
      throw error;
    }
  })();

  // Store the promise
  activeRequests.set(productHandle, requestPromise);

  try {
    const result = await requestPromise;
    return result;
  } finally {
    // Clean up the active request
    activeRequests.delete(productHandle);
  }
}

// -------------------------------
// Loader
// -------------------------------
export const loader = async ({ params, request }) => {
  const { productHandle } = params;
  const normalizedHandle = productHandle.split(':')[0];
  const url = new URL(request.url);
  const forceRefresh = url.searchParams.get('forceRefresh') === 'true';

  console.log(`API hit: reviews for ${productHandle} (normalized: ${normalizedHandle})${forceRefresh ? ' (force refresh)' : ''}`);

  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (!productHandle) {
    return json({ success: false, error: "No product handle provided" }, { headers });
  }

  try {
    const reviewsData = await getProductReviews(normalizedHandle, forceRefresh);

    console.log(
      `Returning data for ${productHandle} (normalized: ${normalizedHandle}): ${reviewsData.reviews?.length || 0} reviews`
    );

    return json(reviewsData, { headers });
  } catch (error) {
    console.error(`API error for ${productHandle}:`, error);

    // Try to get any existing data from database as fallback
    try {
      const fallbackData = await DatabaseService.getReviews(normalizedHandle);
      if (fallbackData.success) {
        console.log(`Returning fallback data for ${productHandle} (normalized: ${normalizedHandle}): ${fallbackData.reviews.length} reviews`);
        return json({
          ...fallbackData,
          warning: 'Returned cached data due to scraping error',
          scrapingError: error.message
        }, { headers });
      }
    } catch (dbError) {
      console.error(`Database fallback also failed: ${dbError.message}`);
    }

    return json(
      {
        success: false,
        error: error.message,
        productHandle,
        normalizedHandle,
        reviews: [],
        stats: { total: 0, average: 0 },
      },
      { status: 500, headers }
    );
  }
};

// -------------------------------
// Action - For manual refresh operations
// -------------------------------
export const action = async ({ params, request }) => {
  const { productHandle } = params;
  const normalizedHandle = productHandle.split(':')[0];
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  try {
    const requestData = await request.json().catch(() => ({}));
    const { action } = requestData;

    switch (action) {
      case 'refresh':
        console.log(`Manual refresh requested for ${productHandle} (normalized: ${normalizedHandle})`);
        const refreshedData = await getProductReviews(normalizedHandle, true);

        return json({
          success: true,
          message: 'Reviews refreshed successfully',
          data: refreshedData,
          timestamp: new Date().toISOString()
        }, { headers });

      case 'clear':
        console.log(`Clear cache requested for ${productHandle} (normalized: ${normalizedHandle})`);
        await DatabaseService.clearProduct(normalizedHandle);

        return json({
          success: true,
          message: `Cache cleared for ${productHandle}`,
          timestamp: new Date().toISOString()
        }, { headers });

      case 'stats':
        const dbReviews = await DatabaseService.getReviews(normalizedHandle);
        if (dbReviews.success) {
          return json({
            success: true,
            stats: dbReviews.stats,
            reviewCount: dbReviews.reviews.length,
            lastCached: dbReviews.cachedAt,
            productHandle,
            normalizedHandle
          }, { headers });
        } else {
          return json({
            success: false,
            error: 'No review data found',
            productHandle,
            normalizedHandle
          }, { headers });
        }

      default:
        return json({
          success: false,
          error: 'Invalid action. Supported actions: refresh, clear, stats'
        }, { status: 400, headers });
    }
  } catch (error) {
    console.error(`Action error for ${productHandle}:`, error);

    return json({
      success: false,
      error: error.message,
      productHandle,
      normalizedHandle
    }, { status: 500, headers });
  }
};

// -------------------------------
// Options
// -------------------------------
export const options = () =>
  new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });