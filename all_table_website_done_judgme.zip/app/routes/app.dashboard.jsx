// // // app/routes/app.dashboard.jsx
// // import fs from "fs/promises";
// // import path from "path";
// // import { json } from "@remix-run/node";
// // import { useLoaderData } from "@remix-run/react";
// // import {
// //   Page,
// //   Layout,
// //   Card,
// //   IndexTable,
// //   Text,
// //   Badge,
// //   Box,
// //   InlineStack,
// //   BlockStack,
// // } from "@shopify/polaris";
// // import ReviewCache from "../../services/reviewCache.server";
// // import shopify from "../shopify.server"; // Shopify API setup

// // // Cache folder path
// // const CACHE_DIR = path.join(process.cwd(), "cache");

// // // ---------------- Loader ----------------
// // export const loader = async () => {
// //   try {
// //     const stats = await ReviewCache.getCacheStats();

// //     const files = await fs.readdir(CACHE_DIR);
// //     const aiFiles = files.filter((f) => f.startsWith("ai_summary_"));

// //     const summaries = [];
// //     for (const file of aiFiles) {
// //       const content = await fs.readFile(path.join(CACHE_DIR, file), "utf8");
// //       const data = JSON.parse(content);

// //       // 👇 fallback handle from filename
// //       const handleFromFile = file
// //         .replace("ai_summary_", "")
// //         .replace(".json", "");

// //       let productTitle = handleFromFile; // default = handle string

// //       try {
// //         const handle = data.productHandle || handleFromFile;
// //         if (handle) {
// //           const admin = await shopify.admin();
// //           const response = await admin.graphql(
// //             `#graphql
// //             query getProductTitle($handle: String!) {
// //               productByHandle(handle: $handle) {
// //                 title
// //               }
// //             }`,
// //             { variables: { handle } }
// //           );
// //           const body = await response.json();
// //           productTitle = body?.data?.productByHandle?.title || handle;
// //         }
// //       } catch (err) {
// //         console.error("❌ Product title fetch error:", err);
// //         productTitle = handleFromFile;
// //       }

// //       summaries.push({
// //         product: productTitle,
// //         summary: data.summary || "No summary",
// //         updated: new Date(data.generatedAt).toLocaleDateString("en-IN", {
// //           day: "numeric",
// //           month: "short",
// //           year: "numeric",
// //         }),
// //       });
// //     }

// //     summaries.sort((a, b) => new Date(b.updated) - new Date(a.updated));
// //     const latestSummaries = summaries.slice(0, 5);

// //     return json({
// //       totalProducts: stats?.reviewsFiles || 0,
// //       avgRating: 4.3, // TODO: calculate from reviews
// //       summariesGenerated: stats?.aiFiles || 0,
// //       latestSummaries,
// //     });
// //   } catch (err) {
// //     console.error("Dashboard loader error:", err);
// //     return json({
// //       totalProducts: 0,
// //       avgRating: 0,
// //       summariesGenerated: 0,
// //       latestSummaries: [],
// //     });
// //   }
// // };

// // // ---------------- Component ----------------
// // export default function Dashboard() {
// //   const { totalProducts, avgRating, summariesGenerated, latestSummaries } =
// //     useLoaderData();

// //   return (
// //     <Page title="Dashboard" fullWidth>
// //       <Box paddingInline="6">
// //         <Layout>
// //           {/* Overview Cards */}
// //           <Layout.Section>
// //             <InlineStack gap="400">
// //               <Card>
// //                 <BlockStack>
// //                   <Text variant="headingLg">Total Products</Text>
// //                   <Text variant="headingXl">{totalProducts}</Text>
// //                 </BlockStack>
// //               </Card>
// //               <Card>
// //                 <BlockStack>
// //                   <Text variant="headingLg">Avg Rating</Text>
// //                   <InlineStack gap="200" align="center">
// //                     <Text variant="headingXl">{avgRating}</Text>
// //                     <Badge tone="warning">★</Badge>
// //                   </InlineStack>
// //                 </BlockStack>
// //               </Card>
// //               <Card>
// //                 <BlockStack>
// //                   <Text variant="headingLg">AI Summaries</Text>
// //                   <Text variant="headingXl">{summariesGenerated}</Text>
// //                 </BlockStack>
// //               </Card>
// //             </InlineStack>
// //           </Layout.Section>

// //           {/* Latest Summaries Table */}
// //           <Layout.Section>
// //             <Card title="Latest AI Summaries">
// //               {latestSummaries.length === 0 ? (
// //                 <Text tone="subdued">No summaries available yet.</Text>
// //               ) : (
// //                 <IndexTable
// //                   resourceName={{ singular: "summary", plural: "summaries" }}
// //                   itemCount={latestSummaries.length}
// //                   selectable={false}
// //                   headings={[
// //                     { title: "Product" },
// //                     { title: "Summary" },
// //                     { title: "Updated" },
// //                   ]}
// //                 >
// //                   {latestSummaries.map((s, index) => (
// //                     <IndexTable.Row
// //                       id={index.toString()}
// //                       key={index}
// //                       position={index}
// //                     >
// //                       <IndexTable.Cell>
// //                         <Text variant="bodyMd" fontWeight="bold" truncate>
// //                           {s.product}
// //                         </Text>
// //                       </IndexTable.Cell>
// //                       <IndexTable.Cell>
// //                         {/* ✅ Wrap like Shopify Reviews */}
// //                         <Box 
// //                           as="p"
// //                           overflowWrap="break-word"
// //                           style={{ whiteSpace: "normal", margin: 0 }}
// //                         >
// //                           {s.summary}
// //                         </Box>
// //                       </IndexTable.Cell>
// //                       <IndexTable.Cell>
// //                         <Text variant="bodyMd">{s.updated}</Text>
// //                       </IndexTable.Cell>
// //                     </IndexTable.Row>
// //                   ))}
// //                 </IndexTable>
// //               )}
// //             </Card>
// //           </Layout.Section>
// //         </Layout>
// //       </Box>
// //     </Page>
// //   );
// // }


// // app/routes/app.dashboard.jsx
// import fs from "fs/promises";
// import path from "path";
// import { json } from "@remix-run/node";
// import { useLoaderData } from "@remix-run/react";
// import {
//   Page,
//   Layout,
//   Card,
//   IndexTable,
//   Text,
//   Badge,
//   Box,
//   InlineStack,
//   BlockStack,
// } from "@shopify/polaris";
// import ReviewCache from "../../services/reviewCache.server";
// import shopify from "../shopify.server"; // Shopify API setup

// // Cache folder path
// const CACHE_DIR = path.join(process.cwd(), "cache");

// // ---------------- Loader ----------------
// export const loader = async () => {
//   try {
//     const stats = await ReviewCache.getCacheStats();

//     const files = await fs.readdir(CACHE_DIR);
//     const aiFiles = files.filter((f) => f.startsWith("ai_summary_"));

//     const summaries = [];
//     for (const file of aiFiles) {
//       const content = await fs.readFile(path.join(CACHE_DIR, file), "utf8");
//       const data = JSON.parse(content);

//       // 👇 fallback handle from filename
//       const handleFromFile = file
//         .replace("ai_summary_", "")
//         .replace(".json", "");

//       let productTitle = handleFromFile; // default = handle string

//       try {
//         const handle = data.productHandle || handleFromFile;
//         if (handle) {
//           const admin = await shopify.admin();
//           const response = await admin.graphql(
//             `#graphql
//             query getProductTitle($handle: String!) {
//               productByHandle(handle: $handle) {
//                 title
//               }
//             }`,
//             { variables: { handle } }
//           );
//           const body = await response.json();
//           productTitle = body?.data?.productByHandle?.title || handle;
//         }
//       } catch (err) {
//         console.error("❌ Product title fetch error:", err);
//         productTitle = handleFromFile;
//       }

//       summaries.push({
//         product: productTitle,
//         summary: data.summary || "No summary",
//         updated: new Date(data.generatedAt).toLocaleDateString("en-IN", {
//           day: "numeric",
//           month: "short",
//           year: "numeric",
//         }),
//       });
//     }

//     summaries.sort((a, b) => new Date(b.updated) - new Date(a.updated));
//     const latestSummaries = summaries.slice(0, 5);

//     return json({
//       totalProducts: stats?.reviewsFiles || 0,
//       avgRating: 4.3, // TODO: calculate from reviews
//       summariesGenerated: stats?.aiFiles || 0,
//       latestSummaries,
//     });
//   } catch (err) {
//     console.error("Dashboard loader error:", err);
//     return json({
//       totalProducts: 0,
//       avgRating: 0,
//       summariesGenerated: 0,
//       latestSummaries: [],
//     });
//   }
// };

// // ---------------- Component ----------------
// export default function Dashboard() {
//   const { totalProducts, avgRating, summariesGenerated, latestSummaries } =
//     useLoaderData();

//   return (
//     <Page title="Dashboard" fullWidth>
//       <Box paddingInline="6">
//         <Layout>
//           {/* Overview Cards */}
//           <Layout.Section>
//             <InlineStack gap="400">
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">Total Products</Text>
//                   <Text variant="headingXl">{totalProducts}</Text>
//                 </BlockStack>
//               </Card>
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">Avg Rating</Text>
//                   <InlineStack gap="200" align="center">
//                     <Text variant="headingXl">{avgRating}</Text>
//                     <Badge tone="warning">★</Badge>
//                   </InlineStack>
//                 </BlockStack>
//               </Card>
//               <Card>
//                 <BlockStack>
//                   <Text variant="headingLg">AI Summaries</Text>
//                   <Text variant="headingXl">{summariesGenerated}</Text>
//                 </BlockStack>
//               </Card>
//             </InlineStack>
//           </Layout.Section>

//           {/* Latest Summaries Table */}
//           <Layout.Section>
//             <Card title="Latest AI Summaries">
//               {latestSummaries.length === 0 ? (
//                 <Text tone="subdued">No summaries available yet.</Text>
//               ) : (
//                 <IndexTable
//                   resourceName={{ singular: "summary", plural: "summaries" }}
//                   itemCount={latestSummaries.length}
//                   selectable={false}
//                   headings={[
//                     { title: "Product" },
//                     { title: "Ai Summary Reviews" },
//                     { title: "Updated" },
//                   ]}
//                 >
//                   {latestSummaries.map((s, index) => (
//                     <IndexTable.Row
//                       id={index.toString()}
//                       key={index}
//                       position={index}
//                     >
//                       {/* Product Column */}
//                       <IndexTable.Cell>
//                         <Box paddingInline="6">
//                           <Text variant="bodyMd" fontWeight="bold" truncate >
//                             {s.product}
//                           </Text>
//                         </Box>
//                       </IndexTable.Cell>

//                       {/* Summary Column */}
//                       <IndexTable.Cell>
//                         <Box
//                           as="p"
//                           paddingInline="6"
//                           overflowWrap="break-word"
//                           style={{ whiteSpace: "normal", margin: 0 }}
//                         >
//                           {s.summary}
//                         </Box>
//                       </IndexTable.Cell>

//                       {/* Updated Column */}
//                       <IndexTable.Cell>
//                         <Box paddingInline="6">
//                           <Text variant="bodyMd">{s.updated}</Text>
//                         </Box>
//                       </IndexTable.Cell>
//                     </IndexTable.Row>
//                   ))}
//                 </IndexTable>
//               )}
//             </Card>
//           </Layout.Section>
//         </Layout>
//       </Box>
//     </Page>
//   );
// }


// app/routes/app.dashboard.jsx - Updated with Database Integration
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  IndexTable,
  Text,
  Badge,
  Box,
  InlineStack,
  BlockStack,
} from "@shopify/polaris";
import DatabaseService from "../../services/database.server.js";
import shopify from "../shopify.server";

// ---------------- Loader ----------------
export const loader = async () => {
  try {
    // Get database statistics
    const dbStats = await DatabaseService.getStats();

    // Get latest AI summaries with product details
    const latestSummaries = [];
    
    if (dbStats.recentReviews && dbStats.recentReviews.length > 0) {
      // Get unique product handles from recent reviews
      const recentProductHandles = [...new Set(
        dbStats.recentReviews
          .map(r => r.product)
          .filter(Boolean)
      )].slice(0, 5);

      // For each product, try to get AI summary and product details
      for (const productHandle of recentProductHandles) {
        try {
          // Get AI summary from database
          const aiSummary = await DatabaseService.getAISummary(productHandle);
          
          let productTitle = productHandle;
          
          // Try to get product title from Shopify
          try {
            const admin = await shopify.admin();
            const response = await admin.graphql(
              `#graphql
              query getProductTitle($handle: String!) {
                productByHandle(handle: $handle) {
                  title
                }
              }`,
              { variables: { handle: productHandle } }
            );
            const body = await response.json();
            productTitle = body?.data?.productByHandle?.title || productHandle.replace(/-/g, ' ');
          } catch (err) {
            console.error(`Error fetching product title for ${productHandle}:`, err);
            productTitle = productHandle.replace(/-/g, ' ');
          }

          if (aiSummary && aiSummary.success) {
            latestSummaries.push({
              product: productTitle,
              summary: aiSummary.summary || "No summary available",
              updated: new Date(aiSummary.generatedAt).toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
              }),
              reviewsAnalyzed: aiSummary.reviewsAnalyzed || 0,
              totalReviews: aiSummary.totalReviews || 0,
              averageRating: aiSummary.averageRating || 0,
              productHandle: productHandle
            });
          }
        } catch (error) {
          console.error(`Error processing AI summary for ${productHandle}:`, error);
        }
      }
    }

    // Sort by update date (most recent first)
    latestSummaries.sort((a, b) => new Date(b.updated) - new Date(a.updated));

    // Calculate average rating from recent reviews
    let avgRating = 4.3; // Default fallback
    if (dbStats.recentReviews && dbStats.recentReviews.length > 0) {
      const ratings = dbStats.recentReviews
        .map(r => r.rating)
        .filter(r => r && r > 0);
      
      if (ratings.length > 0) {
        avgRating = ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length;
        avgRating = Math.round(avgRating * 10) / 10;
      }
    }

    return json({
      totalProducts: dbStats.totalProducts || 0,
      totalReviews: dbStats.totalReviews || 0,
      avgRating: avgRating,
      summariesGenerated: dbStats.aiSummaries || 0,
      latestSummaries: latestSummaries.slice(0, 5),
      databaseStats: {
        totalProducts: dbStats.totalProducts,
        totalReviews: dbStats.totalReviews,
        aiSummaries: dbStats.aiSummaries,
        lastUpdated: dbStats.lastUpdated
      }
    });
  } catch (err) {
    console.error("Dashboard loader error:", err);
    return json({
      totalProducts: 0,
      totalReviews: 0,
      avgRating: 0,
      summariesGenerated: 0,
      latestSummaries: [],
      databaseStats: null,
      error: err.message
    });
  }
};

// ---------------- Component ----------------
export default function Dashboard() {
  const { 
    totalProducts, 
    totalReviews, 
    avgRating, 
    summariesGenerated, 
    latestSummaries,
    databaseStats,
    error 
  } = useLoaderData();

  return (
    <Page title="Dashboard" fullWidth>
      <Box paddingInline="6">
        <Layout>
          {/* Error Banner */}
          {error && (
            <Layout.Section>
              <Card>
                <BlockStack>
                  <Text variant="headingMd" tone="critical">
                    Database Error
                  </Text>
                  <Text tone="subdued">
                    {error}
                  </Text>
                </BlockStack>
              </Card>
            </Layout.Section>
          )}

          {/* Overview Cards */}
          <Layout.Section>
            <InlineStack gap="400">
              <Card>
                <BlockStack>
                  <Text variant="headingLg">Total Products</Text>
                  <Text variant="headingXl">{totalProducts}</Text>
                  <Text variant="bodySm" tone="subdued">
                    In database
                  </Text>
                </BlockStack>
              </Card>
              
              <Card>
                <BlockStack>
                  <Text variant="headingLg">Total Reviews</Text>
                  <Text variant="headingXl">{totalReviews}</Text>
                  <Text variant="bodySm" tone="subdued">
                    Scraped reviews
                  </Text>
                </BlockStack>
              </Card>
              
              <Card>
                <BlockStack>
                  <Text variant="headingLg">Avg Rating</Text>
                  <InlineStack gap="200" align="center">
                    <Text variant="headingXl">{avgRating}</Text>
                    <Badge tone="warning">★</Badge>
                  </InlineStack>
                  <Text variant="bodySm" tone="subdued">
                    Across all products
                  </Text>
                </BlockStack>
              </Card>
              
              <Card>
                <BlockStack>
                  <Text variant="headingLg">AI Summaries</Text>
                  <Text variant="headingXl">{summariesGenerated}</Text>
                  <Text variant="bodySm" tone="subdued">
                    Generated summaries
                  </Text>
                </BlockStack>
              </Card>
            </InlineStack>
          </Layout.Section>

          {/* Latest AI Summaries Table */}
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <InlineStack align="space-between">
                  <Text as="h2" variant="headingLg">
                    Latest AI Summaries
                  </Text>
                  {databaseStats?.lastUpdated && (
                    <Text variant="bodySm" tone="subdued">
                      Last updated: {new Date(databaseStats.lastUpdated).toLocaleString("en-IN")}
                    </Text>
                  )}
                </InlineStack>

                {latestSummaries.length === 0 ? (
                  <Box padding="800">
                    <BlockStack align="center">
                      <Text variant="headingMd" tone="subdued">
                        No AI summaries available yet
                      </Text>
                      <Text tone="subdued">
                        Start by scraping some product reviews to generate AI summaries.
                      </Text>
                    </BlockStack>
                  </Box>
                ) : (
                  <IndexTable
                    resourceName={{ singular: "summary", plural: "summaries" }}
                    itemCount={latestSummaries.length}
                    selectable={false}
                    headings={[
                      { title: "Product" },
                      { title: "AI Summary" },
                      { title: "Reviews Used" },
                      { title: "Rating" },
                      { title: "Updated" },
                    ]}
                  >
                    {latestSummaries.map((summary, index) => (
                      <IndexTable.Row
                        id={index.toString()}
                        key={index}
                        position={index}
                      >
                        {/* Product Column */}
                        <IndexTable.Cell>
                          <Box paddingInline="6">
                            <BlockStack gap="100">
                              <Text variant="bodyMd" fontWeight="bold" truncate>
                                {summary.product}
                              </Text>
                              {summary.productHandle && (
                                <Text variant="bodySm" tone="subdued">
                                  {summary.productHandle}
                                </Text>
                              )}
                            </BlockStack>
                          </Box>
                        </IndexTable.Cell>

                        {/* Summary Column */}
                        <IndexTable.Cell>
                          <Box
                            as="div"
                            paddingInline="6"
                            overflowWrap="break-word"
                            style={{ whiteSpace: "normal" }}
                          >
                            <Text variant="bodyMd">
                              {summary.summary.length > 150
                                ? `${summary.summary.substring(0, 150)}...`
                                : summary.summary
                              }
                            </Text>
                          </Box>
                        </IndexTable.Cell>

                        {/* Reviews Used Column */}
                        <IndexTable.Cell>
                          <Box paddingInline="6">
                            <BlockStack gap="100">
                              <Text variant="bodyMd" fontWeight="medium">
                                {summary.reviewsAnalyzed} / {summary.totalReviews}
                              </Text>
                              <Text variant="bodySm" tone="subdued">
                                analyzed / total
                              </Text>
                            </BlockStack>
                          </Box>
                        </IndexTable.Cell>

                        {/* Rating Column */}
                        <IndexTable.Cell>
                          <Box paddingInline="6">
                            <InlineStack gap="200" align="center">
                              <Text variant="bodyMd" fontWeight="medium">
                                {summary.averageRating}
                              </Text>
                              <Badge tone="warning">★</Badge>
                            </InlineStack>
                          </Box>
                        </IndexTable.Cell>

                        {/* Updated Column */}
                        <IndexTable.Cell>
                          <Box paddingInline="6">
                            <Text variant="bodyMd">{summary.updated}</Text>
                          </Box>
                        </IndexTable.Cell>
                      </IndexTable.Row>
                    ))}
                  </IndexTable>
                )}
              </BlockStack>
            </Card>
          </Layout.Section>

          {/* Database Statistics */}
          {databaseStats && (
            <Layout.Section variant="oneThird">
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingLg">
                    Database Statistics
                  </Text>
                  
                  <BlockStack gap="300">
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Products Tracked</Text>
                      <Badge tone="info">{databaseStats.totalProducts}</Badge>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Reviews Stored</Text>
                      <Badge tone="success">{databaseStats.totalReviews}</Badge>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">AI Summaries</Text>
                      <Badge tone="attention">{databaseStats.aiSummaries}</Badge>
                    </InlineStack>
                    
                    <InlineStack align="space-between">
                      <Text variant="bodyMd">Storage Type</Text>
                      <Badge tone="info">PostgreSQL</Badge>
                    </InlineStack>
                  </BlockStack>

                  <Text variant="bodySm" tone="subdued">
                    All data is stored in PostgreSQL database with automatic caching and refresh mechanisms.
                  </Text>
                </BlockStack>
              </Card>
            </Layout.Section>
          )}

          {/* System Status */}
          <Layout.Section variant="oneThird">
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">
                  System Status
                </Text>
                
                <BlockStack gap="300">
                  <InlineStack align="space-between">
                    <Text variant="bodyMd">Database</Text>
                    <Badge tone={databaseStats ? "success" : "critical"}>
                      {databaseStats ? "Connected" : "Error"}
                    </Badge>
                  </InlineStack>
                  
                  <InlineStack align="space-between">
                    <Text variant="bodyMd">Review Scraping</Text>
                    <Badge tone="success">Active</Badge>
                  </InlineStack>
                  
                  <InlineStack align="space-between">
                    <Text variant="bodyMd">AI Generation</Text>
                    <Badge tone="success">Available</Badge>
                  </InlineStack>
                  
                  <InlineStack align="space-between">
                    <Text variant="bodyMd">Background Jobs</Text>
                    <Badge tone="info">Running</Badge>
                  </InlineStack>
                </BlockStack>

                <Text variant="bodySm" tone="subdued">
                  System is running normally. Reviews are automatically scraped and AI summaries generated on demand.
                </Text>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      </Box>
    </Page>
  );
}