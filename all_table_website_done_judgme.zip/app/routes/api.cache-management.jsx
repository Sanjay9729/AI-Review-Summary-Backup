// // app/routes/api.cache-management.jsx
// import { json } from "@remix-run/node";
// import ReviewCache from "../../services/reviewCache.server";
// import backgroundJobs from "../../services/backgroundJobs.server";

// export const action = async ({ request }) => {
//   const headers = {
//     'Access-Control-Allow-Origin': '*',
//     'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
//     'Access-Control-Allow-Headers': 'Content-Type',
//   };

//   try {
//     const { action, productHandle, options = {} } = await request.json();

//     switch (action) {
//       case 'clear':
//         if (productHandle) {
//           await ReviewCache.clear(productHandle);
//           return json({
//             success: true,
//             message: `Cache cleared for ${productHandle}`
//           }, { headers });
//         } else {
//           await ReviewCache.clearAll();
//           return json({
//             success: true,
//             message: 'All cache cleared'
//           }, { headers });
//         }

//       case 'force-refresh':
//         if (!productHandle) {
//           return json({
//             success: false,
//             error: 'Product handle required for force refresh'
//           }, { status: 400, headers });
//         }

//         console.log(`Force refreshing ${productHandle}...`);
//         const refreshResult = await ReviewCache.forceRefresh(productHandle);
        
//         return json({
//           success: refreshResult.success,
//           message: refreshResult.success ? 
//             `Successfully refreshed ${productHandle}` : 
//             `Failed to refresh ${productHandle}`,
//           data: refreshResult.data,
//           error: refreshResult.error
//         }, { headers });

//       case 'check-freshness':
//         if (!productHandle) {
//           return json({
//             success: false,
//             error: 'Product handle required for freshness check'
//           }, { status: 400, headers });
//         }

//         const cachedData = await ReviewCache.get(productHandle);
//         if (!cachedData) {
//           return json({
//             success: true,
//             fresh: false,
//             message: 'No cached data found'
//           }, { headers });
//         }

//         const isFresh = await ReviewCache.validateCacheFreshness(productHandle, cachedData);
//         return json({
//           success: true,
//           fresh: isFresh,
//           message: isFresh ? 'Cache is fresh' : 'Cache is stale',
//           cachedAt: cachedData.cachedAt,
//           reviewCount: cachedData.reviews?.length || 0
//         }, { headers });

//       case 'batch-refresh':
//         const { productHandles = [] } = options;
//         if (!Array.isArray(productHandles) || productHandles.length === 0) {
//           return json({
//             success: false,
//             error: 'Product handles array required for batch refresh'
//           }, { status: 400, headers });
//         }

//         console.log(`Batch refreshing ${productHandles.length} products...`);
//         const batchResults = [];

//         for (const handle of productHandles) {
//           try {
//             const result = await ReviewCache.forceRefresh(handle);
//             batchResults.push({
//               productHandle: handle,
//               success: result.success,
//               error: result.error
//             });
//           } catch (error) {
//             batchResults.push({
//               productHandle: handle,
//               success: false,
//               error: error.message
//             });
//           }
//         }

//         const successCount = batchResults.filter(r => r.success).length;
//         return json({
//           success: true,
//           message: `Batch refresh completed: ${successCount}/${productHandles.length} successful`,
//           results: batchResults
//         }, { headers });

//       case 'background-job-status':
//         const jobStatus = backgroundJobs.getStatus();
//         return json({
//           success: true,
//           status: jobStatus
//         }, { headers });

//       case 'start-background-jobs':
//         backgroundJobs.start();
//         return json({
//           success: true,
//           message: 'Background jobs started'
//         }, { headers });

//       case 'stop-background-jobs':
//         backgroundJobs.stop();
//         return json({
//           success: true,
//           message: 'Background jobs stopped'
//         }, { headers });

//       case 'run-background-check':
//         console.log('Manually triggering background review check...');
//         await ReviewCache.checkAllProductsForUpdates();
//         return json({
//           success: true,
//           message: 'Background review check completed'
//         }, { headers });

//       default:
//         return json({
//           success: false,
//           error: 'Invalid action'
//         }, { status: 400, headers });
//     }
//   } catch (error) {
//     console.error('Cache management API error:', error);
//     return json({
//       success: false,
//       error: error.message
//     }, { status: 500, headers });
//   }
// };

// export const loader = async ({ request }) => {
//   const url = new URL(request.url);
//   const action = url.searchParams.get('action');
  
//   const headers = {
//     'Access-Control-Allow-Origin': '*',
//     'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
//     'Access-Control-Allow-Headers': 'Content-Type',
//   };

//   try {
//     switch (action) {
//       case 'stats':
//         const stats = await ReviewCache.getCacheStats();
//         return json({
//           success: true,
//           stats
//         }, { headers });

//       case 'background-status':
//         const jobStatus = backgroundJobs.getStatus();
//         return json({
//           success: true,
//           backgroundJobs: jobStatus
//         }, { headers });

//       default:
//         return json({
//           success: false,
//           error: 'Invalid action for GET request'
//         }, { status: 400, headers });
//     }
//   } catch (error) {
//     return json({
//       success: false,
//       error: error.message
//     }, { status: 500, headers });
//   }
// };

// export const options = () => {
//   return new Response(null, {
//     status: 200,
//     headers: {
//       'Access-Control-Allow-Origin': '*',
//       'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
//       'Access-Control-Allow-Headers': 'Content-Type',
//     },
//   });
// };


// app/routes/api.cache-management.jsx - Updated with Database Integration
import { json } from "@remix-run/node";
import DatabaseService from "../../services/database.server.js";
import backgroundJobs from "../../services/backgroundJobs.server.js";

export const action = async ({ request }) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    const { action, productHandle, options = {} } = await request.json();

    switch (action) {
      case 'clear':
        if (productHandle) {
          await DatabaseService.clearProduct(productHandle);
          return json({
            success: true,
            message: `Database cache cleared for ${productHandle}`
          }, { headers });
        } else {
          await DatabaseService.clearAll();
          return json({
            success: true,
            message: 'All database cache cleared'
          }, { headers });
        }

      case 'force-refresh':
        if (!productHandle) {
          return json({
            success: false,
            error: 'Product handle required for force refresh'
          }, { status: 400, headers });
        }

        console.log(`Force refreshing ${productHandle}...`);
        
        try {
          // Import scraper dynamically to avoid circular dependencies
          const reviewScraperModule = await import('../../services/reviewScraper.server.js');
          const freshData = await reviewScraperModule.default.scrapeProductReviews(productHandle);
          
          if (freshData.success) {
            return json({
              success: true,
              message: `Successfully refreshed ${productHandle}`,
              data: {
                reviewCount: freshData.reviews?.length || 0,
                averageRating: freshData.stats?.average || 0,
                scrapedAt: freshData.scrapedAt
              }
            }, { headers });
          } else {
            return json({
              success: false,
              message: `Failed to refresh ${productHandle}`,
              error: freshData.error
            }, { headers });
          }
        } catch (error) {
          return json({
            success: false,
            message: `Failed to refresh ${productHandle}`,
            error: error.message
          }, { headers });
        }

      case 'check-freshness':
        if (!productHandle) {
          return json({
            success: false,
            error: 'Product handle required for freshness check'
          }, { status: 400, headers });
        }

        const isFresh = await DatabaseService.isCacheFresh(productHandle);
        const reviewsData = await DatabaseService.getReviews(productHandle);
        
        return json({
          success: true,
          fresh: isFresh,
          message: isFresh ? 'Cache is fresh' : 'Cache is stale',
          data: reviewsData.success ? {
            cachedAt: reviewsData.cachedAt,
            reviewCount: reviewsData.reviews?.length || 0,
            averageRating: reviewsData.stats?.average || 0
          } : null
        }, { headers });

      case 'batch-refresh':
        const { productHandles = [] } = options;
        if (!Array.isArray(productHandles) || productHandles.length === 0) {
          return json({
            success: false,
            error: 'Product handles array required for batch refresh'
          }, { status: 400, headers });
        }

        console.log(`Batch refreshing ${productHandles.length} products...`);
        const batchResults = [];

        // Import scraper for batch operations
        const reviewScraperModule = await import('../../services/reviewScraper.server.js');

        for (const handle of productHandles) {
          try {
            const result = await reviewScraperModule.default.scrapeProductReviews(handle);
            batchResults.push({
              productHandle: handle,
              success: result.success,
              reviewCount: result.reviews?.length || 0,
              error: result.error || null
            });
          } catch (error) {
            batchResults.push({
              productHandle: handle,
              success: false,
              reviewCount: 0,
              error: error.message
            });
          }
        }

        const successCount = batchResults.filter(r => r.success).length;
        return json({
          success: true,
          message: `Batch refresh completed: ${successCount}/${productHandles.length} successful`,
          results: batchResults,
          summary: {
            total: productHandles.length,
            successful: successCount,
            failed: productHandles.length - successCount
          }
        }, { headers });

      case 'background-job-status':
        const jobStatus = backgroundJobs.getStatus();
        return json({
          success: true,
          status: jobStatus
        }, { headers });

      case 'start-background-jobs':
        backgroundJobs.start();
        return json({
          success: true,
          message: 'Background jobs started'
        }, { headers });

      case 'stop-background-jobs':
        backgroundJobs.stop();
        return json({
          success: true,
          message: 'Background jobs stopped'
        }, { headers });

      case 'run-background-check':
        console.log('Manually triggering background review check...');
        
        try {
          // Get products that need refresh
          const productsNeedingRefresh = await DatabaseService.getProductsNeedingRefresh();
          console.log(`Found ${productsNeedingRefresh.length} products needing refresh`);
          
          let refreshed = 0;
          const reviewScraperModule = await import('../../services/reviewScraper.server.js');
          
          for (const productHandle of productsNeedingRefresh.slice(0, 10)) { // Limit to 10 at a time
            try {
              const result = await reviewScraperModule.default.scrapeProductReviews(productHandle);
              if (result.success) refreshed++;
            } catch (error) {
              console.error(`Background refresh failed for ${productHandle}:`, error);
            }
          }
          
          return json({
            success: true,
            message: `Background review check completed: ${refreshed}/${productsNeedingRefresh.length} refreshed`,
            details: {
              totalChecked: productsNeedingRefresh.length,
              refreshed: refreshed,
              processed: Math.min(productsNeedingRefresh.length, 10)
            }
          }, { headers });
        } catch (error) {
          return json({
            success: false,
            message: 'Background check failed',
            error: error.message
          }, { headers });
        }

      case 'get-stale-products':
        try {
          const staleProducts = await DatabaseService.getProductsNeedingRefresh();
          return json({
            success: true,
            products: staleProducts,
            count: staleProducts.length,
            message: `Found ${staleProducts.length} products needing refresh`
          }, { headers });
        } catch (error) {
          return json({
            success: false,
            error: error.message
          }, { headers });
        }

      case 'database-stats':
        try {
          const stats = await DatabaseService.getStats();
          return json({
            success: true,
            stats: stats
          }, { headers });
        } catch (error) {
          return json({
            success: false,
            error: error.message
          }, { headers });
        }

      default:
        return json({
          success: false,
          error: 'Invalid action'
        }, { status: 400, headers });
    }
  } catch (error) {
    console.error('Cache management API error:', error);
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  }
};

export const loader = async ({ request }) => {
  const url = new URL(request.url);
  const action = url.searchParams.get('action');
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    switch (action) {
      case 'stats':
        const stats = await DatabaseService.getStats();
        return json({
          success: true,
          stats
        }, { headers });

      case 'background-status':
        const jobStatus = backgroundJobs.getStatus();
        return json({
          success: true,
          backgroundJobs: jobStatus
        }, { headers });

      case 'health-check':
        // Check database connection
        try {
          await DatabaseService.getStats(); // This will test the connection
          return json({
            success: true,
            message: 'Database connection healthy',
            timestamp: new Date().toISOString()
          }, { headers });
        } catch (error) {
          return json({
            success: false,
            error: 'Database connection failed',
            details: error.message
          }, { status: 500, headers });
        }

      default:
        return json({
          success: false,
          error: 'Invalid action for GET request. Available: stats, background-status, health-check'
        }, { status: 400, headers });
    }
  } catch (error) {
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  }
};

export const options = () => {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
};