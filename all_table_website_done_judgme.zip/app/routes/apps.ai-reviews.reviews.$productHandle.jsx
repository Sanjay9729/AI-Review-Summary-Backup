// This makes your API accessible via app proxy
// routes/apps.ai-reviews.reviews.$productHandle.jsx
export { loader } from './api.reviews.$productHandle';