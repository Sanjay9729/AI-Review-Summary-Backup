// app/routes/api.dashboard.jsx - Database Dashboard API
import { json } from "@remix-run/node";
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const loader = async ({ request }) => {
  const url = new URL(request.url);
  const action = url.searchParams.get('action') || 'stats';
  
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  try {
    switch (action) {
      case 'stats':
        return await getDashboardStats(headers);
      
      case 'products':
        return await getProductsList(headers);
      
      case 'recent-reviews':
        return await getRecentReviews(headers);
      
      case 'test-connection':
        return await testConnection(headers);
      
      default:
        return json({
          success: false,
          error: 'Invalid action. Available: stats, products, recent-reviews, test-connection'
        }, { status: 400, headers });
    }
  } catch (error) {
    console.error('Dashboard API error:', error);
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  } finally {
    await prisma.$disconnect();
  }
};

async function getDashboardStats(headers) {
  try {
    const [productCount, reviewCount, aiSummaryCount] = await Promise.all([
      prisma.product.count(),
      prisma.review.count(),
      prisma.aiSummary.count()
    ]);

    // Calculate average rating across all reviews
    const avgResult = await prisma.review.aggregate({
      _avg: {
        rating: true
      }
    });

    // Get products with most reviews
    const topProducts = await prisma.product.findMany({
      include: {
        reviews: true,
        cacheMetadata: true
      },
      orderBy: {
        reviews: {
          _count: 'desc'
        }
      },
      take: 5
    });

    // Get recent activity
    const recentReviews = await prisma.review.findMany({
      take: 5,
      orderBy: { scrapedAt: 'desc' },
      include: {
        product: {
          select: { title: true, handle: true }
        }
      }
    });

    return json({
      success: true,
      stats: {
        totalProducts: productCount,
        totalReviews: reviewCount,
        aiSummaries: aiSummaryCount,
        averageRating: avgResult._avg.rating ? Math.round(avgResult._avg.rating * 10) / 10 : 0
      },
      topProducts: topProducts.map(p => ({
        handle: p.handle,
        title: p.title,
        reviewCount: p.reviews.length,
        averageRating: p.cacheMetadata?.averageRating || 0,
        lastScraped: p.cacheMetadata?.lastScraped
      })),
      recentActivity: recentReviews.map(r => ({
        product: r.product.title,
        productHandle: r.product.handle,
        author: r.author,
        rating: r.rating,
        text: r.text.substring(0, 100) + (r.text.length > 100 ? '...' : ''),
        scrapedAt: r.scrapedAt.toISOString()
      })),
      timestamp: new Date().toISOString()
    }, { headers });
  } catch (error) {
    throw error;
  }
}

async function getProductsList(headers) {
  try {
    const products = await prisma.product.findMany({
      include: {
        reviews: true,
        cacheMetadata: true,
        aiSummaries: true
      },
      orderBy: { updatedAt: 'desc' }
    });

    return json({
      success: true,
      products: products.map(p => ({
        id: p.id,
        handle: p.handle,
        title: p.title,
        status: p.status,
        reviewCount: p.reviews.length,
        averageRating: p.cacheMetadata?.averageRating || 0,
        hasAiSummary: p.aiSummaries.length > 0,
        lastScraped: p.cacheMetadata?.lastScraped,
        isStale: p.cacheMetadata?.isStale || false,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString()
      })),
      count: products.length,
      timestamp: new Date().toISOString()
    }, { headers });
  } catch (error) {
    throw error;
  }
}

async function getRecentReviews(headers) {
  try {
    const reviews = await prisma.review.findMany({
      take: 20,
      orderBy: { scrapedAt: 'desc' },
      include: {
        product: {
          select: { title: true, handle: true }
        }
      }
    });

    return json({
      success: true,
      reviews: reviews.map(r => ({
        id: r.id,
        product: r.product.title,
        productHandle: r.product.handle,
        author: r.author,
        rating: r.rating,
        title: r.title,
        text: r.text,
        verified: r.verified,
        platform: r.platform,
        reviewDate: r.reviewDate,
        scrapedAt: r.scrapedAt.toISOString()
      })),
      count: reviews.length,
      timestamp: new Date().toISOString()
    }, { headers });
  } catch (error) {
    throw error;
  }
}

async function testConnection(headers) {
  try {
    await prisma.$queryRaw`SELECT 1`;
    
    return json({
      success: true,
      message: 'Database connection successful',
      database: 'PostgreSQL',
      timestamp: new Date().toISOString()
    }, { headers });
  } catch (error) {
    return json({
      success: false,
      error: 'Database connection failed',
      details: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500, headers });
  }
}

export const options = () => {
  return new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
};