// Quick script to list products
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function listProducts() {
  try {
    const products = await prisma.product.findMany({
      select: {
        handle: true,
        title: true,
        id: true
      }
    });

    console.log(`Found ${products.length} products:`);
    products.forEach(p => {
      console.log(`- ${p.handle}: ${p.title} (ID: ${p.id})`);
    });

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

listProducts();