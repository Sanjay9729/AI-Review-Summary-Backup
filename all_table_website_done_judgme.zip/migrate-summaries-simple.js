import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import 'dotenv/config';

const prisma = new PrismaClient();

async function migrateSummaries() {
  try {
    console.log('Migrating AI summaries from cache files to database...\n');

    const cacheDir = path.join(process.cwd(), 'cache');
    const files = fs.readdirSync(cacheDir).filter(f => f.startsWith('ai_summary_'));

    console.log(`Found ${files.length} cache files\n`);

    for (const file of files) {
      const filePath = path.join(cacheDir, file);
      const productHandle = file.replace('ai_summary_', '').replace('.json', '');

      console.log(`Processing ${productHandle}...`);

      const cacheData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (!cacheData.success || !cacheData.summary) {
        console.log(`❌ Invalid cache data for ${productHandle}, skipping`);
        continue;
      }

      // Find or create product
      let product = await prisma.product.findUnique({
        where: { handle: productHandle }
      });

      if (!product) {
        product = await prisma.product.create({
          data: {
            handle: productHandle,
            title: productHandle.replace(/-/g, ' '),
            status: 'ACTIVE'
          }
        });
        console.log(`Created product record for ${productHandle}`);
      }

      // Check if AI summary already exists
      const existingSummary = await prisma.aISummary.findUnique({
        where: { productId: product.id }
      });

      if (existingSummary) {
        console.log(`AI summary already exists for ${productHandle}, updating...`);
        await prisma.aISummary.update({
          where: { productId: product.id },
          data: {
            summary: cacheData.summary,
            reviewsAnalyzed: cacheData.reviewsAnalyzed || 1,
            totalReviews: cacheData.totalReviews || 1,
            averageRating: cacheData.averageRating || 5,
            model: cacheData.model || 'llama-3.1-8b-instant',
            reviewsHash: cacheData.reviewsHash || 'migrated-' + Date.now(),
            updatedAt: new Date()
          }
        });
      } else {
        console.log(`Creating new AI summary for ${productHandle}...`);
        await prisma.aISummary.create({
          data: {
            productId: product.id,
            handle: productHandle,
            summary: cacheData.summary,
            reviewsAnalyzed: cacheData.reviewsAnalyzed || 1,
            totalReviews: cacheData.totalReviews || 1,
            averageRating: cacheData.averageRating || 5,
            model: cacheData.model || 'llama-3.1-8b-instant',
            reviewsHash: cacheData.reviewsHash || 'migrated-' + Date.now()
          }
        });
      }

      console.log(`✅ Migrated ${productHandle}\n`);
    }

    // Verify migration
    const summaryCount = await prisma.aISummary.count();
    console.log(`Migration complete! Database now has ${summaryCount} AI summaries.`);

    // Show migrated summaries
    const summaries = await prisma.aISummary.findMany({
      include: { product: { select: { handle: true } } },
      take: 5
    });

    console.log('\nMigrated summaries:');
    summaries.forEach(s => {
      console.log(`- ${s.product.handle}: ${s.summary.substring(0, 50)}...`);
    });

  } catch (error) {
    console.error('Migration error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

migrateSummaries();