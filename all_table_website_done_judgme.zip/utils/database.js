// utils/database.js - Database Utility Functions
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get reviews for a specific product
export async function getProductReviews(productHandle) {
  try {
    const product = await prisma.product.findUnique({
      where: { handle: productHandle },
      include: {
        reviews: {
          orderBy: { scrapedAt: 'desc' }
        },
        cacheMetadata: true,
        aiSummaries: true
      }
    });

    if (!product) {
      return { success: false, error: 'Product not found' };
    }

    const stats = calculateReviewStats(product.reviews);

    return {
      success: true,
      product: {
        id: product.id,
        handle: product.handle,
        title: product.title,
        status: product.status
      },
      reviews: product.reviews.map(review => ({
        id: review.id,
        author: review.author,
        rating: review.rating,
        title: review.title,
        text: review.text,
        verified: review.verified,
        platform: review.platform,
        reviewDate: review.reviewDate,
        scrapedAt: review.scrapedAt
      })),
      stats,
      metadata: product.cacheMetadata,
      aiSummary: product.aiSummaries[0] || null
    };
  } catch (error) {
    console.error('Error getting product reviews:', error);
    return { success: false, error: error.message };
  }
}

// Calculate review statistics
function calculateReviewStats(reviews) {
  if (!reviews || reviews.length === 0) {
    return { total: 0, average: 0, distribution: {}, verified: 0, totalWithText: 0 };
  }

  const total = reviews.length;
  const average = reviews.reduce((acc, r) => acc + r.rating, 0) / total;
  const verified = reviews.filter(r => r.verified).length;
  const totalWithText = reviews.filter(r => r.text && r.text.length > 0).length;
  
  const distribution = reviews.reduce((acc, r) => {
    const star = Math.round(r.rating);
    acc[star] = (acc[star] || 0) + 1;
    return acc;
  }, {});

  return {
    total,
    average: Math.round(average * 10) / 10,
    distribution,
    verified,
    totalWithText
  };
}

// Get all products with review counts
export async function getAllProductsWithStats() {
  try {
    const products = await prisma.product.findMany({
      include: {
        reviews: true,
        cacheMetadata: true,
        aiSummaries: true
      },
      orderBy: { updatedAt: 'desc' }
    });

    return products.map(product => ({
      id: product.id,
      handle: product.handle,
      title: product.title,
      status: product.status,
      reviewCount: product.reviews.length,
      averageRating: product.cacheMetadata?.averageRating || 0,
      hasAiSummary: product.aiSummaries.length > 0,
      lastScraped: product.cacheMetadata?.lastScraped,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt
    }));
  } catch (error) {
    console.error('Error getting all products:', error);
    throw error;
  }
}

// Get database statistics
export async function getDatabaseStats() {
  try {
    const [productCount, reviewCount, aiSummaryCount] = await Promise.all([
      prisma.product.count(),
      prisma.review.count(),
      prisma.aISummary.count()
    ]);

    const recentReviews = await prisma.review.findMany({
      take: 10,
      orderBy: { scrapedAt: 'desc' },
      include: {
        product: {
          select: { title: true, handle: true }
        }
      }
    });

    // Calculate average rating across all reviews
    const avgResult = await prisma.review.aggregate({
      _avg: {
        rating: true
      }
    });

    return {
      totalProducts: productCount,
      totalReviews: reviewCount,
      aiSummaries: aiSummaryCount,
      averageRating: avgResult._avg.rating ? Math.round(avgResult._avg.rating * 10) / 10 : 0,
      recentReviews: recentReviews.map(review => ({
        product: review.product.title,
        productHandle: review.product.handle,
        author: review.author,
        rating: review.rating,
        text: review.text.substring(0, 100) + (review.text.length > 100 ? '...' : ''),
        scrapedAt: review.scrapedAt.toISOString()
      })),
      lastUpdated: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error getting database stats:', error);
    throw error;
  }
}

// Clear all data for a product
export async function clearProductData(productHandle) {
  try {
    const product = await prisma.product.findUnique({
      where: { handle: productHandle }
    });

    if (product) {
      await prisma.product.delete({
        where: { id: product.id }
      });
      return { success: true, message: `Cleared all data for ${productHandle}` };
    } else {
      return { success: false, error: 'Product not found' };
    }
  } catch (error) {
    console.error('Error clearing product data:', error);
    return { success: false, error: error.message };
  }
}

// Test database connection
export async function testDatabaseConnection() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { success: true, message: 'Database connection successful' };
  } catch (error) {
    console.error('Database connection failed:', error);
    return { success: false, error: error.message };
  }
}

export default {
  getProductReviews,
  getAllProductsWithStats,
  getDatabaseStats,
  clearProductData,
  testDatabaseConnection
};