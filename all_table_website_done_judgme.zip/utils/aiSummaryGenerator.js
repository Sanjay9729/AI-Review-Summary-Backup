import crypto from 'crypto';

// GROQ API configuration
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_API_KEY = process.env.GROQ_API_KEY;

/**
 * Call GROQ AI API to generate summary
 */
async function generateSummaryWithGroq(reviews, productTitle) {
  if (!GROQ_API_KEY) {
    throw new Error("GROQ_API_KEY not found in environment variables");
  }

  const reviewsText = reviews.map(review =>
    `Rating: ${review.rating}/5
Author: ${review.author}
Review: ${review.text}
${review.title ? `Title: ${review.title}` : ''}
---`
  ).join('\n');

  const prompt = `Based on these customer reviews for "${productTitle}", write a natural product summary:

${reviewsText}

Instructions:
- Write like you're telling a friend about this product
- Only mention specific benefits and features customers actually talked about
- DO NOT include phrases like "analysis", "customer review", "rating", "stars", "feedback", or "based on reviews"
- DO NOT mention review counts, statistics, or ratings
- Focus on what makes this product special according to real customers
- Keep it conversational and helpful, 50-80 words
- Start directly with what customers love about the product

Example good summary: "This shirt has an amazing lightweight fabric that's perfect for hot days. Customers love the subtle floral pattern and how comfortable it feels. The fit is just right - not too tight or loose. Great for both casual outings and weekend adventures."

Now write your summary:`;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        messages: [
          {
            role: 'system',
            content: 'You are a helpful friend recommending products. Create natural, conversational summaries that focus ONLY on specific product benefits customers mentioned. Never use analytical language, review statistics, ratings, or phrases like "analysis", "customer review", "feedback", or "based on". Just describe what makes the product great in a friendly way.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        model: 'llama-3.1-8b-instant',
        temperature: 0.7,
        max_tokens: 200,
        top_p: 0.9
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`GROQ API error: ${response.status} ${response.statusText} - ${errorData}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;

  } catch (error) {
    console.error("Error calling GROQ AI:", error);
    throw error;
  }
}

/**
 * Generate reviews hash for AI summary linking
 */
function generateReviewsHash(reviews) {
  const reviewsString = JSON.stringify(reviews.map(r => ({
    author: r.author,
    rating: r.rating,
    text: r.text,
    reviewDate: r.reviewDate
  })));
  return crypto.createHash('md5').update(reviewsString).digest('hex');
}

/**
 * Calculate review statistics
 */
function calculateReviewStats(reviews) {
  const totalReviews = reviews.length;
  const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
  const averageRating = totalReviews > 0 ? (totalRating / totalReviews).toFixed(2) : 0;

  return {
    totalReviews,
    averageRating: parseFloat(averageRating)
  };
}

/**
 * Generate and store AI summary for a product
 */
export async function generateAISummaryForProduct(prisma, product) {
  console.log(`🤖 Generating AI summary for: ${product.title}`);

  // Get all reviews for this product
  const reviews = await prisma.review.findMany({
    where: { productId: product.id },
    select: {
      rating: true,
      author: true,
      title: true,
      text: true,
      reviewDate: true
    }
  });

  if (reviews.length < 1) {
    console.log(`⚠️ No reviews for ${product.title}, skipping...`);
    return;
  }

  try {
    // Generate AI summary
    const aiSummary = await generateSummaryWithGroq(reviews, product.title);

    // Calculate statistics
    const stats = calculateReviewStats(reviews);

    // Calculate reviews hash
    const reviewsHash = generateReviewsHash(reviews);

    // Store in database
    await prisma.aISummary.upsert({
      where: { productId: product.id },
      create: {
        productId: product.id,
        handle: product.handle,
        summary: aiSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating,
        reviewsHash: reviewsHash
      },
      update: {
        handle: product.handle,
        summary: aiSummary,
        reviewsAnalyzed: stats.totalReviews,
        totalReviews: stats.totalReviews,
        averageRating: stats.averageRating,
        reviewsHash: reviewsHash,
        updatedAt: new Date()
      }
    });

    console.log(`✅ Summary generated and stored for ${product.title}`);
    console.log(`📊 Stats: ${stats.totalReviews} reviews, ${stats.averageRating} avg rating`);

  } catch (error) {
    console.error(`❌ Failed to generate summary for ${product.title}:`, error.message);
  }
}