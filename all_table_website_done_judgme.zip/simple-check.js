import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function simpleCheck() {
  try {
    console.log('Checking AI summaries for blue-cotton-t-shirt...\n');

    // Check for blue-cotton-t-shirt specifically
    const blueTeeSummary = await prisma.aISummary.findFirst({
      where: {
        product: {
          handle: 'blue-cotton-t-shirt'
        }
      },
      include: {
        product: {
          select: { handle: true }
        }
      }
    });

    if (blueTeeSummary) {
      console.log(`✅ Found AI summary for blue-cotton-t-shirt:`);
      console.log(`Summary: ${blueTeeSummary.summary}`);
      console.log(`Generated: ${blueTeeSummary.generatedAt}`);
      console.log(`Reviews analyzed: ${blueTeeSummary.reviewsAnalyzed}`);
    } else {
      console.log('❌ No AI summary found for blue-cotton-t-shirt in database');
    }

    // Check reviews for blue-cotton-t-shirt
    const blueTeeReviews = await prisma.review.findMany({
      where: {
        product: {
          handle: 'blue-cotton-t-shirt'
        }
      }
    });

    console.log(`\n📋 Found ${blueTeeReviews.length} reviews for blue-cotton-t-shirt:`);
    blueTeeReviews.forEach((review, i) => {
      console.log(`${i+1}. Rating: ${review.rating}`);
      console.log(`   Verified: ${review.verified}`);
      console.log(`   Text length: ${review.text?.length || 0}`);
      console.log(`   Text: "${review.text}"`);
      console.log(`   Platform: ${review.platform}`);
      console.log(`   ---`);

      // Check if this review meets the criteria for "meaningful"
      const hasText = review.text && review.text.trim().length > 0;
      const textLengthOk = hasText && review.text.trim().length > 10;
      const ratingOk = review.rating > 0;
      const notNoReview = hasText && !review.text.toLowerCase().includes('no review');
      const notNoComment = hasText && !review.text.toLowerCase().includes('no comment');

      console.log(`   Meets criteria for meaningful review:`);
      console.log(`   - Has text: ${hasText}`);
      console.log(`   - Text length > 10: ${textLengthOk}`);
      console.log(`   - Rating > 0: ${ratingOk}`);
      console.log(`   - Not 'no review': ${notNoReview}`);
      console.log(`   - Not 'no comment': ${notNoComment}`);
      console.log(`   - OVERALL: ${textLengthOk && ratingOk && notNoReview && notNoComment ? '✅ YES' : '❌ NO'}`);
      console.log();
    });

    // Check if there are any summaries at all
    const allSummaries = await prisma.aISummary.count();
    console.log(`Total AI summaries in database: ${allSummaries}`);

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

simpleCheck();