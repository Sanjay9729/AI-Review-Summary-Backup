import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import 'dotenv/config'; // Load environment variables

const prisma = new PrismaClient();

async function migrateAISummaries() {
  try {
    console.log('Starting AI summary migration from cache files to database...\n');

    const cacheDir = path.join(process.cwd(), 'cache');
    const files = fs.readdirSync(cacheDir);

    const aiSummaryFiles = files.filter(file => file.startsWith('ai_summary_') && file.endsWith('.json'));

    console.log(`Found ${aiSummaryFiles.length} AI summary cache files\n`);

    for (const file of aiSummaryFiles) {
      const filePath = path.join(cacheDir, file);
      const productHandle = file.replace('ai_summary_', '').replace('.json', '');

      try {
        const cacheData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

        if (cacheData.success && cacheData.summary) {
          console.log(`Migrating AI summary for ${productHandle}...`);

          // Prepare data for database
          const summaryData = {
            summary: cacheData.summary,
            reviewsAnalyzed: cacheData.reviewsAnalyzed || 1,
            totalReviews: cacheData.totalReviews || 1,
            averageRating: cacheData.averageRating || 5,
            model: cacheData.model || 'llama-3.1-8b-instant',
            reviewsHash: cacheData.reviewsHash || 'migrated-' + Date.now()
          };

          // Find or create product
          let product = await prisma.product.findUnique({
            where: { handle: productHandle }
          });

          if (!product) {
            console.log(`Creating product record for ${productHandle}`);
            product = await prisma.product.create({
              data: {
                handle: productHandle,
                title: productHandle.replace(/-/g, ' '),
                status: 'ACTIVE'
              }
            });
          }

          // Save AI summary
          const result = await prisma.aISummary.upsert({
            where: { productId: product.id },
            update: {
              summary: summaryData.summary,
              reviewsAnalyzed: summaryData.reviewsAnalyzed,
              totalReviews: summaryData.totalReviews,
              averageRating: summaryData.averageRating,
              model: summaryData.model,
              reviewsHash: summaryData.reviewsHash,
              updatedAt: new Date()
            },
            create: {
              productId: product.id,
              handle: productHandle,
              summary: summaryData.summary,
              reviewsAnalyzed: summaryData.reviewsAnalyzed,
              totalReviews: summaryData.totalReviews,
              averageRating: summaryData.averageRating,
              model: summaryData.model,
              reviewsHash: summaryData.reviewsHash
            }
          });

          if (result) {
            console.log(`✅ Successfully migrated ${productHandle}`);
          }
        } else {
          console.log(`⚠️  Skipping ${productHandle} - invalid cache data`);
        }

      } catch (error) {
        console.error(`❌ Error migrating ${productHandle}:`, error.message);
      }
    }

    console.log('\nMigration complete! Verifying results...\n');

    // Verify the migration
    const aiSummaryCount = await prisma.aISummary.count();
    console.log(`Database now contains ${aiSummaryCount} AI summaries`);

    // Check specific products
    const productsToCheck = ['blue-cotton-t-shirt', 'purple-cotton-t-shirt', 'the-desert-bloom-camp-shirt'];

    for (const handle of productsToCheck) {
      const product = await prisma.product.findUnique({
        where: { handle },
        include: { aiSummaries: { orderBy: { generatedAt: 'desc' }, take: 1 } }
      });

      if (product && product.aiSummaries && product.aiSummaries.length > 0) {
        const summary = product.aiSummaries[0];
        console.log(`✅ ${handle}: ${summary.summary.substring(0, 50)}...`);
      } else {
        console.log(`❌ ${handle}: No summary found`);
      }
    }

  } catch (error) {
    console.error('Migration error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

migrateAISummaries();