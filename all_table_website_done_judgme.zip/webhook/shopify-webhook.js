// webhook/shopify-webhook.js
import express from 'express';
import crypto from 'crypto';
import prisma from '../lib/prisma.js';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.WEBHOOK_PORT || 3001;
const WEBHOOK_SECRET = process.env.SHOPIFY_WEBHOOK_SECRET;

// Middleware to capture raw body for signature verification
app.use('/webhook/shopify', express.raw({ type: 'application/json' }));

/**
 * Verify Shopify webhook signature
 */
function verifyShopifyWebhook(data, signature) {
  if (!WEBHOOK_SECRET) {
    console.log('⚠️ No webhook secret configured');
    return true; // Allow for development
  }
  
  const calculated = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(data, 'utf8')
    .digest('base64');
    
  return calculated === signature;
}

/**
 * Handle product creation webhook
 */
app.post('/webhook/shopify/products/create', async (req, res) => {
  try {
    const signature = req.get('X-Shopify-Hmac-Sha256');
    
    if (!verifyShopifyWebhook(req.body, signature)) {
      console.log('❌ Invalid webhook signature');
      return res.status(401).send('Unauthorized');
    }
    
    const product = JSON.parse(req.body.toString());
    console.log('📦 New product webhook received:', product.handle);
    
    // Create product in Prisma
    await prisma.product.upsert({
      where: { handle: product.handle },
      create: {
        handle: product.handle,
        title: product.title,
        status: product.status?.toUpperCase() || 'ACTIVE',
        shopifyId: product.id.toString(),
      },
      update: {
        title: product.title,
        status: product.status?.toUpperCase() || 'ACTIVE',
        updatedAt: new Date(),
      },
    });
    
    console.log('✅ Product added to database:', product.handle);
    res.status(200).send('OK');
    
  } catch (error) {
    console.error('❌ Webhook error:', error);
    res.status(500).send('Error');
  }
});

/**
 * Handle product update webhook
 */
app.post('/webhook/shopify/products/update', async (req, res) => {
  try {
    const signature = req.get('X-Shopify-Hmac-Sha256');
    
    if (!verifyShopifyWebhook(req.body, signature)) {
      return res.status(401).send('Unauthorized');
    }
    
    const product = JSON.parse(req.body.toString());
    console.log('📝 Product update webhook:', product.handle);
    
    await prisma.product.upsert({
      where: { handle: product.handle },
      create: {
        handle: product.handle,
        title: product.title,
        status: product.status?.toUpperCase() || 'ACTIVE',
        shopifyId: product.id.toString(),
      },
      update: {
        title: product.title,
        status: product.status?.toUpperCase() || 'ACTIVE',
        updatedAt: new Date(),
      },
    });
    
    console.log('✅ Product updated in database:', product.handle);
    res.status(200).send('OK');
    
  } catch (error) {
    console.error('❌ Webhook update error:', error);
    res.status(500).send('Error');
  }
});

/**
 * Handle product deletion webhook
 */
app.post('/webhook/shopify/products/delete', async (req, res) => {
  try {
    const signature = req.get('X-Shopify-Hmac-Sha256');
    
    if (!verifyShopifyWebhook(req.body, signature)) {
      return res.status(401).send('Unauthorized');
    }
    
    const product = JSON.parse(req.body.toString());
    console.log('🗑️ Product deletion webhook:', product.handle);
    
    // Soft delete - just update status
    await prisma.product.updateMany({
      where: { shopifyId: product.id.toString() },
      data: { status: 'DELETED' },
    });
    
    console.log('✅ Product marked as deleted:', product.handle);
    res.status(200).send('OK');
    
  } catch (error) {
    console.error('❌ Webhook deletion error:', error);
    res.status(500).send('Error');
  }
});

/**
 * Health check endpoint
 */
app.get('/webhook/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`🚀 Webhook server running on port ${PORT}`);
  console.log(`📡 Endpoints:`);
  console.log(`   POST /webhook/shopify/products/create`);
  console.log(`   POST /webhook/shopify/products/update`);
  console.log(`   POST /webhook/shopify/products/delete`);
  console.log(`   GET  /webhook/health`);
});

export default app;