/*
  Warnings:

  - A unique constraint covering the columns `[handle]` on the table `ai_summaries` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "public"."ai_summaries" ADD COLUMN     "handle" TEXT;

-- AlterTable
ALTER TABLE "public"."reviews" ADD COLUMN     "handle" TEXT;

-- Populate handle from products
UPDATE "public"."ai_summaries" SET "handle" = p."handle" FROM "public"."products" p WHERE "ai_summaries"."productId" = p."id";
UPDATE "public"."reviews" SET "handle" = p."handle" FROM "public"."products" p WHERE "reviews"."productId" = p."id";

-- AlterTable to make not null
ALTER TABLE "public"."ai_summaries" ALTER COLUMN "handle" SET NOT NULL;
ALTER TABLE "public"."reviews" ALTER COLUMN "handle" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "ai_summaries_handle_key" ON "public"."ai_summaries"("handle");

-- CreateIndex
CREATE INDEX "reviews_handle_idx" ON "public"."reviews"("handle");
