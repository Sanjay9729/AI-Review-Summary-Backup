// Test script to add a new review and check if AI summary is generated
import DatabaseService from './services/database.server.js';

async function testNewReview() {
  try {
    console.log('🧪 Testing new review addition and AI summary generation...');

    // Create a test product if it doesn't exist
    const testProductHandle = 'test-new-product-for-summary';

    // Add a new review
    const testReviewData = {
      reviews: [{
        author: 'Test Customer',
        rating: 5,
        title: 'Amazing Product',
        text: 'This is a fantastic product that I really love. The quality is outstanding and it performs exactly as expected. Highly recommended!',
        verified: true,
        platform: 'Test',
        reviewDate: new Date().toISOString(),
        date: new Date().toISOString()
      }],
      stats: {
        total: 1,
        average: 5,
        verified: 1,
        totalWithText: 1,
        distribution: { '5': 1 }
      }
    };

    console.log('💾 Adding test review...');
    const saveResult = await DatabaseService.saveReviews(testProductHandle, testReviewData);

    if (saveResult.success) {
      console.log(`✅ Review saved successfully. Saved: ${saveResult.saved}, Skipped: ${saveResult.skipped}`);

      // Wait a moment for AI generation to complete
      console.log('⏳ Waiting for AI summary generation...');
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Check if AI summary was generated
      const aiSummary = await DatabaseService.getAISummary(testProductHandle);

      if (aiSummary && aiSummary.success) {
        console.log('🎉 SUCCESS: AI summary was generated!');
        console.log('📖 Summary:', aiSummary.summary.substring(0, 100) + '...');
        console.log('📊 Metadata:', {
          reviewsAnalyzed: aiSummary.reviewsAnalyzed,
          totalReviews: aiSummary.totalReviews,
          averageRating: aiSummary.averageRating,
          generatedAt: aiSummary.generatedAt
        });
      } else {
        console.log('❌ FAILED: AI summary was not generated');
      }
    } else {
      console.log('❌ Failed to save review');
    }

  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

testNewReview();