async function testAPI() {
  try {
    console.log('Testing APIs for blue-cotton-t-shirt...\n');

    // Test multiple URL patterns
    const urlPatterns = [
      'http://localhost:3457/apps/ai-reviews/reviews/blue-cotton-t-shirt',
      'http://localhost:3457/api/apps/ai-reviews/reviews/blue-cotton-t-shirt',
      'http://localhost:3457/reviews/blue-cotton-t-shirt'
    ];

    for (let i = 0; i < urlPatterns.length; i++) {
      console.log(`${i + 1}. Testing reviews endpoint pattern ${i + 1}...`);
      const reviewsUrl = urlPatterns[i];
      console.log(`Calling: ${reviewsUrl}`);

      try {
        const reviewsResponse = await fetch(reviewsUrl);
        console.log('Reviews response status:', reviewsResponse.status);

        const reviewsText = await reviewsResponse.text();
        console.log('Reviews response (first 100 chars):', reviewsText.substring(0, 100));

        if (reviewsResponse.ok && reviewsText.includes('success')) {
          console.log('✅ Reviews endpoint working with this pattern\n');
          break;
        } else {
          console.log('❌ This pattern not working\n');
        }
      } catch (error) {
        console.log('❌ Error with this pattern:', error.message, '\n');
      }
    }

    // Test the AI summary GET endpoint with multiple patterns
    const aiPatterns = [
      'http://localhost:3457/apps/ai-reviews/ai-review-summary?productHandle=blue-cotton-t-shirt',
      'http://localhost:3457/api/apps/ai-reviews/ai-review-summary?productHandle=blue-cotton-t-shirt',
      'http://localhost:3457/ai-review-summary?productHandle=blue-cotton-t-shirt'
    ];

    for (let i = 0; i < aiPatterns.length; i++) {
      console.log(`${i + 1}. Testing AI summary endpoint pattern ${i + 1}...`);
      const aiSummaryUrl = aiPatterns[i];
      console.log(`Calling: ${aiSummaryUrl}`);

      try {
        const aiResponse = await fetch(aiSummaryUrl);
        console.log('AI summary response status:', aiResponse.status);

        const aiText = await aiResponse.text();
        console.log('AI summary response (first 100 chars):', aiText.substring(0, 100));

        if (aiResponse.ok && aiText.includes('success')) {
          console.log('✅ AI summary endpoint working with this pattern');
          const aiData = JSON.parse(aiText);
          if (aiData.success && aiData.summary) {
            console.log('✅ AI summary found!');
            console.log('Summary:', aiData.summary);
          } else {
            console.log('❌ No AI summary in response');
          }
          break;
        } else {
          console.log('❌ This pattern not working\n');
        }
      } catch (error) {
        console.log('❌ Error with this pattern:', error.message, '\n');
      }
    }

    const aiResponse = await fetch(aiSummaryUrl);
    console.log('AI summary response status:', aiResponse.status);
    console.log('AI summary response headers:', Object.fromEntries(aiResponse.headers.entries()));

    const aiText = await aiResponse.text();
    console.log('AI summary response (first 200 chars):', aiText.substring(0, 200));

    if (aiResponse.ok && aiText.includes('success')) {
      console.log('✅ AI summary endpoint working');
      const aiData = JSON.parse(aiText);
      if (aiData.success && aiData.summary) {
        console.log('✅ AI summary found!');
        console.log('Summary:', aiData.summary);
      } else {
        console.log('❌ No AI summary in response');
      }
    } else {
      console.log('❌ AI summary endpoint not working or returned HTML');
    }

  } catch (error) {
    console.error('Test error:', error);
  }
}

testAPI();