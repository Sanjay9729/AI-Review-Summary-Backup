import { prisma } from './lib/prisma.js';

async function debugAISummaries() {
  try {
    console.log('=== DEBUGGING AI SUMMARIES ===\n');

    // Check total counts
    const productCount = await prisma.product.count();
    const reviewCount = await prisma.review.count();
    const aiSummaryCount = await prisma.aISummary.count();

    console.log(`Total products: ${productCount}`);
    console.log(`Total reviews: ${reviewCount}`);
    console.log(`Total AI summaries: ${aiSummaryCount}\n`);

    // Get all AI summaries
    const allSummaries = await prisma.aISummary.findMany({
      include: {
        product: {
          select: { handle: true, title: true }
        }
      }
    });

    console.log('=== EXISTING AI SUMMARIES ===');
    if (allSummaries.length === 0) {
      console.log('No AI summaries found in database!');
    } else {
      allSummaries.forEach(summary => {
        console.log(`✅ ${summary.product?.handle || 'unknown'}: ${summary.summary.substring(0, 50)}...`);
      });
    }

    // Check specific products that should have summaries
    const testHandles = ['pink', 'yellow-cotton-t-shirt', 'blue-cotton-t-shirt'];

    console.log('\n=== CHECKING SPECIFIC PRODUCTS ===');
    for (const handle of testHandles) {
      const product = await prisma.product.findUnique({
        where: { handle },
        include: {
          reviews: true,
          aiSummaries: true
        }
      });

      if (product) {
        console.log(`\n📊 ${handle}:`);
        console.log(`   Reviews: ${product.reviews.length}`);
        console.log(`   AI Summaries: ${product.aiSummaries ? 1 : 0}`);

        if (product.aiSummaries) {
          console.log(`   Summary: ${product.aiSummaries.summary.substring(0, 50)}...`);
        }

        // Check review quality
        const meaningfulReviews = product.reviews.filter(review =>
          review.text &&
          review.text.trim().length > 10 &&
          review.rating > 0
        );
        console.log(`   Meaningful reviews: ${meaningfulReviews.length}/${product.reviews.length}`);
      } else {
        console.log(`❌ Product ${handle} not found`);
      }
    }

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

debugAISummaries();