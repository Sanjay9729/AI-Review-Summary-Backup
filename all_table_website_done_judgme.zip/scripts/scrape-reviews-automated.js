// scripts/scrape-reviews-automated.js - Script to run automated review scraping
import { config } from 'dotenv';
import AutomatedReviewScraper from '../services/reviewScraper.automated.js';

// Load environment variables
config();

const scraper = new AutomatedReviewScraper({
  scrapeIntervalMinutes: process.env.SCRAPE_INTERVAL_MINUTES || 60, // Default 1 hour
  headless: process.env.PUPPETEER_HEADLESS !== 'false', // Default true
  maxConcurrent: parseInt(process.env.MAX_CONCURRENT_SCRAPES) || 2,
  force: false
});

async function main() {
  const command = process.argv[2];

  switch (command) {
    case 'start':
      console.log('🚀 Starting automated review scraper...');
      await scraper.start();

      // Keep the process running
      process.on('SIGINT', async () => {
        console.log('\n🛑 Received SIGINT, shutting down gracefully...');
        await scraper.close();
        process.exit(0);
      });

      process.on('SIGTERM', async () => {
        console.log('\n🛑 Received SIGTERM, shutting down gracefully...');
        await scraper.close();
        process.exit(0);
      });

      console.log('✅ Automated scraper is now running. Press Ctrl+C to stop.');
      break;

    case 'stop':
      console.log('🛑 Stopping automated review scraper...');
      scraper.stop();
      await scraper.close();
      console.log('✅ Automated scraper stopped.');
      break;

    case 'stats':
      console.log('📊 Getting scraper statistics...');
      const stats = await scraper.getStats();
      if (stats) {
        console.log('Scraper Statistics:');
        console.log(`  - Total Products: ${stats.totalProducts}`);
        console.log(`  - Total Reviews: ${stats.totalReviews}`);
        console.log(`  - Recent Reviews (24h): ${stats.recentReviewsCount}`);
        console.log(`  - Average Rating: ${stats.averageRating}★`);
        console.log(`  - Platform Stats:`, JSON.stringify(stats.platformStats, null, 2));
        console.log(`  - Is Running: ${stats.isRunning ? 'Yes' : 'No'}`);
      } else {
        console.log('❌ Unable to get statistics');
      }
      await scraper.close();
      break;

    case 'once':
      console.log('🔄 Running one-time scrape of all products...');
      scraper.options.force = true; // Force scrape even if recently scraped
      await scraper.scrapeAllProducts();
      console.log('✅ One-time scrape completed.');
      await scraper.close();
      break;

    case 'product':
      const productHandle = process.argv[3];
      if (!productHandle) {
        console.error('❌ Please provide a product handle: npm run scrape:product <handle>');
        process.exit(1);
      }
      console.log(`🔍 Scraping product: ${productHandle}`);
      scraper.options.force = true; // Force scrape even if recently scraped
      const result = await scraper.scrapeAndStoreProductReviews(productHandle);
      console.log('Result:', result);
      await scraper.close();
      break;

    default:
      console.log('Usage:');
      console.log('  npm run scrape:start     - Start automated scraping');
      console.log('  npm run scrape:stop      - Stop automated scraping');
      console.log('  npm run scrape:stats     - Show scraping statistics');
      console.log('  npm run scrape:once      - Run one-time scrape of all products');
      console.log('  npm run scrape:product <handle> - Scrape specific product');
      await scraper.close();
      process.exit(1);
  }
}

// Handle uncaught errors
process.on('unhandledRejection', (error) => {
  console.error('❌ Unhandled promise rejection:', error);
  scraper.close().finally(() => process.exit(1));
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught exception:', error);
  scraper.close().finally(() => process.exit(1));
});

main().catch((error) => {
  console.error('❌ Script error:', error);
  scraper.close().finally(() => process.exit(1));
});