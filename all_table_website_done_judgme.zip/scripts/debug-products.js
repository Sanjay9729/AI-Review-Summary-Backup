// debug-products.js - Debug script to find all products
import puppeteer from "puppeteer";
import dotenv from "dotenv";

dotenv.config();

const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;

async function unlockStoreIfNeeded(page) {
  const isPasswordPage = await page.$('input[name="password"]');
  if (isPasswordPage && STORE_PASSWORD) {
    console.log("🔒 Password page detected — submitting password");
    await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2" }),
      page.click('button[type="submit"], input[type="submit"]'),
    ]);
    console.log("✅ Unlocked storefront");
  }
}

async function debugProductDetection() {
  const browser = await puppeteer.launch({
    headless: false, // Keep browser open to see what's happening
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });
  
  const page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 768 });
  
  try {
    // Method 1: Collections/all page
    console.log("\n🔍 === METHOD 1: Collections/all page ===");
    const collectionUrl = `${STORE_URL}/collections/all`;
    await page.goto(collectionUrl, { waitUntil: "networkidle2" });
    await unlockStoreIfNeeded(page);
    
    // Check pagination
    const hasPagination = await page.evaluate(() => {
      const paginationSelectors = [
        '.pagination',
        '.paginate',
        '[data-pagination]',
        '.load-more',
        '.show-more',
        'button[data-load-more]'
      ];
      
      for (const selector of paginationSelectors) {
        if (document.querySelector(selector)) {
          console.log(`Found pagination: ${selector}`);
          return selector;
        }
      }
      return null;
    });
    
    if (hasPagination) {
      console.log(`📄 Pagination found: ${hasPagination}`);
    } else {
      console.log("📄 No pagination found");
    }
    
    // Enhanced scroll with more attempts
    console.log("🔄 Enhanced scrolling...");
    await page.evaluate(async () => {
      let previousHeight = 0;
      let currentHeight = document.body.scrollHeight;
      let attempts = 0;
      const maxAttempts = 20;
      
      while (previousHeight !== currentHeight && attempts < maxAttempts) {
        previousHeight = currentHeight;
        window.scrollTo(0, document.body.scrollHeight);
        
        // Wait for potential lazy loading
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        currentHeight = document.body.scrollHeight;
        attempts++;
        console.log(`Scroll attempt ${attempts}: height ${currentHeight}`);
      }
      
      console.log(`Final scroll attempts: ${attempts}`);
    });
    
    // Try multiple selectors and get detailed info
    const productInfo = await page.evaluate(() => {
      const selectors = [
        '.card-wrapper a[href*="/products/"]',
        '.product-item a[href*="/products/"]',
        '.grid__item a[href*="/products/"]',
        '.product-card a[href*="/products/"]',
        '.product a[href*="/products/"]',
        '[data-product] a[href*="/products/"]',
        'a[href*="/products/"]'
      ];
      
      const results = {};
      let allLinks = [];
      
      for (const selector of selectors) {
        const links = Array.from(document.querySelectorAll(selector));
        results[selector] = links.length;
        if (links.length > 0) {
          allLinks = allLinks.concat(links.map(a => a.href));
        }
      }
      
      // Get unique product handles
      const uniqueLinks = [...new Set(allLinks)];
      const handles = uniqueLinks
        .map(href => {
          const match = href.match(/\/products\/([^?#\/]+)/);
          return match ? match[1] : null;
        })
        .filter(Boolean);
      
      return {
        selectorResults: results,
        totalUniqueLinks: uniqueLinks.length,
        handles: [...new Set(handles)]
      };
    });
    
    console.log("📊 Selector Results:", productInfo.selectorResults);
    console.log(`🔗 Total unique product links: ${productInfo.totalUniqueLinks}`);
    console.log(`📦 Product handles found: ${productInfo.handles.length}`);
    console.log("📝 Handles:", productInfo.handles);
    
    // Method 2: Try different collection URLs
    console.log("\n🔍 === METHOD 2: Alternative Collection URLs ===");
    const alternativeUrls = [
      '/collections/all?view=grid',
      '/collections/all?limit=250',
      '/collections/all?sort_by=created-descending',
      '/products.json'
    ];
    
    for (const altUrl of alternativeUrls) {
      try {
        console.log(`Trying: ${STORE_URL}${altUrl}`);
        await page.goto(`${STORE_URL}${altUrl}`, { waitUntil: "networkidle2", timeout: 10000 });
        await unlockStoreIfNeeded(page);
        
        if (altUrl.includes('.json')) {
          // Handle JSON response
          const jsonData = await page.evaluate(() => {
            try {
              const text = document.body.textContent;
              const data = JSON.parse(text);
              return data.products ? data.products.length : 0;
            } catch (e) {
              return 0;
            }
          });
          console.log(`📊 Products in JSON: ${jsonData}`);
        } else {
          // Handle HTML response
          const count = await page.evaluate(() => {
            return document.querySelectorAll('a[href*="/products/"]').length;
          });
          console.log(`📊 Product links found: ${count}`);
        }
      } catch (error) {
        console.log(`❌ Failed: ${altUrl} - ${error.message}`);
      }
    }
    
    // Method 3: Check sitemap variations
    console.log("\n🔍 === METHOD 3: Sitemap Variations ===");
    const sitemapUrls = [
      '/sitemap_products_1.xml',
      '/sitemap.xml',
      '/sitemap_index.xml',
      '/sitemap_products.xml'
    ];
    
    for (const sitemapUrl of sitemapUrls) {
      try {
        console.log(`Trying sitemap: ${STORE_URL}${sitemapUrl}`);
        await page.goto(`${STORE_URL}${sitemapUrl}`, { waitUntil: "networkidle2", timeout: 10000 });
        
        const productCount = await page.evaluate(() => {
          const text = document.body.textContent;
          const matches = text.match(/\/products\/[^<\s]+/g);
          return matches ? matches.length : 0;
        });
        
        console.log(`📊 Products in sitemap: ${productCount}`);
        
        if (productCount > 0) {
          const handles = await page.evaluate(() => {
            const text = document.body.textContent;
            const matches = text.match(/\/products\/([^<\s\/]+)/g);
            if (!matches) return [];
            
            return matches
              .map(match => match.replace('/products/', ''))
              .filter((v, i, arr) => arr.indexOf(v) === i);
          });
          console.log("📝 Sitemap handles:", handles);
        }
      } catch (error) {
        console.log(`❌ Sitemap failed: ${sitemapUrl} - ${error.message}`);
      }
    }
    
    // Method 4: Manual inspection
    console.log("\n🔍 === METHOD 4: Manual Page Inspection ===");
    await page.goto(`${STORE_URL}/collections/all`, { waitUntil: "networkidle2" });
    await unlockStoreIfNeeded(page);
    
    const pageInfo = await page.evaluate(() => {
      return {
        title: document.title,
        bodyClasses: document.body.className,
        hasInfiniteScroll: !!(document.querySelector('.infinite-scroll') || 
                             document.querySelector('[data-infinite-scroll]') ||
                             document.querySelector('.load-more')),
        hasJavaScriptProducts: !!document.querySelector('[data-products]'),
        metaDescription: document.querySelector('meta[name="description"]')?.content,
        canonicalUrl: document.querySelector('link[rel="canonical"]')?.href
      };
    });
    
    console.log("📊 Page Info:", pageInfo);
    
    console.log("\n⏳ Keeping browser open for 30 seconds for manual inspection...");
    console.log("💡 Check the browser window to see the actual page structure");
    await new Promise(resolve => setTimeout(resolve, 30000));
    
  } catch (error) {
    console.error("❌ Debug failed:", error);
  } finally {
    await browser.close();
  }
}

debugProductDetection()
  .then(() => {
    console.log("\n✅ Debug completed");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Debug failed:", err);
    process.exit(1);
  });