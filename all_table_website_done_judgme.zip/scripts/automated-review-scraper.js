// scripts/automated-review-scraper.js
import puppeteer from "puppeteer";
import { PrismaClient } from "@prisma/client";
import dotenv from "dotenv";
import cron from "node-cron";
import crypto from "crypto";

dotenv.config();

const prisma = new PrismaClient();
const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;
const HEADLESS = process.env.PUPPETEER_HEADLESS !== "false";

// Schedule configurations
const REVIEW_SYNC_INTERVAL = process.env.REVIEW_SYNC_INTERVAL || '0 */6 * * *'; // Every 6 hours
const NEW_PRODUCT_CHECK_INTERVAL = process.env.NEW_PRODUCT_CHECK_INTERVAL || '*/30 * * * *'; // Every 30 minutes

/**
 * Generate MD5 hash for duplicate detection
 */
function makeHash(review) {
  return crypto
    .createHash("md5")
    .update(
      `${review.author || ""}-${review.rating || 0}-${review.text || ""}-${review.reviewDate || ""}`
    )
    .digest("hex");
}

/**
 * Unlock Shopify password protected storefront
 */
async function unlockStoreIfNeeded(page) {
  const isPasswordPage = await page.$('input[name="password"]');
  if (isPasswordPage && STORE_PASSWORD) {
    console.log("🔒 Password page detected — submitting password");
    await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2" }),
      page.click('button[type="submit"], input[type="submit"]'),
    ]);
  }
}

/**
 * Extract reviews from product page
 */
/**
 * Enhanced extract reviews function with multiple CSS selector support
 * Add this to both scrape-all-reviews.js and automated-review-scraper.js
 */
async function extractReviewsFromPage(page) {
  // Wait for reviews to load
  await new Promise(resolve => setTimeout(resolve, 3000)); // Increased wait time
  
  return await page.evaluate(() => {
    // Multiple selector patterns for different Judge.me versions
    const selectorPatterns = [
      // Pattern 1: Standard Judge.me (current)
      {
        container: '.jdgm-rev',
        author: '.jdgm-rev__author',
        rating: '.jdgm-star.jdgm-star--on',
        title: '.jdgm-rev__title',
        text: '.jdgm-rev__body',
        date: '.jdgm-rev__timestamp'
      },
      // Pattern 2: Alternative Judge.me structure
      {
        container: '[data-review-id]',
        author: '.jdgm-reviewer-name, .reviewer-name',
        rating: '.jdgm-star--on, .star--on, .rating-star.filled',
        title: '.jdgm-review-title, .review-title',
        text: '.jdgm-review-body, .review-body, .review-content',
        date: '.jdgm-review-date, .review-date'
      },
      // Pattern 3: Newer Judge.me widget
      {
        container: '.review-widget .review-item, .review-entry',
        author: '.author-name, [data-author]',
        rating: '.stars .star.filled, .rating .star.filled',
        title: '.review-title h3, .review-title',
        text: '.review-text, .review-body p',
        date: '.review-date, [data-date]'
      },
      // Pattern 4: Generic review structure (fallback)
      {
        container: '[class*="review"], [id*="review"]',
        author: '[class*="author"], [class*="name"]',
        rating: '[class*="star"][class*="fill"], [class*="rating"] [class*="active"]',
        title: '[class*="title"]',
        text: '[class*="text"], [class*="body"], [class*="content"]',
        date: '[class*="date"], [class*="time"]'
      }
    ];
    
    let allReviews = [];
    
    // Try each selector pattern
    for (const pattern of selectorPatterns) {
      const containers = document.querySelectorAll(pattern.container);
      
      if (containers.length > 0) {
        console.log(`Found ${containers.length} reviews with pattern: ${pattern.container}`);
        
        containers.forEach((container, index) => {
          try {
            // Extract author
            let author = 'Anonymous';
            const authorElement = container.querySelector(pattern.author);
            if (authorElement) {
              author = authorElement.textContent?.trim() || 'Anonymous';
            }
            
            // Extract rating (count filled stars)
            let rating = 0;
            const starElements = container.querySelectorAll(pattern.rating);
            rating = starElements.length;
            
            // If no filled stars found, try alternative methods
            if (rating === 0) {
              // Look for numeric rating
              const ratingText = container.textContent.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/)\s*5|(\d+)\s*stars?/i);
              if (ratingText) {
                rating = parseInt(ratingText[1] || ratingText[2]) || 0;
              }
            }
            
            // Extract title
            let title = '';
            const titleElement = container.querySelector(pattern.title);
            if (titleElement) {
              title = titleElement.textContent?.trim() || '';
            }
            
            // Extract review text
            let text = '';
            const textElement = container.querySelector(pattern.text);
            if (textElement) {
              text = textElement.textContent?.trim() || '';
            }
            
            // Extract date
            let reviewDate = null;
            const dateElement = container.querySelector(pattern.date);
            if (dateElement) {
              reviewDate = dateElement.textContent?.trim() || null;
            }
            
            // Only add if we have meaningful data
            if (author !== 'Anonymous' || text.length > 0 || rating > 0) {
              allReviews.push({
                author,
                rating,
                title,
                text,
                reviewDate,
                extractedWith: pattern.container // Debug info
              });
            }
          } catch (error) {
            console.error(`Error extracting review ${index}:`, error);
          }
        });
        
        // If we found reviews with this pattern, don't try others
        if (allReviews.length > 0) {
          console.log(`Successfully extracted ${allReviews.length} reviews`);
          break;
        }
      }
    }
    
    // If no reviews found with standard patterns, try manual inspection
    if (allReviews.length === 0) {
      console.log('No reviews found with standard patterns, trying manual inspection...');
      
      // Look for any text that might be review content
      const possibleReviews = document.querySelectorAll('*');
      const reviewTexts = [];
      
      possibleReviews.forEach(element => {
        const text = element.textContent?.trim();
        // Look for substantial text that might be a review
        if (text && text.length > 20 && text.length < 1000) {
          // Check if text contains review-like content
          if (text.match(/good|great|excellent|poor|bad|recommend|love|hate|quality|product/i)) {
            const parent = element.closest('[class*="review"], [id*="review"]') || element;
            reviewTexts.push({
              text: text,
              element: element.tagName,
              classes: element.className,
              parent: parent.className
            });
          }
        }
      });
      
      console.log('Possible review content found:', reviewTexts.length);
      if (reviewTexts.length > 0) {
        console.log('Sample:', reviewTexts[0]);
      }
    }
    
    // Remove duplicates based on content
    const uniqueReviews = allReviews.filter((review, index, self) => 
      index === self.findIndex(r => 
        r.author === review.author && 
        r.text === review.text && 
        r.rating === review.rating
      )
    );
    
    console.log(`Final review count: ${uniqueReviews.length}`);
    return uniqueReviews;
  });
}

/**
 * Save review in DB
 */
async function saveReview(review, productId) {
  const contentHash = makeHash(review);

  return await prisma.review.upsert({
    where: { productId_contentHash: { productId, contentHash } },
    create: {
      productId,
      author: review.author,
      rating: review.rating,
      title: review.title,
      text: review.text,
      verified: false,
      helpful: 0,
      platform: "Scraped",
      reviewDate: review.reviewDate,
      contentHash,
    },
    update: {
      rating: review.rating,
      text: review.text,
      updatedAt: new Date(),
    },
  });
}

/**
 * Scrape reviews for specific products
 */
async function scrapeReviewsForProducts(productIds = null) {
  console.log(`🔄 [${new Date().toISOString()}] Starting review scraping...`);
  
  const browser = await puppeteer.launch({
    headless: HEADLESS,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
  });
  
  const page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 768 });
  
  try {
    // Get products to scrape
    const whereClause = productIds ? { id: { in: productIds } } : { status: 'ACTIVE' };
    const products = await prisma.product.findMany({
      where: whereClause,
      select: { id: true, handle: true, title: true }
    });
    
    console.log(`📦 Scraping reviews for ${products.length} products`);
    
    let totalNewReviews = 0;
    let totalUpdatedReviews = 0;
    
    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      const url = `${STORE_URL}/products/${product.handle}`;
      
      console.log(`➡️ [${i+1}/${products.length}] ${product.handle}`);
      
      try {
        await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
        await unlockStoreIfNeeded(page);

        const reviews = await extractReviewsFromPage(page);
        
        if (reviews.length > 0) {
          console.log(`📝 Found ${reviews.length} reviews`);
          
          for (const review of reviews) {
            const result = await saveReview(review, product.id);
            // Check if it's a new review or updated
            // Prisma upsert doesn't return info about create vs update
            // We'll count them all as processed
          }
          
          totalNewReviews += reviews.length;
        }
        
        // Small delay between requests
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error(`❌ Error processing ${product.handle}:`, error.message);
        continue;
      }
    }
    
    console.log(`✅ Review scraping completed`);
    console.log(`📝 Processed ${totalNewReviews} reviews across ${products.length} products`);
    
    return { productsProcessed: products.length, reviewsProcessed: totalNewReviews };
    
  } catch (error) {
    console.error("❌ Review scraping failed:", error);
    throw error;
  } finally {
    await browser.close();
  }
}

/**
 * Check for products that haven't been scraped recently
 */
async function getProductsNeedingReviewUpdate() {
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  
  // Get products that either have no reviews or reviews older than 24 hours
  const products = await prisma.product.findMany({
    where: {
      status: 'ACTIVE',
      OR: [
        { reviews: { none: {} } },  // No reviews at all
        { 
          reviews: { 
            every: { 
              updatedAt: { lt: oneDayAgo } 
            } 
          } 
        }  // All reviews older than 24 hours
      ]
    },
    select: { id: true, handle: true }
  });
  
  return products.map(p => p.id);
}

/**
 * Smart review scraping - only scrape products that need updates
 */
async function smartReviewScraping() {
  console.log(`🧠 [${new Date().toISOString()}] Smart review scraping started...`);
  
  try {
    const productIds = await getProductsNeedingReviewUpdate();
    
    if (productIds.length === 0) {
      console.log("✅ All products have recent review data");
      return;
    }
    
    console.log(`🎯 Found ${productIds.length} products needing review updates`);
    await scrapeReviewsForProducts(productIds);
    
  } catch (error) {
    console.error("❌ Smart review scraping failed:", error);
  }
}

/**
 * Full review scraping - scrape all active products
 */
async function fullReviewScraping() {
  console.log(`🌍 [${new Date().toISOString()}] Full review scraping started...`);
  
  try {
    await scrapeReviewsForProducts(); // No productIds = all products
  } catch (error) {
    console.error("❌ Full review scraping failed:", error);
  }
}

/**
 * Run once and exit
 */
async function runOnce(type = 'full') {
  try {
    if (type === 'smart') {
      await smartReviewScraping();
    } else {
      await fullReviewScraping();
    }
  } finally {
    await prisma.$disconnect();
    process.exit(0);
  }
}

/**
 * Start scheduled review scraping
 */
function startScheduledReviewScraping() {
  console.log(`🕐 Review scraping scheduler starting...`);
  console.log(`📅 Full scraping: ${REVIEW_SYNC_INTERVAL}`);
  console.log(`🎯 Smart scraping: ${NEW_PRODUCT_CHECK_INTERVAL}`);
  
  // Full review scraping (every 6 hours by default)
  cron.schedule(REVIEW_SYNC_INTERVAL, async () => {
    await fullReviewScraping();
  });
  
  // Smart review scraping (every 30 minutes by default)
  cron.schedule(NEW_PRODUCT_CHECK_INTERVAL, async () => {
    await smartReviewScraping();
  });
  
  // Run smart scraping once immediately
  smartReviewScraping();
  
  console.log(`✅ Review scraping scheduler started`);
}

// Handle command line arguments
const args = process.argv.slice(2);

if (args.includes('--once')) {
  const type = args.includes('--smart') ? 'smart' : 'full';
  runOnce(type);
} else if (args.includes('--smart')) {
  runOnce('smart');
} else if (args.includes('--full')) {
  runOnce('full');
} else {
  startScheduledReviewScraping();
}