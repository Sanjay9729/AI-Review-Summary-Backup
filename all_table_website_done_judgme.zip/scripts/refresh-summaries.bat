@echo off
echo Refreshing AI summaries for all products...
node scripts/refresh-ai-summaries.js
pause