// scripts/generate-ai-summaries.js - Updated for GROQ API
import pkg from '@prisma/client';
const { PrismaClient } = pkg;
import dotenv from "dotenv";
import { generateAISummaryForProduct } from '../utils/aiSummaryGenerator.js';

dotenv.config();

const prisma = new PrismaClient();

/**
 * Generate and store AI summary for a product
 */
async function generateSummaryForProduct(product) {
  await generateAISummaryForProduct(prisma, product);
}

/**
 * Generate summaries for all products with reviews
 */
async function generateAllSummaries() {
  console.log("🚀 Starting AI summary generation...");

  try {
    // Get all products that have reviews
    const products = await prisma.product.findMany({
      where: {
        reviews: {
          some: {}
        }
      },
      select: {
        id: true,
        title: true,
        handle: true,
        _count: {
          select: {
            reviews: true
          }
        }
      }
    });

    console.log(`📦 Found ${products.length} products with reviews`);

    if (products.length === 0) {
      console.log("⚠️ No products with reviews found");
      return;
    }

    // Generate summaries for each product
    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      console.log(`\n[${i + 1}/${products.length}] Processing: ${product.title} (${product._count.reviews} reviews)`);
      
      await generateSummaryForProduct(product);
      
      // Add delay to avoid rate limiting
      if (i < products.length - 1) {
        console.log("⏳ Waiting 2 seconds...");
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    console.log("\n🎉 AI summary generation completed!");

    // Display final stats
    const summaryCount = await prisma.aISummary.count();
    console.log(`📈 Total AI summaries in database: ${summaryCount}`);

  } catch (error) {
    console.error("❌ Error in summary generation:", error);
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Generate summary for specific product by handle
 */
async function generateSummaryForSpecificProduct(productHandle) {
  try {
    const product = await prisma.product.findUnique({
      where: { handle: productHandle },
      select: { id: true, title: true, handle: true }
    });

    if (!product) {
      console.log(`❌ Product not found: ${productHandle}`);
      return;
    }

    await generateSummaryForProduct(product);

  } catch (error) {
    console.error(`❌ Error generating summary for ${productHandle}:`, error);
  } finally {
    await prisma.$disconnect();
  }
}

// Command line interface
const args = process.argv.slice(2);

if (args.length === 0) {
  // Generate summaries for all products
  generateAllSummaries();
} else if (args[0] === '--product' && args[1]) {
  // Generate summary for specific product
  generateSummaryForSpecificProduct(args[1]);
} else {
  console.log("Usage:");
  console.log("  node scripts/generate-ai-summaries.js                    # All products");
  console.log("  node scripts/generate-ai-summaries.js --product [handle] # Specific product");
  process.exit(1);
}