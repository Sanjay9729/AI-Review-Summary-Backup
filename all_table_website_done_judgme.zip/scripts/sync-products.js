// scripts/sync-products.js
import puppeteer from "puppeteer";
import { PrismaClient } from "@prisma/client";
import dotenv from "dotenv";
import cron from "node-cron";

dotenv.config();

const prisma = new PrismaClient();
const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;
const SYNC_INTERVAL = process.env.SYNC_INTERVAL || '*/15 * * * *'; // Every 15 minutes

/**
 * Unlock Shopify password protected storefront
 */
async function unlockStoreIfNeeded(page) {
  const isPasswordPage = await page.$('input[name="password"]');
  if (isPasswordPage && STORE_PASSWORD) {
    console.log("🔒 Password page detected — submitting password");
    await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2" }),
      page.click('button[type="submit"], input[type="submit"]'),
    ]);
  }
}

/**
 * Get all products from Shopify JSON API (Fixed version)
 */
async function getShopifyProducts() {
  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });
  
  const page = await browser.newPage();
  
  try {
    // Method 1: Try products.json first
    await page.goto(`${STORE_URL}/products.json`, { waitUntil: "networkidle2" });
    await unlockStoreIfNeeded(page);
    
    let products = await page.evaluate(() => {
      try {
        const text = document.body.textContent;
        const data = JSON.parse(text);
        
        if (data.products && Array.isArray(data.products)) {
          return data.products.map(product => ({
            handle: product.handle,
            title: product.title,
            shopifyId: product.id.toString(),
            status: product.status || 'active'
          }));
        }
        return [];
      } catch (e) {
        console.error("JSON parse error:", e);
        return [];
      }
    });
    
    // Method 2: If no products found, try paginated approach
    if (products.length === 0) {
      console.log("🔄 Trying paginated JSON...");
      let allProducts = [];
      let pageNum = 1;
      
      do {
        let url = `${STORE_URL}/products.json?limit=250`;
        if (pageNum > 1) {
          url += `&page=${pageNum}`;
        }
        
        console.log(`📄 Fetching page ${pageNum}: ${url}`);
        await page.goto(url, { waitUntil: "networkidle2" });
        await unlockStoreIfNeeded(page);
        
        const pageData = await page.evaluate(() => {
          try {
            const text = document.body.textContent;
            const data = JSON.parse(text);
            
            const products = data.products || [];
            return {
              products: products.map(product => ({
                handle: product.handle,
                title: product.title,
                shopifyId: product.id.toString(),
                status: product.status || 'active'
              })),
              hasMore: products.length === 250
            };
          } catch (e) {
            return { products: [], hasMore: false };
          }
        });
        
        allProducts = allProducts.concat(pageData.products);
        
        if (!pageData.hasMore || pageData.products.length === 0) {
          break;
        }
        
        pageNum++;
        
        if (pageNum > 10) { // Safety limit
          console.log("⚠️ Reached pagination limit");
          break;
        }
        
      } while (pageNum <= 10);
      
      products = allProducts;
    }
    
    console.log(`📦 Found ${products.length} products via JSON API`);
    return products;
    
  } catch (error) {
    console.error("❌ Error fetching Shopify products:", error);
    return [];
  } finally {
    await browser.close();
  }
}

/**
 * Sync products with database
 */
async function syncProducts() {
  console.log(`🔄 [${new Date().toISOString()}] Starting product sync...`);
  
  try {
    // Get products from Shopify
    const shopifyProducts = await getShopifyProducts();
    console.log(`📦 Found ${shopifyProducts.length} products in Shopify`);
    
    if (shopifyProducts.length === 0) {
      console.log("⚠️ No products found, skipping sync");
      return;
    }
    
    // Get existing products from database
    const existingProducts = await prisma.product.findMany({
      select: { handle: true, shopifyId: true, title: true }
    });
    
    const existingHandles = new Set(existingProducts.map(p => p.handle));
    
    // Find new products to add
    const newProducts = shopifyProducts.filter(p => !existingHandles.has(p.handle));
    
    // Add new products
    if (newProducts.length > 0) {
      console.log(`➕ Adding ${newProducts.length} new products:`);
      
      for (const product of newProducts) {
        await prisma.product.create({
          data: {
            handle: product.handle,
            title: product.title,
            status: product.status.toUpperCase(),
            shopifyId: product.shopifyId,
          },
        });
        console.log(`   ✅ Added: ${product.handle}`);
      }
    } else {
      console.log("📝 No new products to add");
    }
    
    // Update existing products (title changes, status changes)
    const existingProductMap = new Map(existingProducts.map(p => [p.handle, p]));
    const productsToUpdate = shopifyProducts.filter(sp => {
      const existing = existingProductMap.get(sp.handle);
      return existing && (existing.title !== sp.title || existing.shopifyId !== sp.shopifyId);
    });
    
    if (productsToUpdate.length > 0) {
      console.log(`📝 Updating ${productsToUpdate.length} products:`);
      
      for (const product of productsToUpdate) {
        await prisma.product.update({
          where: { handle: product.handle },
          data: {
            title: product.title,
            shopifyId: product.shopifyId,
            status: product.status.toUpperCase(),
            updatedAt: new Date(),
          },
        });
        console.log(`   ✅ Updated: ${product.handle}`);
      }
    }
    
    // Check for deleted products (exist in DB but not in Shopify)
    const shopifyHandles = new Set(shopifyProducts.map(p => p.handle));
    const deletedProducts = existingProducts.filter(p => !shopifyHandles.has(p.handle));
    
    if (deletedProducts.length > 0) {
      console.log(`🗑️ Marking ${deletedProducts.length} products as deleted:`);
      
      for (const product of deletedProducts) {
        await prisma.product.update({
          where: { handle: product.handle },
          data: { status: 'DELETED' },
        });
        console.log(`   ✅ Deleted: ${product.handle}`);
      }
    }
    
    console.log(`✅ Sync completed successfully`);
    
  } catch (error) {
    console.error("❌ Sync failed:", error);
  }
}

/**
 * Run sync immediately (for testing)
 */
async function runOnce() {
  await syncProducts();
  await prisma.$disconnect();
  process.exit(0);
}

/**
 * Start scheduled sync
 */
function startScheduledSync() {
  console.log(`🕐 Scheduled sync starting with interval: ${SYNC_INTERVAL}`);
  
  // Run once immediately
  syncProducts();
  
  // Schedule recurring sync
  cron.schedule(SYNC_INTERVAL, async () => {
    await syncProducts();
  });
  
  console.log(`✅ Sync scheduler started`);
}

// Check command line arguments
const args = process.argv.slice(2);

if (args.includes('--once')) {
  runOnce();
} else {
  startScheduledSync();
}