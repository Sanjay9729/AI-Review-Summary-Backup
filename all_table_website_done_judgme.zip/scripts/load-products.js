#!/usr/bin/env node

// scripts/load-products.js
import { PrismaClient } from '@prisma/client';

/**
 * CLI script for loading products from Shopify into database
 *
 * Usage:
 * node scripts/load-products.js --shop=your-shop.myshopify.com
 */

function parseArgs() {
  const args = {};
  process.argv.slice(2).forEach(arg => {
    if (arg.startsWith('--')) {
      const [key, value] = arg.slice(2).split('=');
      args[key] = value || true;
    }
  });
  return args;
}

function showHelp() {
  console.log(`
🛍️  Product Loading CLI

Usage:
   Load products: node scripts/load-products.js --shop=your-shop.myshopify.com

Options:
   --shop             Shop domain (e.g., mystore.myshopify.com)
   --help             Show this help message

Examples:
   node scripts/load-products.js --shop=sanjayvaghela-testing.myshopify.com
   `);
}

async function fetchAllProducts(admin) {
  const products = [];
  let hasNextPage = true;
  let cursor = null;

  console.log('📦 Fetching products from Shopify...');

  while (hasNextPage) {
    const query = `
      query getProducts($after: String) {
        products(first: 250, after: $after) {
          edges {
            node {
              id
              title
              handle
              status
              description
              vendor
              productType
              tags
              featuredImage {
                url
              }
              createdAt
              updatedAt
            }
            cursor
          }
          pageInfo {
            hasNextPage
            endCursor
          }
        }
      }
    `;

    const variables = {};
    if (cursor) {
      variables.after = cursor;
    }

    try {
      console.log('📊 Variables:', variables);
      const response = await admin.graphql(query, { variables });
      const body = await response.json();

      if (body.errors) {
        console.error('❌ GraphQL errors:', JSON.stringify(body.errors, null, 2));
        throw new Error('GraphQL query failed');
      }

      const { edges, pageInfo } = body.data.products;
      const batch = edges.map(edge => edge.node);

      products.push(...batch);
      hasNextPage = pageInfo.hasNextPage;
      cursor = pageInfo.endCursor;

      console.log(`📦 Fetched ${batch.length} products (total: ${products.length})`);

      // Small delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 100));

    } catch (error) {
      console.error('❌ Error fetching products:', error.message);
      throw error;
    }
  }

  return products;
}

async function upsertProducts(prisma, products, shop) {
  console.log('💾 Upserting products to database...');

  let upserted = 0;
  let skipped = 0;

  for (const product of products) {
    try {
      // Extract Shopify ID from GraphQL ID (remove gid://shopify/Product/)
      const shopifyId = product.id.replace('gid://shopify/Product/', '');

      await prisma.product.upsert({
        where: { shopifyId: shopifyId },
        update: {
          shopifyId,
          title: product.title,
          status: product.status.toUpperCase(),
          description: product.description,
          vendor: product.vendor,
          productType: product.productType,
          tags: product.tags || [],
          featuredImageUrl: product.featuredImage?.url || null,
          updatedAt: new Date(product.updatedAt)
        },
        create: {
          shopifyId,
          handle: product.handle,
          title: product.title,
          status: product.status.toUpperCase(),
          description: product.description,
          vendor: product.vendor,
          productType: product.productType,
          tags: product.tags || [],
          featuredImageUrl: product.featuredImage?.url || null,
          createdAt: new Date(product.createdAt),
          updatedAt: new Date(product.updatedAt)
        }
      });

      upserted++;
    } catch (error) {
      console.error(`❌ Error upserting product ${product.handle}:`, error.message);
      skipped++;
    }
  }

  return { upserted, skipped };
}

async function main() {
  const args = parseArgs();

  if (args.help) {
    showHelp();
    process.exit(0);
  }

  const { shop } = args;

  if (!shop) {
    console.error('❌ Shop domain is required');
    showHelp();
    process.exit(1);
  }

  try {
    console.log(`🚀 Starting product load for ${shop}...`);

    // Initialize Prisma
    const prisma = new PrismaClient();

    // Initialize Shopify admin (this might need session setup)
    // For CLI, we need to create a session or use direct API
    // Since it's a CLI script, we'll use the access token directly

    const accessToken = process.env.SHOPIFY_ACCESS_TOKEN;
    if (!accessToken) {
      console.error('❌ SHOPIFY_ACCESS_TOKEN not found in environment');
      process.exit(1);
    }

    // Create a simple admin client
    const admin = {
      graphql: async (query, variables = {}) => {
        const url = `https://${shop}/admin/api/2025-07/graphql.json`;
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Shopify-Access-Token': accessToken,
          },
          body: JSON.stringify({ query, variables }),
        });
        return response;
      }
    };

    // Fetch all products
    const products = await fetchAllProducts(admin);

    if (products.length === 0) {
      console.log('⚠️  No products found in Shopify');
      return;
    }

    console.log(`✅ Fetched ${products.length} products from Shopify`);

    // Upsert to database
    const { upserted, skipped } = await upsertProducts(prisma, products, shop);

    console.log(`\\n📊 Summary:`);
    console.log(`✅ Upserted: ${upserted} products`);
    if (skipped > 0) console.log(`⚠️  Skipped: ${skipped} products`);
    console.log(`📦 Total products in database: ${await prisma.product.count()}`);

    await prisma.$disconnect();

    console.log('\\n🎉 Product loading completed successfully!');

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

// Run the script
main().catch(error => {
  console.error('❌ Unexpected error:', error);
  process.exit(1);
});