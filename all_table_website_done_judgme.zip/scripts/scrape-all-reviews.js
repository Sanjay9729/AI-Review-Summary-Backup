// import puppeteer from 'puppeteer';
// import prisma from '../lib/prisma.js';
// import dotenv from 'dotenv';
// import crypto from 'crypto';

// dotenv.config();

// const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
// const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;
// const HEADLESS = process.env.PUPPETEER_HEADLESS !== 'false';

// function makeHash(review) {
//   return crypto
//     .createHash('md5')
//     .update(
//       `${review.author || ''}-${review.rating || 0}-${review.text || ''}-${review.reviewDate || ''}`
//     )
//     .digest('hex');
// }

// async function unlockStoreIfNeeded(page) {
//   const isPasswordPage = await page.$('input[name="password"]');
//   if (isPasswordPage && STORE_PASSWORD) {
//     console.log('🔒 Password page detected — submitting password');
//     await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
//     await Promise.all([
//       page.waitForNavigation({ waitUntil: 'networkidle2' }),
//       page.click('button[type="submit"], input[type="submit"]'),
//     ]);
//     console.log('✅ Unlocked storefront');
//   }
// }

// async function getAllProductHandles(page) {
//   const collectionUrl = `${STORE_URL}/collections/all`;
//   await page.goto(collectionUrl, { waitUntil: 'networkidle2' });
//   await unlockStoreIfNeeded(page);

//   return await page.evaluate(() => {
//     return Array.from(document.querySelectorAll('a[href*="/products/"]'))
//       .map((a) => a.getAttribute('href'))
//       .filter(Boolean)
//       .map((href) => href.split('/products/')[1])
//       .filter((v, i, arr) => arr.indexOf(v) === i); // unique
//   });
// }

// async function extractReviewsFromPage(page) {
//   // ⚠️ यहां selectors आपके review widget के हिसाब से बदलने होंगे
//   return await page.evaluate(() => {
//     const nodes = Array.from(document.querySelectorAll('.jdgm-rev')); // Example for Judge.me
//     return nodes.map((node) => {
//       const author = node.querySelector('.jdgm-rev__author')?.textContent?.trim() || 'Anonymous';
//       const rating = node.querySelector('.jdgm-rev__rating')?.textContent?.trim()?.length || 0;
//       const title = node.querySelector('.jdgm-rev__title')?.textContent?.trim() || '';
//       const text = node.querySelector('.jdgm-rev__body')?.textContent?.trim() || '';
//       const reviewDate = node.querySelector('.jdgm-rev__timestamp')?.textContent?.trim() || null;

//       return { author, rating, title, text, reviewDate };
//     });
//   });
// }

// async function saveReview(review, productId) {
//   const contentHash = makeHash(review);

//   await prisma.review.upsert({
//     where: { productId_contentHash: { productId, contentHash } },
//     create: {
//       productId,
//       author: review.author,
//       rating: review.rating,
//       title: review.title,
//       text: review.text,
//       verified: false,
//       helpful: 0,
//       platform: 'Scraped',
//       reviewDate: review.reviewDate,
//       contentHash,
//     },
//     update: {
//       rating: review.rating,
//       text: review.text,
//       updatedAt: new Date(),
//     },
//   });
// }

// async function scrapeAllReviews() {
//   const browser = await puppeteer.launch({
//     headless: HEADLESS,
//     args: ['--no-sandbox', '--disable-setuid-sandbox'],
//   });
//   const page = await browser.newPage();

//   // Step 1: get all product handles
//   const handles = await getAllProductHandles(page);
//   console.log(`📦 Found ${handles.length} products`);

//   // Step 2: visit each product and scrape reviews
// // Ensure all products exist in DB
// for (const handle of handles) {
//   let product = await prisma.product.findUnique({ where: { handle } });
//   if (!product) {
//     await prisma.product.create({
//       data: {
//         handle,
//         title: handle, // आप चाहो तो Puppeteer से title scrape करके डाल सकते हो
//         status: 'ACTIVE',
//       },
//     });
//   }
// }


//   await browser.close();
//   await prisma.$disconnect();
// }

// // run
// scrapeAllReviews()
//   .then(() => {
//     console.log('✅ Done scraping all reviews');
//     process.exit(0);
//   })
//   .catch((err) => {
//     console.error('❌ Scrape failed:', err);
//     process.exit(1);
//   });



// scripts/scrape-all-reviews.js
import puppeteer from "puppeteer";
import prisma from "../lib/prisma.js";
import dotenv from "dotenv";
import crypto from "crypto";

dotenv.config();

const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;
const HEADLESS = process.env.PUPPETEER_HEADLESS !== "false";

/**
 * Generate MD5 hash for duplicate detection
 */
function makeHash(review) {
  return crypto
    .createHash("md5")
    .update(
      `${review.author || ""}-${review.rating || 0}-${review.text || ""}-${review.reviewDate || ""}`
    )
    .digest("hex");
}

/**
 * Unlock Shopify password protected storefront
 */
async function unlockStoreIfNeeded(page) {
  const isPasswordPage = await page.$('input[name="password"]');
  if (isPasswordPage && STORE_PASSWORD) {
    console.log("🔒 Password page detected — submitting password");
    await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2" }),
      page.click('button[type="submit"], input[type="submit"]'),
    ]);
    console.log("✅ Unlocked storefront");
  }
}

/**
 * Get all product handles using Shopify Products JSON API
 */
async function getAllProductHandlesFromJSON(page) {
  console.log("🔍 Getting products from JSON API...");
  
  try {
    // Method 1: Try products.json (most reliable)
    await page.goto(`${STORE_URL}/products.json`, { waitUntil: "networkidle2" });
    await unlockStoreIfNeeded(page);
    
    const jsonProducts = await page.evaluate(() => {
      try {
        const text = document.body.textContent;
        const data = JSON.parse(text);
        
        if (data.products && Array.isArray(data.products)) {
          return data.products.map(product => ({
            handle: product.handle,
            title: product.title,
            id: product.id
          }));
        }
        return [];
      } catch (e) {
        console.error("JSON parse error:", e);
        return [];
      }
    });
    
    if (jsonProducts.length > 0) {
      console.log(`📦 Found ${jsonProducts.length} products via JSON API`);
      return jsonProducts.map(p => p.handle);
    }
    
    // Method 2: Try paginated JSON if first method returns empty
    console.log("🔄 Trying paginated JSON...");
    let allHandles = [];
    let page_info = null;
    let pageNum = 1;
    
    do {
      let url = `${STORE_URL}/products.json?limit=250`;
      if (page_info) {
        url += `&page_info=${page_info}`;
      }
      
      console.log(`📄 Fetching page ${pageNum}: ${url}`);
      await page.goto(url, { waitUntil: "networkidle2" });
      await unlockStoreIfNeeded(page);
      
      const pageData = await page.evaluate(() => {
        try {
          const text = document.body.textContent;
          const data = JSON.parse(text);
          
          const products = data.products || [];
          const handles = products.map(p => p.handle);
          
          // Check for pagination info in response headers or data
          const hasMore = products.length === 250; // If we got max limit, there might be more
          
          return { handles, hasMore };
        } catch (e) {
          return { handles: [], hasMore: false };
        }
      });
      
      allHandles = allHandles.concat(pageData.handles);
      
      if (!pageData.hasMore || pageData.handles.length === 0) {
        break;
      }
      
      // For simple pagination, increment page number
      pageNum++;
      page_info = null; // Reset for simple pagination
      
      if (pageNum > 10) { // Safety limit
        console.log("⚠️ Reached pagination limit");
        break;
      }
      
    } while (pageNum <= 10);
    
    // Remove duplicates
    const uniqueHandles = [...new Set(allHandles)];
    console.log(`📦 Found ${uniqueHandles.length} unique products via paginated JSON`);
    return uniqueHandles;
    
  } catch (error) {
    console.error("❌ JSON API failed:", error.message);
    return [];
  }
}

/**
 * Fallback: Get products from collections page (improved)
 */
async function getAllProductHandlesFromCollection(page) {
  console.log("🔄 Fallback: Using collections page...");
  
  try {
    // Try the URL that worked in debug (with limit parameter)
    const collectionUrl = `${STORE_URL}/collections/all?limit=250`;
    await page.goto(collectionUrl, { waitUntil: "networkidle2" });
    await unlockStoreIfNeeded(page);
    
    // Enhanced scroll
    await page.evaluate(async () => {
      let previousHeight = 0;
      let currentHeight = document.body.scrollHeight;
      let attempts = 0;
      
      while (previousHeight !== currentHeight && attempts < 10) {
        previousHeight = currentHeight;
        window.scrollTo(0, document.body.scrollHeight);
        await new Promise(resolve => setTimeout(resolve, 1000));
        currentHeight = document.body.scrollHeight;
        attempts++;
      }
    });
    
    const handles = await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a[href*="/products/"]'));
      const uniqueHrefs = [...new Set(links.map(a => a.getAttribute('href')))];
      
      return uniqueHrefs
        .map(href => {
          const match = href.match(/\/products\/([^?#\/]+)/);
          return match ? match[1] : null;
        })
        .filter(Boolean)
        .filter((v, i, arr) => arr.indexOf(v) === i); // Remove duplicates
    });
    
    console.log(`📦 Collection fallback found ${handles.length} products`);
    return handles;
    
  } catch (error) {
    console.error("❌ Collection fallback failed:", error.message);
    return [];
  }
}

/**
 * Enhanced extract reviews function with multiple CSS selector support
 * Add this to both scrape-all-reviews.js and automated-review-scraper.js
 */
async function extractReviewsFromPage(page) {
  // Wait for reviews to load
  await new Promise(resolve => setTimeout(resolve, 3000)); // Increased wait time
  
  return await page.evaluate(() => {
    // Multiple selector patterns for different Judge.me versions
    const selectorPatterns = [
      // Pattern 1: Standard Judge.me (current)
      {
        container: '.jdgm-rev',
        author: '.jdgm-rev__author',
        rating: '.jdgm-star.jdgm-star--on',
        title: '.jdgm-rev__title',
        text: '.jdgm-rev__body',
        date: '.jdgm-rev__timestamp'
      },
      // Pattern 2: Alternative Judge.me structure
      {
        container: '[data-review-id]',
        author: '.jdgm-reviewer-name, .reviewer-name',
        rating: '.jdgm-star--on, .star--on, .rating-star.filled',
        title: '.jdgm-review-title, .review-title',
        text: '.jdgm-review-body, .review-body, .review-content',
        date: '.jdgm-review-date, .review-date'
      },
      // Pattern 3: Newer Judge.me widget
      {
        container: '.review-widget .review-item, .review-entry',
        author: '.author-name, [data-author]',
        rating: '.stars .star.filled, .rating .star.filled',
        title: '.review-title h3, .review-title',
        text: '.review-text, .review-body p',
        date: '.review-date, [data-date]'
      },
      // Pattern 4: Generic review structure (fallback)
      {
        container: '[class*="review"], [id*="review"]',
        author: '[class*="author"], [class*="name"]',
        rating: '[class*="star"][class*="fill"], [class*="rating"] [class*="active"]',
        title: '[class*="title"]',
        text: '[class*="text"], [class*="body"], [class*="content"]',
        date: '[class*="date"], [class*="time"]'
      }
    ];
    
    let allReviews = [];
    
    // Try each selector pattern
    for (const pattern of selectorPatterns) {
      const containers = document.querySelectorAll(pattern.container);
      
      if (containers.length > 0) {
        console.log(`Found ${containers.length} reviews with pattern: ${pattern.container}`);
        
        containers.forEach((container, index) => {
          try {
            // Extract author
            let author = 'Anonymous';
            const authorElement = container.querySelector(pattern.author);
            if (authorElement) {
              author = authorElement.textContent?.trim() || 'Anonymous';
            }
            
            // Extract rating (count filled stars)
            let rating = 0;
            const starElements = container.querySelectorAll(pattern.rating);
            rating = starElements.length;
            
            // If no filled stars found, try alternative methods
            if (rating === 0) {
              // Look for numeric rating
              const ratingText = container.textContent.match(/(\d+(?:\.\d+)?)\s*(?:out of|\/)\s*5|(\d+)\s*stars?/i);
              if (ratingText) {
                rating = parseInt(ratingText[1] || ratingText[2]) || 0;
              }
            }
            
            // Extract title
            let title = '';
            const titleElement = container.querySelector(pattern.title);
            if (titleElement) {
              title = titleElement.textContent?.trim() || '';
            }
            
            // Extract review text
            let text = '';
            const textElement = container.querySelector(pattern.text);
            if (textElement) {
              text = textElement.textContent?.trim() || '';
            }
            
            // Extract date
            let reviewDate = null;
            const dateElement = container.querySelector(pattern.date);
            if (dateElement) {
              reviewDate = dateElement.textContent?.trim() || null;
            }
            
            // Only add if we have meaningful data
            if (author !== 'Anonymous' || text.length > 0 || rating > 0) {
              allReviews.push({
                author,
                rating,
                title,
                text,
                reviewDate,
                extractedWith: pattern.container // Debug info
              });
            }
          } catch (error) {
            console.error(`Error extracting review ${index}:`, error);
          }
        });
        
        // If we found reviews with this pattern, don't try others
        if (allReviews.length > 0) {
          console.log(`Successfully extracted ${allReviews.length} reviews`);
          break;
        }
      }
    }
    
    // If no reviews found with standard patterns, try manual inspection
    if (allReviews.length === 0) {
      console.log('No reviews found with standard patterns, trying manual inspection...');
      
      // Look for any text that might be review content
      const possibleReviews = document.querySelectorAll('*');
      const reviewTexts = [];
      
      possibleReviews.forEach(element => {
        const text = element.textContent?.trim();
        // Look for substantial text that might be a review
        if (text && text.length > 20 && text.length < 1000) {
          // Check if text contains review-like content
          if (text.match(/good|great|excellent|poor|bad|recommend|love|hate|quality|product/i)) {
            const parent = element.closest('[class*="review"], [id*="review"]') || element;
            reviewTexts.push({
              text: text,
              element: element.tagName,
              classes: element.className,
              parent: parent.className
            });
          }
        }
      });
      
      console.log('Possible review content found:', reviewTexts.length);
      if (reviewTexts.length > 0) {
        console.log('Sample:', reviewTexts[0]);
      }
    }
    
    // Remove duplicates based on content
    const uniqueReviews = allReviews.filter((review, index, self) => 
      index === self.findIndex(r => 
        r.author === review.author && 
        r.text === review.text && 
        r.rating === review.rating
      )
    );
    
    console.log(`Final review count: ${uniqueReviews.length}`);
    return uniqueReviews;
  });
}
/**
 * Save review in DB
 */
async function saveReview(review, productId) {
  const contentHash = makeHash(review);

  await prisma.review.upsert({
    where: { productId_contentHash: { productId, contentHash } },
    create: {
      productId,
      author: review.author,
      rating: review.rating,
      title: review.title,
      text: review.text,
      verified: false,
      helpful: 0,
      platform: "Scraped",
      reviewDate: review.reviewDate,
      contentHash,
    },
    update: {
      rating: review.rating,
      text: review.text,
      updatedAt: new Date(),
    },
  });
}

/**
 * Main function to scrape all products + reviews
 */
async function scrapeAllReviews() {
  const browser = await puppeteer.launch({
    headless: HEADLESS,
    args: [
      "--no-sandbox", 
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-accelerated-2d-canvas",
      "--disable-gpu"
    ],
  });
  
  const page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 768 });
  
  try {
    // Step 1: Get all product handles using JSON API (most reliable)
    let handles = await getAllProductHandlesFromJSON(page);
    
    // Step 2: Fallback to collection page if JSON method fails
    if (handles.length === 0) {
      console.log("🔄 JSON method failed, trying collection page...");
      handles = await getAllProductHandlesFromCollection(page);
    }
    
    console.log(`📦 Final count: ${handles.length} unique products`);
    console.log("📝 Product handles:", handles);
    
    if (handles.length === 0) {
      throw new Error("❌ No products found. Please check your store configuration.");
    }

    // Step 3: Ensure all products exist in DB
    console.log("💾 Creating/updating products in database...");
    for (const handle of handles) {
      let product = await prisma.product.findUnique({ where: { handle } });
      if (!product) {
        console.log(`➕ Creating product: ${handle}`);
        await prisma.product.create({
          data: { handle, title: handle, status: "ACTIVE" },
        });
      }
    }

    // Step 4: Visit each product and scrape reviews
    console.log("📝 Starting review scraping...");
    let totalReviews = 0;
    
    for (let i = 0; i < handles.length; i++) {
      const handle = handles[i];
      const url = `${STORE_URL}/products/${handle}`;
      console.log(`➡️ [${i+1}/${handles.length}] Visiting: ${url}`);
      
      try {
        await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
        await unlockStoreIfNeeded(page);

        const product = await prisma.product.findUnique({ where: { handle } });
        if (!product) {
          console.log(`⚠️ Product not found in DB: ${handle}`);
          continue;
        }

        const reviews = await extractReviewsFromPage(page);
        console.log(`📝 Found ${reviews.length} reviews for ${handle}`);
        totalReviews += reviews.length;

        for (const r of reviews) {
          await saveReview(r, product.id);
        }
        
        // Small delay between requests
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error(`❌ Error processing ${handle}:`, error.message);
        continue;
      }
    }
    
    console.log(`\n🎉 Scraping completed successfully!`);
    console.log(`📦 Products processed: ${handles.length}`);
    console.log(`📝 Total reviews found: ${totalReviews}`);

  } catch (error) {
    console.error("❌ Scraping failed:", error);
    throw error;
  } finally {
    await browser.close();
    await prisma.$disconnect();
  }
}

// Run
scrapeAllReviews()
  .then(() => {
    console.log("✅ Done scraping all products + reviews");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Scrape failed:", err);
    process.exit(1);
  });