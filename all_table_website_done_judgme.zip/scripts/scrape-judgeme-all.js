import puppeteer from "puppeteer";
import crypto from "crypto";
import { prisma } from "../app/prisma.js";

// Helper: MD5 hash for duplicate detection
function generateContentHash(author, rating, text, date) {
  return crypto
    .createHash("md5")
    .update(`${author}-${rating}-${text}-${date}`)
    .digest("hex");
}

// Puppeteer scraping logic
async function scrapeReviews(productHandle) {
  const browser = await puppeteer.launch({
    headless: process.env.PUPPETEER_HEADLESS === "true",
  });
  const page = await browser.newPage();

  const url = `https://${process.env.SHOPIFY_STORE}/products/${productHandle}`;
  console.log("➡️ Navigating to:", url);
  await page.goto(url, { waitUntil: "networkidle2", timeout: 60000 });

  // Wait for Judge.me review widget
  try {
    await page.waitForSelector(".jdgm-rev", { timeout: 10000 });
  } catch {
    console.warn(`⚠️ No reviews found for ${productHandle}`);
    await browser.close();
    return [];
  }

  // Extract reviews
  const reviews = await page.$$eval(".jdgm-rev", (nodes) =>
    nodes.map((el) => ({
      author:
        el.querySelector(".jdgm-rev__author")?.textContent?.trim() ||
        "Anonymous",
      rating: Number(
        el
          .querySelector(".jdgm-rev__rating")
          ?.getAttribute("data-score") || 0
      ),
      title: el.querySelector(".jdgm-rev__title")?.textContent?.trim() || "",
      text: el.querySelector(".jdgm-rev__body")?.textContent?.trim() || "",
      reviewDate:
        el.querySelector(".jdgm-rev__timestamp")?.textContent?.trim() || null,
    }))
  );

  await browser.close();
  return reviews;
}

// Save reviews to DB
async function saveReviews(product, reviews) {
  for (const r of reviews) {
    const hash = generateContentHash(
      r.author,
      r.rating,
      r.text,
      r.reviewDate
    );
    try {
      await prisma.review.create({
        data: {
          productId: product.id,
          author: r.author,
          rating: r.rating,
          title: r.title,
          text: r.text,
          reviewDate: r.reviewDate,
          platform: "Judge.me",
          contentHash: hash,
        },
      });
      console.log(`✅ Inserted review for ${product.handle}: ${r.title}`);
    } catch (err) {
      if (err.code === "P2002") {
        console.log(`⚠️ Duplicate skipped for ${product.handle}: ${r.title}`);
      } else {
        console.error("❌ Error inserting review:", err);
      }
    }
  }
}

// Main function: loop all products
async function scrapeAllProducts() {
  const products = await prisma.product.findMany();

  console.log(`📦 Found ${products.length} products in DB`);

  for (const product of products) {
    console.log(`\n🔍 Scraping reviews for: ${product.handle}`);
    const reviews = await scrapeReviews(product.handle);
    console.log(`📝 Found ${reviews.length} reviews for ${product.handle}`);
    await saveReviews(product, reviews);
  }

  console.log("🎉 All products processed.");
  process.exit(0);
}

// Run
scrapeAllProducts().catch((e) => {
  console.error(e);
  process.exit(1);
});
