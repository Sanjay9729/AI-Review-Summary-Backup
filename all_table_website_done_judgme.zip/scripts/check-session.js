import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkSessionTable() {
  try {
    const result = await prisma.$queryRaw`SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'Session'`;
    if (result.length > 0) {
      console.log('✅ Session table exists');
    } else {
      console.log('❌ Session table does not exist');
    }
  } catch (error) {
    console.error('Error checking table:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkSessionTable();