// scripts/scrape-all-products.js
import puppeteer from "puppeteer";
import dotenv from "dotenv";
import prisma from "../lib/prisma.js";
import crypto from "crypto";
dotenv.config();

const SHOPIFY_STORE = process.env.SHOPIFY_STORE_URL;
const SHOPIFY_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD || "";
const WAIT_TIMEOUT = 30000;

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

function contentHash({ author = "", rating = 0, text = "", date = "" }) {
  const s = `${author}||${rating}||${text}||${date}`;
  return crypto.createHash("md5").update(s).digest("hex");
}

async function handlePassword(page) {
  const pwSelector = 'input[type="password"], input[name="password"], #password';
  const pwExists = await page.$(pwSelector);
  if (pwExists) {
    console.log("🔒 Password form detected, submitting...");
    await page.type(pwSelector, SHOPIFY_PASSWORD, { delay: 30 });
    await page.keyboard.press("Enter");
    await page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {});
    console.log("✅ Storefront unlocked.");
  }
}

/** Scrape reviews (Stamped.io widget) */
async function scrapeStampedReviews(page) {
  const reviewSel = ".stamped-review";
  try {
    await page.waitForSelector(reviewSel, { timeout: 8000 });
  } catch {
    console.log("⚠️ No Stamped.io reviews found on this product");
    return [];
  }

  return await page.$$eval(reviewSel, (nodes) =>
    nodes.map((n) => {
      const author =
        n.querySelector(".author, .stamped-review-author")?.innerText?.trim() ||
        "Anonymous";
      const ratingText =
        n.querySelector(".stamped-review-rating")?.getAttribute("data-rating") ||
        "";
      const rating = parseFloat(ratingText) || 0;
      const title =
        n.querySelector(".stamped-review-title")?.innerText?.trim() || "";
      const text =
        n.querySelector(".stamped-review-content")?.innerText?.trim() || "";
      const date =
        n.querySelector(".stamped-review-date")?.innerText?.trim() || "";
      return { author, rating, title, text, date, verified: false };
    })
  );
}

/** Scrape all product handles from /collections/all */
async function getAllProductHandles(page) {
  if (!SHOPIFY_STORE) throw new Error("SHOPIFY_STORE_URL missing in .env");
  const base = SHOPIFY_STORE.startsWith("http")
    ? SHOPIFY_STORE
    : `https://${SHOPIFY_STORE}`;
  const url = `${base.replace(/\/$/, "")}/collections/all`;

  console.log("➡️ Navigating to collection:", url);
  await page.goto(url, { waitUntil: "networkidle2", timeout: WAIT_TIMEOUT });
  await handlePassword(page);

  return await page.$$eval("a[href*='/products/']", (links) =>
    [...new Set(links.map((a) => a.getAttribute("href")))]
      .filter((h) => h.includes("/products/"))
      .map((h) => h.split("/products/")[1].split(/[?#]/)[0])
  );
}

/** Main */
async function main() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  const handles = await getAllProductHandles(page);
  console.log("Found product handles:", handles);

  for (const handle of handles) {
    const base = SHOPIFY_STORE.startsWith("http")
      ? SHOPIFY_STORE
      : `https://${SHOPIFY_STORE}`;
    const productUrl = `${base.replace(/\/$/, "")}/products/${handle}`;

    console.log(`➡️ Scraping ${productUrl}`);

    await page.goto(productUrl, {
      waitUntil: "networkidle2",
      timeout: WAIT_TIMEOUT,
    });
    await handlePassword(page);
    await sleep(2000);

    const reviews = await scrapeStampedReviews(page);
    console.log(`📦 ${handle} — found ${reviews.length} reviews`);

    // Upsert product
    const product = await prisma.product.upsert({
      where: { handle },
      update: { updatedAt: new Date() },
      create: { handle, title: handle },
    });

    // Insert reviews
    for (const r of reviews) {
      const hash = contentHash(r);
      try {
        await prisma.review.create({
          data: {
            productId: product.id,
            author: r.author,
            rating: r.rating,
            title: r.title,
            text: r.text,
            verified: r.verified,
            reviewDate: r.date || null,
            contentHash: hash,
            platform: "Stamped.io",
          },
        });
        console.log(`✅ Inserted review for ${handle}: ${r.author}`);
      } catch (err) {
        if (/unique|duplicate/i.test(err.message)) {
          console.log(`⏩ Skipping duplicate review for ${handle}: ${r.author}`);
        } else {
          console.error("❌ DB error:", err.message);
        }
      }
    }
  }

  await browser.close();
  await prisma.$disconnect();
  console.log("🎉 Done scraping all products.");
}

main();
