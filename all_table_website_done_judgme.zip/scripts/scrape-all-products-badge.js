// scripts/scrape-all-products-badge.js
import puppeteer from "puppeteer";
import dotenv from "dotenv";
import prisma from "../lib/prisma.js";
dotenv.config();

const SHOPIFY_STORE = process.env.SHOPIFY_STORE_URL;
const SHOPIFY_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD || "";
const WAIT_TIMEOUT = 30000;

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

async function handlePassword(page) {
  const pwSelector = 'input[type="password"], input[name="password"], #password';
  const pwExists = await page.$(pwSelector);
  if (pwExists) {
    console.log("🔒 Password form detected, submitting...");
    await page.type(pwSelector, SHOPIFY_PASSWORD, { delay: 30 });
    await page.keyboard.press("Enter");
    await page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {});
    console.log("✅ Storefront unlocked.");
  }
}

/** Scrape badge data (average rating + review count) */
async function scrapeStampedBadge(page) {
  try {
    // Wait until badge exists
    await page.waitForSelector(".stamped-product-reviews-badge", {
      timeout: 10000,
    });

    // Wait until Stamped.io JS injects data-rating and data-count
    await page.waitForFunction(
      () => {
        const el = document.querySelector(".stamped-product-reviews-badge");
        return (
          el &&
          el.getAttribute("data-rating") &&
          el.getAttribute("data-count")
        );
      },
      { timeout: 15000 }
    );

    // Extract attributes
    const badge = await page.$eval(".stamped-product-reviews-badge", (el) => ({
      averageRating: parseFloat(el.getAttribute("data-rating") || "0"),
      reviewCount: parseInt(el.getAttribute("data-count") || "0"),
      rawHTML: el.outerHTML,
    }));

    console.log("🔎 Badge HTML snippet:", badge.rawHTML);
    return badge;
  } catch (err) {
    console.log("⚠️ No Stamped.io badge found or attributes missing");
    return { averageRating: 0, reviewCount: 0 };
  }
}

/** Scrape all product handles from /collections/all */
async function getAllProductHandles(page) {
  if (!SHOPIFY_STORE) throw new Error("SHOPIFY_STORE_URL missing in .env");
  const base = SHOPIFY_STORE.startsWith("http")
    ? SHOPIFY_STORE
    : `https://${SHOPIFY_STORE}`;
  const url = `${base.replace(/\/$/, "")}/collections/all`;

  console.log("➡️ Navigating to collection:", url);
  await page.goto(url, { waitUntil: "networkidle2", timeout: WAIT_TIMEOUT });
  await handlePassword(page);

  return await page.$$eval("a[href*='/products/']", (links) =>
    [...new Set(links.map((a) => a.getAttribute("href")))]
      .filter((h) => h.includes("/products/"))
      .map((h) => h.split("/products/")[1].split(/[?#]/)[0])
  );
}

/** Main */
async function main() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  const handles = await getAllProductHandles(page);
  console.log("Found product handles:", handles);

  for (const handle of handles) {
    const base = SHOPIFY_STORE.startsWith("http")
      ? SHOPIFY_STORE
      : `https://${SHOPIFY_STORE}`;
    const productUrl = `${base.replace(/\/$/, "")}/products/${handle}`;

    console.log(`➡️ Scraping badge for ${productUrl}`);

    await page.goto(productUrl, {
      waitUntil: "networkidle2",
      timeout: WAIT_TIMEOUT,
    });
    await handlePassword(page);

    const badge = await scrapeStampedBadge(page);
    console.log(
      `📦 ${handle} — Rating: ${badge.averageRating}, Reviews: ${badge.reviewCount}`
    );

    // Upsert product and cache metadata
    const product = await prisma.product.upsert({
      where: { handle },
      update: { updatedAt: new Date() },
      create: { handle, title: handle },
    });

    await prisma.cacheMetadata.upsert({
      where: { productId: product.id },
      update: {
        reviewCount: badge.reviewCount,
        averageRating: badge.averageRating,
        lastChecked: new Date(),
      },
      create: {
        productId: product.id,
        reviewCount: badge.reviewCount,
        averageRating: badge.averageRating,
      },
    });
  }

  await browser.close();
  await prisma.$disconnect();
  console.log("🎉 Done scraping all products (badge data).");
}

main();
