// scripts/scrape-reviews-debug.js
import puppeteer from "puppeteer";
import dotenv from "dotenv";
dotenv.config();

const SHOPIFY_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD || "";
const SHOPIFY_STORE =
  process.env.SHOPIFY_STORE_URL || process.env.SHOPIFY_STORE;
const WAIT_TIMEOUT = 30000;

function toProductUrl(input) {
  if (!input) throw new Error("No product handle/url provided");
  if (input.startsWith("http")) return input;
  if (!SHOPIFY_STORE)
    throw new Error("Set SHOPIFY_STORE_URL in .env (or pass full URL)");
  const base = SHOPIFY_STORE.startsWith("http")
    ? SHOPIFY_STORE
    : `https://${SHOPIFY_STORE}`;
  return `${base.replace(/\/$/, "")}/products/${input}`;
}

async function handleShopifyPassword(page) {
  const pwSelector = 'input[type="password"], input[name="password"], #password';
  const pwExists = await page.$(pwSelector);
  if (pwExists) {
    if (!SHOPIFY_PASSWORD)
      throw new Error("Store is password protected but no password in .env");

    console.log("Password form detected — submitting...");
    await page.type(pwSelector, SHOPIFY_PASSWORD, { delay: 30 });

    const submitSel =
      'form[action*="/password"] button, form button[type=submit], button[type="submit"], button';
    const btn = await page.$(submitSel);
    if (btn) {
      await Promise.all([
        page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {}),
        btn.click(),
      ]);
    } else {
      await page.keyboard.press("Enter");
      await page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {});
    }
    console.log("✅ Password submitted.");
  }
}

async function debugStamped(page) {
  console.log("🔍 Looking for Stamped.io widget...");

  // wait for any element that has "stamped" in class
  await page.waitForSelector('[class*="stamped"]', { timeout: 10000 }).catch(() =>
    console.log("⚠️ No stamped class found quickly")
  );

  // dump all classes that contain 'stamped'
  const matches = await page.$$eval("[class*='stamped']", (nodes) =>
    nodes.map((n) => n.outerHTML.slice(0, 300)) // only first 300 chars
  );

  console.log("=== Found elements with 'stamped' in class ===");
  matches.slice(0, 10).forEach((m, i) => {
    console.log(`Element ${i + 1}:`, m);
  });
}

async function main() {
  const arg = process.argv[2];
  if (!arg) {
    console.error("Usage: node scripts/scrape-reviews-debug.js <handle-or-url>");
    process.exit(1);
  }
  const url = toProductUrl(arg);
  console.log("Product URL:", url);

  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  await page.goto(url, { waitUntil: "networkidle2", timeout: WAIT_TIMEOUT }).catch(() => {});
  await handleShopifyPassword(page);

  console.log("Reloading product page...");
  await page.goto(url, { waitUntil: "networkidle2", timeout: WAIT_TIMEOUT }).catch(() => {});

  await new Promise((r) => setTimeout(r, 3000));

  await debugStamped(page);

  await browser.close();
  process.exit(0);
}

main();
