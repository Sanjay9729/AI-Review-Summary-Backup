// scripts/debug-scrape.js
import puppeteer from 'puppeteer';
import dotenv from 'dotenv';
dotenv.config();

const SHOPIFY_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD || '';
const SHOPIFY_STORE = process.env.SHOPIFY_STORE_URL || process.env.SHOPIFY_STORE;
const WAIT_TIMEOUT = 30000;

function toProductUrl(input) {
  if (!input) throw new Error('No product handle/url provided');
  if (input.startsWith('http')) return input;
  if (!SHOPIFY_STORE) throw new Error('Set SHOPIFY_STORE_URL in .env');
  const base = SHOPIFY_STORE.startsWith('http') ? SHOPIFY_STORE : `https://${SHOPIFY_STORE}`;
  return `${base.replace(/\/$/, '')}/products/${input}`;
}

async function handlePassword(page) {
  const pwSelector = 'input[type="password"], input[name="password"], #password';
  const pwExists = await page.$(pwSelector);
  if (pwExists) {
    if (!SHOPIFY_PASSWORD) throw new Error('Password not set in .env');
    await page.type(pwSelector, SHOPIFY_PASSWORD, { delay: 30 });
    const submitSel =
      'form[action*="/password"] button, form button[type=submit], button[type="submit"], button';
    const btn = await page.$(submitSel);
    if (btn) {
      await Promise.all([
        page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {}),
        btn.click(),
      ]);
    } else {
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ timeout: WAIT_TIMEOUT }).catch(() => {});
    }
    console.log('✅ Password submitted. Store unlocked.');
  }
}

async function main() {
  const arg = process.argv[2];
  if (!arg) {
    console.error('Usage: node scripts/debug-scrape.js <handle-or-url>');
    process.exit(1);
  }
  const url = toProductUrl(arg);
  console.log('Product URL:', url);

  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  await page.goto(url, { waitUntil: 'networkidle2', timeout: WAIT_TIMEOUT }).catch(() => {});
  await handlePassword(page);

  console.log('Reloading product page after password...');
  await page.goto(url, { waitUntil: 'networkidle2', timeout: WAIT_TIMEOUT }).catch(() => {});

  await new Promise((r) => setTimeout(r, 2000));

  // Log all frame URLs
  const frames = page.frames();
  console.log('=== Frame URLs ===');
  frames.forEach((f) => {
    console.log('Frame:', f.url());
  });

  // Dump first 500 chars of page content
  const content = await page.content();
  console.log('=== First 500 chars of page HTML ===');
  console.log(content.slice(0, 500));

  if (/judge\.me|jdgm/i.test(content)) {
    console.log('Judge.me keywords present in HTML ✅');
  } else {
    console.log('No Judge.me keywords found in HTML ❌');
  }

  await browser.close();
  process.exit(0);
}

main();
