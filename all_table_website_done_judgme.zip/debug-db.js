import { PrismaClient } from '@prisma/client';
import 'dotenv/config';

const prisma = new PrismaClient();

async function debugDB() {
  try {
    console.log('=== DEBUGGING DATABASE ===\n');

    // Count all products
    const productCount = await prisma.product.count();
    console.log(`Total products: ${productCount}`);

    // Count all reviews
    const reviewCount = await prisma.review.count();
    console.log(`Total reviews: ${reviewCount}`);

    // Count all AI summaries
    const aiSummaryCount = await prisma.aISummary.count();
    console.log(`Total AI summaries: ${aiSummaryCount}`);

    // Get all product handles with reviews
    const productsWithReviews = await prisma.product.findMany({
      where: {
        reviews: {
          some: {}
        }
      },
      select: {
        handle: true,
        title: true,
        reviews: {
          select: { id: true }
        }
      }
    });

    console.log(`\nProducts with reviews: ${productsWithReviews.length}`);
    productsWithReviews.forEach(p => {
      console.log(`- ${p.handle}: ${p.reviews.length} reviews`);
    });

    // Check products with AI summaries
    const productsWithAISummaries = await prisma.product.findMany({
      include: {
        aiSummaries: {
          select: {
            id: true,
            summary: true,
            generatedAt: true
          }
        }
      },
      where: {
        aiSummaries: {
          some: {}
        }
      }
    });

    console.log(`\nProducts with AI summaries: ${productsWithAISummaries.length}`);
    productsWithAISummaries.forEach(p => {
      console.log(`- ${p.handle}: ${p.aiSummaries.length} summaries`);
      p.aiSummaries.forEach(s => {
        console.log(`  Summary: ${s.summary.substring(0, 50)}...`);
      });
    });

    // Check specific product
    const blueTee = await prisma.product.findUnique({
      where: { handle: 'blue-cotton-t-shirt' },
      include: {
        reviews: true,
        aiSummaries: true
      }
    });

    if (blueTee) {
      console.log(`\n=== BLUE COTTON T-SHIRT ===`);
      console.log(`Handle: ${blueTee.handle}`);
      console.log(`Reviews: ${blueTee.reviews.length}`);
      console.log(`AI Summaries: ${blueTee.aiSummaries.length}`);
      if (blueTee.aiSummaries.length > 0) {
        console.log(`Summary: ${blueTee.aiSummaries[0].summary}`);
      }
    }

  } catch (error) {
    console.error('Debug error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

debugDB();