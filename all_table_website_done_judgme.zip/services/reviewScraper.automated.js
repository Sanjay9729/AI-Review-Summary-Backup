// services/reviewScraper.automated.js - Automated Review Scraping with Prisma Storage
import puppeteer from 'puppeteer';
import cron from 'node-cron';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const prisma = new PrismaClient();

class AutomatedReviewScraper {
  constructor(options = {}) {
    this.options = {
      headless: true,
      timeout: 30000,
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      maxConcurrent: 2,
      delayBetweenRequests: 3000,
      scrapeIntervalMinutes: 60, // Run every hour
      ...options
    };

    this.activeRequests = new Map();
    this.isRunning = false;
    this.cronJob = null;

    console.log('🤖 Automated Review Scraper initialized');
  }

  /**
   * Start the automated scraping process
   */
  async start() {
    if (this.isRunning) {
      console.log('⚠️ Automated scraper is already running');
      return;
    }

    this.isRunning = true;
    console.log('🚀 Starting automated review scraping...');

    // Get all products to scrape
    const products = await this.getProductsToScrape();
    console.log(`📦 Found ${products.length} products to monitor`);

    if (products.length === 0) {
      console.log('⚠️ No products found. Automated scraper will check again later.');
    }

    // Start periodic scraping
    this.cronJob = cron.schedule(`*/${this.options.scrapeIntervalMinutes} * * * *`, async () => {
      console.log('⏰ Running scheduled review scraping...');
      await this.scrapeAllProducts();
    });

    // Run initial scrape
    await this.scrapeAllProducts();
  }

  /**
   * Stop the automated scraping process
   */
  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
      this.cronJob = null;
    }
    this.isRunning = false;
    console.log('🛑 Automated review scraper stopped');
  }

  /**
   * Get products that should be scraped
   */
  async getProductsToScrape() {
    try {
      return await prisma.product.findMany({
        where: {
          status: 'ACTIVE'
        },
        select: {
          id: true,
          handle: true,
          title: true,
          shopifyId: true
        }
      });
    } catch (error) {
      console.error('❌ Error fetching products:', error);
      return [];
    }
  }

  /**
   * Scrape all products for new reviews
   */
  async scrapeAllProducts() {
    const products = await this.getProductsToScrape();

    for (const product of products) {
      try {
        await this.scrapeAndStoreProductReviews(product.handle);
        // Delay between products
        await new Promise(resolve => setTimeout(resolve, this.options.delayBetweenRequests));
      } catch (error) {
        console.error(`❌ Error scraping product ${product.handle}:`, error);
      }
    }
  }

  /**
   * Scrape and store reviews for a specific product
   */
  async scrapeAndStoreProductReviews(productHandle) {
    const requestKey = `scrape-${productHandle}`;
    if (this.activeRequests.has(requestKey)) {
      console.log(`⏳ Scrape already in progress for ${productHandle}`);
      return await this.activeRequests.get(requestKey);
    }

    const requestPromise = this._performScrapingAndStorage(productHandle);
    this.activeRequests.set(requestKey, requestPromise);

    try {
      return await requestPromise;
    } finally {
      this.activeRequests.delete(requestKey);
    }
  }

  /**
   * Internal method to perform scraping and storage
   */
  async _performScrapingAndStorage(productHandle) {
    console.log(`🔍 Starting scrape for ${productHandle}`);

    let browser = null;
    let page = null;

    try {
      // Find product in database
      let product = await prisma.product.findFirst({
        where: {
          OR: [
            { handle: productHandle },
            { shopifyId: productHandle }
          ]
        }
      });

      if (!product) {
        console.log(`📦 Creating new product for ${productHandle}`);
        product = await prisma.product.create({
          data: {
            shopifyId: `scraped-${productHandle}`,
            handle: productHandle,
            title: `Scraped Product: ${productHandle}`,
            status: 'ACTIVE'
          }
        });
      }

      // Check if we need to scrape (based on cache metadata)
      const cacheMetadata = await prisma.cacheMetadata.findUnique({
        where: { productId: product.id }
      });

      const now = new Date();
      const shouldScrape = this.options.force || !cacheMetadata ||
        (now.getTime() - cacheMetadata.lastScraped.getTime()) > (this.options.scrapeIntervalMinutes * 60 * 1000);

      if (!shouldScrape) {
        console.log(`⏭️ Skipping ${productHandle} - recently scraped`);
        return { skipped: true, product: product.title };
      }

      // Launch browser
      browser = await puppeteer.launch({
        headless: this.options.headless,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ]
      });

      page = await browser.newPage();

      // Block unnecessary resources
      await page.setRequestInterception(true);
      page.on('request', (req) => {
        if (['image', 'stylesheet', 'font', 'media'].includes(req.resourceType())) {
          req.abort();
        } else {
          req.continue();
        }
      });

      await page.setUserAgent(this.options.userAgent);

      // Navigate to product page
      const shopUrl = process.env.SHOPIFY_STORE_URL || 'your-store.myshopify.com';
      const productUrl = `https://${shopUrl}/products/${productHandle}`;
      console.log(`🌐 Navigating to ${productUrl}`);

      await page.goto(productUrl, {
        waitUntil: 'domcontentloaded',
        timeout: this.options.timeout
      });

      // Handle password protection
      await this._handlePasswordProtection(page, shopUrl);

      // Wait for review widgets and additional content
      await this._waitForReviewWidgets(page);

      // Additional wait for AJAX-loaded content
      await new Promise(resolve => setTimeout(resolve, 5000));

      // Try to load more reviews if available (click load more buttons)
      await this._loadMoreReviews(page);

      // Extract reviews
      const extractResult = await this._extractReviews(page);
      const reviews = extractResult.reviews;

      console.log(`✅ Extracted ${reviews.length} reviews for ${productHandle}`);
      console.log(`   Debug - Judge.me elements: ${extractResult.debug.judgeMeElementsCount}, Yotpo: ${extractResult.debug.yotpoElementsCount}, Generic: ${extractResult.debug.genericElementsCount}`);

      // Store reviews and update metadata
      const result = await this._storeReviews(product.id, reviews, productHandle);

      // Update cache metadata
      await this._updateCacheMetadata(product.id, reviews.length);

      return {
        success: true,
        product: product.title,
        newReviews: result.newReviews,
        duplicates: result.duplicates,
        totalReviews: reviews.length
      };

    } catch (error) {
      console.error(`❌ Error scraping ${productHandle}:`, error.message);
      return { success: false, error: error.message };
    } finally {
      if (page) await page.close().catch(() => {});
      if (browser) await browser.close().catch(() => {});
    }
  }

  /**
   * Handle password-protected stores
   */
  async _handlePasswordProtection(page, shopUrl) {
    try {
      // Wait a moment for the page to load
      await new Promise(resolve => setTimeout(resolve, 1000));

      const needsPassword = await page.evaluate(() => {
        return window.location.pathname === '/password' ||
               window.location.pathname.includes('/password') ||
               document.querySelector('input[type="password"]') !== null ||
               document.querySelector('form[action*="password"]') !== null ||
               document.body.textContent.includes('Enter store password');
      });

      if (needsPassword) {
        console.log(`🔓 Handling password protection for ${shopUrl}`);
        const password = process.env.SHOPIFY_STORE_PASSWORD;

        if (!password) {
          throw new Error('SHOPIFY_STORE_PASSWORD not set for password-protected store');
        }

        // Try multiple password input selectors
        const passwordSelectors = [
          'input[type="password"]',
          'input[name="password"]',
          'input[id*="password"]',
          'input[class*="password"]',
          'input[placeholder*="password"]',
          'input[placeholder*="Password"]'
        ];

        let passwordInput = null;
        for (const selector of passwordSelectors) {
          passwordInput = await page.$(selector);
          if (passwordInput) break;
        }

        if (passwordInput) {
          await page.evaluate(el => el.value = '', passwordInput);
          await passwordInput.type(password, { delay: 100 });
          await page.keyboard.press('Enter');

          // Wait for navigation or content change
          try {
            await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 10000 });
          } catch (error) {
            // Navigation might not happen, wait for content change instead
            await new Promise(resolve => setTimeout(resolve, 2000));
          }

          // Verify password was accepted
          const stillNeedsPassword = await page.evaluate(() => {
            return window.location.pathname === '/password' ||
                   document.querySelector('input[type="password"]') !== null;
          });

          if (stillNeedsPassword) {
            throw new Error('Password was not accepted or incorrect');
          }

          console.log(`✅ Password protection bypassed for ${shopUrl}`);
        } else {
          throw new Error('Password input field not found');
        }
      }
    } catch (error) {
      console.error(`❌ Error handling password protection: ${error.message}`);
      throw error;
    }
  }

  /**
   * Wait for review widgets to load
   */
  async _waitForReviewWidgets(page) {
    // Enhanced selectors for Judge.me and other platforms
    const selectors = [
      '#judgeme_product_reviews',
      '.jdgm-review-widget',
      '.jdgm-widget',
      '.jdgm-reviews',
      '.jdgm-rev__wrapper',
      '.judgeme-review-widget',
      '.judgeme-widget',
      '[class*="jdgm"]',
      '[id*="jdgm"]',
      '[id*="judgeme"]',
      '.yotpo-reviews',
      '.yotpo-main-widget',
      '[data-yotpo-element-id]',
      '.stamped-reviews-widget',
      '.loox-reviews',
      '.rvw-widget'
    ];

    // First, try to wait for any review-related content to load
    try {
      await page.waitForFunction(() => {
        // Wait for page to have substantial content
        return document.body.textContent.length > 1000 ||
               document.querySelectorAll('[class*="review"], [id*="review"]').length > 0;
      }, { timeout: 10000 });
    } catch (error) {
      console.log('⚠️ Page content loading timeout');
    }

    // Try specific selectors
    for (const selector of selectors) {
      try {
        await page.waitForSelector(selector, { timeout: 3000 });
        console.log(`✅ Found widget: ${selector}`);
        return;
      } catch (error) {
        // Continue to next selector
      }
    }

    console.log(`⚠️ No review widgets found, proceeding with generic scraping`);
  }

  /**
   * Try to load more reviews by clicking "Load More" buttons
   */
  async _loadMoreReviews(page) {
    try {
      const loadMoreSelectors = [
        '.jdgm-load-more',
        '.judgeme-load-more',
        '.jdgm-pagination__load-more',
        '.jdgm-rev__load-more',
        '.yotpo-load-more',
        '.stamped-load-more',
        '[class*="load-more"]',
        '[class*="load_more"]',
        'button[class*="load"]',
        'a[class*="load"]'
      ];

      for (const selector of loadMoreSelectors) {
        try {
          const loadMoreButton = await page.$(selector);
          if (loadMoreButton) {
            const isVisible = await page.evaluate(el => {
              const style = window.getComputedStyle(el);
              return style.display !== 'none' && style.visibility !== 'hidden';
            }, loadMoreButton);

            if (isVisible) {
              console.log(`🔄 Clicking load more button: ${selector}`);
              await loadMoreButton.click();
              await new Promise(resolve => setTimeout(resolve, 2000)); // Wait for new reviews to load

              // Check if we can load even more
              const stillMore = await page.$(selector);
              if (stillMore) {
                const stillVisible = await page.evaluate(el => {
                  const style = window.getComputedStyle(el);
                  return style.display !== 'none' && style.visibility !== 'hidden';
                }, stillMore);

                if (!stillVisible) {
                  break; // No more reviews to load
                }
              }
            }
          }
        } catch (error) {
          // Continue to next selector
        }
      }
    } catch (error) {
      console.log('⚠️ Error loading more reviews:', error.message);
    }
  }

  /**
   * Extract reviews from the page
   */
  async _extractReviews(page) {
    return await page.evaluate(() => {
      const reviews = [];

      // Enhanced Judge.me selectors - multiple variations
      const judgeMeSelectors = [
        '.jdgm-rev',
        '.jdgm-review',
        '.jdgm-review-item',
        '.jdgm-rev__wrapper',
        '.judgeme-review',
        '.judgeme-review-item',
        '[class*="jdgm-rev"]',
        '[class*="judgeme-review"]'
      ];

      let judgeMeElements = [];
      for (const selector of judgeMeSelectors) {
        judgeMeElements = judgeMeElements.concat(Array.from(document.querySelectorAll(selector)));
      }

      // Remove duplicates by comparing element references
      judgeMeElements = [...new Set(judgeMeElements)];

      judgeMeElements.forEach((el, index) => {
        try {
          const review = {
            id: `judgeme-${Date.now()}-${index}`,
            author: el.querySelector('.jdgm-rev__author, .jdgm-author, .judgeme-author, .jdgm-rev__customer, [class*="author"]')?.textContent?.trim() || 'Anonymous',
            rating: parseFloat(
              el.querySelector('.jdgm-rev__rating, [data-score], .jdgm-stars, .judgeme-stars')?.getAttribute('data-score') ||
              el.querySelector('.jdgm-rev__rating, .jdgm-stars, .judgeme-stars')?.textContent?.match(/(\d+(?:\.\d+)?)/)?.[1] ||
              el.querySelectorAll('.jdgm-star, .judgeme-star, [class*="star"][class*="full"]').length ||
              5
            ),
            title: el.querySelector('.jdgm-rev__title, .judgeme-title, .jdgm-title')?.textContent?.trim() || '',
            text: el.querySelector('.jdgm-rev__body, .jdgm-rev__content, .judgeme-content, .jdgm-content, .jdgm-rev__text')?.textContent?.trim() || '',
            verified: !!el.querySelector('.jdgm-rev__verified, .jdgm-verified, .judgeme-verified'),
            platform: 'Judge.me',
            reviewDate: el.querySelector('.jdgm-rev__timestamp, .judgeme-date, .jdgm-date, .jdgm-rev__date')?.textContent?.trim() || '',
            scrapedAt: new Date().toISOString()
          };

          // More lenient criteria for including reviews
          if (review.text.length > 5 || review.author !== 'Anonymous' || review.rating !== 5) {
            reviews.push(review);
          }
        } catch (error) {
          console.log(`Error extracting Judge.me review ${index}:`, error);
        }
      });

      // Also try to find reviews in common container patterns
      const reviewContainers = document.querySelectorAll('#judgeme_product_reviews, .jdgm-widget, .judgeme-widget');
      reviewContainers.forEach(container => {
        const containerReviews = container.querySelectorAll('[class*="review"], [class*="rev"]');
        containerReviews.forEach((el, index) => {
          try {
            const reviewText = el.textContent?.trim() || '';
            if (reviewText.length > 20 && reviewText.length < 2000) {
              reviews.push({
                id: `judgeme-container-${Date.now()}-${index}`,
                author: 'Customer',
                rating: 5,
                title: reviewText.substring(0, 100),
                text: reviewText,
                verified: false,
                platform: 'Judge.me',
                reviewDate: '',
                scrapedAt: new Date().toISOString()
              });
            }
          } catch (error) {
            console.log(`Error extracting container review ${index}:`, error);
          }
        });
      });

      // Yotpo selectors
      const yotpoSelectors = '.yotpo-review, .yotpo-single-review';
      const yotpoElements = document.querySelectorAll(yotpoSelectors);

      yotpoElements.forEach((el, index) => {
        try {
          const review = {
            id: `yotpo-${Date.now()}-${index}`,
            author: el.querySelector('.yotpo-review-author, .yotpo-user-name')?.textContent?.trim() || 'Anonymous',
            rating: parseFloat(el.querySelector('.yotpo-review-stars, [data-yotpo-review-rating]')?.getAttribute('data-yotpo-review-rating') ||
                              el.querySelector('.yotpo-review-stars')?.querySelectorAll('.yotpo-icon-full-star').length) || 5,
            title: el.querySelector('.yotpo-review-title')?.textContent?.trim() || '',
            text: el.querySelector('.yotpo-review-content, .yotpo-review-text')?.textContent?.trim() || '',
            verified: !!el.querySelector('.yotpo-verified-buyer'),
            platform: 'Yotpo',
            reviewDate: el.querySelector('.yotpo-review-date')?.textContent?.trim() || '',
            scrapedAt: new Date().toISOString()
          };

          if (review.text.length > 10 || review.rating > 0) {
            reviews.push(review);
          }
        } catch (error) {
          console.log(`Error extracting Yotpo review ${index}:`, error);
        }
      });

      // Generic fallback
      const genericElements = document.querySelectorAll('[class*="review"], [id*="review"]');
      if (reviews.length === 0) {
        genericElements.forEach((el, index) => {
          const text = el.textContent?.trim() || '';
          if (text.length > 20 && text.length < 2000) {
            reviews.push({
              id: `generic-${Date.now()}-${index}`,
              author: 'Customer',
              rating: 5,
              title: text.substring(0, 100),
              text: text,
              verified: false,
              platform: 'Generic',
              reviewDate: '',
              scrapedAt: new Date().toISOString()
            });
          }
        });
      }

      return { reviews, debug: { judgeMeElementsCount: judgeMeElements.length, yotpoElementsCount: yotpoElements.length, genericElementsCount: genericElements.length } };
    });
  }

  /**
   * Store reviews in database
   */
  async _storeReviews(productId, reviews, productHandle) {
    let newReviews = 0;
    let duplicates = 0;

    for (const reviewData of reviews) {
      try {
        // Create content hash for duplicate detection
        const contentHash = crypto.createHash('md5')
          .update(`${reviewData.author}${reviewData.rating}${reviewData.text}${reviewData.reviewDate}`)
          .digest('hex');

        // Check for existing review
        const existingReview = await prisma.review.findFirst({
          where: {
            productId,
            contentHash,
            platform: reviewData.platform
          }
        });

        if (!existingReview) {
          await prisma.review.create({
            data: {
              productId,
              author: reviewData.author || 'Anonymous',
              rating: Math.max(1, Math.min(5, reviewData.rating || 5)),
              title: reviewData.title?.substring(0, 200) || null,
              text: reviewData.text?.substring(0, 2000) || '',
              verified: reviewData.verified || false,
              platform: reviewData.platform || 'Unknown',
              reviewDate: reviewData.reviewDate ? new Date(reviewData.reviewDate) : new Date(),
              contentHash,
              scrapedAt: new Date()
            }
          });

          newReviews++;
          console.log(`  ✅ Stored: ${reviewData.author} (${reviewData.rating}★)`);
        } else {
          duplicates++;
        }
      } catch (error) {
        console.error(`  ❌ Error storing review: ${error.message}`);
      }
    }

    console.log(`📊 Storage complete: ${newReviews} new, ${duplicates} duplicates for ${productHandle}`);
    return { newReviews, duplicates };
  }

  /**
   * Update cache metadata
   */
  async _updateCacheMetadata(productId, reviewCount) {
    try {
      const now = new Date();

      await prisma.cacheMetadata.upsert({
        where: { productId },
        update: {
          lastScraped: now,
          lastChecked: now,
          reviewCount: {
            increment: reviewCount
          },
          isStale: false
        },
        create: {
          productId,
          lastScraped: now,
          lastChecked: now,
          reviewCount,
          lastError: null,
          consecutiveErrors: 0,
          isStale: false
        }
      });
    } catch (error) {
      console.error('❌ Error updating cache metadata:', error);
    }
  }

  /**
   * Get scraping statistics
   */
  async getStats() {
    try {
      const totalProducts = await prisma.product.count({ where: { status: 'ACTIVE' } });
      const totalReviews = await prisma.review.count();

      const recentReviews = await prisma.review.findMany({
        where: {
          scrapedAt: {
            gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
          }
        },
        select: {
          platform: true,
          rating: true
        }
      });

      const platformStats = recentReviews.reduce((acc, review) => {
        acc[review.platform] = (acc[review.platform] || 0) + 1;
        return acc;
      }, {});

      const averageRating = recentReviews.length > 0
        ? recentReviews.reduce((sum, r) => sum + r.rating, 0) / recentReviews.length
        : 0;

      return {
        totalProducts,
        totalReviews,
        recentReviewsCount: recentReviews.length,
        averageRating: Math.round(averageRating * 10) / 10,
        platformStats,
        isRunning: this.isRunning
      };
    } catch (error) {
      console.error('❌ Error getting stats:', error);
      return null;
    }
  }

  /**
   * Clean up resources
   */
  async close() {
    this.stop();
    await prisma.$disconnect();
  }
}

export default AutomatedReviewScraper;