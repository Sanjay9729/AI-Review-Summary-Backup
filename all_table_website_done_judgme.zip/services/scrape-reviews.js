// scripts/scrape-reviews.js
import puppeteer from 'puppeteer';
import prisma from '../lib/prisma.js';
import dotenv from 'dotenv';
dotenv.config();

const STORE_URL = `https://${process.env.SHOPIFY_STORE}`;
const STORE_PASSWORD = process.env.SHOPIFY_STORE_PASSWORD;
const HEADLESS = process.env.PUPPETEER_HEADLESS !== 'false';

const PRODUCT_HANDLES = [
  'blue-cotton-t-shirt',
  'purple-cotton-t-shirt',
  // यहां बाकी products add कर लो
];

async function unlockStoreIfNeeded(page) {
  const isPasswordPage = await page.$('input[name="password"]');
  if (isPasswordPage && STORE_PASSWORD) {
    console.log('🔒 Password page detected — submitting password');
    await page.type('input[name="password"]', STORE_PASSWORD, { delay: 50 });
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle2' }),
      page.click('button[type="submit"], input[type="submit"]'),
    ]);
    console.log('✅ Unlocked storefront');
  }
}

async function extractReviewsFromPage(page) {
  return await page.evaluate(() => {
    const nodes = Array.from(document.querySelectorAll('.review, [data-review-id]'));
    return nodes.map((node) => {
      const externalId = node.getAttribute('data-review-id') || null;
      const author = node.querySelector('.author, .reviewer')?.textContent?.trim() || null;
      const ratingText = node.querySelector('.rating')?.textContent;
      const rating = ratingText ? parseInt(ratingText.replace(/[^\d]/g, ''), 10) : null;
      const body = node.querySelector('.review-body, .content')?.textContent?.trim() || null;
      return { externalId, author, rating, body };
    });
  });
}

async function scrape() {
  const browser = await puppeteer.launch({
    headless: HEADLESS,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();

  for (const handle of PRODUCT_HANDLES) {
    const url = `${STORE_URL}/products/${handle}`;
    console.log('➡️ Visiting', url);
    await page.goto(url, { waitUntil: 'networkidle2' });
    await unlockStoreIfNeeded(page);

    const reviews = await extractReviewsFromPage(page);
    console.log(`📝 Found ${reviews.length} reviews for ${handle}`);

    for (const r of reviews) {
      await prisma.review.create({
        data: {
          externalId: r.externalId || `${handle}-${Date.now()}`,
          store: STORE_URL,
          productHandle: handle,
          author: r.author,
          rating: r.rating,
          body: r.body,
        },
      });
    }
  }

  await browser.close();
  await prisma.$disconnect();
}

scrape().then(() => {
  console.log('✅ Done scraping');
  process.exit(0);
}).catch((err) => {
  console.error('❌ Scrape failed:', err);
  process.exit(1);
});
