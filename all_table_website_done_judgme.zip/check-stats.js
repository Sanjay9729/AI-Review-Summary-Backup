// Check database statistics
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkStats() {
  try {
    const [productCount, reviewCount, aiSummaryCount] = await Promise.all([
      prisma.product.count(),
      prisma.review.count(),
      prisma.aISummary.count()
    ]);

    console.log(`Products: ${productCount}`);
    console.log(`Reviews: ${reviewCount}`);
    console.log(`AI Summaries: ${aiSummaryCount}`);

    // Get sample AI summaries
    const aiSummaries = await prisma.aISummary.findMany({
      take: 5,
      select: {
        id: true,
        productId: true,
        handle: true,
        summary: true,
        reviewsAnalyzed: true,
        generatedAt: true
      }
    });

    console.log('\nSample AI summaries:');
    aiSummaries.forEach(summary => {
      console.log(`- ${summary.handle}: ${summary.summary.substring(0, 50)}...`);
    });

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkStats();