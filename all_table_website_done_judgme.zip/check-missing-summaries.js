import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkMissingSummaries() {
  try {
    console.log('Checking for products with reviews but missing AI summaries...\n');

    // Get all products that have reviews
    const productsWithReviews = await prisma.product.findMany({
      include: {
        reviews: {
          select: {
            id: true,
            text: true,
            rating: true,
            title: true,
            verified: true,
            platform: true
          }
        },
        aiSummaries: true
      },
      where: {
        reviews: {
          some: {} // Has at least one review
        }
      }
    });

    console.log(`Found ${productsWithReviews.length} products with reviews\n`);

    const withSummary = [];
    const withoutSummary = [];

    for (const product of productsWithReviews) {
      const reviewCount = product.reviews.length;
      const hasSummary = !!product.aiSummaries;

      // Analyze review quality
      const meaningfulReviews = product.reviews.filter(review =>
        review.text &&
        review.text.trim().length > 10 &&
        review.rating > 0 &&
        !review.text.toLowerCase().includes('no review') &&
        !review.text.toLowerCase().includes('no comment')
      );

      const qualityInfo = {
        handle: product.handle,
        totalReviews: reviewCount,
        meaningfulReviews: meaningfulReviews.length,
        hasSummary,
        summary: hasSummary ? product.aiSummaries.summary.substring(0, 50) + '...' : null
      };

      if (hasSummary) {
        withSummary.push(qualityInfo);
      } else {
        withoutSummary.push(qualityInfo);
      }
    }

    console.log('=== PRODUCTS WITH AI SUMMARIES ===');
    withSummary.forEach(p => {
      console.log(`✅ ${p.handle}: ${p.totalReviews} reviews (${p.meaningfulReviews} meaningful)`);
    });

    console.log('\n=== PRODUCTS WITHOUT AI SUMMARIES ===');
    withoutSummary.forEach(p => {
      console.log(`❌ ${p.handle}: ${p.totalReviews} reviews (${p.meaningfulReviews} meaningful)`);
      if (p.meaningfulReviews === 0) {
        console.log(`   Reason: No meaningful reviews (all reviews lack sufficient text content)`);
      }
    });

    console.log(`\nSummary: ${withSummary.length} products have summaries, ${withoutSummary.length} products missing summaries`);

    // Show details for products without summaries
    if (withoutSummary.length > 0) {
      console.log('\n=== DETAILED ANALYSIS FOR PRODUCTS WITHOUT SUMMARIES ===');
      for (const product of withoutSummary) {
        const fullProduct = productsWithReviews.find(p => p.handle === product.handle);
        console.log(`\n📊 ${product.handle}:`);
        console.log(`   Total reviews: ${product.totalReviews}`);
        console.log(`   Meaningful reviews: ${product.meaningfulReviews}`);

        if (product.meaningfulReviews > 0) {
          console.log(`   ❌ Should have summary but doesn't!`);
          console.log(`   Review details:`);
          fullProduct.reviews.forEach((review, i) => {
            console.log(`     ${i+1}. Rating: ${review.rating}, Text length: ${review.text?.length || 0}`);
            if (review.text) {
              console.log(`        "${review.text.substring(0, 50)}${review.text.length > 50 ? '...' : ''}"`);
            }
          });
        }
      }
    }

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkMissingSummaries();