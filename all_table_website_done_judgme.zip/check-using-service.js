import DatabaseService from './services/database.server.js';

async function checkUsingService() {
  try {
    console.log('Checking AI summaries using DatabaseService...\n');

    // Get products with reviews
    const products = await DatabaseService.getProductsNeedingRefresh();

    console.log(`Products needing refresh: ${products.length}`);

    // Check specific products
    const testHandles = ['pink', 'yellow-cotton-t-shirt', 'blue-cotton-t-shirt'];

    for (const handle of testHandles) {
      console.log(`\nChecking ${handle}:`);

      try {
        const summary = await DatabaseService.getAISummary(handle);
        if (summary && summary.success) {
          console.log(`  ✅ Has AI summary: ${summary.summary.substring(0, 50)}...`);
        } else {
          console.log(`  ❌ No AI summary found`);
        }

        const reviews = await DatabaseService.getReviews(handle);
        if (reviews.success) {
          console.log(`  📊 Has ${reviews.reviews.length} reviews`);

          const meaningful = reviews.reviews.filter(r =>
            r.text && r.text.length > 10 && r.rating > 0
          );
          console.log(`  📝 ${meaningful.length} meaningful reviews`);
        } else {
          console.log(`  ❌ No reviews found`);
        }
      } catch (error) {
        console.log(`  ❌ Error: ${error.message}`);
      }
    }

  } catch (error) {
    console.error('Service error:', error);
  }
}

checkUsingService();