// Diagnostic script to inspect a product page for Judge.me reviews
import puppeteer from 'puppeteer';

async function diagnosePage(productHandle = 'classic-cotton-t-shirt-2') {
  const browser = await puppeteer.launch({
    headless: false, // Set to false to see the browser
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

  const shopUrl = process.env.SHOPIFY_STORE_URL || 'your-store.myshopify.com';
  const productUrl = `https://${shopUrl}/products/${productHandle}`;

  console.log(`🌐 Navigating to: ${productUrl}`);

  try {
    await page.goto(productUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 30000
    });

    // Handle password protection
    const password = process.env.SHOPIFY_STORE_PASSWORD;
    if (password) {
      const passwordInput = await page.$('input[type="password"]');
      if (passwordInput) {
        console.log('🔓 Entering password...');
        await passwordInput.type(password);
        await page.keyboard.press('Enter');
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    // Wait for content to load
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Check for Judge.me elements
    const judgeMeInfo = await page.evaluate(() => {
      const info = {
        hasJudgeMe: false,
        judgeMeElements: [],
        allReviewElements: [],
        pageTitle: document.title,
        bodyText: document.body.innerText.substring(0, 500)
      };

      // Check for Judge.me specific elements
      const judgeMeSelectors = [
        '#judgeme_product_reviews',
        '.jdgm-review-widget',
        '.jdgm-widget',
        '.jdgm-reviews',
        '.jdgm-rev__wrapper',
        '.judgeme-review-widget',
        '.judgeme-widget',
        '[class*="jdgm"]',
        '[id*="jdgm"]',
        '[id*="judgeme"]'
      ];

      judgeMeSelectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          info.hasJudgeMe = true;
          info.judgeMeElements.push({
            selector,
            count: elements.length,
            content: Array.from(elements).map(el => ({
              tagName: el.tagName,
              className: el.className,
              id: el.id,
              textContent: el.textContent?.substring(0, 200)
            }))
          });
        }
      });

      // Check for any review-related elements
      const reviewSelectors = [
        '[class*="review"]',
        '[id*="review"]',
        '[class*="rating"]',
        '[class*="star"]',
        '.yotpo',
        '.stamped'
      ];

      reviewSelectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          info.allReviewElements.push({
            selector,
            count: elements.length,
            content: Array.from(elements).map(el => ({
              tagName: el.tagName,
              className: el.className,
              id: el.id,
              textContent: el.textContent?.substring(0, 100)
            }))
          });
        }
      });

      return info;
    });

    console.log('📋 Page Analysis:');
    console.log(`Title: ${judgeMeInfo.pageTitle}`);
    console.log(`Body preview: ${judgeMeInfo.bodyText}...`);

    if (judgeMeInfo.hasJudgeMe) {
      console.log('\n✅ Judge.me elements found:');
      judgeMeInfo.judgeMeElements.forEach(item => {
        console.log(`  - ${item.selector}: ${item.count} elements`);
        item.content.forEach((el, idx) => {
          console.log(`    [${idx}] ${el.tagName}.${el.className}#${el.id}`);
          console.log(`        "${el.textContent}"`);
        });
      });
    } else {
      console.log('\n❌ No Judge.me elements found');
    }

    if (judgeMeInfo.allReviewElements.length > 0) {
      console.log('\n🔍 Other review-related elements:');
      judgeMeInfo.allReviewElements.forEach(item => {
        console.log(`  - ${item.selector}: ${item.count} elements`);
      });
    }

    // Check for iframes (Judge.me sometimes loads in iframes)
    const iframeInfo = await page.evaluate(() => {
      const iframes = document.querySelectorAll('iframe');
      return Array.from(iframes).map(iframe => ({
        src: iframe.src,
        className: iframe.className,
        id: iframe.id
      }));
    });

    if (iframeInfo.length > 0) {
      console.log('\n📺 Iframes found:');
      iframeInfo.forEach((iframe, idx) => {
        console.log(`  [${idx}] ${iframe.src} (${iframe.className}#${iframe.id})`);
      });
    }

  } catch (error) {
    console.error('❌ Error diagnosing page:', error);
  }

  console.log('\n🔍 Close browser manually when done inspecting');
  // Don't close browser automatically so user can inspect
  // await browser.close();
}

diagnosePage();