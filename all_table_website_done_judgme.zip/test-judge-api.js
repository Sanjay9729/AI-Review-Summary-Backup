// Test Judge.me API
import fetch from 'node-fetch';

const shopDomain = 'sanjayvaghela-testing.myshopify.com';
const productHandle = 'purple-cotton-t-shirt'; // One with reviewsAnalyzed: 3

const url = `https://sanjayvaghela-testing.judge.me/api/v1/reviews?shop_domain=${shopDomain}&handle=${productHandle}&per_page=100&page=1`;

console.log('Fetching:', url);

fetch(url, {
  headers: {
    'Content-Type': 'application/json',
    'User-Agent': 'Shopify-Review-App/1.0'
  }
})
.then(res => {
  console.log('Status:', res.status);
  return res.json();
})
.then(data => {
  console.log('Reviews found:', data.reviews ? data.reviews.length : 0);
  if (data.reviews && data.reviews.length > 0) {
    console.log('Sample:', data.reviews[0]);
  }
})
.catch(err => console.error('Error:', err));