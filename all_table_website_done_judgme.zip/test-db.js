// Quick test to check database connection and review count
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function testDb() {
  try {
    console.log('Testing database connection...');

    // Test connection
    await prisma.$queryRaw`SELECT 1`;

    // Count reviews
    const reviewCount = await prisma.review.count();
    console.log(`✅ Database connected. Total reviews: ${reviewCount}`);

    // Count products
    const productCount = await prisma.product.count();
    console.log(`📦 Total products: ${productCount}`);

    // Show recent reviews
    const recentReviews = await prisma.review.findMany({
      take: 3,
      orderBy: { scrapedAt: 'desc' },
      select: {
        author: true,
        rating: true,
        platform: true,
        product: {
          select: { title: true }
        }
      }
    });

    if (recentReviews.length > 0) {
      console.log('\n📝 Recent reviews:');
      recentReviews.forEach(review => {
        console.log(`  - ${review.author}: ${review.rating}★ (${review.platform}) on ${review.product.title}`);
      });
    }

  } catch (error) {
    console.error('❌ Database error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

testDb();