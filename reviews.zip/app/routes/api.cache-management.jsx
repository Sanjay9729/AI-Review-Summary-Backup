// app/routes/api.cache-management.jsx
import { json } from "@remix-run/node";
import ReviewCache from "../../services/reviewCache.server";
import backgroundJobs from "../../services/backgroundJobs.server";

export const action = async ({ request }) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    const { action, productHandle, options = {} } = await request.json();

    switch (action) {
      case 'clear':
        if (productHandle) {
          await ReviewCache.clear(productHandle);
          return json({
            success: true,
            message: `Cache cleared for ${productHandle}`
          }, { headers });
        } else {
          await ReviewCache.clearAll();
          return json({
            success: true,
            message: 'All cache cleared'
          }, { headers });
        }

      case 'force-refresh':
        if (!productHandle) {
          return json({
            success: false,
            error: 'Product handle required for force refresh'
          }, { status: 400, headers });
        }

        console.log(`Force refreshing ${productHandle}...`);
        const refreshResult = await ReviewCache.forceRefresh(productHandle);
        
        return json({
          success: refreshResult.success,
          message: refreshResult.success ? 
            `Successfully refreshed ${productHandle}` : 
            `Failed to refresh ${productHandle}`,
          data: refreshResult.data,
          error: refreshResult.error
        }, { headers });

      case 'check-freshness':
        if (!productHandle) {
          return json({
            success: false,
            error: 'Product handle required for freshness check'
          }, { status: 400, headers });
        }

        const cachedData = await ReviewCache.get(productHandle);
        if (!cachedData) {
          return json({
            success: true,
            fresh: false,
            message: 'No cached data found'
          }, { headers });
        }

        const isFresh = await ReviewCache.validateCacheFreshness(productHandle, cachedData);
        return json({
          success: true,
          fresh: isFresh,
          message: isFresh ? 'Cache is fresh' : 'Cache is stale',
          cachedAt: cachedData.cachedAt,
          reviewCount: cachedData.reviews?.length || 0
        }, { headers });

      case 'batch-refresh':
        const { productHandles = [] } = options;
        if (!Array.isArray(productHandles) || productHandles.length === 0) {
          return json({
            success: false,
            error: 'Product handles array required for batch refresh'
          }, { status: 400, headers });
        }

        console.log(`Batch refreshing ${productHandles.length} products...`);
        const batchResults = [];

        for (const handle of productHandles) {
          try {
            const result = await ReviewCache.forceRefresh(handle);
            batchResults.push({
              productHandle: handle,
              success: result.success,
              error: result.error
            });
          } catch (error) {
            batchResults.push({
              productHandle: handle,
              success: false,
              error: error.message
            });
          }
        }

        const successCount = batchResults.filter(r => r.success).length;
        return json({
          success: true,
          message: `Batch refresh completed: ${successCount}/${productHandles.length} successful`,
          results: batchResults
        }, { headers });

      case 'background-job-status':
        const jobStatus = backgroundJobs.getStatus();
        return json({
          success: true,
          status: jobStatus
        }, { headers });

      case 'start-background-jobs':
        backgroundJobs.start();
        return json({
          success: true,
          message: 'Background jobs started'
        }, { headers });

      case 'stop-background-jobs':
        backgroundJobs.stop();
        return json({
          success: true,
          message: 'Background jobs stopped'
        }, { headers });

      case 'run-background-check':
        console.log('Manually triggering background review check...');
        await ReviewCache.checkAllProductsForUpdates();
        return json({
          success: true,
          message: 'Background review check completed'
        }, { headers });

      default:
        return json({
          success: false,
          error: 'Invalid action'
        }, { status: 400, headers });
    }
  } catch (error) {
    console.error('Cache management API error:', error);
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  }
};

export const loader = async ({ request }) => {
  const url = new URL(request.url);
  const action = url.searchParams.get('action');
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    switch (action) {
      case 'stats':
        const stats = await ReviewCache.getCacheStats();
        return json({
          success: true,
          stats
        }, { headers });

      case 'background-status':
        const jobStatus = backgroundJobs.getStatus();
        return json({
          success: true,
          backgroundJobs: jobStatus
        }, { headers });

      default:
        return json({
          success: false,
          error: 'Invalid action for GET request'
        }, { status: 400, headers });
    }
  } catch (error) {
    return json({
      success: false,
      error: error.message
    }, { status: 500, headers });
  }
};

export const options = () => {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
};