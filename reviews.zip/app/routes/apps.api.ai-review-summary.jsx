// This makes your AI API accessible via app proxy
// routes/apps.api.ai-review-summary.jsx 
export { action } from './api.ai-review-summary';