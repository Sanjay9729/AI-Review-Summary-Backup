// // Updated Utils File: utils/productHelpers.js

// /**
//  * Format raw product data for display
//  * @param {Array} products - Raw products from Shopify GraphQL
//  * @returns {Array} Formatted products
//  */
// export const formatProductsData = (products) => {
//   return products.map((productEdge, index) => {
//     const product = productEdge.node;
//     return {
//       id: product.id,
//       serialNumber: index + 1,
//       title: product.title,
//       handle: product.handle,
//       status: product.status,
//       createdAt: new Date(product.createdAt).toLocaleDateString('en-IN'),
//       updatedAt: new Date(product.updatedAt).toLocaleDateString('en-IN'),
//       shopifyAdminUrl: `shopify:admin/products/${product.id.replace("gid://shopify/Product/", "")}`,
//       storeUrl: `${process.env.SHOPIFY_STORE_URL}/products/${product.handle}`,
//       reviewsApiUrl: `/api/reviews/${product.handle}`, // New: API endpoint for reviews
//     };
//   });
// };

// /**
//  * Calculate product statistics
//  * @param {Array} products - Raw products from Shopify GraphQL
//  * @returns {Object} Statistics object
//  */
// export const calculateProductStats = (products) => {
//   const totalProducts = products.length;
//   const activeProducts = products.filter(p => p.node.status === 'ACTIVE').length;
//   const draftProducts = products.filter(p => p.node.status === 'DRAFT').length;
//   const archivedProducts = products.filter(p => p.node.status === 'ARCHIVED').length;

//   return {
//     total: totalProducts,
//     active: activeProducts,
//     draft: draftProducts,
//     archived: archivedProducts,
//     percentage: {
//       active: totalProducts > 0 ? Math.round((activeProducts / totalProducts) * 100) : 0,
//       draft: totalProducts > 0 ? Math.round((draftProducts / totalProducts) * 100) : 0,
//       archived: totalProducts > 0 ? Math.round((archivedProducts / totalProducts) * 100) : 0,
//     }
//   };
// };

// /**
//  * Calculate review statistics for products
//  * @param {Array} productsWithReviews - Products with review data
//  * @returns {Object} Review statistics
//  */
// export const calculateReviewStats = (productsWithReviews) => {
//   const productsWithReviewData = productsWithReviews.filter(p => p.reviewsData?.success);
//   const totalReviews = productsWithReviewData.reduce((acc, p) => acc + (p.reviewsData?.stats?.total || 0), 0);
//   const totalRatedProducts = productsWithReviewData.filter(p => (p.reviewsData?.stats?.total || 0) > 0).length;
  
//   let averageRating = 0;
//   if (productsWithReviewData.length > 0) {
//     const ratingsSum = productsWithReviewData.reduce((acc, p) => {
//       const productAvg = p.reviewsData?.stats?.average || 0;
//       const reviewCount = p.reviewsData?.stats?.total || 0;
//       return acc + (productAvg * reviewCount);
//     }, 0);
//     averageRating = totalReviews > 0 ? ratingsSum / totalReviews : 0;
//   }

//   return {
//     totalProducts: productsWithReviews.length,
//     productsWithReviews: totalRatedProducts,
//     totalReviews,
//     averageRating: Math.round(averageRating * 10) / 10,
//     reviewCoverage: productsWithReviews.length > 0 ? Math.round((totalRatedProducts / productsWithReviews.length) * 100) : 0
//   };
// };

// /**
//  * Filter products by review criteria
//  * @param {Array} products - Products with review data
//  * @param {Object} criteria - Filter criteria
//  * @returns {Array} Filtered products
//  */
// export const filterProductsByReviews = (products, criteria = {}) => {
//   const {
//     minRating = 0,
//     maxRating = 5,
//     hasReviews = null, // null = all, true = only with reviews, false = only without reviews
//     verified = null, // null = all, true = only verified, false = only unverified
//     minReviewCount = 0
//   } = criteria;

//   return products.filter(product => {
//     const reviewStats = product.reviewsData?.stats;
    
//     if (!reviewStats && hasReviews === true) return false;
//     if (reviewStats && hasReviews === false) return false;
    
//     if (reviewStats) {
//       if (reviewStats.average < minRating || reviewStats.average > maxRating) return false;
//       if (reviewStats.total < minReviewCount) return false;
//       if (verified === true && reviewStats.verified === 0) return false;
//       if (verified === false && reviewStats.verified > 0) return false;
//     }
    
//     return true;
//   });
// };

// /**
//  * Filter products by status
//  * @param {Array} products - Formatted products array
//  * @param {String} status - Status to filter by ('ACTIVE', 'DRAFT', 'ARCHIVED')
//  * @returns {Array} Filtered products
//  */
// export const filterProductsByStatus = (products, status) => {
//   if (!status || status === 'ALL') {
//     return products;
//   }
//   return products.filter(product => product.status === status);
// };

// /**
//  * Search products by title or handle
//  * @param {Array} products - Formatted products array
//  * @param {String} searchTerm - Search term
//  * @returns {Array} Filtered products
//  */
// export const searchProducts = (products, searchTerm) => {
//   if (!searchTerm || searchTerm.trim() === '') {
//     return products;
//   }
  
//   const term = searchTerm.toLowerCase().trim();
//   return products.filter(product => 
//     product.title.toLowerCase().includes(term) ||
//     product.handle.toLowerCase().includes(term)
//   );
// };

// /**
//  * Sort products by different criteria
//  * @param {Array} products - Products to sort
//  * @param {String} sortBy - Sort criteria ('title', 'createdAt', 'updatedAt', 'status', 'rating', 'reviewCount')
//  * @param {String} sortOrder - Sort order ('asc', 'desc')
//  * @returns {Array} Sorted products
//  */
// export const sortProducts = (products, sortBy = 'createdAt', sortOrder = 'desc') => {
//   return [...products].sort((a, b) => {
//     let aValue = a[sortBy];
//     let bValue = b[sortBy];
    
//     // Handle review-specific sorting
//     if (sortBy === 'rating') {
//       aValue = a.reviewsData?.stats?.average || 0;
//       bValue = b.reviewsData?.stats?.average || 0;
//     } else if (sortBy === 'reviewCount') {
//       aValue = a.reviewsData?.stats?.total || 0;
//       bValue = b.reviewsData?.stats?.total || 0;
//     }
//     // Handle date sorting
//     else if (sortBy === 'createdAt' || sortBy === 'updatedAt') {
//       aValue = new Date(aValue).getTime();
//       bValue = new Date(bValue).getTime();
//     }
//     // Handle string sorting
//     else if (typeof aValue === 'string' && typeof bValue === 'string') {
//       aValue = aValue.toLowerCase();
//       bValue = bValue.toLowerCase();
//     }
    
//     if (sortOrder === 'asc') {
//       return aValue > bValue ? 1 : aValue < bValue ? -1 : 0;
//     } else {
//       return aValue < bValue ? 1 : aValue > bValue ? -1 : 0;
//     }
//   });
// };

// /**
//  * Get badge tone based on product status
//  * @param {String} status - Product status
//  * @returns {String} Badge tone for Polaris
//  */
// export const getStatusBadgeTone = (status) => {
//   switch (status) {
//     case 'ACTIVE':
//       return 'success';
//     case 'DRAFT':
//       return 'attention';
//     case 'ARCHIVED':
//       return 'critical';
//     default:
//       return 'info';
//   }
// };

// /**
//  * Get badge tone based on review rating
//  * @param {Number} rating - Average rating (0-5)
//  * @returns {String} Badge tone for Polaris
//  */
// export const getRatingBadgeTone = (rating) => {
//   if (rating >= 4.5) return 'success';
//   if (rating >= 4) return 'info';
//   if (rating >= 3) return 'attention';
//   if (rating >= 2) return 'warning';
//   return 'critical';
// };

// /**
//  * Format rating display
//  * @param {Number} rating - Rating value
//  * @param {Number} precision - Decimal places (default: 1)
//  * @returns {String} Formatted rating
//  */
// export const formatRating = (rating, precision = 1) => {
//   if (!rating || rating === 0) return 'No rating';
//   return `${rating.toFixed(precision)}⭐`;
// };

// /**
//  * Format review count display
//  * @param {Number} count - Number of reviews
//  * @returns {String} Formatted review count
//  */
// export const formatReviewCount = (count) => {
//   if (!count || count === 0) return 'No reviews';
//   if (count === 1) return '1 review';
//   if (count < 1000) return `${count} reviews`;
//   return `${(count / 1000).toFixed(1)}k reviews`;
// };

// /**
//  * Generate star rating HTML/components
//  * @param {Number} rating - Rating (0-5)
//  * @param {Object} options - Options for rendering
//  * @returns {Array} Array of star elements
//  */
// export const generateStarRating = (rating, options = {}) => {
//   const { showEmpty = true, maxStars = 5 } = options;
//   const stars = [];
//   const fullStars = Math.floor(rating);
//   const hasHalfStar = rating % 1 >= 0.5;
  
//   for (let i = 0; i < maxStars; i++) {
//     let starType = 'empty';
//     if (i < fullStars) {
//       starType = 'full';
//     } else if (i === fullStars && hasHalfStar) {
//       starType = 'half';
//     }
    
//     if (showEmpty || starType !== 'empty') {
//       stars.push({
//         index: i,
//         type: starType,
//         filled: starType === 'full' || starType === 'half'
//       });
//     }
//   }
  
//   return stars;
// };

// /**
//  * Format date in Indian locale
//  * @param {String} dateString - ISO date string
//  * @returns {String} Formatted date
//  */
// export const formatDate = (dateString) => {
//   return new Date(dateString).toLocaleDateString('en-IN', {
//     year: 'numeric',
//     month: 'short',
//     day: 'numeric',
//   });
// };

// /**
//  * Format date with time
//  * @param {String} dateString - ISO date string
//  * @returns {String} Formatted date with time
//  */
// export const formatDateTime = (dateString) => {
//   return new Date(dateString).toLocaleString('en-IN', {
//     year: 'numeric',
//     month: 'short',
//     day: 'numeric',
//     hour: '2-digit',
//     minute: '2-digit',
//   });
// };

// /**
//  * Get Shopify admin product URL
//  * @param {String} productId - Product ID from GraphQL
//  * @returns {String} Shopify admin URL
//  */
// export const getShopifyAdminUrl = (productId) => {
//   const cleanId = productId.replace("gid://shopify/Product/", "");
//   return `shopify:admin/products/${cleanId}`;
// };

// /**
//  * Get store product URL
//  * @param {String} productHandle - Product handle
//  * @returns {String} Store product URL
//  */
// export const getStoreProductUrl = (productHandle) => {
//   return `${process.env.SHOPIFY_STORE_URL}/products/${productHandle}`;
// };

// /**
//  * Validate product data
//  * @param {Array} products - Products array to validate
//  * @returns {Object} Validation result
//  */
// export const validateProductsData = (products) => {
//   if (!Array.isArray(products)) {
//     return {
//       isValid: false,
//       error: 'Products data must be an array',
//       products: []
//     };
//   }
  
//   const validProducts = products.filter(product => 
//     product && 
//     product.node && 
//     product.node.id && 
//     product.node.title
//   );
  
//   return {
//     isValid: true,
//     products: validProducts,
//     invalidCount: products.length - validProducts.length
//   };
// };

// /**
//  * Validate review data
//  * @param {Object} reviewData - Review data to validate
//  * @returns {Object} Validation result
//  */
// export const validateReviewData = (reviewData) => {
//   if (!reviewData || typeof reviewData !== 'object') {
//     return {
//       isValid: false,
//       error: 'Review data must be an object'
//     };
//   }
  
//   const { reviews = [], stats = {} } = reviewData;
  
//   if (!Array.isArray(reviews)) {
//     return {
//       isValid: false,
//       error: 'Reviews must be an array'
//     };
//   }
  
//   const validReviews = reviews.filter(review => 
//     review && 
//     (review.author || review.text || review.rating > 0)
//   );
  
//   return {
//     isValid: true,
//     reviews: validReviews,
//     stats: {
//       total: validReviews.length,
//       average: stats.average || 0,
//       verified: stats.verified || 0,
//       ...stats
//     },
//     invalidCount: reviews.length - validReviews.length
//   };
// };

// /**
//  * Merge product data with review data
//  * @param {Array} products - Formatted products
//  * @param {Object} reviewsMap - Map of product handle to review data
//  * @returns {Array} Products with review data merged
//  */
// export const mergeProductsWithReviews = (products, reviewsMap = {}) => {
//   return products.map(product => ({
//     ...product,
//     reviewsData: reviewsMap[product.handle] || {
//       reviews: [],
//       stats: { total: 0, average: 0, verified: 0 },
//       success: false,
//       loading: false
//     }
//   }));
// };

// /**
//  * Cache management for review data
//  */
// export class ReviewCache {
//   constructor(ttl = 300000) { // 5 minutes default TTL
//     this.cache = new Map();
//     this.ttl = ttl;
//   }
  
//   set(key, value) {
//     this.cache.set(key, {
//       value,
//       timestamp: Date.now()
//     });
//   }
  
//   get(key) {
//     const item = this.cache.get(key);
//     if (!item) return null;
    
//     if (Date.now() - item.timestamp > this.ttl) {
//       this.cache.delete(key);
//       return null;
//     }
    
//     return item.value;
//   }
  
//   clear() {
//     this.cache.clear();
//   }
  
//   size() {
//     return this.cache.size;
//   }
// }

// // Default export
// export default {
//   formatProductsData,
//   calculateProductStats,
//   calculateReviewStats,
//   filterProductsByReviews,
//   filterProductsByStatus,
//   searchProducts,
//   sortProducts,
//   getStatusBadgeTone,
//   getRatingBadgeTone,
//   formatRating,
//   formatReviewCount,
//   generateStarRating,
//   formatDate,
//   formatDateTime,
//   getShopifyAdminUrl,
//   getStoreProductUrl,
//   validateProductsData,
//   validateReviewData,
//   mergeProductsWithReviews,
//   ReviewCache
// };